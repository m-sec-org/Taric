import { homedir, tmpdir } from "node:os";
import { dirname, join, resolve } from "node:path";
import { mkdirSync } from "node:fs";
import { uuidv7 } from "./identity.js";
import {
  authorityStartupDiagnostics,
  resolveAuthorityConfiguration,
  type AuthorityStartupDiagnostics,
  type ResolvedAuthorityConfiguration,
  type SharedAuthorityConfiguration,
} from "./shared-authority-config.js";
import type { DeploymentGuardInput } from "./deployment-guard.js";
import type { PrincipalRole, PrincipalCapability } from "./service.js";

export interface RuntimeStartupConfig {
  db_path?: string;
  content_root?: string;
  principal_id?: string;
  principal_role?: Extract<PrincipalRole, "operator" | "model" | "host">;
  engagement_id?: string;
  content_read_enabled?: boolean;
  authority?: SharedAuthorityConfiguration;
  deployment?: DeploymentGuardInput;
}

export interface RuntimeStartupOptions {
  config?: RuntimeStartupConfig;
  env?: NodeJS.ProcessEnv;
  home?: string;
  /** A test-only home lets callers avoid touching the real user directory. */
  test?: boolean;
}

export interface RuntimePrincipalContext {
  id: string;
  role: Extract<PrincipalRole, "operator" | "model" | "host">;
  engagement_id?: string;
  capabilities: readonly PrincipalCapability[];
}

export interface RuntimeStartupResolution {
  authority: ResolvedAuthorityConfiguration;
  dbPath: string;
  contentRoot: string;
  principal: RuntimePrincipalContext;
  diagnostics: AuthorityStartupDiagnostics;
  explicitMemory: boolean;
}

export type RuntimeStartupErrorCode = "postgresql_unavailable" | "unsupported_deployment" | "configuration_invalid";

/** Public startup failure. The diagnostic is safe to expose on stderr. */
export class RuntimeStartupError extends Error {
  readonly code: RuntimeStartupErrorCode;
  readonly diagnostics: AuthorityStartupDiagnostics;

  constructor(diagnostics: AuthorityStartupDiagnostics) {
    super(diagnostics.message);
    this.name = "RuntimeStartupError";
    this.code = diagnostics.code as RuntimeStartupErrorCode;
    this.diagnostics = diagnostics;
  }
}

function envAuthority(env: NodeJS.ProcessEnv): SharedAuthorityConfiguration | undefined {
  if (!env.TARIC_AUTHORITY_PROFILE) return undefined;
  return {
    profile: env.TARIC_AUTHORITY_PROFILE,
    ...(env.TARIC_DATABASE_URL ? { postgresql: { connection_string: env.TARIC_DATABASE_URL } } : {}),
    ...(env.TARIC_HOST_ID ? { host_id: env.TARIC_HOST_ID } : {}),
    ...(env.TARIC_LEASE_MODE ? { lease_mode: env.TARIC_LEASE_MODE } : {}),
  } as unknown as SharedAuthorityConfiguration;
}

/** Resolve all process-facing authority decisions before constructing a store. */
export function resolveRuntimeAuthority(options: RuntimeStartupOptions = {}): RuntimeStartupResolution {
  const env = options.env ?? process.env;
  const config = options.config ?? {};
  const home = options.home ?? homedir();
  const authorityInput = config.authority ?? envAuthority(env);
  const authority = resolveAuthorityConfiguration(authorityInput);
  // `resolveAuthorityConfiguration` keeps its library/test default as
  // `:memory:`. Runtime entrypoints only honor memory when it was explicitly
  // requested in TARIC_DB or authority.sqlite.path.
  const configuredSqlitePath = authorityInput && authority.backend === "sqlite" && "sqlite" in authorityInput && authorityInput.sqlite?.path
    ? authorityInput.sqlite.path
    : undefined;
  const dbPath = env.TARIC_DB ?? config.db_path ?? configuredSqlitePath ?? join(home, ".taric", "authority.sqlite");
  const explicitMemory = dbPath === ":memory:";
  const contentRoot = env.TARIC_CONTENT_ROOT ?? config.content_root ?? (explicitMemory
    ? join(tmpdir(), "taric-content", uuidv7())
    : join(dirname(resolve(dbPath)), "content"));
  const role = (env.TARIC_PRINCIPAL_ROLE ?? config.principal_role ?? "operator") as RuntimePrincipalContext["role"];
  const engagement = env.TARIC_ENGAGEMENT_ID ?? config.engagement_id;
  const principal: RuntimePrincipalContext = {
    id: env.TARIC_PRINCIPAL_ID ?? config.principal_id ?? (role === "model" ? "mcp-model" : "operator-local"),
    role,
    ...(engagement ? { engagement_id: engagement } : {}),
    capabilities: env.TARIC_CONTENT_READ_ENABLED === "true" || config.content_read_enabled === true ? ["content_read"] : [],
  };
  const diagnostics = authorityStartupDiagnostics(authority, authority.backend === "postgresql" ? false : undefined, config.deployment);
  return { authority, dbPath, contentRoot, principal, diagnostics, explicitMemory };
}

/** Resolve and fail closed before opening any authority store. */
export function requireRuntimeAuthority(options: RuntimeStartupOptions = {}): RuntimeStartupResolution {
  const resolution = resolveRuntimeAuthority(options);
  if (!resolution.diagnostics.ok) {
    throw new RuntimeStartupError(resolution.diagnostics);
  }
  if (!resolution.explicitMemory) mkdirSync(dirname(resolve(resolution.dbPath)), { recursive: true, mode: 0o700 });
  mkdirSync(resolve(resolution.contentRoot), { recursive: true, mode: 0o700 });
  return resolution;
}
