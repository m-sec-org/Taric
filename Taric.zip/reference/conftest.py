"""pytest config for runtime/ — adds runtime/ to sys.path so tests can do
`from tools.kb import ...`.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
