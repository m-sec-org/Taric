"""report renumber — make chapter ordinals + sub-section numbers contiguous.

After the agent drops optional chapters (e.g. 六/七), the baked-in ordinals jump
(五 → 八). This deterministic fixup reassigns contiguous Chinese ordinals to the
numbered chapters in document order, renumbers their `X.Y` sub-sections to match,
and rebuilds the ToC. Appendices (附录A/附录B) keep their letters. Idempotent.

Run after keep/drop decisions, before validate.
Usage: python3 -m tools.report renumber <report.md>
"""
from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path
from typing import List

from .scaffold import anchor

ORD = ["一", "二", "三", "四", "五", "六", "七", "八", "九", "十",
       "十一", "十二", "十三", "十四"]

_H1 = re.compile(r"^#\s+(.+?)\s*$")
_H1_NUM = re.compile(r"^#\s+[一二三四五六七八九十]+\.\s*(.+?)\s*$")  # numbered chapter
_H2_NUM = re.compile(r"^##\s+\d+\.\d+\s*(.+?)\s*$")                  # X.Y sub-section

_OPT_OPEN = re.compile(r"^<!--\s*OPTIONAL-CHAPTER\s+(\S+)")          # tag = first token
_OPT_CLOSE = re.compile(r"^<!--\s*/OPTIONAL-CHAPTER\s+(\S+)\s*-->")
_PAGEBREAK = "<!-- PAGEBREAK -->"

_TOC_PLACEHOLDER = "\x00TOC\x00"


def _ord(n: int) -> str:
    return ORD[n - 1] if 1 <= n <= len(ORD) else str(n)


def optional_tags(text: str) -> List[str]:
    """Every `<!-- OPTIONAL-CHAPTER <tag> … -->` tag still present, in order."""
    return [m.group(1) for ln in text.splitlines()
            if (m := _OPT_OPEN.match(ln.strip()))]


def drop_optional(text: str, tags: List[str]) -> str:
    """Delete each `<!-- OPTIONAL-CHAPTER <tag> … --> … <!-- /OPTIONAL-CHAPTER <tag> -->`
    block whose tag is in `tags` (both markers + everything between, inclusive).

    Deterministic replacement for the agent hand-deleting optional-chapter blocks
    byte-by-byte. Fence-aware (never matches a marker copied into an evidence
    fence). Raises KeyError(unmatched_tags) so a typo'd tag fails loudly instead
    of silently leaving the block in.
    """
    want = set(tags)
    lines = text.splitlines()
    out: List[str] = []
    dropped: set = set()
    i, total_lines, in_fence = 0, len(lines), False
    while i < total_lines:
        line = lines[i]
        if line.lstrip().startswith("```"):
            in_fence = not in_fence
            out.append(line); i += 1; continue
        m = None if in_fence else _OPT_OPEN.match(line.strip())
        if m and m.group(1) in want:
            tag = m.group(1)
            leading_blank = bool(out and out[-1] == "")
            j = i + 1
            while j < total_lines and not (
                (c := _OPT_CLOSE.match(lines[j].strip())) and c.group(1) == tag):
                j += 1
            dropped.add(tag)
            i = j + 1                              # skip through close marker inclusive
            while i < total_lines and lines[i] == "":
                i += 1
            # Whole optional chapters in the scaffold always end with a page break
            # immediately after the closing marker; consume it with the chapter.
            if i < total_lines and lines[i].strip() == _PAGEBREAK:
                i += 1
                while i < total_lines and lines[i] == "":
                    i += 1
            if leading_blank and out and out[-1] == "":
                out.pop()
            continue
        out.append(line); i += 1
    missing = want - dropped
    if missing:
        raise KeyError(missing)
    return "\n".join(out).rstrip() + "\n"


def _collapse_pagebreak_runs(lines: List[str]) -> List[str]:
    out: List[str] = []
    pending_blank = False
    prev_pagebreak = False
    for line in lines:
        stripped = line.strip()
        if stripped == "":
            pending_blank = True
            continue
        if stripped == _PAGEBREAK:
            if prev_pagebreak:
                pending_blank = False
                continue
            if pending_blank and out:
                out.append("")
            out.append(_PAGEBREAK)
            pending_blank = False
            prev_pagebreak = True
            continue
        if pending_blank and out:
            out.append("")
        out.append(line)
        pending_blank = False
        prev_pagebreak = False
    return out


def renumber(text: str) -> str:
    lines = text.splitlines()
    out: List[str] = []
    toc_titles: List[str] = []   # display titles of every chapter (numbered + appendix), in order
    n = 0                        # numbered-chapter counter
    cur_major = 0                # current numbered chapter's Arabic index (0 = inside appendix/none)
    cur_minor = 0
    i, total_lines = 0, len(lines)
    in_fence = False

    while i < total_lines:
        line = lines[i]
        # Track ``` code fences: headings copied verbatim into evidence fences
        # (shell comments '# ...', config bodies) must NOT be treated as chapters
        # or sub-sections — renumbering them would corrupt the evidence.
        if line.lstrip().startswith("```"):
            in_fence = not in_fence
            out.append(line)
            i += 1
            continue
        if in_fence:
            out.append(line)
            i += 1
            continue
        h1 = _H1.match(line)
        if h1:
            title = h1.group(1)
            if title == "目录":
                out.append(_TOC_PLACEHOLDER)          # rebuilt at the end
                i += 1
                while i < total_lines and not lines[i].startswith("# "):
                    i += 1                             # drop old ToC body
                continue
            num = _H1_NUM.match(line)
            if num:                                    # numbered chapter → reassign ordinal
                n += 1
                cur_major, cur_minor = n, 0
                disp = f"{_ord(n)}. {num.group(1)}"
                out.append(f"# {disp}")
                toc_titles.append(disp)
            else:                                      # appendix / other H1 → keep
                cur_major = 0
                out.append(line)
                toc_titles.append(title)
            i += 1
            continue

        h2 = _H2_NUM.match(line)
        if h2 and cur_major:                           # X.Y sub-section → fix major, resequence minor
            cur_minor += 1
            out.append(f"## {cur_major}.{cur_minor} {h2.group(1)}")
            i += 1
            continue

        out.append(line)
        i += 1

    toc = ["# 目录", ""] + [f"- [{t}](#{anchor(t)})" for t in toc_titles] + ["", _PAGEBREAK]
    result: List[str] = []
    for ln in out:
        result.extend(toc if ln == _TOC_PLACEHOLDER else [ln])
    return "\n".join(_collapse_pagebreak_runs(result)).rstrip() + "\n"


def main(argv: List[str] | None = None) -> int:
    p = argparse.ArgumentParser(prog="report renumber")
    p.add_argument("report", help="path to the report markdown (rewritten in place)")
    p.add_argument("--drop", action="append", metavar="TAG", default=[],
                   help="drop the OPTIONAL-CHAPTER block with this tag (e.g. 四, 三-assets); "
                        "repeatable. Runs before renumber so ordinals/ToC stay contiguous.")
    args = p.parse_args(argv)
    path = Path(args.report)
    text = path.read_text(encoding="utf-8")
    if args.drop:
        try:
            text = drop_optional(text, args.drop)
        except KeyError as e:
            avail = "、".join(optional_tags(text)) or "（无未决可选章）"
            print(f"report renumber: 找不到可选章 tag {sorted(e.args[0])}；"
                  f"当前可删：{avail}", file=sys.stderr)
            return 2
    new = renumber(text)
    path.write_text(new, encoding="utf-8")
    msg = f"renumbered {path}"
    if args.drop:
        msg = f"dropped {args.drop} + " + msg
    print(msg)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
