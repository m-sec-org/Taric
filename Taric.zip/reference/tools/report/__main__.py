"""report CLI — dispatch `report <verb> ...` to the verb modules.

Verbs: scaffold, finding, nav, renumber, validate  (render, convert added later).
"""
from __future__ import annotations

import sys
from typing import List, Optional

_VERBS = ("scaffold", "finding", "nav", "renumber", "validate")


def main(argv: Optional[List[str]] = None) -> int:
    argv = list(sys.argv[1:]) if argv is None else list(argv)
    if not argv or argv[0] in ("-h", "--help"):
        print(f"usage: report <{'|'.join(_VERBS)}> [args...]", file=sys.stderr)
        return 0 if argv else 2
    verb, rest = argv[0], argv[1:]
    if verb == "scaffold":
        from . import scaffold
        return scaffold.main(rest)
    if verb == "finding":
        from . import finding
        return finding.main(rest)
    if verb == "nav":
        from . import nav
        return nav.main(rest)
    if verb == "renumber":
        from . import renumber
        return renumber.main(rest)
    if verb == "validate":
        from . import validate
        return validate.main(rest)
    print(f"report: unknown verb {verb!r} (expected {'|'.join(_VERBS)})", file=sys.stderr)
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
