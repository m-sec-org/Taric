"""report nav — print the report's chapter outline + per-finding fill status.

Gives the agent a progress map without re-reading a 1000-line file: which chapters
exist, which optional chapters are still undecided, how many <!-- FILL --> markers
remain, and — per finding — whether its evidence palette / 结论 are still pending.
Fence-aware (shares validate's fenced-line guard), so '#' inside evidence never
inflates the outline.

Usage:
    report nav <report.md> [--kb data/kb/<slug>] [--json]
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

from .validate import h1_chapters, _fenced_lines, _bare
from .scaffold import load_findings

_FILL_RE = re.compile(r"<!--\s*FILL:")
_OPT_RE = re.compile(r"<!--\s*OPTIONAL-CHAPTER\b")
_SLOT_OPEN = re.compile(r"<!--\s*FINDING-SLOT:\s*(FINDING-\d+)\s*-->")
_EV_REMINDER = "证据填充"


def _count(pat, lines: List[str], s: int, e: int, fenced: set) -> int:
    return sum(1 for i in range(s, e) if i not in fenced and pat.search(lines[i]))


def _classify_optionals(lines: List[str], fenced: set,
                        chapters: List) -> Dict[int, Dict[str, int]]:
    """Attribute each `<!-- OPTIONAL-CHAPTER -->` marker to the chapter it governs.

    A chapter-level marker is rendered immediately BEFORE the chapter's `# ` heading,
    so it lands in the previous chapter's line span — attribute it by the heading it
    precedes (whole-chapter), not by span. Markers that precede a `##`/table (chapter
    三's optional subtables) are inner blocks of their owning chapter.
    """
    owner: Dict[int, int] = {}
    for ci, (_t, s, e) in enumerate(chapters):
        for i in range(s, e):
            owner[i] = ci
    res = {ci: {"whole": 0, "inner": 0} for ci in range(len(chapters))}
    for i, l in enumerate(lines):
        if i in fenced or not _OPT_RE.search(l):
            continue
        gj = next((j for j in range(i + 1, min(len(lines), i + 12))
                   if lines[j].startswith("#")), None)
        if gj is not None and lines[gj].startswith("# ") and gj in owner:
            res[owner[gj]]["whole"] += 1          # governs a whole chapter
        elif i in owner:
            res[owner[i]]["inner"] += 1            # inner optional block
    return res


def _finding_slots(lines: List[str], s: int, e: int) -> List[Dict[str, Any]]:
    """Per-finding fill status inside the findings chapter [s,e)."""
    fenced = _fenced_lines(lines)
    slots: List[Dict[str, Any]] = []
    cur = None
    for i in range(s, e):
        if i in fenced:
            if cur is not None:
                cur["lines"].append(lines[i])
            continue
        m = _SLOT_OPEN.match(lines[i].strip())
        if m:
            cur = {"id": m.group(1), "lines": []}
            slots.append(cur)
        elif cur is not None and lines[i].strip() == f"<!-- /FINDING-SLOT: {cur['id']} -->":
            cur = None
        elif cur is not None:
            cur["lines"].append(lines[i])
    result = []
    for sl in slots:
        block = "\n".join(sl["lines"])
        ev_pending = _EV_REMINDER in block
        # 结论 empty → still pending
        mm = re.search(r"\*\*结论\*\*[:：](.*)", block)
        concl_pending = bool(mm) and not mm.group(1).strip()
        has_heading = any(l.startswith("### ") for l in sl["lines"])
        status = "done"
        if not has_heading:
            status = "empty"
        elif ev_pending or concl_pending:
            status = "evidence-pending" if ev_pending else "结论-pending"
        result.append({"id": sl["id"], "status": status,
                       "evidence_pending": ev_pending, "conclusion_pending": concl_pending})
    return result


def build_nav(report: Path, kb: Optional[Path]) -> Dict[str, Any]:
    text = report.read_text(encoding="utf-8")
    lines = text.splitlines()
    fenced = _fenced_lines(lines)
    chapters = h1_chapters(lines)
    findings_kb = load_findings(kb) if kb else None
    opt_by_ci = _classify_optionals(lines, fenced, chapters)

    chs: List[Dict[str, Any]] = []
    findings_status: List[Dict[str, Any]] = []
    for ci, (title, s, e) in enumerate(chapters):
        if title == "目录":
            continue
        fills = _count(_FILL_RE, lines, s, e, fenced)
        opt = (opt_by_ci[ci]["whole"] + opt_by_ci[ci]["inner"]) > 0
        entry = {"title": title, "line": s + 1, "fills": fills, "optional_undecided": opt}
        if _bare(title) == "漏洞详情":
            findings_status = _finding_slots(lines, s, e)
            entry["findings"] = len(findings_status)
        chs.append(entry)

    total_fills = sum(c["fills"] for c in chs)
    undecided = [c["title"] for c in chs if c["optional_undecided"]]
    pending_findings = [f for f in findings_status if f["status"] != "done"]
    placed = {f["id"] for f in findings_status}
    missing = [d["id"] for d in (findings_kb or []) if d.get("id") not in placed]

    return {
        "report": str(report),
        "chapters": chs,
        "findings_status": findings_status,
        "kb_finding_count": len(findings_kb) if findings_kb is not None else None,
        "total_fills": total_fills,
        "optional_undecided": undecided,
        "findings_pending": [f["id"] for f in pending_findings],
        "findings_missing_slot": missing,
        "done": total_fills == 0 and not undecided and not pending_findings and not missing,
    }


def _print_human(nav: Dict[str, Any]) -> None:
    print(f"报告导航：{nav['report']}")
    for c in nav["chapters"]:
        flags = []
        if c["fills"]:
            flags.append(f"{c['fills']} 个 FILL")
        if c["optional_undecided"]:
            flags.append("可选章未决")
        if "findings" in c:
            flags.append(f"{c['findings']} 个 finding 小节")
        tail = f"  — {'，'.join(flags)}" if flags else "  ✓"
        print(f"  L{c['line']:>4}  # {c['title']}{tail}")
    if nav["findings_status"]:
        print("  漏洞小节状态：")
        for f in nav["findings_status"]:
            mark = "✓" if f["status"] == "done" else "…"
            print(f"    {mark} {f['id']}: {f['status']}")
    if nav["findings_missing_slot"]:
        print(f"  ⚠ kb 有但报告缺小节：{', '.join(nav['findings_missing_slot'])}"
              f"（跑 `report finding <id> --out <报告>` 生成）")
    if nav["kb_finding_count"] is not None and nav["findings_status"]:
        print(f"  finding 计数：报告 {len(nav['findings_status'])} / kb {nav['kb_finding_count']}")
    print(f"  总计 {nav['total_fills']} 个 FILL 待填；"
          f"{'全部就绪 ✓' if nav['done'] else '仍有待办'}")


def main(argv: Optional[List[str]] = None) -> int:
    p = argparse.ArgumentParser(prog="report nav")
    p.add_argument("report", help="path to the report markdown")
    p.add_argument("--kb", default=None, help="engagement dir (compares finding count)")
    p.add_argument("--json", action="store_true")
    args = p.parse_args(argv)

    report = Path(args.report)
    if not report.is_file():
        print(f"找不到报告：{report}", file=sys.stderr)
        return 2
    nav = build_nav(report, Path(args.kb) if args.kb else None)
    if args.json:
        print(json.dumps(nav, ensure_ascii=False, indent=2))
    else:
        _print_human(nav)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
