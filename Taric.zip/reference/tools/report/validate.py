"""report validate — the deterministic gate over an agent-filled report.

Checks STRUCTURE + COMPLETENESS, never semantic chapter necessity (that's the
agent's call). Exit 0 = PASS, 3 = FAIL. `--json` emits a TODO list the agent
consumes for its next fill pass.

Usage:
    python3 -m tools.report.validate <report.md> [--kb data/kb/<slug>] [--json]
"""
from __future__ import annotations

import argparse
import json
import re
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any, Dict, List, Tuple

import yaml

from .scaffold import load_findings, SEVERITY_CN
from .renumber import ORD, _H1_NUM

MANIFEST = Path(__file__).with_name("manifest.yaml")

# Advisory checks never fail the gate — they inform, they don't block.
ADVISORY_CHECKS = {"dot-skip", "finding-count-skip", "appendix-a-summary-detail"}

_COMMENT_RE = re.compile(r"<!--(.*?)-->", re.DOTALL)
_FENCE_RE = re.compile(r"```.*?\n.*?```", re.DOTALL)
_MD_LINK_RE = re.compile(r"(?<!\!)\[[^\]]+\]\([^)]+\)")  # [text](url) but not ![..](..)
_SLOT_OPEN_LINE_RE = re.compile(r"^<!--\s*FINDING-SLOT:\s*(FINDING-\d+)\s*-->$")
_SLOT_CLOSE_LINE_RE = re.compile(r"^<!--\s*/FINDING-SLOT:\s*(FINDING-\d+)\s*-->$")
_OPT_OPEN_START_RE = re.compile(r"^<!--\s*OPTIONAL-CHAPTER\s+(\S+)\b")
_OPT_CLOSE_LINE_RE = re.compile(r"^<!--\s*/OPTIONAL-CHAPTER\s+(\S+)\s*-->$")
_PAGEBREAK_LINE_RE = re.compile(r"^<!--\s*PAGEBREAK\s*-->$")


def _line_of(text: str, pos: int) -> int:
    return text.count("\n", 0, pos) + 1


def strip_comments(text: str) -> str:
    return _COMMENT_RE.sub("", text)


def strip_fences(text: str) -> str:
    return _FENCE_RE.sub("", text)


def _fenced_lines(lines: List[str]) -> set:
    """Line indices inside ``` code fences (incl. the fence lines themselves).

    Structural detection (chapters, finding sections, numbered ordinals) must
    skip these — evidence is copied verbatim into fences and routinely contains
    lines starting with '#'/'##'/'###' (shell comments, config bodies, markdown
    payloads). Without this guard a '# foo' inside an evidence fence is mis-read
    as a new H1 chapter, truncating spans and corrupting the finding count.
    """
    inside, fence = set(), False
    for i, line_text in enumerate(lines):
        if line_text.lstrip().startswith("```"):
            inside.add(i)
            fence = not fence
        elif fence:
            inside.add(i)
    return inside


def issue(out: List[Dict[str, Any]], check: str, line: int, msg: str) -> None:
    out.append({"check": check, "line": line, "msg": msg})


# ───────────────────────── checks ─────────────────────────

def check_leftover_markers(text: str, out: List[Dict[str, Any]]) -> None:
    """Any HTML comment except structural markers means the agent hasn't finished.

    PAGEBREAK and FINDING-SLOT anchors are persistent machine markers (page break
    hint / per-finding replace anchors used by `report finding`) — they survive to
    the convert step (pandoc drops HTML comments), so they are not leftover work.
    """
    for m in _COMMENT_RE.finditer(text):
        inner = m.group(1).strip()
        if inner == "PAGEBREAK" or inner.startswith(("FINDING-SLOT:", "/FINDING-SLOT:")):
            continue
        head = inner.splitlines()[0][:60] if inner else ""
        issue(out, "leftover-marker", _line_of(text, m.start()),
              f"未处理的 scaffold 注释（填完即删除）：{head}")


def check_marker_corruption(lines: List[str], out: List[Dict[str, Any]]) -> None:
    """Validate raw comment delimiters + structural marker pairing outside fences."""
    fenced = _fenced_lines(lines)
    in_multiline_comment = False
    comment_open_line = 0
    finding_slots: List[Tuple[str, int]] = []
    optional_blocks: List[Tuple[str, int]] = []
    for i, line in enumerate(lines):
        if i in fenced:
            continue
        stripped = line.strip()
        if not stripped:
            continue

        if in_multiline_comment:
            if stripped.startswith("<!--"):
                issue(out, "orphan-comment-open", i + 1,
                      "多行注释尚未结束时又遇到新的注释起始标记（疑似注释配对损坏）")
            if "-->" in line:
                tail = line.split("-->", 1)[1].strip()
                if tail:
                    issue(out, "comment-close-tail", i + 1,
                          "注释结束标记后仍有正文残片（疑似部分删注释）")
                in_multiline_comment = False
                comment_open_line = 0
            continue

        if "-->" in line and "<!--" not in line:
            issue(out, "orphan-comment-close", i + 1,
                  "发现孤立的注释结束标记（缺少对应的注释起始标记）")
            continue

        if "<!--" not in line:
            continue

        if stripped.startswith("<!--") and "-->" not in line:
            mm = _OPT_OPEN_START_RE.match(stripped)
            if mm:
                optional_blocks.append((mm.group(1), i + 1))
            in_multiline_comment = True
            comment_open_line = i + 1
            continue

        if not stripped.startswith("<!--"):
            issue(out, "orphan-comment-open", i + 1,
                  "发现孤立的注释起始标记（起始标记前仍有正文）")
            continue

        if not stripped.endswith("-->"):
            body = stripped[4:].split("-->", 1)[0].strip()
            if body.startswith(("FINDING-SLOT:", "/FINDING-SLOT:", "OPTIONAL-CHAPTER", "/OPTIONAL-CHAPTER", "PAGEBREAK")):
                issue(out, "structural-marker-inline", i + 1,
                      "结构标记必须独占一行，不得与正文拼接")
            else:
                issue(out, "comment-close-tail", i + 1,
                      "注释结束标记后仍有正文残片（疑似部分删注释）")
            continue

        if _PAGEBREAK_LINE_RE.match(stripped):
            continue

        slot_open = _SLOT_OPEN_LINE_RE.match(stripped)
        if slot_open:
            finding_slots.append((slot_open.group(1), i + 1))
            continue

        slot_close = _SLOT_CLOSE_LINE_RE.match(stripped)
        if slot_close:
            fid = slot_close.group(1)
            if not finding_slots or finding_slots[-1][0] != fid:
                issue(out, "finding-slot-balance", i + 1,
                      f"FINDING-SLOT 结束标记 {fid} 缺少匹配的起始标记")
            else:
                finding_slots.pop()
            continue

        opt_close = _OPT_CLOSE_LINE_RE.match(stripped)
        if opt_close:
            tag = opt_close.group(1)
            if not optional_blocks or optional_blocks[-1][0] != tag:
                issue(out, "optional-chapter-balance", i + 1,
                      f"OPTIONAL-CHAPTER 结束标记 {tag} 缺少匹配的起始标记")
            else:
                optional_blocks.pop()

    if in_multiline_comment:
        issue(out, "orphan-comment-open", comment_open_line,
              "发现未闭合的注释起始标记（缺少对应的注释结束标记）")

    for fid, ln in finding_slots:
        issue(out, "finding-slot-balance", ln,
              f"FINDING-SLOT 起始标记 {fid} 缺少匹配的结束标记")

    for tag, ln in optional_blocks:
        issue(out, "optional-chapter-balance", ln,
              f"OPTIONAL-CHAPTER 起始标记 {tag} 缺少匹配的结束标记")


def h1_chapters(lines: List[str]) -> List[Tuple[str, int, int]]:
    fenced = _fenced_lines(lines)
    idx = [i for i, line_text in enumerate(lines) if line_text.startswith("# ") and i not in fenced]
    spans = []
    for k, i in enumerate(idx):
        end = idx[k + 1] if k + 1 < len(idx) else len(lines)
        spans.append((lines[i][2:].strip(), i, end))
    return spans


_ORD_PREFIX = re.compile(r"^[一二三四五六七八九十]+\.\s*")


def _bare(title: str) -> str:
    """Chapter title without its ordinal prefix — the stable id (renumber reassigns ordinals)."""
    return _ORD_PREFIX.sub("", title).strip()


def check_required_chapters(lines: List[str], m: Dict[str, Any], out: List[Dict[str, Any]]) -> None:
    # Match by BARE title, not "九. …": renumber reassigns ordinals after optional-chapter
    # drops, so the stable identity is the title text. (Contiguity of ordinals is a
    # separate check — check_chapter_numbering.)
    present = [_bare(t) for (t, _, _) in h1_chapters(lines) if t != "目录"]
    required = [_bare(c["title"]) for c in m["chapters"] if c.get("required")]
    for t in required:
        if t not in present:
            issue(out, "missing-chapter", 0, f"缺少必需章节：{t}")
    # order: required chapters must appear in manifest order
    seq = [t for t in present if t in required]
    if seq != [t for t in required if t in present]:
        issue(out, "chapter-order", 0, f"必需章节顺序错误：{seq}")


def check_chapter_numbering(lines: List[str], out: List[Dict[str, Any]]) -> None:
    """Numbered chapter ordinals must be contiguous 一,二,三… (no 五→八 gap after a drop)."""
    fenced = _fenced_lines(lines)
    n = 0
    for ln_no, line in enumerate(lines, 1):
        if (ln_no - 1) in fenced or not _H1_NUM.match(line):
            continue
        cur = line[2:].split(".", 1)[0].strip()
        n += 1
        expected = ORD[n - 1] if n <= len(ORD) else None
        if cur != expected:
            issue(out, "chapter-number", ln_no,
                  f"章节序号不连续:第 {n} 个编号章节应为「{expected}」,实为「{cur}」—— 跑 `report renumber`")


def check_toc(lines: List[str], out: List[Dict[str, Any]]) -> None:
    chapters = h1_chapters(lines)
    titles = {t for (t, _, _) in chapters if t != "目录"}
    toc_span = next(((s, e) for (t, s, e) in chapters if t == "目录"), None)
    if not toc_span:
        issue(out, "toc", 0, "缺少「目录」章节")
        return
    s, e = toc_span
    toc_titles = set()
    for i in range(s, e):
        mm = re.match(r"\s*-\s*\[([^\]]+)\]\(#", lines[i])
        if mm:
            toc_titles.add(mm.group(1).strip())
    for t in titles - toc_titles:
        issue(out, "toc-missing", 0, f"章节存在但 ToC 缺条目：{t}")
    for t in toc_titles - titles:
        issue(out, "toc-extra", 0, f"ToC 有条目但章节不存在（删章未删 ToC？）：{t}")


def _section_blocks(lines: List[str], start: int, end: int) -> List[Tuple[str, int, int]]:
    """H3 (### ) sections within [start,end) — fence-aware (skip ### inside evidence)."""
    fenced = _fenced_lines(lines)
    idx = [i for i in range(start, end) if lines[i].startswith("### ") and i not in fenced]
    out = []
    for k, i in enumerate(idx):
        nxt = idx[k + 1] if k + 1 < len(idx) else end
        out.append((lines[i][4:].strip(), i, nxt))
    return out


def check_findings(lines: List[str], m: Dict[str, Any], findings: List[Dict[str, Any]] | None,
                   out: List[Dict[str, Any]]) -> None:
    chapters = h1_chapters(lines)
    fid_title = _bare(next(c["title"] for c in m["chapters"] if c["id"] == "findings"))
    span = next(((s, e) for (t, s, e) in chapters if _bare(t) == fid_title), None)
    if not span:
        issue(out, "missing-chapter", 0, f"缺少 {fid_title}")
        return
    s, e = span
    sections = _section_blocks(lines, s, e)
    if findings is not None and len(sections) != len(findings):
        issue(out, "finding-count", s + 1,
              f"finding 小节数 {len(sections)} ≠ KB finding 数 {len(findings)}")
    fields = m["finding_fields"]
    p0_fields = {
        "复现前置条件与动态参数",
        "真实 POC",
        "成功判据",
        "影响验证",
    }
    for (title, si, sj) in sections:
        block = "\n".join(lines[si:sj])
        clean = strip_comments(block)
        for f in fields:
            if f"**{f}**" not in clean:
                issue(out, "finding-field", si + 1, f"小节「{title[:24]}」缺字段 **{f}**")
        # P0 fields are the minimum reproducibility contract. Unlike other prose
        # fields, their labels alone are not enough: an empty body would let a
        # report present a non-reproducible example as a completed vulnerability.
        for f in p0_fields:
            match = re.search(
                rf"\*\*{re.escape(f)}\*\*[:：][ \t]*(.*?)(?=\n\*\*[^\n]+\*\*[:：]|\Z)",
                clean,
                re.DOTALL,
            )
            if match and not match.group(1).strip():
                issue(out, "finding-p0", si + 1, f"小节「{title[:24]}」P0 字段 **{f}** 为空")
        # 结论 mandatory + non-empty
        mm = re.search(r"\*\*结论\*\*[:：](.*)", clean)
        if mm and not mm.group(1).strip():
            issue(out, "finding-conclusion", si + 1, f"小节「{title[:24]}」**结论** 为空")
        # evidence inlined: ≥1 code fence
        if block.count("```") < 2:
            issue(out, "finding-evidence", si + 1, f"小节「{title[:24]}」无内联证据围栏（请原文照抄请求/响应）")
        # no links / wikilinks outside code fences (images allowed)
        nolinks = strip_fences(clean)
        if "[[" in nolinks:
            issue(out, "finding-wikilink", si + 1, f"小节「{title[:24]}」含 [[..]] 维链（证据须内联，不得引用）")
        if _MD_LINK_RE.search(nolinks):
            issue(out, "finding-link", si + 1, f"小节「{title[:24]}」含 [文本](链接)（证据须内联，不得用链接）")


# 附录A 汇总表行标签（manifest appendix_a 的 fixed_rows）。「存在漏洞的检查项」
# = 有 finding 的检查项数（含信息收集类），与「漏洞条数」是两个维度。
# 兼容历史标签「发现漏洞」：在制品报告可能尚未改标签，按同一槽位解析。
_SUMMARY_LABELS = ("总检查项", "已检查", "通过", "存在漏洞的检查项", "发现漏洞")
_LABEL_ALIAS = {"发现漏洞": "存在漏洞的检查项"}


def _summary_int(value: str) -> int | None:
    """解析汇总数值的前导整数；允许尾部括号/文字说明（如「13（含受限验证项：…）」）。"""
    mm = re.match(r"\s*(\d+)", value)
    return int(mm.group(1)) if mm else None


def check_appendix_a(lines: List[str], m: Dict[str, Any], out: List[Dict[str, Any]]) -> None:
    """附录A 合规性检查清单 — 固定 SOP 条目 + 汇总表内部一致性。

    Blocking:
      - 条目缺失 / 测试情况为空 (原有)
      - 同一检查项重复出现 (appendix-a-duplicate) —— manifest 明写「不增删」，
        重复行会让明细失真（旧报告曾整段重复 25→45 行）
      - SOP覆盖汇总 数值缺行 / 非整数（数字后可带括号说明），且
        `已检查 != 通过 + 存在漏洞的检查项` (appendix-a-summary)
    Advisory (appendix-a-summary-detail): 总检查项 == 清单条目数。
    """
    chapters = h1_chapters(lines)
    span = next(((s, e) for (t, s, e) in chapters if t.startswith("附录A")), None)
    if not span:
        issue(out, "missing-chapter", 0, "缺少 附录A 合规性检查清单")
        return
    s, e = span
    fenced = _fenced_lines(lines)
    manifest_items = [item for grp in m["compliance_checklist"] for item in grp["items"]]
    item_set = set(manifest_items)
    summary: Dict[str, Tuple[str, int]] = {}              # label -> (value, line)
    per_item: Dict[str, List[Tuple[str, int]]] = {}       # item -> [(status, line)]
    for ln_no in range(s, e):
        if ln_no in fenced:
            continue
        cells = [c.strip() for c in lines[ln_no].split("|")]
        if len(cells) < 4 or cells[0] != "":
            continue
        if cells[1] in _SUMMARY_LABELS:                       # | 统计项 | 数值 | (2 列)
            summary[_LABEL_ALIAS.get(cells[1], cells[1])] = (cells[2], ln_no + 1)
        elif len(cells) >= 5 and cells[2] in item_set:        # | 类别 | 测试项 | 测试情况 |
            per_item.setdefault(cells[2], []).append((cells[3], ln_no + 1))

    # ── 条目存在 + 测试情况非空 (blocking, 原有) ──
    for item in manifest_items:
        sts = per_item.get(item)
        if not sts:
            issue(out, "appendix-a-item", s + 1, f"附录A 缺检查项：{item}")
        elif not sts[0][0] or sts[0][0].startswith("<!--"):
            issue(out, "appendix-a-status", s + 1, f"附录A「{item}」测试情况为空")

    # ── 重复行 (blocking) ──
    for item, sts in per_item.items():
        if len(sts) > 1:
            issue(out, "appendix-a-duplicate", sts[1][1],
                  f"附录A「{item}」出现 {len(sts)} 次（条目固定，不增删；请删重复行）")

    # ── 汇总表：数值可解析（前导整数，可带括号说明）+ 已检查 == 通过 + 存在漏洞 (blocking) ──
    def _num(label: str) -> int | None:
        entry = summary.get(label)
        if not entry or not entry[0]:
            issue(out, "appendix-a-summary", s + 1, f"SOP覆盖汇总缺少「{label}」数值")
            return None
        v = _summary_int(entry[0])
        if v is None:
            issue(out, "appendix-a-summary", entry[1],
                  f"SOP覆盖汇总「{label}」数值不是整数（数字后可带括号说明，如 13（含受限验证项））：{entry[0]!r}")
            return None
        return v

    checked, passed, vuln = _num("已检查"), _num("通过"), _num("存在漏洞的检查项")
    if checked is not None and passed is not None and vuln is not None \
            and checked != passed + vuln:
        issue(out, "appendix-a-summary", s + 1,
              f"SOP覆盖汇总不自洽：已检查({checked}) != 通过({passed}) + 存在漏洞的检查项({vuln})")

    # ── 总检查项 == 清单条目数 (advisory) ──
    total = summary.get("总检查项")
    if total:
        tval = _summary_int(total[0])
        if tval is not None and tval != len(manifest_items):
            issue(out, "appendix-a-summary-detail", total[1],
                  f"SOP覆盖汇总 总检查项={tval} ≠ 清单条目数 {len(manifest_items)}")


def check_chains(lines: List[str], m: Dict[str, Any], out: List[Dict[str, Any]]) -> None:
    """攻击链章节是可选的，但一旦保留，每条链须有 dot 图——本章至少含一个 ```dot 图。"""
    chains_title = _bare(next(c["title"] for c in m["chapters"] if c["id"] == "attack_chain"))
    span = next(((s, e) for (t, s, e) in h1_chapters(lines) if _bare(t) == chains_title), None)
    if not span:
        return  # 可选章，整章删除是合法选择（无攻击链时）
    s, e = span
    body = strip_comments("\n".join(lines[s:e]))
    if not re.search(r"```dot\b", body):
        issue(out, "chain-dot", s + 1,
              f"「{chains_title}」章节缺攻击链 dot 图（每条链须有一个 ```dot 图，无链则删除整章）")


_SEP_CELL = re.compile(r"^:?-+:?$")


def _is_separator(line: str) -> bool:
    """GFM 分隔行：每个单元格为 可选: + 一个以上 - + 可选:（如 ---, :--, :-:）。"""
    s = line.strip()
    if not (s.startswith("|") and s.endswith("|")):
        return False
    cells = [c.strip() for c in s.strip("|").split("|")]
    return bool(cells) and all(_SEP_CELL.match(c) for c in cells)


def check_tables(lines: List[str], out: List[Dict[str, Any]]) -> None:
    fenced = _fenced_lines(lines)
    n = len(lines)

    def is_row(i: int) -> bool:  # 围栏外、以 | 起始的行才算表格行
        return i not in fenced and lines[i].strip().startswith("|")

    i = 0
    while i < n:
        if not is_row(i):
            i += 1
            continue
        start = i                       # 一段连续管道行 = 一个表块
        while i < n and is_row(i):
            i += 1
        block = list(range(start, i))
        if len(block) < 2:              # 孤立单行不当表块判（罕见，避免意外误报）
            continue
        if not _is_separator(lines[start + 1]):
            issue(out, "table-separator", start + 1,
                  "表格缺有效分隔行（表头下须紧跟 |---|---|，每列一个 ---，不可空行隔断）")
            continue
        ncol = lines[start].count("|") - 1
        if lines[start + 1].count("|") - 1 != ncol:
            issue(out, "table-separator", start + 2,
                  f"表格分隔行列数与表头不一致（表头 {ncol} 列）")
        for k in block[2:]:             # 数据行：列数一致 + 非全空占位
            cells = [c.strip() for c in lines[k].strip().strip("|").split("|")]
            if lines[k].count("|") - 1 != ncol:
                issue(out, "table-cols", k + 1, f"表格列数不一致（应 {ncol} 列）")
            if cells and all(c == "" for c in cells):
                issue(out, "table-empty-row", k + 1, "表格存在全空占位行（请填或删）")


def check_fences_and_dot(text: str, out: List[Dict[str, Any]]) -> None:
    if text.count("```") % 2 != 0:
        issue(out, "code-fence", 0, "代码围栏 ``` 数量为奇数（未闭合）")
    dot_bin = shutil.which("dot")
    for m in re.finditer(r"```dot\n(.*?)```", text, re.DOTALL):
        src = m.group(1)
        ln = _line_of(text, m.start())
        if not dot_bin:
            issue(out, "dot-skip", ln, "graphviz 未安装，跳过 dot 语法校验（render 时会再查）")
            continue
        r = subprocess.run([dot_bin, "-Tcanon"], input=src, capture_output=True, text=True, check=False)
        if r.returncode != 0:
            issue(out, "dot-syntax", ln, f"dot 图语法错误：{r.stderr.strip().splitlines()[-1] if r.stderr.strip() else '解析失败'}")


# ───────────────────────── driver ─────────────────────────

def validate(report_path: Path, kb_path: Path | None,
             *, count_findings: bool = True) -> List[Dict[str, Any]]:
    """Structure + completeness gate.

    `count_findings=False` (CLI `--no-finding-count`) skips ONLY the
    「小节数 == KB finding 数」assertion, for reports the user has deliberately
    customized (added / removed findings). Every per-section format check
    (fields, 结论, evidence fences, no external links) still runs — the finding
    list drives nothing else, so structure remains fully enforced.
    """
    text = report_path.read_text(encoding="utf-8")
    lines = text.splitlines()
    m = yaml.safe_load(MANIFEST.read_text(encoding="utf-8"))
    findings = load_findings(kb_path) if kb_path else None
    out: List[Dict[str, Any]] = []
    check_marker_corruption(lines, out)
    check_leftover_markers(text, out)
    check_required_chapters(lines, m, out)
    check_chapter_numbering(lines, out)
    check_toc(lines, out)
    check_findings(lines, m, findings if count_findings else None, out)
    check_chains(lines, m, out)
    check_appendix_a(lines, m, out)
    check_tables(lines, out)
    check_fences_and_dot(text, out)
    if not count_findings:
        issue(out, "finding-count-skip", 0,
              "已跳过 finding 数量校验(--no-finding-count):只校验保留小节的格式,"
              "不比对 KB finding 计数 —— 用于用户已增删 finding 的定制报告")
    out.sort(key=lambda d: d["line"])
    return out


# ─────────────── severity sidecar (auto-written on PASS, agent-invisible) ───────────────
# On a passing gate, drop a machine-readable severity breakdown BESIDE the report
# (same basename, .json). It is NOT written into the report .md, is not a verb the
# report agent invokes, and is never mentioned in stdout — it is a side artifact of
# the gate for downstream / machine consumers. Counted from the report's OWN 五
# sections (KB-independent → faithful to what actually shipped, incl. customized
# reports where the finding set was deliberately trimmed).

_SLOT_OPEN_RE = re.compile(r"<!--\s*FINDING-SLOT:\s*(FINDING-\d+)\s*-->")
_SLOT_CLOSE_RE = re.compile(r"<!--\s*/FINDING-SLOT:\s*FINDING-\d+\s*-->")
_SEV_LABEL_RE = re.compile(r"^\s*###\s*【\s*([^】]+?)\s*】")
_CN_TO_EN = {cn: en for en, cn in SEVERITY_CN.items()}
_SEV_ORDER_EN = ["critical", "high", "medium", "low", "info"]


def _findings_span(lines: List[str], m: Dict[str, Any]) -> Tuple[int, int] | None:
    fid_title = _bare(next(c["title"] for c in m["chapters"] if c["id"] == "findings"))
    return next(((s, e) for (t, s, e) in h1_chapters(lines) if _bare(t) == fid_title), None)


def report_severity_index(lines: List[str], m: Dict[str, Any]) -> List[Tuple[str | None, str | None]]:
    """(finding_id|None, severity_en|None) per finding section in chapter 五.

    Fence-aware: a `### 【超危】` line copied verbatim into an evidence fence is
    skipped. severity comes from the section's `### 【等级】…` heading; the id from
    the enclosing FINDING-SLOT marker (None when a section has no slot — e.g. a
    hand-added section in a customized report). severity_en is None when the label
    is not one of the canonical 超危/高危/中危/低危/风险提示.
    """
    span = _findings_span(lines, m)
    if not span:
        return []
    s, e = span
    fenced = _fenced_lines(lines)
    out: List[Tuple[str | None, str | None]] = []
    cur_id: str | None = None
    for i in range(s, e):
        if i in fenced:
            continue
        mo = _SLOT_OPEN_RE.search(lines[i])
        if mo:
            cur_id = mo.group(1)
            continue
        if _SLOT_CLOSE_RE.search(lines[i]):
            cur_id = None
            continue
        if lines[i].startswith("### "):
            mm = _SEV_LABEL_RE.match(lines[i])
            out.append((cur_id, _CN_TO_EN.get(mm.group(1).strip()) if mm else None))
    return out


def severity_sidecar_payload(report_path: Path) -> Dict[str, Any]:
    """Severity breakdown of the report's 五 finding sections. `report` names the
    .md this describes; counts/findings are keyed by the canonical English enum."""
    m = yaml.safe_load(MANIFEST.read_text(encoding="utf-8"))
    lines = report_path.read_text(encoding="utf-8").splitlines()
    index = report_severity_index(lines, m)
    by_sev: Dict[str, List[str | None]] = {en: [] for en in _SEV_ORDER_EN}
    unknown: List[str | None] = []
    for fid, en in index:
        (by_sev[en] if en in by_sev else unknown).append(fid)
    counts = {en: len(by_sev[en]) for en in _SEV_ORDER_EN}
    payload: Dict[str, Any] = {
        "report": report_path.name,
        "total": len(index),
        "counts": counts,
        "counts_cn": {SEVERITY_CN[en]: counts[en] for en in _SEV_ORDER_EN},
        "findings": {en: by_sev[en] for en in _SEV_ORDER_EN},
    }
    if unknown:  # sections whose 【等级】 was not a canonical label — surface, don't drop
        payload["findings"]["unknown"] = unknown
    return payload


def write_severity_sidecar(report_path: Path) -> Path | None:
    """Write `<report basename>.json` beside the report. Best-effort: any failure
    is swallowed so this auxiliary artifact can never change the gate's verdict."""
    sidecar = report_path.with_suffix(".json")
    try:
        payload = severity_sidecar_payload(report_path)
        sidecar.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n",
                           encoding="utf-8")
        return sidecar
    except Exception:
        return None


def remove_stale_sidecar(report_path: Path) -> None:
    """Uphold `sidecar exists ⟺ report currently PASSes`: on FAIL, drop any sidecar
    a previous PASS left behind so a stale severity stat never lingers."""
    try:
        report_path.with_suffix(".json").unlink(missing_ok=True)
    except Exception:
        pass


def _engagement_root(report_path: Path, kb: str | None) -> Path | None:
    """Engagement dir that owns `.api/report.json`. `--kb` wins; otherwise a
    report that lives in `<eng>/report/` identifies its engagement."""
    if kb:
        return Path(kb)
    if report_path.parent.name == "report":
        return report_path.parent.parent
    return None


def sync_report_json(report_path: Path, kb: str | None, *, passed: bool) -> None:
    """Record the gate in `.api/report.json`. Best-effort: a failure here must
    not change the validate exit code.

    A pass writes `exists: true` plus the report body. A blocking failure writes
    `exists: false`, so a later edit that no longer passes does not leave the
    delivery flag set. `kb export` rebuilds the same file on the next commit.
    """
    root = _engagement_root(report_path, kb)
    if root is None:
        return
    try:
        from tools.kb.verbs.export_ import publish_report_view
        publish_report_view(root, report_path if passed else None)
    except Exception:
        return


def main(argv: List[str] | None = None) -> int:
    p = argparse.ArgumentParser(prog="report validate")
    p.add_argument("report", help="path to the (agent-filled) report markdown")
    p.add_argument("--kb", default=None, help="engagement dir (for finding-count check)")
    p.add_argument("--no-finding-count", action="store_true",
                   help="用户已按要求增删 finding 时:跳过『小节数 == KB finding 数』计数校验,"
                        "但仍校验每个保留小节的格式(字段 / 结论 / 证据围栏 / 无外链)")
    p.add_argument("--json", action="store_true")
    args = p.parse_args(argv)

    issues = validate(Path(args.report), Path(args.kb) if args.kb else None,
                      count_findings=not args.no_finding_count)
    # advisory checks inform but never fail the gate
    blocking = [i for i in issues if i["check"] not in ADVISORY_CHECKS]

    if args.json:
        print(json.dumps({"pass": not blocking, "issues": issues}, ensure_ascii=False, indent=2))
    else:
        if not issues:
            print("PASS — 报告结构与完整性校验通过")
        else:
            print(f"{'PASS（含提示）' if not blocking else 'FAIL'} — {len(blocking)} 个待办：")
            for i in issues:
                tag = "·" if i["check"] in ADVISORY_CHECKS else "✗"
                print(f"  {tag} [{i['check']}] L{i['line']}: {i['msg']}")
    # A passing gate silently drops a machine-readable severity sidecar beside the
    # report; a failing gate clears any stale one. Agent-invisible: no new step, and
    # nothing about the sidecar is printed either way.
    report_path = Path(args.report)
    if not blocking:
        write_severity_sidecar(report_path)
    else:
        remove_stale_sidecar(report_path)
    # Same gate decides the delivery flag the progress snapshot reads. Silent,
    # like the sidecar: the agent is not asked to export after a pass.
    sync_report_json(report_path, args.kb, passed=not blocking)
    return 0 if not blocking else 3


if __name__ == "__main__":
    raise SystemExit(main())
