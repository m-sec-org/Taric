"""report scaffold — render the report STRUCTURE skeleton from manifest.yaml.

Structure only. This emits chapter/section headings, table skeletons (header +
separator, with fixed first-column labels where the label set is itself fixed),
the locked per-finding block shape, the fixed compliance checklist rows, the ToC,
and <!-- OPTIONAL-CHAPTER --> decision blocks. It fills NO engagement data —
the report agent reads the KB and fills every value, count, row, finding block,
and <!-- FILL --> marker.

Usage:
    python3 -m tools.report.scaffold [--out report/渗透测试报告.md]
    (no --out → write to stdout)
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Any, Dict, List

import yaml

from tools.kb.parser import parse_frontmatter, split_frontmatter

MANIFEST = Path(__file__).with_name("manifest.yaml")

FILL = "<!-- FILL: {} -->"

SEVERITY_CN = {"critical": "超危", "high": "高危", "medium": "中危", "low": "低危", "info": "风险提示"}
_SEV_RANK = {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}


def load_manifest() -> Dict[str, Any]:
    return yaml.safe_load(MANIFEST.read_text(encoding="utf-8"))


def anchor(title: str) -> str:
    """GitHub-style heading anchor (approx): lowercase, drop punctuation, space→-."""
    out = []
    for ch in title.lower():
        if ch.isalnum() or ch in ("-", " ") or ord(ch) > 127:
            out.append(ch)
        # else drop (e.g. '.')
    return "".join(out).strip().replace(" ", "-")


# ───────────────────────── block renderers ─────────────────────────

def render_table(cols: List[str], fixed_rows: List[str] | None) -> List[str]:
    lines = ["| " + " | ".join(cols) + " |", "|" + "|".join(["---"] * len(cols)) + "|"]
    if fixed_rows:
        for label in fixed_rows:
            cells = [label] + [""] * (len(cols) - 1)
            lines.append("| " + " | ".join(cells) + " |")
    else:
        lines.append("<!-- FILL: 按 KB 数据逐行填写，每条一行 -->")
        lines.append("|" + "|".join([" "] * len(cols)) + "|")
    return lines


def _aslist(v: Any) -> List[str]:
    if v is None:
        return []
    if isinstance(v, list):
        return [str(x) for x in v if x not in (None, "")]
    return [str(v)]


def load_findings(kb_path: Path) -> List[Dict[str, Any]]:
    """Read record/findings/*.md frontmatter (IDs + refs only). Sorted by severity."""
    fdir = kb_path / "record" / "findings"
    out: List[Dict[str, Any]] = []
    if not fdir.is_dir():
        return out
    for f in sorted(fdir.glob("FINDING-*.md")):
        fm, _ = split_frontmatter(f.read_text(encoding="utf-8"))
        d = parse_frontmatter(fm) if fm else {}
        if d.get("id") and d.get("status", "to-fix") != "false-positive":
            out.append(d)
    out.sort(key=lambda d: (_SEV_RANK.get(str(d.get("severity")), 9), str(d.get("id"))))
    return out


def _finding_section(d: Dict[str, Any]) -> List[str]:
    """One section per finding: heading anchor + reference IDs (for kb lookup) + filled-by-agent shape."""
    fid = str(d.get("id"))
    sev = str(d.get("severity") or "?")
    ev = ", ".join(_aslist(d.get("evidence"))) or "（无）"
    re_, ra = _aslist(d.get("related_endpoints")), _aslist(d.get("related_assets"))
    addr_key = "related_endpoints" if re_ else ("related_assets" if ra else "related_endpoints/related_assets")
    addr_ids = ", ".join(re_ or ra) or "（见 kb show）"
    return [
        f"### 【{FILL.format('等级，severity=' + sev + ' → ' + SEVERITY_CN.get(sev, '?'))}】{FILL.format('中文标题：据 ' + fid + ' 概括，简体中文，勿写 FINDING-id（参考 a.docx：【等级】中文标题）')}",
        "",
        "<!-- 参考数据 —— 用下列 ID 去 kb 取原始数据后填充本节；填完删除本注释，勿写入最终报告：",
        f"     · 漏洞主体 {fid}：跑 `kb show {fid}`，取 标题 / ## Impact / ## Recommendation（severity={sev}）",
        f"     · 证据 {ev}：跑 `kb show <EVIDENCE-id>`；「验证过程」的请求/响应一律从证据原文照抄，禁止改写",
        f"     · 漏洞位置来源（{addr_key}）：{addr_ids}",
        "     · 证据若含截图（evidence frontmatter 的 artifacts:），按下面图片占位内联 -->",
        "",
        f"**问题描述**：{FILL.format('一句话点出漏洞类别与本质')}",
        f"**漏洞位置**：{FILL.format('把上面 ' + addr_key + ' 实体解析成 URL / host:port')}",
        "**漏洞影响**：",
        FILL.format(f"照搬 {fid} 的 ## Impact"),
        "",
        "**复现前置条件与动态参数**：",
        FILL.format("说明测试账号/权限、受控真实对象及初始状态；说明 token、签名、对象 ID 等动态值的取得或构造方式。敏感值可脱敏，但不可只留 <JWT>/<sign>"),
        "",
        "**真实 POC**：",
        FILL.format("写导致本漏洞成立的实际请求结构和关键参数；不得用空 body、无效 ID 或仅用于探测的示例代替"),
        "",
        "**成功判据**：",
        FILL.format("写明具体响应字段、身份差异、对象字段或行为；不得仅以 200/success:true 判定成功"),
        "",
        "**影响验证**：",
        FILL.format("写 POC 后的详情回读、流程历史、审计日志、登录验证或数据结果；未验证则收紧影响至已证实控制缺陷"),
        "",
        "**验证过程**：",
        "<!-- 从上面 evidence 里挑能证明漏洞的请求/响应，原文照抄进围栏；对照型漏洞（越权/注入/绕过/限速…）",
        "     用 A/B 两组，直接回显型删除 B 组。围栏语言按原始证据（http/json/text 等）。 -->",
        "",
        f"对照组 (A) — {FILL.format('baseline 一句话')}",
        "请求：",
        "```",
        FILL.format("EVIDENCE(A) 请求原文照抄"),
        "```",
        "响应：",
        "```",
        FILL.format("EVIDENCE(A) 响应原文照抄"),
        "```",
        "",
        f"攻击组 (B) — {FILL.format('attack 一句话')}",
        "请求：",
        "```",
        FILL.format("EVIDENCE(B) 请求原文照抄"),
        "```",
        "响应：",
        "```",
        FILL.format("EVIDENCE(B) 响应原文照抄"),
        "```",
        "",
        "<!-- 截图/图片证据（可选）：evidence 的 artifacts: 里若有图片，在此内联，可多张；路径相对本报告，",
        "     图片由 convert 复制到报告旁。无图则删除下面一行。 -->",
        f"![{FILL.format('图片说明')}](artifacts/{FILL.format('截图文件名，取自 evidence artifacts')})",
        "",
        f"**结论**：{FILL.format('用 A/B 的具体差异（状态码 / 记录数 / 字段）点明漏洞成立')}",
        "",
        "**修复建议**：",
        FILL.format(f"照搬 {fid} 的 ## Recommendation 编号列表"),
    ]


def render_findings(findings: List[Dict[str, Any]]) -> List[str]:
    if not findings:
        return [
            "<!-- 未读到 kb findings（生成时用 --kb 指向 engagement 目录）。",
            "     正式生成时本章每个 FINDING 一节，各自带 evidence 引用。 -->",
        ]
    out = [
        f"<!-- 共 {len(findings)} 个 finding，已按 severity 降序排节。",
        "     每节用 `report finding <FINDING-id> --out <本报告>` 一键生成（照抄 kb 的影响/修复，",
        "     并把该 finding 的全部证据原文抄进「验证过程」候选区）；随后只需就地 Edit：选证据、",
        "     排单组/A-B、写结论。<!-- FINDING-SLOT: … --> 是机器锚点，勿删（convert 时自动丢弃）。 -->",
        "",
    ]
    for i, d in enumerate(findings):
        if i:
            out += ["", "---", ""]
        fid = str(d.get("id"))
        out += [f"<!-- FINDING-SLOT: {fid} -->"]
        out += _finding_section(d)
        out += [f"<!-- /FINDING-SLOT: {fid} -->"]
    return out


def render_chains() -> List[str]:
    """Chapter 四 — supports MULTIPLE chains: one sub-section + one dot per chain."""
    return [
        "<!-- 攻击链可有多条。每条链 = 一个「### 攻击链 N」小节 + 一个独立 dot 图（fig-id 唯一：",
        "     attack-chain-1 / -2 …，report render 各自渲染为 figures/<fig-id>.png）。",
        "     下面是一条链的模板；按实际链数转换，每条链必须有一个 dot 图，无链则删除整章。 -->",
        "",
        f"### 攻击链 1 — {FILL.format('本链名称 / 一句话')}",
        "",
        FILL.format("本链：入口 → 扩散 → 影响 的叙述"),
        "",
        "```dot",
        "// fig-id: attack-chain-1   (report render → figures/attack-chain-1.png)",
        "digraph chain1 {",
        "  rankdir=TB;",
        "  bgcolor=white;",
        '  node [shape=box, style=rounded, fontname="Noto Sans CJK SC"];',
        "  // FILL: 自由绘制本链入侵路径，由你按实际情况构图。节点不限于 finding——",
        "  //       入口 / 主机 / 服务 / 凭据 / 数据 / 任一步骤 / 最终影响 皆可，按链路连边并标注。",
        "  //       下面仅为示意，按需整体替换：",
        '  // entry [label="外部访问 :8444 /benchmark", color=red];',
        '  // step1 [label="LDAP 注入 (FINDING-002)"];',
        '  // data  [label="ApacheDS 目录读取", shape=cylinder];',
        "  // entry -> step1 -> data;",
        "}",
        "```",
        "",
        "<!-- 更多攻击链：复制上面「### 攻击链 N」小节，递增 N 与 fig-id（attack-chain-2 / -3 …）。 -->",
    ]


def render_compliance(checklist: List[Dict[str, Any]]) -> List[str]:
    lines = ["| 类别 | 测试项 | 测试情况 |", "|---|---|---|"]
    for grp in checklist:
        cat = grp["category"]
        for item in grp["items"]:
            lines.append(f"| {cat} | {item} | {FILL.format('已完成 / 未发现漏洞 / 发现漏洞N个')} |")
    return lines


def render_block(b: Dict[str, Any], m: Dict[str, Any]) -> List[str]:
    kind = b["kind"]
    if kind == "prose":
        return [FILL.format(b["hint"])]
    if kind == "subhead":
        text = b["text"]
        return [f"**{text}**"] if b.get("bold") else [f"## {text}"]
    if kind == "prose_subheads":
        out: List[str] = []
        for it in b["items"]:
            out += [f"**{it}**", FILL.format(f"{it}内容"), ""]
        return out[:-1]
    if kind == "table":
        return render_table(b["columns"], b.get("fixed_rows"))
    if kind == "chains":
        return render_chains()
    if kind == "findings":
        return render_findings(m.get("_findings", []))
    if kind == "compliance":
        return render_compliance(m["compliance_checklist"])
    if kind == "optional":
        tag = b["id"].split()[0]
        out = [
            f"<!-- OPTIONAL-CHAPTER {b['id']}  INCLUDE-IF: {b['include_if']}。",
            "     决策：填写本块并删除本注释，或删除整块。 -->",
        ]
        for inner in b["body"]:
            out += render_block(inner, m)
            out.append("")
        out.append(f"<!-- /OPTIONAL-CHAPTER {tag} -->")
        return out
    raise ValueError(f"unknown block kind: {kind!r}")


# ───────────────────────── chapter / document ─────────────────────────

def render_chapter(ch: Dict[str, Any], m: Dict[str, Any]) -> List[str]:
    out: List[str] = []
    optional = not ch.get("required", False)
    tag = ch["title"].split(".")[0].strip()
    if optional:
        out += [
            f"<!-- OPTIONAL-CHAPTER {tag} {ch['id']}  INCLUDE-IF: {ch['include_if']}。",
            "     决策：填写本章并删除本注释，或删除整章（连同目录条目）。 -->",
        ]
    out.append(f"# {ch['title']}")
    out.append("")
    for b in ch["body"]:
        out += render_block(b, m)
        out.append("")
    if optional:
        out.append(f"<!-- /OPTIONAL-CHAPTER {tag} -->")
    out.append("<!-- PAGEBREAK -->")
    return out


def render_toc(m: Dict[str, Any]) -> List[str]:
    out = ["# 目录", ""]
    for ch in m["chapters"]:
        mark = "" if ch.get("required") else "  （可选，删除本章时一并删除此行）"
        out.append(f"- [{ch['title']}](#{anchor(ch['title'])}){mark}")
    out.append("")
    out.append("<!-- PAGEBREAK -->")
    return out


def render_document(m: Dict[str, Any]) -> str:
    head = [
        "<!-- ===========================================================================",
        "  报告生成工作底稿 —— 本文件既是结构骨架，也是给 report subagent 的 prompt。",
        "  你（report agent）的任务：把本骨架填成完整交付报告。逐条执行：",
        "",
        "  1. 把每个 <!-- FILL: 指示 --> 替换为正文，按注释里的指示填；填完删除该注释。",
        "  2. 每个 <!-- OPTIONAL-CHAPTER … --> 块：本次确有该内容 → 填写并删掉成对标记注释；",
        "     否则删除整块（目录与章节号由 report renumber 重建，无需手动删 ToC 条目）。判断依据看 INCLUDE-IF。",
        "  3. 表格：按 KB 数据逐行填，删掉占位空行与 FILL 行注释。",
        "  4. 五. 漏洞详情：每节顶部「参考数据」已列出该 finding 及其 evidence 的 ID；",
        "     用 `kb show <ID>` 取原始数据。验证过程的请求/响应必须从 evidence 原文照抄，",
        "     不得改写或省略；evidence 含截图时用 ![](artifacts/<file>) 内联。",
        "  5. 证据只内联、不引用：不要用 [[EVIDENCE-N]] 或链接代替原文。",
        "  6. 四. 攻击链可有多条：每条一个小节 + 一个 dot 图（fig-id 唯一）。",
        "  7. 可选章删定后跑 `report renumber`（重排章节序号 + 子节号 + 目录）→ `report validate`",
        "     直到通过 → `report render` → `report convert`。",
        f"  8. 把文件名改为 <业务名>-<范围>{m['title_suffix']}.md。",
        "",
        "  本文件由 `report scaffold` 生成：只有结构与引用 ID，零 KB 正文数据。",
        "=========================================================================== -->",
        "",
    ]
    lines = head + render_toc(m)
    for ch in m["chapters"]:
        lines.append("")
        lines += render_chapter(ch, m)
    return "\n".join(lines).rstrip() + "\n"


def main(argv: List[str] | None = None) -> int:
    p = argparse.ArgumentParser(prog="report scaffold")
    p.add_argument("--kb", default=None,
                   help="engagement dir (data/kb/<slug>) — read findings for chapter 五 sections")
    p.add_argument("--out", default=None, help="output path (default: stdout)")
    p.add_argument("--force", action="store_true",
                   help="overwrite an existing report (default: refuse, to protect filled content)")
    args = p.parse_args(argv)
    # Never clobber an existing (possibly agent-filled) report: a re-dispatched
    # report agent should edit + validate the existing file, not re-scaffold.
    if args.out and Path(args.out).exists() and not args.force:
        print(f"报告已存在,跳过 scaffold(避免清空已填内容):{args.out}\n"
              f"  → 直接 Read 现有报告、Edit 续填、再 `report validate`;确需从零重建才加 --force。")
        return 0
    m = load_manifest()
    m["_findings"] = load_findings(Path(args.kb)) if args.kb else []
    doc = render_document(m)
    if args.out:
        out = Path(args.out)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(doc, encoding="utf-8")
        print(f"wrote {out} ({len(doc.splitlines())} lines)")
    else:
        sys.stdout.write(doc)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
