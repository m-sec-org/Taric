"""report finding — assemble ONE finding's chapter-五 section from the KB.

Why this exists: the report agent used to hand-transcribe each finding block with
Edit — copying `## Impact` / `## Recommendation` prose and the evidence request/
response into fenced blocks. Large verbatim Edits truncate/drift, and evidence text
routinely contains '#' lines that corrupt structural validation. This verb does the
deterministic, byte-exact half in one shot:

  * 标题 (severity label + finding title)
  * 漏洞影响   = verbatim `## Impact`
  * 修复建议   = verbatim `## Recommendation`
  * 漏洞位置 = observed evidence request address, falling back to
                     related_endpoints / related_assets
  * 截图      = inlined from each evidence's `artifacts:`
  * 验证过程   = a CANDIDATE PALETTE: every cited evidence's fenced request/response
                copied verbatim, under a reminder to keep the 1-2 that prove the vuln
                and shape them single-group or A/B.

Evidence bodies are free-form (probe writes markdown 自由格式) and only 1-2 of N
evidence usually matter, so evidence selection stays the AGENT's judgement — the
verb hands over the raw material inline (no re-running `kb show`, no re-typing) and
leaves `**结论**` empty for the agent. The FILL reminder + empty 结论 are exactly the
two validator signals that say "evidence still needs you".

Usage:
    report finding FINDING-007 --kb data/kb/<slug>              # print section (context)
    report finding FINDING-007 --kb data/kb/<slug> --out <report.md>   # write in place
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from tools.kb.parser import parse_frontmatter, split_frontmatter, parse_id
from tools.kb.ctx import Engagement
from tools.kb.index import build_index

from .scaffold import SEVERITY_CN, _aslist

_IMG_EXT = (".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp", ".svg")
_FENCE_RE = re.compile(r"```.*?\n.*?```", re.DOTALL)
_EV_RE = re.compile(r"EVIDENCE-\d+")
_HTTP_REQUEST_RE = re.compile(r"^(?:GET|POST|PUT|PATCH|DELETE|HEAD|OPTIONS)\s+(\S+)", re.MULTILINE)
_HOST_RE = re.compile(r"^Host:\s*([^\s/]+)", re.MULTILINE | re.IGNORECASE)


# ───────────────────────── kb readers ─────────────────────────

def _load_md(path: Path) -> Tuple[Dict[str, Any], str]:
    fm_text, body = split_frontmatter(path.read_text(encoding="utf-8"))
    fm = parse_frontmatter(fm_text) if fm_text else {}
    return fm, body


def _extract_h2(body: str, section: str) -> Optional[str]:
    """Verbatim text between `## <section>` and the next H2 (or EOF); None if absent."""
    lines = body.splitlines()
    head = re.compile(rf"^##\s+{re.escape(section)}\s*$")
    nxt = re.compile(r"^##\s+")
    start = None
    for i, ln in enumerate(lines):
        if head.match(ln):
            start = i + 1
            break
    if start is None:
        return None
    end = len(lines)
    for j in range(start, len(lines)):
        if nxt.match(lines[j]):
            end = j
            break
    return "\n".join(lines[start:end]).strip("\n")


def _fenced_blocks(body: str) -> List[str]:
    """Every ``` fenced block, verbatim (fences + language preserved)."""
    return [m.group(0) for m in _FENCE_RE.finditer(body)]


def _resolve_address(idx, ref_id: str, base_url: str) -> str:
    """Best-effort human address for an ENDPOINT / SERVICE / HOST / WEBAPP ref."""
    ent = idx.by_id.get(ref_id)
    if ent is None:
        return ref_id
    b = ent.bullets or {}
    method = str(b.get("method", "")).strip()
    path = str(b.get("path", "")).strip()
    if path:
        url = path if path.startswith(("http://", "https://")) else f"{base_url.rstrip('/')}{path}"
        return f"{method + ' ' if method else ''}{url}".strip()
    # host / service / webapp style
    for k in ("url", "address", "host", "endpoint", "target"):
        if b.get(k):
            v = str(b[k]).strip()
            port = str(b.get("port", "")).strip()
            return f"{v}:{port}" if port and ":" not in v else v
    return f"{ref_id}（{ent.title}）" if getattr(ent, "title", "") else ref_id


# ───────────────────────── section assembly ─────────────────────────

def _finding_evidence_ids(fm: Dict[str, Any], body: str) -> List[str]:
    """Evidence ids a finding cites, deduped in first-seen order.

    Canonical source is the frontmatter `evidence:` list. But findings written by
    probe/curation routinely leave `evidence: []` in frontmatter while citing the
    evidence in a `## Evidence` body section (or an inline `[[EVIDENCE-N]]`).
    Reading frontmatter alone then yields an empty palette and forces the agent to
    hand-splice every request/response — the single biggest report-fill cost. So
    when frontmatter carries none, recover the refs from the body: the `## Evidence`
    section if present, else anywhere in the body.
    """
    ids = [m.group(0) for x in _aslist(fm.get("evidence"))
           for m in [_EV_RE.search(str(x))] if m]
    if ids:
        return list(dict.fromkeys(ids))
    section = _extract_h2(body, "Evidence")
    return list(dict.fromkeys(_EV_RE.findall(section if section is not None else body)))


def _evidence_addresses(kb: Path, ev_ids: List[str], base_url: str) -> List[str]:
    """Extract concrete request targets from cited evidence in first-seen order.

    A finding's related asset often names the reconnaissance entry point, while
    the proof request can reach a different service or port. Report locations
    must describe the latter whenever the evidence records it.
    """
    addresses: List[str] = []
    scheme = re.match(r"https?://", base_url, re.IGNORECASE)
    scheme_prefix = scheme.group(0) if scheme else "https://"
    edir = kb / "record" / "evidence"
    for eid in ev_ids:
        path = edir / f"{eid}.md"
        if not path.is_file():
            continue
        _, body = _load_md(path)
        requests = list(_HTTP_REQUEST_RE.finditer(body))
        for i, request_match in enumerate(requests):
            request = request_match.group(1)
            if request.startswith(("http://", "https://")):
                addresses.append(request)
                continue
            # Evidence can contain baseline and attack requests for different
            # services. Bind Host only from this request's header block.
            next_start = requests[i + 1].start() if i + 1 < len(requests) else len(body)
            headers = body[request_match.end():next_start]
            header_end = re.search(r"\n[ \t]*\n", headers)
            if header_end:
                headers = headers[:header_end.start()]
            host = _HOST_RE.search(headers)
            if host and request.startswith("/"):
                addresses.append(f"{scheme_prefix}{host.group(1)}{request}")
    return list(dict.fromkeys(addresses))


def _evidence_palette(kb: Path, ev_ids: List[str]) -> Tuple[List[str], List[str]]:
    """Return (verification-process lines, screenshot lines) from the finding's evidence."""
    proc: List[str] = [
        "**验证过程**：",
        "<!-- 证据填充（自由格式，需你判断，删完本注释再交付）：",
        "     下面「候选证据」区已把本 finding 引用的每条证据原文（fenced 请求/响应）照抄自 kb，请勿改动其内容。",
        "     ① 选出能证明漏洞的 1-2 条证据；",
        "     ② 对照型（越权/注入/绕过/限速…）→ 保留两组，把标题行改为「对照组 (A) — <一句话>」「攻击组 (B) — <一句话>」；",
        "        直接回显型 → 只留一组，删掉 A/B 措辞；",
        "     ③ 删除未采用的候选块与本注释，然后在下方 **结论** 用 A/B 的具体差异（状态码/记录数/字段）点明漏洞成立。 -->",
        "",
    ]
    shots: List[str] = []
    edir = kb / "record" / "evidence"
    for eid in ev_ids:
        f = edir / f"{eid}.md"
        if not f.is_file():
            proc += [f"候选证据 {eid} — （未找到 {f.name}，请核对 kb）", ""]
            continue
        fm, body = _load_md(f)
        title = str(fm.get("title", "")).strip()
        proc.append(f"候选证据 {eid} — {title}" if title else f"候选证据 {eid}")
        blocks = _fenced_blocks(body)
        if blocks:
            for blk in blocks:
                proc += ["", blk]
        else:
            proc += ["", "```text", f"（{eid} 正文无 fenced 请求/响应，请 `kb show {eid}` 补原文）", "```"]
        proc.append("")
        for art in _aslist(fm.get("artifacts")):
            if str(art).lower().endswith(_IMG_EXT):
                shots.append(f"![{title or eid}](artifacts/{Path(str(art)).name})")
    return proc, shots


def assemble(kb: Path, fid: str) -> List[str]:
    fpath = kb / "record" / "findings" / f"{fid}.md"
    if not fpath.is_file():
        raise FileNotFoundError(f"找不到 finding 文件：{fpath}")
    fm, body = _load_md(fpath)
    if fm.get("status", "to-fix") == "false-positive":
        raise ValueError(f"finding {fid} is marked false-positive and cannot be assembled")

    sev = str(fm.get("severity") or "?")
    sevcn = SEVERITY_CN.get(sev, sev)
    title = str(fm.get("title") or fid).strip()

    tgt = {}
    tj = kb / "target.json"
    if tj.is_file():
        tgt = json.loads(tj.read_text(encoding="utf-8"))
    base_url = str(tgt.get("base_url", "")).strip()

    eng = Engagement(slug=kb.name, root=kb)
    idx = build_index(eng)

    impact = _extract_h2(body, "Impact")
    rec = _extract_h2(body, "Recommendation")
    ev_ids = _finding_evidence_ids(fm, body)
    # The verified request is authoritative for the report location. Asset links
    # describe entry points and are only a fallback when evidence lacks a target.
    addrs = _evidence_addresses(kb, ev_ids, base_url)
    if not addrs:
        refs = _aslist(fm.get("related_endpoints")) or _aslist(fm.get("related_assets"))
        addrs = [_resolve_address(idx, r, base_url) for r in refs] or ["（见 kb，未解析到地址）"]
    addr_line = "；".join(addrs)

    proc, shots = _evidence_palette(kb, ev_ids)

    out: List[str] = [
        f"### 【{sevcn}】{title}",
        "",
        f"**问题描述**：{title}",
        f"**漏洞位置**：{addr_line}",
        "**漏洞影响**：",
        impact if impact is not None else "<!-- FILL: 该 finding 缺 ## Impact，请 kb show 后补写 -->",
        "",
        "**复现前置条件与动态参数**：",
        "<!-- FILL: 说明测试账号/权限、受控真实对象及初始状态；说明 token、签名、对象 ID 等动态值的取得或构造方式。敏感值可脱敏，但不可只留 <JWT>/<sign> -->",
        "",
        "**真实 POC**：",
        "<!-- FILL: 从下方原始证据提炼导致漏洞成立的实际请求结构和关键参数；不得用空 body、无效 ID 或仅用于探测的示例代替 -->",
        "",
        "**成功判据**：",
        "<!-- FILL: 写明具体响应字段、身份差异、对象字段或行为；不得仅以 200/success:true 判定成功 -->",
        "",
        "**影响验证**：",
        "<!-- FILL: 写 POC 后的详情回读、流程历史、审计日志、登录验证或数据结果；未验证则收紧影响至已证实控制缺陷 -->",
        "",
    ]
    out += proc
    if shots:
        out += shots + [""]
    out += [
        "**结论**：",
        "",
        "**修复建议**：",
        rec if rec is not None else "<!-- FILL: 该 finding 缺 ## Recommendation，请 kb show 后补写 -->",
    ]
    return out


# ───────────────────────── in-place write ─────────────────────────

def _slot_bounds(lines: List[str], fid: str) -> Optional[Tuple[int, int]]:
    """(open_idx, close_idx) of the `<!-- FINDING-SLOT: fid -->` … pair, or None."""
    op = f"<!-- FINDING-SLOT: {fid} -->"
    cl = f"<!-- /FINDING-SLOT: {fid} -->"
    a = b = None
    for i, ln in enumerate(lines):
        if ln.strip() == op:
            a = i
        elif ln.strip() == cl:
            b = i
            if a is not None:
                return (a, b)
    return None


def _available_slots(lines: List[str]) -> List[str]:
    out = []
    for ln in lines:
        m = re.match(r"<!--\s*FINDING-SLOT:\s*(FINDING-\d+)\s*-->", ln.strip())
        if m:
            out.append(m.group(1))
    return out


def write_in_place(report: Path, fid: str, section: List[str]) -> str:
    text = report.read_text(encoding="utf-8")
    lines = text.splitlines()
    bounds = _slot_bounds(lines, fid)
    if bounds is None:
        avail = ", ".join(_available_slots(lines)) or "（无）"
        raise KeyError(
            f"报告中找不到 {fid} 的 FINDING-SLOT 锚点。可用槽位：{avail}\n"
            f"  → 先 `report scaffold`（会为每个 finding 生成锚点），或核对 FINDING id。"
        )
    a, b = bounds
    new = lines[: a + 1] + section + lines[b:]
    report.write_text("\n".join(new).rstrip() + "\n", encoding="utf-8")
    return f"filled {fid} into {report} ({len(section)} lines at slot L{a + 1}-L{b + 1})"


# ───────────────────────── cli ─────────────────────────

def main(argv: Optional[List[str]] = None) -> int:
    p = argparse.ArgumentParser(prog="report finding")
    p.add_argument("fid", help="FINDING id, e.g. FINDING-007")
    p.add_argument("--kb", required=True, help="engagement dir (data/kb/<slug>)")
    p.add_argument("--out", default=None,
                   help="report md to patch in place at the FINDING-SLOT anchor; omit → print to stdout")
    args = p.parse_args(argv)

    kb = Path(args.kb)
    try:
        section = assemble(kb, args.fid)
    except (FileNotFoundError, ValueError) as e:
        print(str(e), file=sys.stderr)
        return 2

    if not args.out:
        sys.stdout.write("\n".join(section) + "\n")
        return 0
    try:
        print(write_in_place(Path(args.out), args.fid, section))
    except KeyError as e:
        print(str(e), file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
