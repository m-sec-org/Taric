"""Body-content validation — entities that must carry a fenced code block.

Some entity types require a fenced code block in their body, not just metadata
bullets: a CHAIN must carry a ```dot attack-path graph (schema.REQUIRED_FENCES).
This module is the single source of that rule + its fix hint, shared by
`kb commit` (hard gate — blocks the commit) and `kb health` (lint). The fence
token matches report/validate.py's `dot` check so the report can reuse the
graph verbatim.
"""
from __future__ import annotations

import re
from typing import Dict, List, Pattern

from ..schema import FENCE_FORMAT_HINTS, REQUIRED_FENCES

# A fenced code-block opener: ``` (optionally indented) then the info string
# leading with the language token. Anchored to line start — a real markdown
# fence always opens a line — so an inline mention of ```dot in prose can't
# satisfy the requirement.
_FENCE_CACHE: Dict[str, Pattern] = {}


def _fence_re(lang: str) -> Pattern:
    rx = _FENCE_CACHE.get(lang)
    if rx is None:
        rx = re.compile(rf"(?m)^[ \t]*```[ \t]*{re.escape(lang)}\b")
        _FENCE_CACHE[lang] = rx
    return rx


def missing_fences(entity) -> List[str]:
    """Required fence languages absent from the entity's body, in spec order."""
    body = entity.body or ""
    return [lang for lang in REQUIRED_FENCES.get(entity.type, [])
            if not _fence_re(lang).search(body)]


def format_hint(lang: str) -> str:
    """Verbatim correct-format template for a fence language (shown on failure)."""
    return FENCE_FORMAT_HINTS.get(lang, f"body must contain a ```{lang} code block")
