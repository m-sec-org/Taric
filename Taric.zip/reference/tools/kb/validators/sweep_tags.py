"""Per-endpoint sweep-membership tags — the recall ledger for the sweep checks.

Every ENDPOINT declares, for each system-wide read-comparison sweep, whether it
must be covered by that sweep. The tag is born at observe (`required` / `na`),
advanced by the sweep runner (`enforced` / `missing` / `blocked`), and read by
coverage to keep the sweep's universal check open until every tagged endpoint is
resolved.

This module is the single source of the tag grammar, shared by `kb commit`
(hard gate — every ENDPOINT must carry every profile-declared sweep tag with a
valid value) and `kb coverage` (closure — an endpoint still `required` or
`blocked(needs-…)` keeps its sweep's universal check OPEN).

Grammar (case-insensitive):

    required                    # must be swept, not yet done                   → OPEN
    blocked(needs-<x>)          # can't sweep YET — owed: needs a contract /     → OPEN
                                # comparison actor / peer. Orchestrator resolves.
    enforced                    # swept: control present (denied)               → CLOSING (clean)
    missing                     # swept: control absent → FINDING                → CLOSING (finding)
    na(<reason>)                # sweep genuinely N/A (static asset, no auth)    → CLOSING
    blocked(technical: <why>)   # sweep RAN but the endpoint is genuinely        → CLOSING (recorded)
                                # untestable (500 state / WAF / no data
                                # baseline) — no resolution possible; recorded,
                                # does NOT hold the gate. Mirrors coverage-block
                                # `technical:`.

`required` / `na(<reason>)` are what observe sets; the sweep runner advances a
`required` endpoint to `enforced` / `missing` / `blocked(<reason>)`.

The two `blocked` kinds differ deliberately: `blocked(needs-…)` is an OWED gap
(a comparison actor / peer / contract the orchestrator can still acquire) and
keeps the check open so it can't be dodged; `blocked(technical: …)` is a
terminal, evidence-backed "cannot be tested at all" that CLOSES the check while
staying on the record — so one permanently-untestable endpoint can't wedge the
exit gate open forever.
"""
from __future__ import annotations

import re
from typing import List, Optional, Tuple

# States that never take an argument.
_BARE_ONLY = {"required", "enforced", "missing"}
# States that MAY take a `(reason)`.
_PARENTHESIZED = {"na", "blocked"}
_ALL_STATES = _BARE_ONLY | _PARENTHESIZED

# The sweep actually ran and made a determination.
_RAN = {"enforced", "missing"}

_VALUE_RE = re.compile(r"^([a-z]+)\s*(?:\(([^)]*)\))?$")


def _is_terminal_block(state: str, reason: str) -> bool:
    """A `blocked(technical: …)` is terminal (genuinely untestable → recorded,
    closes the check); every other `blocked` is an owed gap that keeps it open."""
    return state == "blocked" and reason.strip().lower().startswith("technical")


def parse(value) -> Optional[Tuple[str, str]]:
    """(state, reason) for a tag value, or None when it is missing / malformed.

    `reason` is the parenthesized text (may be empty). A state that does not take
    a `(reason)` but carries one — or an unknown state — is malformed → None.
    """
    if not isinstance(value, str):
        return None
    m = _VALUE_RE.match(value.strip().lower())
    if not m:
        return None
    state, reason = m.group(1), (m.group(2) or "").strip()
    if state not in _ALL_STATES:
        return None
    if reason and state not in _PARENTHESIZED:
        return None
    return state, reason


def is_valid(value) -> bool:
    return parse(value) is not None


def is_open(value) -> bool:
    """Keeps the sweep's universal check OPEN: `required`, or a non-technical
    `blocked(needs-…)` (an owed gap). `blocked(technical: …)` is terminal and
    does NOT hold the check open."""
    p = parse(value)
    if not p:
        return False
    state, reason = p
    if state == "required":
        return True
    if state == "blocked":
        return not _is_terminal_block(state, reason)
    return False


def is_terminal_block(value) -> bool:
    """blocked(technical: …) — swept but genuinely untestable; recorded, closes."""
    p = parse(value)
    return bool(p and _is_terminal_block(p[0], p[1]))


def is_ran(value) -> bool:
    """enforced / missing — the sweep produced a determination here."""
    p = parse(value)
    return bool(p and p[0] in _RAN)


def is_missing(value) -> bool:
    p = parse(value)
    return bool(p and p[0] == "missing")


def state_of(value) -> Optional[str]:
    p = parse(value)
    return p[0] if p else None


def missing_tags(entity, tags) -> List[str]:
    """Sweep tags absent or holding a malformed value on this ENDPOINT."""
    out: List[str] = []
    for t in tags:
        if not is_valid(entity.bullets.get(t)):
            out.append(t)
    return out
