"""Semantic inventory validation.

Capability inventory NOTEs are machine-readable ledgers, not free-form prose.
This module keeps shape validation (commit-time) separate from closure
validation (coverage-time): commit rejects malformed ledgers, while coverage
decides whether valid selected/missing slots are still open.
"""
from __future__ import annotations

import re
from typing import Any, Dict, List, Optional

from ..index import Index


SLOT_SLUG_RE = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)+$")
WORK_ITEM_RE = re.compile(r"\b(?:HYPOTHESIS|TASK|FINDING)-\d+\b")


def extract_slot_slug(item: str) -> Optional[str]:
    text = str(item or "").strip()
    if not text:
        return None
    first = text.split()[0].strip("`*:")
    return first if SLOT_SLUG_RE.fullmatch(first) else None


def _display_value(value: Any) -> str:
    if isinstance(value, list):
        return ", ".join(str(v).strip() for v in value if str(v).strip())
    return str(value or "").strip()


def _split_csv(value: Any) -> List[str]:
    if isinstance(value, list):
        return [str(v).strip() for v in value if str(v).strip()]
    if not isinstance(value, str) or not value.strip():
        return []
    return [p.strip() for p in value.split(",") if p.strip()]


def nested_slot_items(raw_block: str, key: str) -> List[str]:
    """Extract markdown nested list items under `- slots_*:`."""
    lines = raw_block.splitlines()
    items: List[str] = []
    key_re = re.compile(rf"^\s*[-*+]\s+{re.escape(key)}\s*[:=]\s*(.*)$")
    top_bullet_re = re.compile(r"^\s*[-*+]\s+[A-Za-z_][A-Za-z0-9_-]*\s*[:=]")
    in_block = False
    base_indent = 0
    for line in lines:
        if not in_block:
            m = key_re.match(line)
            if not m:
                continue
            in_block = True
            base_indent = len(line) - len(line.lstrip())
            inline = m.group(1).strip()
            if inline:
                items.append(inline)
            continue

        stripped = line.strip()
        if not stripped:
            break
        indent = len(line) - len(line.lstrip())
        if indent <= base_indent and top_bullet_re.match(line):
            break
        nested = re.match(r"^\s*[-*+]\s+(.*\S)\s*$", line)
        if nested:
            items.append(nested.group(1).strip())
    return items


def build_inventory(idx: Index, profile, *, include_placeholders: bool = False) -> List[dict]:
    note_type = profile.semantic_inventory_note_type
    if not note_type:
        return []
    archived = idx.archived_entity_ids()
    out: List[dict] = []
    for n in idx.by_type.get("NOTE", []):
        if (n.is_placeholder and not include_placeholders) or n.id in archived:
            continue
        if str(n.bullets.get("type", "")).strip() != note_type:
            continue
        slots: Dict[str, List[str]] = {}
        invalid_slots: Dict[str, List[str]] = {}
        for key in profile.semantic_inventory_slot_keys:
            raw_items = nested_slot_items(n.raw_block or "", key)
            valid_items = [item for item in raw_items if extract_slot_slug(item)]
            invalid_items = [item for item in raw_items if not extract_slot_slug(item)]
            slots[key] = valid_items
            if invalid_items:
                invalid_slots[key] = invalid_items
        out.append({
            "note_id": n.id,
            "title": n.title,
            "target": _display_value(n.bullets.get("target")),
            "tier": _display_value(n.bullets.get("tier")),
            "pattern": _display_value(n.bullets.get("pattern")),
            "capabilities": _split_csv(n.bullets.get("capabilities")),
            "slots": slots,
            "invalid_slots": invalid_slots,
            "missing_count": len(slots.get("slots_missing", [])),
            "selected_count": len(slots.get("slots_selected", [])),
            "refuted_count": len(slots.get("slots_refuted", [])),
            "blocked_count": len(slots.get("slots_blocked", [])),
            "deferred_count": len(slots.get("slots_deferred", [])),
            "skipped_count": len(slots.get("slots_skipped", [])),
            "covered_count": len(slots.get("slots_covered", [])),
        })
    return out


def build_missing_type_warnings(idx: Index, profile, *, include_placeholders: bool = False) -> List[dict]:
    note_type = profile.semantic_inventory_note_type
    if not note_type:
        return []
    archived = idx.archived_entity_ids()
    out: List[dict] = []
    title_re = re.compile(rf"\b{re.escape(note_type)}\b", re.IGNORECASE)
    for n in idx.by_type.get("NOTE", []):
        if (n.is_placeholder and not include_placeholders) or n.id in archived:
            continue
        actual_type = str(n.bullets.get("type", "")).strip()
        if actual_type == note_type:
            continue
        if title_re.search(n.title or ""):
            out.append({
                "note_id": n.id,
                "title": n.title,
                "warning": f"title mentions {note_type!r} but missing '- type: {note_type}' bullet",
            })
    return out


def validate_shape(inventory: List[dict], warnings: List[dict], profile) -> List[dict]:
    issues: List[dict] = []
    for w in warnings:
        issues.append({
            "note_id": w["note_id"],
            "severity": "blocking",
            "issue": w["warning"],
        })
    allowed_patterns = set(profile.semantic_inventory_patterns)
    for inv in inventory:
        note_id = inv["note_id"]
        pattern = inv.get("pattern")
        if not pattern:
            issues.append({"note_id": note_id, "severity": "blocking", "issue": "missing pattern"})
        elif allowed_patterns and pattern not in allowed_patterns:
            issues.append({"note_id": note_id, "severity": "blocking", "issue": f"pattern not in Tier 0 Pattern Catalog: {pattern}"})
        if not inv.get("target"):
            issues.append({"note_id": note_id, "severity": "warning", "issue": "missing target"})
        for field, items in inv.get("invalid_slots", {}).items():
            for item in items:
                issues.append({
                    "note_id": note_id,
                    "severity": "blocking",
                    "field": field,
                    "issue": "slot item must start with lowercase kebab-case slot slug; omit the field when empty",
                    "item": item,
                })
    return issues


def validate_closure(inventory: List[dict]) -> List[dict]:
    issues: List[dict] = []
    for inv in inventory:
        note_id = inv["note_id"]
        if inv.get("selected_count", 0) > 0:
            issues.append({"note_id": note_id, "severity": "blocking", "issue": "slots_selected is not terminal closure"})
        if inv.get("missing_count", 0) > 0:
            issues.append({"note_id": note_id, "severity": "blocking", "issue": "slots_missing remains unresolved"})
        total_slots = sum(len(v) for v in inv.get("slots", {}).values())
        invalid_total = sum(len(v) for v in inv.get("invalid_slots", {}).values())
        if total_slots == 0 and invalid_total == 0:
            issues.append({"note_id": note_id, "severity": "blocking", "issue": "no slot disposition bullets"})
        for item in inv.get("slots", {}).get("slots_deferred", []):
            if WORK_ITEM_RE.search(item):
                issues.append({
                    "note_id": note_id,
                    "severity": "blocking",
                    "issue": "slots_deferred references a work item; move it to selected/covered/refuted/blocked or remove the reference",
                })
                break
    return issues


def validate_inventory(idx: Index, profile, *, closure: bool = True) -> List[dict]:
    inventory = build_inventory(idx, profile)
    warnings = build_missing_type_warnings(idx, profile)
    issues = validate_shape(inventory, warnings, profile)
    if closure:
        issues.extend(validate_closure(inventory))
    return issues
