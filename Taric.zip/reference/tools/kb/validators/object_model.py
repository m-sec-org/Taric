"""Conditional object-model contract for web A01/A04 hypotheses."""
from __future__ import annotations

from typing import Iterable, List, Mapping

from ..schema import WEB_OBJECT_MODEL_CLASSES, WEB_OBJECT_MODEL_FIELDS

_BOUNDARY_TO_CONTROL = {
    "ownership": "selector-swap",
    "role": "actor-swap",
    "state": "state-swap",
    "trusted-value": "value-swap",
    "invariant": "concurrency",
}
_ID_SOURCE_FORBIDDEN = ("enumerat", "guess", "brute", "range", "construct", "predict")


def requires_object_model(profile_name: str, class_name: object, targets: object) -> bool:
    """Whether this hypothesis must declare the web object-model fields."""
    if profile_name != "web" or not isinstance(class_name, str):
        return False
    if class_name.strip().lower() not in WEB_OBJECT_MODEL_CLASSES:
        return False
    values = targets if isinstance(targets, list) else [targets]
    return "system-wide" not in {str(value).strip().strip("[]") for value in values}


def missing_object_model_fields(profile_name: str, values: Mapping[str, object]) -> List[str]:
    """Return required fields absent/blank for a conditional object-model hypothesis."""
    if not requires_object_model(profile_name, values.get("class"), values.get("targets")):
        return []
    return [field for field in WEB_OBJECT_MODEL_FIELDS if not str(values.get(field, "")).strip()]


def invalid_object_model_fields(profile_name: str, values: Mapping[str, object]) -> List[str]:
    """Return semantic contract violations after the required fields are present."""
    if not requires_object_model(profile_name, values.get("class"), values.get("targets")):
        return []
    boundary = str(values.get("boundary", "")).strip().lower()
    control = str(values.get("control", "")).strip().lower()
    expected_control = _BOUNDARY_TO_CONTROL.get(boundary)
    errors: List[str] = []
    if expected_control is None:
        errors.append("`boundary` must be one of " + "/".join(_BOUNDARY_TO_CONTROL))
    elif control != expected_control:
        errors.append(f"`boundary: {boundary}` requires `control: {expected_control}`")
    source = str(values.get("object_id_source", "")).lower()
    if any(term in source for term in _ID_SOURCE_FORBIDDEN):
        errors.append("`object_id_source` must use baseline/UI/known test data, not enumeration or guessing")
    return errors
