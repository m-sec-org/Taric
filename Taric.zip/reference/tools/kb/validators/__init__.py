"""KB validation helpers."""
