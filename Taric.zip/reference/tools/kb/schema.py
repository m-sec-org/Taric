"""Entity-model schema — single source of truth.

Adding a new entity type:
  1. Add an entry to _ENTITY_SPECS below.
  2. parser.py and health.py pick it up automatically via the derived exports.
  3. (Optional) add a prose example / gotcha in tools/kb/schema_docs.py
     (COMMON / WEB / HOST). `kb schema <type>` renders the structural contract
     (required bullets / status / frontmatter) from here automatically; the prose
     module only carries examples the live render can't give.

Adding a new file-type frontmatter requirement: edit REQUIRED_FRONTMATTER below.

This module has no internal imports. parser.py re-exports `ENTITY_TYPES` and
`ID_PAD` for back-compat with existing call sites.
"""
from __future__ import annotations

# Width for committed (real) entity IDs. A TYPE-N with fewer digits is a placeholder.
ID_PAD = 3

# Web-only, non-system-wide A01/A04 hypotheses use the object model. These
# fields make the test contract machine-visible instead of burying it in
# rationale prose. Host and generic/system-wide hypotheses remain unaffected.
WEB_OBJECT_MODEL_CLASSES = frozenset({
    "authz-horizontal", "authz-vertical", "idor", "bola", "rbac",
    "business-logic", "workflow-bypass", "race-condition",
})
WEB_OBJECT_MODEL_FIELDS = (
    "object_type", "object_id_source", "owner_scope", "operation",
    "boundary", "control", "unique_variable", "verified_if", "refuted_if",
)


# ─────────────────────────────────────────────────────────────────────────
# Entity specs — the source of truth. Each entry describes one entity type:
#   required_bullets — bullets that must appear under the entity heading.
#                      FINDING/EVIDENCE declare via frontmatter, not bullets,
#                      so their required_bullets list is empty.
#   status_values    — allowed values for the `status` bullet.
#   layout           — directory prefixes the entity may live under.
# ─────────────────────────────────────────────────────────────────────────
_ENTITY_SPECS = {
    "ENDPOINT": {
        "required_bullets": ["method", "path", "status"],
        "status_values":    ["undocumented", "documented", "untested",
                             "tested-clean", "verified-issue"],
        "layout":           ["wiki/"],
    },
    "ROUTE": {
        "required_bullets": ["url_path", "status"],
        "status_values":    ["undocumented", "documented"],
        "layout":           ["wiki/"],
    },
    "PAGE": {
        "required_bullets": ["status"],
        "status_values":    ["undocumented", "documented"],
        "layout":           ["wiki/"],
    },
    "BUNDLE": {
        "required_bullets": ["url", "status"],
        "status_values":    ["undocumented", "documented"],
        "layout":           ["wiki/"],
    },
    "WORKFLOW": {
        "required_bullets": ["starts_at", "status"],
        "status_values":    ["undocumented", "documented"],
        "layout":           ["wiki/"],
    },
    # ── Host / network entities (docs/framework-host/overview.md §4). Additive:
    # web engagements never emit these, so they sit inert under the web profile.
    "HOST": {
        "required_bullets": ["ip", "status"],
        "status_values":    ["undocumented", "documented", "alive", "dead"],
        "layout":           ["wiki/"],
    },
    "DOMAIN": {
        # Root domain and subdomain unified: optional `parent:` bullet present
        # ⇒ subdomain, absent ⇒ registrable root.
        "required_bullets": ["fqdn", "status"],
        "status_values":    ["undocumented", "documented", "resolves", "nxdomain"],
        "layout":           ["wiki/"],
    },
    "SERVICE": {
        "required_bullets": ["host", "port", "proto", "status"],
        "status_values":    ["undocumented", "documented", "untested",
                             "tested-clean", "verified-issue"],
        "layout":           ["wiki/"],
    },
    "WEBAPP": {
        "required_bullets": ["url", "status"],
        "status_values":    ["undocumented", "documented", "delegated", "returned"],
        "layout":           ["wiki/"],
    },
    "CRED": {
        "required_bullets": ["kind", "value_hash", "source", "status"],
        "status_values":    ["discovered", "validated", "expired", "used-for"],
        "layout":           ["wiki/"],
    },
    "HYPOTHESIS": {
        "required_bullets": ["targets", "class", "severity_guess",
                             "rationale", "status"],
        "status_values":    ["untested", "testing", "verified",
                             "refuted", "abandoned", "blocked"],
        "layout":           ["plan/", "plan/archive/"],
    },
    "TASK": {
        "required_bullets": ["hypothesis", "status"],
        "status_values":    ["pending", "running", "done", "blocked"],
        "layout":           ["plan/", "plan/archive/"],
    },
    "FINDING": {
        "required_bullets": [],     # declared via file frontmatter
        # Triage / remediation lifecycle. English slugs per the runtime's
        # "schema 词元 (…status…) 保持英文" convention (Chinese gloss for the
        # human/report: to-fix=待修复, risk-accepted=接受风险, fixed=已修复,
        # false-positive=误报). Optional frontmatter field, auto-seeded to
        # FINDING_STATUS_DEFAULT at creation so the agent never types it; the
        # human owns triage via `kb status set`. Kept OUT of REQUIRED_FRONTMATTER
        # so legacy/hand-authored findings and a low-friction workflow are never
        # blocked by a missing status.
        "status_values":    ["to-fix", "risk-accepted", "fixed", "false-positive"],
        "layout":           ["record/findings/"],
    },
    "EVIDENCE": {
        "required_bullets": [],     # declared via file frontmatter
        "status_values":    [],
        "layout":           ["record/evidence/"],
    },
    "CHAIN": {
        "required_bullets": [],
        "status_values":    [],
        "layout":           ["record/"],
        # Body must carry a `dot` attack-path graph (report reuses it verbatim).
        # Enforced per-entity via schema.REQUIRED_FENCES — see validators/entity_body.py.
        "required_fences":  ["dot"],
    },
    "NOTE": {
        # Free-form agent observation: vuln-class heuristics, user steering,
        # standalone observations that aren't yet hypotheses. The agent uses
        # NOTE freely; placement is its judgment. Optional bullets like
        # `status:` / `targets:` / `source:` are accepted but not required.
        "required_bullets": [],
        "status_values":    [],
        "layout":           ["wiki/", "plan/", "record/"],
    },
}


# ─────────────────────────────────────────────────────────────────────────
# Per-file-type frontmatter — required keys per `type:` value in the YAML
# header. Drives the `missing-frontmatter` health rule.
# ─────────────────────────────────────────────────────────────────────────
REQUIRED_FRONTMATTER = {
    "topic":    ["title", "type", "workflow", "tags", "status",
                 "created", "last_updated"],
    "plan":     ["title", "type", "last_updated"],
    "finding":  ["id", "type", "title", "severity", "cvss_vector",
                 "related_endpoints", "evidence", "hypothesis", "tags",
                 "created", "last_updated"],
    "evidence": ["id", "type", "title", "captured_at", "related_endpoint",
                 "proof_type", "evidence_level", "verification_result",
                 "claim", "limitations", "artifacts", "created", "last_updated"],
    "chains":   ["title", "type", "last_updated"],
    "index":    ["type", "last_updated"],
    "log":      ["type"],
    "state":    ["type", "last_updated"],
    "inbox":    ["title", "type", "last_updated"],
}


# ─────────────────────────────────────────────────────────────────────────
# Frontmatter key aliases. The host model renames finding/evidence asset
# references — related_endpoints/related_endpoint → related_assets/related_asset
# (docs/framework-host §13.3) — because a host FINDING relates to HOST / SERVICE
# / WEBAPP / CRED, not endpoints. Both names are accepted on read and on the
# required-frontmatter check; writers keep emitting the legacy name for
# back-compat. The map is keyed by the legacy (canonical-on-write) name.
# ─────────────────────────────────────────────────────────────────────────
FRONTMATTER_ALIASES = {
    "related_endpoints": "related_assets",   # finding: list of asset IDs
    "related_endpoint":  "related_asset",    # evidence: single asset ID
}


def fm_has(fm: dict, key: str) -> bool:
    """True if `key` (or its accepted alias) is present in a frontmatter dict."""
    if key in fm:
        return True
    alias = FRONTMATTER_ALIASES.get(key)
    return bool(alias and alias in fm)


def fm_get(fm: dict, key: str, default=None):
    """Read `key` from a frontmatter dict, falling back to its accepted alias."""
    if key in fm:
        return fm[key]
    alias = FRONTMATTER_ALIASES.get(key)
    if alias is not None and alias in fm:
        return fm[alias]
    return default


# ─────────────────────────────────────────────────────────────────────────
# Derived exports. Built from _ENTITY_SPECS so adding an entity type is a
# single-place edit.
# ─────────────────────────────────────────────────────────────────────────
ENTITY_TYPES = set(_ENTITY_SPECS.keys())

REQUIRED_BULLETS = {
    name: spec["required_bullets"]
    for name, spec in _ENTITY_SPECS.items()
    if spec["required_bullets"]
}

LAYOUT_RULES = {
    name: spec["layout"]
    for name, spec in _ENTITY_SPECS.items()
}

STATUS_VALUES = {
    name: spec["status_values"]
    for name, spec in _ENTITY_SPECS.items()
    if spec["status_values"]
}

# Default triage status stamped onto a freshly generated FINDING (first value of
# its enum). Single source of truth for the creation paths (promote / draft
# scaffold) and the export default for legacy findings that predate the field.
FINDING_STATUS_DEFAULT = _ENTITY_SPECS["FINDING"]["status_values"][0]

# Body-content requirement: entity types that must carry one or more fenced code
# blocks in their body (keyed by fence language). Unlike required_bullets, this
# checks entity.body, not the metadata block. Drives the `missing-required-fence`
# health rule and the `kb commit` body gate.
REQUIRED_FENCES = {
    name: spec["required_fences"]
    for name, spec in _ENTITY_SPECS.items()
    if spec.get("required_fences")
}


# ─────────────────────────────────────────────────────────────────────────
# Correct-format templates, shown verbatim when a required fence is missing so
# the agent can fix the entity without opening the docs. Keyed by fence lang.
# ─────────────────────────────────────────────────────────────────────────
FENCE_FORMAT_HINTS = {
    "dot": (
        "A CHAIN body must contain ONE ```dot attack-path graph plus one\n"
        "narrative paragraph (both required). The graph draws the path as a\n"
        "digraph: nodes = entry / each finding / unlocked capability / final\n"
        "impact; edges = \"unlocks -> next step\"; one graph per chain with a\n"
        "unique fig-id; draw any not-yet-verified hop with style=dashed. The\n"
        "report's attack-chain chapter reuses this graph verbatim, so it must\n"
        "be drawn here at creation. Correct format:\n"
        "\n"
        "```dot\n"
        "// fig-id: chain-1\n"
        "digraph chain1 {\n"
        "  rankdir=LR;\n"
        "  node [shape=box, style=rounded];\n"
        "  entry  [label=\"unauth GET /api/config\", color=red];\n"
        "  f3     [label=\"leak admin JWT (FINDING-003)\"];\n"
        "  f7     [label=\"admin API takeover (FINDING-007)\"];\n"
        "  impact [label=\"full admin takeover\", shape=doubleoctagon];\n"
        "  entry -> f3 -> f7 -> impact;\n"
        "}\n"
        "```"
    ),
}
