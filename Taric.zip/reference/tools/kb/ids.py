"""ID counter management — stored inside target.json under `counters:`."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Dict, List

from .parser import ENTITY_TYPES, format_id


def read_target(target_json: Path) -> dict:
    if not target_json.exists():
        return {}
    return json.loads(target_json.read_text(encoding="utf-8"))


def write_target(target_json: Path, data: dict) -> None:
    target_json.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def read_counters(target_json: Path) -> Dict[str, int]:
    data = read_target(target_json)
    counters = data.get("counters") or {}
    # Normalize: every entity type has a counter, default 0.
    return {t: int(counters.get(t.lower(), 0)) for t in ENTITY_TYPES}


def write_counters(target_json: Path, counters: Dict[str, int]) -> None:
    data = read_target(target_json)
    data["counters"] = {t.lower(): int(counters.get(t, 0)) for t in ENTITY_TYPES}
    write_target(target_json, data)


def allocate_ids(counters: Dict[str, int], type_: str, count: int) -> List[str]:
    """Increment the counter for `type_` by `count`. Return the freshly-allocated real IDs."""
    type_ = type_.upper()
    start = counters.get(type_, 0) + 1
    end = start + count
    counters[type_] = end - 1
    return [format_id(type_, n) for n in range(start, end)]


def reconcile_counters(stored: Dict[str, int], real_ids) -> Dict[str, int]:
    """Lift each counter to at least the highest real ID that already exists.

    `allocate_ids` is counter-only — it never looks at disk. If the stored counter
    drifts *below* what is already present (a reset/restored target.json, record/
    restored from a snapshot, a partially-applied prior write), allocation would
    hand back an ID that already exists and the caller would collide on move /
    rename — and, because the counter is only persisted *after* the move, every
    retry re-allocates the same colliding ID and dead-loops. Reconciling to
    max(stored, derived-from-existing) before allocating makes the counter
    monotonic and allocation self-healing."""
    derived = derive_counters_from_ids(list(real_ids))
    return {t: max(int(stored.get(t, 0)), int(derived.get(t, 0))) for t in ENTITY_TYPES}


def derive_counters_from_ids(ids: List[str]) -> Dict[str, int]:
    """Given the set of real IDs across the engagement, return the per-type max."""
    out: Dict[str, int] = {t: 0 for t in ENTITY_TYPES}
    for id_ in ids:
        if "-" not in id_:
            continue
        type_, _, digits = id_.partition("-")
        if type_ not in ENTITY_TYPES:
            continue
        try:
            n = int(digits)
        except ValueError:
            continue
        if n > out[type_]:
            out[type_] = n
    return out
