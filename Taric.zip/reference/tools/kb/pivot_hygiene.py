"""Pivot-capture reminder — a just-in-time `<system-reminder>` at `kb draft commit`.

When a probe commits a FINDING (i.e. the draft validated and carries `finding.md`),
nudge the worker to bank a reusable artifact into `pivot/` — but ONLY a complex,
runnable one a future probe would actually re-run. Like pool_hygiene.py /
reprobe_hygiene.py this is a computed reminder, never a gate: it does not touch the
commit result.

The bar is deliberately high so `pivot/` does not fill with low-value junk:
  KEEP → a runnable script / POC / payload-sender that WORKED against this target
         and that a plain curl / one-line bash CANNOT reproduce — a signed or
         encrypted request replayer, a decrypt-encrypt helper, a multi-step
         exploit chain, a webshell client.
  DROP → a single request, a one-liner, a generic payload, notes, scanner output.
         Those live in evidence / NOTE, not pivot.

It stays silent when the finding already points at a pivot (`FINDING.pivot`) — the
worker has already banked it — so it fires at most once per finding, and never for
a refuted / blocked / failed draft (those carry no finding.md).
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import Optional

# `pivot:` in the finding frontmatter, with a real value (not empty / none / -).
# Horizontal-whitespace only around the colon so the value capture stays on the
# same line (a bare `\s*` would span the newline and grab the next line).
_PIVOT_LINE = re.compile(r"(?im)^[ \t]*pivot[ \t]*:[ \t]*([^\n]*)$")
_EMPTY_VALUES = {"", "none", "-", "n/a", "na"}


def _already_banked(draft_dir: Path) -> bool:
    """True when finding.md already references a pivot artifact (worker did it)."""
    try:
        text = (draft_dir / "finding.md").read_text(encoding="utf-8")
    except OSError:
        return False
    m = _PIVOT_LINE.search(text)
    return bool(m) and m.group(1).strip().lower() not in _EMPTY_VALUES


def banner(draft_dir: Path) -> Optional[str]:
    """`<system-reminder>` nudging pivot capture, or None when it should stay quiet."""
    if not (draft_dir / "finding.md").exists():
        return None
    if _already_banked(draft_dir):
        return None
    return "\n".join([
        "<system-reminder>",
        "Finding committed. If proving it required a RUNNABLE artifact a future probe would",
        "RE-RUN, bank it now so the next worker doesn't rebuild it:",
        "  bin/kb pivot add --kind exploit|transport|implant --file <path> --name <name> \\",
        "      --target <url|FINDING-N> --run '<how to run>' --needs '<auth actor|->' --task <TASK-N>",
        "KEEP only what a plain curl / one-line bash CANNOT reproduce and that WORKED here —",
        "a signed / encrypted request replayer, a decrypt-encrypt helper, a multi-step exploit",
        "chain, a webshell client.",
        "DROP a single request, a one-liner, a generic payload, notes, or scanner output — those",
        "stay in evidence / NOTE. Nothing reusable? Do nothing.",
        "</system-reminder>",
    ])


def emit(draft_dir: Path) -> None:
    b = banner(draft_dir)
    if b:
        print(b)
