"""kb state, kb stats."""
from __future__ import annotations

import json
import re
from collections import Counter, defaultdict
from typing import Dict, List, Tuple

from .. import ctx
from ..ids import read_target
from ..index import build_index
from ..parser import ENTITY_TYPES

# Engagement bullets already surfaced by the target/scope header — don't repeat.
_ENGAGEMENT_SKIP = {"target", "slug", "notes", "base_url"}


def _engagement_extras(eng) -> List[Tuple[str, str]]:
    """`- key: value` bullets from STATE.md's `## Engagement` block, minus the
    ones the target/scope header already prints. Surfaces the coordination facts
    the agent would otherwise grep STATE.md for (Auth posture / Assessment mode /
    OTP-assist mode). Empty on a fresh engagement (only target/slug present)."""
    if not eng.state_md.exists():
        return []
    out: List[Tuple[str, str]] = []
    in_block = False
    for ln in eng.state_md.read_text(encoding="utf-8").splitlines():
        s = ln.strip()
        if s.startswith("## "):
            in_block = s == "## Engagement"
            continue
        if not in_block:
            continue
        m = re.match(r"^-\s+([^:]+):\s*(.*)$", s)
        if m and m.group(1).strip().lower() not in _ENGAGEMENT_SKIP:
            out.append((m.group(1).strip(), m.group(2).strip()))
    return out


def _counts(idx) -> Dict[str, Dict[str, int]]:
    by_type: Dict[str, int] = {t.lower(): 0 for t in ENTITY_TYPES}
    by_status: Dict[str, Dict[str, int]] = {t.lower(): defaultdict(int) for t in ENTITY_TYPES}
    findings_by_severity: Counter = Counter()
    open_hypotheses = 0
    pending_tasks = 0
    by_workflow: Dict[str, Dict[str, int]] = defaultdict(lambda: defaultdict(int))
    archived = idx.archived_entity_ids()
    for e in idx.all_entities():
        if e.is_placeholder:
            continue
        if e.id in archived:
            continue
        t_lower = e.type.lower()
        by_type[t_lower] += 1
        status = e.bullets.get("status")
        if isinstance(status, str):
            by_status[t_lower][status] += 1
        # Workflow attribution: from the file's frontmatter.
        for f in idx.files:
            if any(en.id == e.id for en in f.entities):
                wf = f.frontmatter.get("workflow")
                if isinstance(wf, str):
                    by_workflow[wf][t_lower] += 1
                break
        if e.type == "FINDING":
            sev = e.bullets.get("severity") or "unknown"
            if isinstance(sev, str):
                findings_by_severity[sev] += 1
        if e.type == "HYPOTHESIS" and status in ("untested", "testing"):
            open_hypotheses += 1
        if e.type == "TASK" and status in ("pending", "running"):
            pending_tasks += 1
    return {
        "by_type": by_type,
        "by_status": {k: dict(v) for k, v in by_status.items()},
        "by_workflow": {k: dict(v) for k, v in by_workflow.items()},
        "findings_by_severity": dict(findings_by_severity),
        "open_hypotheses": open_hypotheses,
        "pending_tasks": pending_tasks,
    }


def _topic_summaries(idx) -> Dict[str, Dict[str, str]]:
    out: Dict[str, Dict[str, str]] = {}
    for slug, f in idx.topics.items():
        out[slug] = {
            "file": f.rel_path,
            "last_updated": str(f.frontmatter.get("last_updated", "")),
            "status": str(f.frontmatter.get("status", "")),
            "workflow": str(f.frontmatter.get("workflow", "")),
        }
    return out


def cmd_state(args) -> int:
    eng = ctx.require(args.engagement)
    target = read_target(eng.target_json)
    idx = build_index(eng)
    counts = _counts(idx)
    extras = _engagement_extras(eng)
    if getattr(args, "json", False):
        print(json.dumps({
            "engagement": eng.slug,
            "target": target,
            "engagement_fields": dict(extras),
            "counts": counts,
        }, indent=2, ensure_ascii=False))
        return 0
    print(f"engagement: {eng.slug}")
    notes = target.get("notes") or ""
    suffix = f"  (notes: {notes!r})" if notes else ""
    if target.get("base_url"):
        print(f"target: {target.get('base_url')}{suffix}")
    elif target.get("scope_in"):
        from ..scope import as_seed
        seeds = target["scope_in"]
        shown = ", ".join(f"{s['kind']}:{s['value']}" for s in map(as_seed, seeds[:6]))
        more = f" (+{len(seeds) - 6} more)" if len(seeds) > 6 else ""
        print(f"scope: {shown}{more}{suffix}")
    elif notes:
        print(f"notes: {notes!r}")
    for k, v in extras:
        print(f"  {k}: {v}")
    print()
    print("counts:")
    # Web attack-surface types first (preserves web output order), then host
    # types, then plan/record types. Zero-count types are skipped below, so a
    # web engagement renders exactly as before.
    print_order = [
        "endpoint", "route", "page", "bundle", "workflow",
        "host", "domain", "service", "webapp", "cred",
        "hypothesis", "task", "finding", "evidence", "chain", "note",
    ]
    extra = [t for t in sorted(counts["by_type"]) if t not in print_order]
    for t in print_order + extra:
        c = counts["by_type"].get(t, 0)
        if c == 0:
            continue
        bs = counts["by_status"].get(t, {})
        if bs:
            statuses = ", ".join(f"{k} {v}" for k, v in sorted(bs.items()))
            print(f"  {t:11s} {c:3d}  ({statuses})")
        else:
            print(f"  {t:11s} {c:3d}")
    # Recent log:
    if eng.log_md.exists():
        print()
        print("recent log:")
        lines = eng.log_md.read_text(encoding="utf-8").splitlines()
        headers = [ln for ln in lines if ln.startswith("## [")]
        for h in headers[-5:]:
            print(f"  {h[3:]}")
    return 0


def cmd_stats(args) -> int:
    eng = ctx.require(args.engagement)
    idx = build_index(eng)
    out = {
        **_counts(idx),
        "topics": _topic_summaries(idx),
    }
    print(json.dumps(out, indent=2, ensure_ascii=False))
    return 0
