"""kb export — render the engagement index to pre-baked .api/*.json.

Consumed by the server's REST API to show engagement progress. Runs on demand
(`kb export`) and automatically after every `kb commit` (via `auto_export`).

Principle: best-effort, never-fail. A malformed entity or missing file must
never crash the export, and `auto_export` must never fail a `kb commit`. The
three guard layers:

  1. per-entity try/except  — skip the broken item, keep going
  2. per-view try/except    — one view's failure still emits the others
  3. auto_export() wrapper  — swallows everything; the commit always wins

Output goes to `data/kb/<slug>/.api/`. Every file is written atomically
(`.tmp` then os.replace). `meta.json` is written LAST — the server polls its
mtime as the change signal, so it must appear only once the rest is on disk.
"""
from __future__ import annotations

import ipaddress
import json
import os
import re
import sys
from collections import Counter, defaultdict
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Dict, List, Tuple

from .. import ctx
from .. import target_gate
from ..ids import read_target
from ..index import build_index, Index
from ..parser import find_wikilinks
from ..schema import FINDING_STATUS_DEFAULT, fm_get


# ── Generic helpers ──────────────────────────────────────────────────

def _warn(msg: str) -> None:
    print(f"[kb export] {msg}", file=sys.stderr)


def _now() -> str:
    return datetime.now().isoformat()


def _write_json(path: Path, data: Any) -> None:
    """Atomic write: serialize to a temp file, then rename into place."""
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    os.replace(tmp, path)


def _ownership_map(eng) -> Dict[str, Dict[str, Any]]:
    """entity_id -> {created_by, touched_by[]}, derived from events.jsonl.

    created_by = the dispatch_id (subagent) whose commit first allocated the id,
    or whose integrate produced the finding/evidence. touched_by = every
    dispatch_id that created or status-flipped it. Powers the subagent-timeline
    UI's per-node entity filter. Events without a dispatch_id (main agent /
    pre-feature) are skipped.
    """
    owners: Dict[str, Dict[str, Any]] = {}
    path = eng.events_jsonl
    if not path.exists():
        return owners

    def _touch(eid: Any, did: str, created: bool) -> None:
        if not isinstance(eid, str) or not eid:
            return
        rec = owners.setdefault(eid, {"created_by": None, "touched_by": []})
        if created and rec["created_by"] is None:
            rec["created_by"] = did
        if did not in rec["touched_by"]:
            rec["touched_by"].append(did)

    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            ev = json.loads(line)
        except Exception:
            continue
        did = ev.get("dispatch_id")
        verb = ev.get("verb")
        if verb == "commit":
            # commit runs in the allocating subagent's shell (observe/reason);
            # its dispatch_id owns the ids it allocated.
            if not did:
                continue
            for eid in ev.get("ids_allocated") or []:
                _touch(eid, did, created=True)
        elif verb == "draft_integrate":
            # integrate runs in the orchestrator's shell (dispatch_id ~always
            # None). The producing probe's id rides along as owner_dispatch_id,
            # captured on the handoff at `draft commit` time; prefer it so the
            # finding/evidence are attributed to the probe, not the integrator.
            owner = ev.get("owner_dispatch_id") or did
            if not owner:
                continue
            for key in ("finding", "evidence"):
                val = ev.get(key)
                if isinstance(val, list):
                    for eid in val:
                        _touch(eid, owner, created=True)
                else:
                    _touch(val, owner, created=True)
            for eid in ev.get("status_flips") or []:
                _touch(eid, owner, created=False)
    return owners


def _attach_ownership(obj: Any, owners: Dict[str, Dict[str, Any]]) -> None:
    """Recursively stamp created_by/touched_by onto every entity dict (has 'id')."""
    if isinstance(obj, dict):
        eid = obj.get("id")
        if isinstance(eid, str) and eid in owners and "created_by" not in obj:
            obj["created_by"] = owners[eid]["created_by"]
            obj["touched_by"] = owners[eid]["touched_by"]
        for v in obj.values():
            _attach_ownership(v, owners)
    elif isinstance(obj, list):
        for v in obj:
            _attach_ownership(v, owners)


def _chain_ids(val: Any) -> List[str]:
    """Normalize a findings:/frontier: bullet (may be [[ID]] wikilinks) to an
    ordered list of plain entity ids, preserving kill-chain order."""
    ids: List[str] = []
    for item in _as_list(val):
        for m in re.finditer(r"([A-Z]+-\d+)", str(item)):
            ids.append(m.group(1))
    return ids


def _build_chains(idx) -> Dict[str, Any]:
    """CHAIN kill-chain entities (record/chains.md) — for deepening nodes.

    Exports the structure a UI graph needs: the verified `spine` (ordered
    FINDING ids = the attack path), the `frontier` (unverified next-hop
    HYPOTHESIS ids), and the raw graphviz `dot` attack-path graph carried in the
    entity body (required_fences: ["dot"]).
    """
    chains = []
    for e in _live_entities(idx):
        if getattr(e, "type", None) != "CHAIN":
            continue
        b = e.bullets or {}
        dot = None
        m = re.search(r"```dot\s*\n(.*?)```", getattr(e, "raw_block", "") or "", re.DOTALL)
        if m:
            dot = m.group(1).strip()
        # Narrative = the required prose paragraph in the body, i.e. the body
        # with all fenced code blocks (the ```dot graph) stripped out.
        prose = re.sub(r"```.*?```", "", getattr(e, "body", "") or "", flags=re.DOTALL)
        chains.append({
            "id": e.id, "title": e.title,
            "status": b.get("status") or "unknown",
            "narrative": _first_paragraph(prose),        # prose describing the path
            "spine": _chain_ids(b.get("findings")),      # ordered verified backbone
            "frontier": _chain_ids(b.get("frontier")),   # unverified next-hop hypotheses
            "dot": dot,                                   # graphviz attack-path graph
        })
    return {"chains": chains, "count": len(chains)}


def _as_str(v: Any) -> str:
    """Coerce a bullet value to a string. None → '', list → comma-joined."""
    if v is None:
        return ""
    if isinstance(v, list):
        return ", ".join(str(x) for x in v)
    return str(v)


def _as_list(v: Any) -> List[str]:
    """Coerce a bullet value to a list of strings. Handles str|list|None."""
    if isinstance(v, list):
        return [str(x) for x in v if x is not None]
    if isinstance(v, str) and v:
        return [v]
    return []


def _extract_section(text: str, heading: str) -> str:
    """Return the markdown under `## <heading>`, up to the next `## ` or EOF.

    Returns '' if absent or a placeholder like `_(none)_`.
    """
    if not text:
        return ""
    pattern = rf"^## {re.escape(heading)}\s*\n(.*?)(?=^## |\Z)"
    m = re.search(pattern, text, re.MULTILINE | re.DOTALL)
    if not m:
        return ""
    content = m.group(1).strip()
    if content in ("_(none)_", "_(none yet)_", ""):
        return ""
    return content


def _section_to_list(section_text: str) -> List[str]:
    """Parse `- item` bullet lines from a section into a list of strings."""
    if not section_text:
        return []
    items: List[str] = []
    for line in section_text.splitlines():
        line = line.strip()
        if line.startswith("- "):
            items.append(line[2:].strip())
    return items


def _first_paragraph(text: str) -> str:
    """First non-heading, non-empty block of a section (split on blank lines)."""
    if not text:
        return ""
    for block in re.split(r"\n\n+", text.strip()):
        stripped = block.strip()
        if stripped and not stripped.startswith("#"):
            return stripped
    return ""


_SEV_ORDER = {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4, "unknown": 5}


def _ordered_severity(d: Dict[str, int]) -> Dict[str, int]:
    """Re-key a severity → count map into critical→high→…→unknown order."""
    out: Dict[str, int] = {}
    for k in ("critical", "high", "medium", "low", "info", "unknown"):
        if k in d:
            out[k] = d[k]
    for k, v in d.items():
        out.setdefault(k, v)
    return out


# ── Entity selection ─────────────────────────────────────────────────

def _entity_richness(e) -> Tuple[int, int]:
    """How complete an entity looks — a non-empty title, then bullet count. Used to
    pick the surviving copy when two entities share an id (see `_live_entities`)."""
    return (1 if (e.title or "").strip() else 0, len(e.bullets))


def _bullet_has_value(v: Any) -> bool:
    """True when a bullet carries real content — not None, blank string, or empty list."""
    if v is None:
        return False
    if isinstance(v, str):
        return bool(v.strip())
    if isinstance(v, (list, tuple)):
        return any(_bullet_has_value(x) for x in v)
    return True  # int / float / bool are values


def _is_substantive(e) -> bool:
    """Whether an entity carries enough to render as more than an empty shell.

    A bare heading that reused an already-allocated id (an in-place "correction"
    block, a blank twin) has no title and no bullet values — it would only ever show
    as an all-empty row, so it is dropped: we prefer losing it to surfacing a blank
    item. SERVICE / WEBAPP additionally need an identifying field, so a note-in-
    disguise like `### SERVICE-013: 服务标识更正` with no port doesn't leak in as a
    hollow service. Deliverables (FINDING / EVIDENCE / HYPOTHESIS / …) are never
    dropped for sparseness — only the universal empty-heading floor applies to them.
    """
    has_title = bool((e.title or "").strip())
    b = e.bullets
    if not has_title and not any(_bullet_has_value(v) for v in b.values()):
        return False  # universal floor: a bare heading with nothing at all
    if e.type == "SERVICE":
        return any(_bullet_has_value(b.get(k)) for k in ("port", "proto", "name", "product"))
    if e.type == "WEBAPP":
        return has_title or _bullet_has_value(b.get("url"))
    return True


def _live_entities(idx: Index) -> List:
    """Substantive non-placeholder entities (active and archived), collapsed to one per id.

    The `report/` folder is human narration (a report draft narrates findings by
    `### FINDING-NNN` heading, which the parser would otherwise read as entities),
    so it is skipped entirely.

    Content-free / degenerate entities are dropped (`_is_substantive`): a bare
    heading that reused an id carries nothing to show, so it never becomes an empty
    row or feeds an orphan bucket — losing it beats surfacing a blank item.

    A real (non-placeholder) entity id is a unique anchor, so two entities sharing
    an id are the same logical entity — an archive copy still lingering beside the
    active one, or a malformed heading that reused an already-allocated id (e.g. an
    in-place "correction" block written as a fresh `### HOST-001:` heading). We keep
    a single representative per id: the richest (`_entity_richness` — a non-empty
    title and the most bullets win; ties keep the first seen), so a stray twin can't
    fan out into a phantom asset node or double the totals.

    Archived entities (plan/archive/) ARE included — dropping them makes
    progress/summary metrics regress as resolved hypotheses and done tasks get
    swept out. Callers classify each via `idx.archived_entity_ids()`.
    """
    root = idx.eng.root
    pos_by_id: Dict[str, int] = {}
    out: List = []
    for e in idx.all_entities():
        if e.is_placeholder:
            continue
        try:
            rel = str(e.source_file.relative_to(root)).replace("\\", "/") if e.source_file else ""
        except Exception:  # noqa: BLE001
            rel = ""
        if rel.startswith("report/"):
            continue  # report folder is narration, not entity declarations
        if not _is_substantive(e):
            continue  # phantom / hollow entity — drop rather than render an empty row
        if e.id in pos_by_id:
            i = pos_by_id[e.id]
            if _entity_richness(e) > _entity_richness(out[i]):
                out[i] = e  # keep the fuller copy, in the original position
            continue
        pos_by_id[e.id] = len(out)
        out.append(e)
    return out


# ── Counts ───────────────────────────────────────────────────────────

def _counts(idx: Index) -> Dict[str, Any]:
    by_type: Dict[str, int] = {}
    by_status: Dict[str, Dict[str, int]] = defaultdict(lambda: defaultdict(int))
    findings_by_severity: Counter = Counter()
    for e in _live_entities(idx):
        try:
            t = e.type.lower()
            by_type[t] = by_type.get(t, 0) + 1
            status = e.bullets.get("status")
            if isinstance(status, str):
                by_status[t][status] += 1
            if e.type == "FINDING":
                sev = e.bullets.get("severity") or "unknown"
                if isinstance(sev, str):
                    findings_by_severity[sev] += 1
        except Exception as exc:  # noqa: BLE001 — best-effort, skip the entity
            _warn(f"skipping {e.id} in counts: {exc}")
            continue
    return {
        "by_type": by_type,
        "by_status": {k: dict(v) for k, v in by_status.items()},
        "findings_by_severity": dict(findings_by_severity),
    }


# ── View: progress ───────────────────────────────────────────────────

def _build_progress(eng, idx, counts, target, state_text) -> Dict[str, Any]:
    by_type = counts["by_type"]
    task_status = counts["by_status"].get("task", {})
    done = task_status.get("done", 0)
    pending = task_status.get("pending", 0)
    running = task_status.get("running", 0)
    blocked = task_status.get("blocked", 0)
    total = done + pending + running + blocked
    completion_pct = int(done / total * 100) if total > 0 else 0

    stages: List[Dict[str, Any]] = []

    # Stage: recon (count-based, never keyword-parsed) — covers both the web
    # attack surface (endpoints/pages/bundles) and the host one (hosts/services/
    # webapps/domains). Pure-web engagements keep their exact prior output.
    n_ep = by_type.get("endpoint", 0)
    n_pg = by_type.get("page", 0)
    n_bd = by_type.get("bundle", 0)
    n_host = by_type.get("host", 0)
    n_svc = by_type.get("service", 0)
    n_wa = by_type.get("webapp", 0)
    n_dom = by_type.get("domain", 0)
    recon_items: List[Dict[str, Any]] = []
    if n_ep:
        recon_items.append({"id": "endpoints", "label": f"{n_ep} endpoints discovered", "status": "done"})
    if n_pg:
        recon_items.append({"id": "pages", "label": f"{n_pg} pages documented", "status": "done"})
    if n_bd:
        recon_items.append({"id": "bundles", "label": f"{n_bd} JS bundles analyzed", "status": "done"})
    if n_host:
        recon_items.append({"id": "hosts", "label": f"{n_host} hosts discovered", "status": "done"})
    if n_svc:
        recon_items.append({"id": "services", "label": f"{n_svc} services enumerated", "status": "done"})
    if n_wa:
        recon_items.append({"id": "webapps", "label": f"{n_wa} web apps identified", "status": "done"})
    if n_dom:
        recon_items.append({"id": "domains", "label": f"{n_dom} domains resolved", "status": "done"})
    web_surface = n_ep or n_pg or n_bd
    host_surface = n_host or n_svc or n_wa or n_dom
    web_summary = f"{n_ep} endpoints, {n_pg} pages, {n_bd} bundles"
    host_summary = ", ".join(p for p in (
        f"{n_host} hosts" if n_host else "",
        f"{n_svc} services" if n_svc else "",
        f"{n_wa} webapps" if n_wa else "",
        f"{n_dom} domains" if n_dom else "",
    ) if p)
    if host_surface and not web_surface:
        recon_summary = host_summary
    elif host_surface and web_surface:
        recon_summary = f"{web_summary}, {host_summary}"
    else:
        recon_summary = web_summary
    stages.append({
        "id": "recon", "label": "Information Gathering",
        "status": "complete" if (n_ep or n_pg or host_surface) else "pending",
        "summary": recon_summary,
        "items": recon_items,
    })

    # Stage: threat-model
    hyp_s = counts["by_status"].get("hypothesis", {})
    n_hyp = by_type.get("hypothesis", 0)
    stages.append({
        "id": "threat-model", "label": "Threat Modeling",
        "status": "complete" if n_hyp > 0 else "pending",
        "summary": (f"{n_hyp} hypotheses ({hyp_s.get('verified', 0)} verified, "
                    f"{hyp_s.get('refuted', 0)} refuted, {hyp_s.get('untested', 0)} untested)"),
        "items": [],
    })

    # Stage: probe — every TASK, sorted active-first then running→pending→blocked→done.
    # Archived (swept) tasks carry archived=true so the UI can group/hide them; the
    # counts below still cover them.
    archived = idx.archived_entity_ids()
    task_items: List[Dict[str, Any]] = []
    for e in _live_entities(idx):
        if e.type != "TASK":
            continue
        try:
            status = e.bullets.get("status")
            task_items.append({
                "id": e.id, "label": e.title,
                "status": status if isinstance(status, str) else "pending",
                "detail": "",
                "archived": e.id in archived,
            })
        except Exception as exc:  # noqa: BLE001
            _warn(f"skipping {e.id} in progress: {exc}")
            continue
    priority = {"running": 0, "pending": 1, "blocked": 2, "done": 3}
    task_items.sort(key=lambda t: (t["archived"], priority.get(t["status"], 99)))
    n_findings = by_type.get("finding", 0)
    # complete only when every task is genuinely done — blocked/pending/running
    # all mean work remains (a blocked task is not a finished one).
    if total > 0 and pending == 0 and running == 0 and blocked == 0:
        probe_status = "complete"
    elif done > 0:
        probe_status = "active"
    else:
        probe_status = "pending"
    stages.append({
        "id": "probe", "label": "Vulnerability Verification",
        "status": probe_status,
        "summary": f"{done}/{total} tasks done, {n_findings} findings",
        "items": task_items,
    })

    # Stage: report
    report_exists = _report_file(eng) is not None
    stages.append({
        "id": "report", "label": "Report Generation",
        "status": "complete" if report_exists else "pending",
        "summary": "Report generated" if report_exists else "Pending",
        "items": [],
    })

    notes = target.get("notes") or ""
    blockers = _section_to_list(_extract_section(state_text, "Blockers"))
    next_actions = _section_to_list(_extract_section(state_text, "Next actions"))
    # During a migration, prefer the OLD session's own progress_llm.json blockers
    # / next_actions (polished, often Chinese) over re-deriving from STATE.md —
    # old sessions want their last-known progress, not a fresh STATE.md parse.
    if _migrate_timeline_enabled():
        try:
            old = json.loads((eng.root / ".api" / "progress_llm.json").read_text(encoding="utf-8"))
            ob = [x.strip() for x in (old.get("blockers") or []) if isinstance(x, str) and x.strip()]
            on = [x.strip() for x in (old.get("next_actions") or []) if isinstance(x, str) and x.strip()]
            if ob:
                blockers = ob
            if on:
                next_actions = on
        except Exception:  # noqa: BLE001
            pass
    return {
        "engagement": {
            "slug": eng.slug,
            "target_url": target.get("base_url") or "",
            "notes": notes,
        },
        "completion_pct": completion_pct,
        # Top-level progress summary the new dashboard/API reads. Old sessions
        # never generated an LLM summary and old progress had no top-level
        # `summary`; surface the engagement notes here so old (migrated) data
        # renders in the new format (backward-compat — this is the old "note").
        "summary": notes,
        "stages": stages,
        "blockers": blockers,
        "next_actions": next_actions,
        "last_updated": _now(),
    }


# ── View: assets ─────────────────────────────────────────────────────

def _endpoint_view(ep, finding_counts) -> Dict[str, Any]:
    b = ep.bullets
    return {
        "id": ep.id,
        "method": _as_str(b.get("method")),
        "path": _as_str(b.get("path")),
        "auth": _as_str(b.get("auth")),
        "status": b.get("status") or "unknown",
        "tags": _as_list(b.get("tags")),
        "description": _as_str(b.get("description")),
        "finding_count": finding_counts.get(ep.id, 0),
    }


def _page_view(pg) -> Dict[str, Any]:
    b = pg.bullets
    return {"id": pg.id, "title": pg.title, "url": _as_str(b.get("url")),
            "status": b.get("status") or "unknown"}


def _bundle_view(bd) -> Dict[str, Any]:
    return {"id": bd.id, "filename": bd.title, "status": bd.bullets.get("status") or "unknown"}


def _service_view(svc, finding_counts) -> Dict[str, Any]:
    b = svc.bullets
    port = b.get("port")
    if not isinstance(port, int):
        port = _as_str(port)
    return {
        "id": svc.id, "label": svc.title,
        "port": port, "proto": _as_str(b.get("proto")),
        "name": _as_str(b.get("name")), "product": _as_str(b.get("product")),
        "status": b.get("status") or "unknown",
        "finding_count": finding_counts.get(svc.id, 0),
    }


def _webapp_view(wa, finding_counts) -> Dict[str, Any]:
    b = wa.bullets
    return {
        "id": wa.id, "label": wa.title, "url": _as_str(b.get("url")),
        "status": b.get("status") or "unknown",
        "service": _as_str(b.get("service")),
        "tech": _as_list(b.get("tech")),
        "finding_count": finding_counts.get(wa.id, 0),
    }


def _domain_view(d) -> Dict[str, Any]:
    b = d.bullets
    return {"id": d.id, "fqdn": _as_str(b.get("fqdn")), "label": d.title,
            "status": b.get("status") or "unknown", "parent": _as_str(b.get("parent"))}


def _url_host(url: Any) -> str:
    """Bare host from a url / ``host:port`` string — scheme, credentials, port and
    path stripped, lowercased. ``https://10.0.0.5:443/app`` → ``10.0.0.5``,
    ``[::1]:8443`` → ``::1``. Empty when there is nothing host-like."""
    s = _as_str(url).strip()
    if not s:
        return ""
    if "://" in s:
        s = s.split("://", 1)[1]
    if "@" in s:
        s = s.rsplit("@", 1)[1]
    s = s.split("/", 1)[0].split("?", 1)[0].split("#", 1)[0]
    if s.startswith("["):            # bracketed IPv6 literal: [::1]:443
        s = s[1:].split("]", 1)[0]
    elif s.count(":") == 1:          # host:port (a bare IPv6 has >1 colon)
        s = s.split(":", 1)[0]
    return s.strip().lower()


def _build_host_assets(live, by_id, finding_counts):
    """Group the host attack surface as HOST → {services, webapps}, mirroring the
    web workflow→{endpoints,…} shape. SERVICE links to its HOST via `host:`, WEBAPP
    to its SERVICE via `service:`; a WEBAPP without a service link is attached to the
    HOST whose ip/label matches the host part of its `url:`.

    Anything that resolves to no host is dropped — we never emit a synthetic 'orphan'
    host. A SERVICE with a broken `host:` link or a WEBAPP for an unknown host is left
    out rather than surfaced as an 'Unattached' bucket: per the export contract we
    prefer losing an unattachable item to showing an orphan node. (`_live_entities`
    has already dropped the empty/degenerate phantoms, so what remains is real but
    unhomed.) DOMAINs are a flat list. Returns (hosts, domains)."""
    # service id → host id (only when it resolves to a real HOST)
    svc_host: Dict[str, str] = {}
    for e in live:
        if e.type != "SERVICE":
            continue
        hid = _as_str(e.bullets.get("host"))
        if hid in by_id and by_id[hid].type == "HOST":
            svc_host[e.id] = hid

    hosts: List[Dict[str, Any]] = []
    # url-host string (ip / label) → the host node an unresolved webapp maps to
    host_by_urlkey: Dict[str, Dict[str, Any]] = {}
    for host in [e for e in live if e.type == "HOST"]:
        try:
            svcs = [s for s in live if s.type == "SERVICE" and svc_host.get(s.id) == host.id]
            svc_ids = {s.id for s in svcs}
            was = [w for w in live if w.type == "WEBAPP"
                   and _as_str(w.bullets.get("service")) in svc_ids]
            b = host.bullets
            node = {
                "id": host.id, "label": host.title, "ip": _as_str(b.get("ip")),
                "status": b.get("status") or "unknown", "os": _as_str(b.get("os")),
                "finding_count": finding_counts.get(host.id, 0),
                "services": [_service_view(s, finding_counts) for s in svcs],
                "webapps": [_webapp_view(w, finding_counts) for w in was],
            }
            hosts.append(node)
            for k in (_host_display_ip(host).lower(), (host.title or "").strip().lower()):
                if k:
                    host_by_urlkey.setdefault(k, node)
        except Exception as exc:  # noqa: BLE001
            _warn(f"skipping {host.id} in assets (host): {exc}")
            continue

    # WEBAPPs that didn't resolve through a service attach to the host whose ip/label
    # matches the url's host part; one that matches no host is dropped (no orphan
    # node). Services already sit under their host, or nowhere.
    attached_wa = {w["id"] for h in hosts for w in h["webapps"]}
    for w in [w for w in live if w.type == "WEBAPP" and w.id not in attached_wa]:
        node = host_by_urlkey.get(_url_host(w.bullets.get("url")))
        if node is not None:
            node["webapps"].append(_webapp_view(w, finding_counts))
            attached_wa.add(w.id)
        # else: unknown host → drop, rather than surface an orphan/empty item

    domains = [_domain_view(d) for d in live if d.type == "DOMAIN"]
    return hosts, domains


def _scenario_view(wf) -> Dict[str, Any]:
    """A WORKFLOW entity = a named business scenario (a flow spanning pages/
    endpoints), surfaced within its workflow area. Its relationship bullets are
    kept as ID refs for the UI to resolve."""
    b = wf.bullets
    return {
        "id": wf.id, "name": wf.title,
        "starts_at": _as_str(b.get("starts_at")),
        "status": b.get("status") or "unknown",
        "description": _as_str(b.get("description") or b.get("Description")),
        "endpoints": _as_list(b.get("endpoints")),
        "pages": _as_list(b.get("pages")),
        "bundles": _as_list(b.get("bundles")),
    }


def _build_assets(idx) -> Dict[str, Any]:
    live = _live_entities(idx)
    by_id = {e.id: e for e in live}
    by_path = {f.path: f for f in idx.files}

    # finding_count per asset id (host findings resolve via the related_assets alias).
    finding_counts: Dict[str, int] = defaultdict(int)
    for e in live:
        if e.type != "FINDING":
            continue
        for eid in _as_list(fm_get(e.bullets, "related_endpoints")):
            finding_counts[eid] += 1

    # Primary grouping is the source topic file's `workflow:` frontmatter slug —
    # the framework's own attribution (cf. kb state by_workflow / coverage), one
    # topic page per business-flow area. WORKFLOW *entities* are richer named
    # scenarios surfaced within their area, not the grouping key. Assets whose
    # file carries no slug fall to the synthetic '_orphan' area.
    def _slug(e):
        pf = by_path.get(e.source_file)
        wf = pf.frontmatter.get("workflow") if pf else None
        return wf if isinstance(wf, str) and wf else None

    area_meta: Dict[str, Dict[str, str]] = {}
    for f in idx.files:
        wf = f.frontmatter.get("workflow")
        if isinstance(wf, str) and wf and wf not in area_meta:
            area_meta[wf] = {
                "name": _as_str(f.frontmatter.get("title")) or wf,
                "status": _as_str(f.frontmatter.get("status")) or "unknown",
            }

    def _blank() -> Dict[str, Any]:
        return {"endpoints": [], "pages": [], "bundles": [], "scenarios": []}

    areas: Dict[str, Dict[str, Any]] = {}
    orphan = _blank()
    for e in live:
        if e.type not in ("ENDPOINT", "PAGE", "BUNDLE", "WORKFLOW"):
            continue
        slug = _slug(e)
        bucket = areas.setdefault(slug, _blank()) if slug else orphan
        try:
            if e.type == "ENDPOINT":
                bucket["endpoints"].append(_endpoint_view(e, finding_counts))
            elif e.type == "PAGE":
                bucket["pages"].append(_page_view(e))
            elif e.type == "BUNDLE":
                bucket["bundles"].append(_bundle_view(e))
            else:  # WORKFLOW
                bucket["scenarios"].append(_scenario_view(e))
        except Exception as exc:  # noqa: BLE001
            _warn(f"skipping {e.id} in assets: {exc}")
            continue

    workflows: List[Dict[str, Any]] = []
    for slug, b in areas.items():
        meta = area_meta.get(slug) or {"name": slug, "status": "unknown"}
        workflows.append({
            "id": slug, "name": meta["name"], "status": meta["status"],
            "endpoints": b["endpoints"], "pages": b["pages"],
            "bundles": b["bundles"], "scenarios": b["scenarios"],
        })
    if any(orphan[k] for k in orphan):
        workflows.append({
            "id": "_orphan", "name": "Uncategorized", "status": "",
            "endpoints": orphan["endpoints"], "pages": orphan["pages"],
            "bundles": orphan["bundles"], "scenarios": orphan["scenarios"],
        })

    # Host attack surface (empty for pure-web engagements).
    hosts, domains = _build_host_assets(live, by_id, finding_counts)

    # Totals count DISTINCT entities, not per-group occurrences.
    def _ntype(t: str) -> int:
        return sum(1 for e in live if e.type == t)

    return {
        "workflows": workflows,
        "hosts": hosts,
        "domains": domains,
        "totals": {
            "endpoints": _ntype("ENDPOINT"),
            "pages": _ntype("PAGE"),
            "bundles": _ntype("BUNDLE"),
            "workflows": sum(1 for w in workflows if w["id"] != "_orphan"),
            "scenarios": _ntype("WORKFLOW"),
            "hosts": _ntype("HOST"),
            "services": _ntype("SERVICE"),
            "webapps": _ntype("WEBAPP"),
            "domains": _ntype("DOMAIN"),
        },
    }


# ── Raw scanner ports (ai-pts quickref) folded into the host view ─────

def _assets_view(idx, eng) -> Dict[str, Any]:
    """The assets view with raw ai-pts quickref ports folded into hosts[].services.

    Curated hosts/services come from KB entities; the raw scanner inventory is
    merged into the single ``hosts[].services[]`` list keyed by IP then
    ``(port, proto)`` — curated content wins, the scan rides along as the flat
    ``server`` / ``banner`` fields, and a scanned port with no curated service is
    appended as a ``scanned`` entry (``id: null``). EASM mapping quickrefs then
    enrich hosts by IP with ``company`` / ``domain`` / ``is_cdn`` / ``is_private``
    (see ``_merge_mapping_meta``). Each merge is isolated in a try/except: a
    failure must never corrupt the curated assets view (the export loop would
    otherwise replace the whole view with an error stub)."""
    d = _build_assets(idx)
    try:
        _merge_raw_ports(d, eng)
    except Exception as exc:  # noqa: BLE001 — curated assets must survive raw failures
        _warn(f"raw port merge failed: {exc}")
    try:
        _merge_mapping_meta(d, eng)
    except Exception as exc:  # noqa: BLE001 — curated assets must survive raw failures
        _warn(f"mapping meta merge failed: {exc}")
    return d


def _merge_raw_ports(d: Dict[str, Any], eng) -> None:
    """Fold every ``quickref.json`` anywhere under ``raw/`` into ``d['hosts'][].services``.

    No-op when there is no ``raw/`` dir, so web sessions stay byte-identical. The
    search is a full ``raw/`` walk (not just ``raw/aipts/*/``) so quickrefs written
    under other sources or nested task dirs are still picked up; dispatch is by the
    file's contents (``assets[]`` here), not its folder name.
    Ports dedupe by ``(port, proto)`` (proto defaults to ``tcp`` — quickref omits
    it); across re-scans the longer non-empty ``server``/``title`` and the first
    non-null ``service`` win. ``os`` per host = first non-empty across tasks.
    A curated host matches a scanned IP by its ``ip`` field, or — when that bullet
    is blank — by a ``label`` that is itself a bare IP (so a host titled with its
    address but missing the ``ip:`` bullet still merges instead of forking a
    ``raw:<ip>`` twin); the blank ``ip`` is then backfilled from the scan.

    The scan folds into the curated ``services[]`` by ``(port, proto)``: curated
    content always wins; the scan's ``server`` and ``title`` attach as the flat
    ``server`` / ``banner`` fields, a blank curated ``name`` is gap-filled from the
    scan's ``service``, and a scanned port with no curated service is appended as a
    ``status: scanned`` entry (``id: null``). Once any scan is present every service
    carries ``server`` / ``banner`` keys (null when unscanned) for a stable shape.
    Hosts seen only by the scanner (no curated entity) are synthesised with id
    ``raw:<ip>`` whose ``services[]`` are entirely scan-derived. ``totals`` count
    curated entities only and are untouched. Deterministic ordering throughout; a
    single broken quickref is skipped with a warning rather than failing the merge."""
    raw_dir = eng.raw_dir
    if not raw_dir.is_dir():
        return

    # ip -> {"os": str, "source_tasks": set, "ports": {(port, proto): row}}
    raw_hosts: Dict[str, Any] = {}
    for qf in sorted(raw_dir.rglob("quickref.json")):
        try:
            qr = json.loads(qf.read_text(encoding="utf-8"))
        except Exception as exc:  # noqa: BLE001
            _warn(f"skipping {qf}: {exc}")
            continue
        task_id = qr.get("task_id")
        for asset in qr.get("assets", []) or []:
            ip = (asset.get("ip") or "").strip()
            if not ip:
                continue
            rh = raw_hosts.setdefault(ip, {"os": "", "source_tasks": set(), "ports": {}})
            if task_id is not None:
                rh["source_tasks"].add(task_id)
            if not rh["os"] and asset.get("os"):
                rh["os"] = asset["os"]
            for p in asset.get("ports", []) or []:
                port = p.get("port")
                if port is None:
                    continue
                proto = (p.get("proto") or "tcp").lower()
                key = (port, proto)
                row = {
                    "port": port, "proto": proto,
                    "service": p.get("service"),
                    "server": p.get("server"),
                    "title": p.get("title"),
                }
                cur = rh["ports"].get(key)
                if cur is None:
                    rh["ports"][key] = row
                else:  # re-scan: first non-null service; longest non-empty server/title
                    if not cur.get("service") and row.get("service"):
                        cur["service"] = row["service"]
                    for f in ("server", "title"):
                        cv, nv = cur.get(f), row.get(f)
                        if nv and (not cv or len(str(nv)) > len(str(cv))):
                            cur[f] = nv

    if not raw_hosts:
        return

    def _tasks_list(rh) -> List[Any]:
        return sorted((t for t in rh["source_tasks"] if t is not None),
                      key=lambda t: (isinstance(t, str), t))

    def _merge_services(services: List[Dict[str, Any]], rh, ip: str) -> List[Dict[str, Any]]:
        """Fold rh's scan ports into a curated services list (curated wins).

        Matched curated service: gain ``server`` (scan server) + ``banner`` (scan
        title); a blank ``name`` is filled from the scan ``service``. Scan-only
        port: appended as a ``status: scanned`` entry with ``id: null``, sorted
        after the curated services by (port, proto)."""
        by_key = {(s.get("port"), (s.get("proto") or "tcp")): s for s in services}
        for (port, proto), p in sorted(rh["ports"].items()):
            cur = by_key.get((port, proto))
            if cur is not None:
                if p.get("server"):
                    cur["server"] = p["server"]
                if p.get("title"):
                    cur["banner"] = p["title"]
                if not cur.get("name") and p.get("service"):
                    cur["name"] = p["service"]
            else:
                name = p.get("service") or ""
                label = (f"{name} on {ip}:{port}" if name else f"{ip}:{port}/{proto}") \
                    if ip else (name or f"{port}/{proto}")
                services.append({
                    "id": None, "label": label, "port": port, "proto": proto,
                    "name": name, "product": "", "status": "scanned",
                    "finding_count": 0,
                    "server": p.get("server"), "banner": p.get("title"),
                })
        return services

    def _valid_ip(s: str) -> bool:
        try:
            ipaddress.ip_address(s)
            return True
        except ValueError:
            return False

    # Index curated hosts for the join. The explicit ``ip`` bullet wins; a host
    # with a blank ``ip`` falls back to its ``label`` when that is itself a bare
    # IP — the common case where the worker put the address in the heading/title
    # but left ``ip:`` empty. Without this fallback the scan forks a duplicate
    # ``raw:<ip>`` host for a machine the KB already knows.
    hosts: List[Dict[str, Any]] = d.get("hosts") or []
    by_ip: Dict[str, Dict[str, Any]] = {}
    for h in hosts:
        ip = (h.get("ip") or "").strip()
        if ip and ip not in by_ip:
            by_ip[ip] = h
    for h in hosts:
        if (h.get("ip") or "").strip():
            continue
        label = (h.get("label") or "").strip()
        if label and label not in by_ip and _valid_ip(label):
            by_ip[label] = h

    matched: set = set()
    for ip, rh in raw_hosts.items():
        h = by_ip.get(ip)
        if h is None:
            continue
        matched.add(ip)
        h["services"] = _merge_services(h.get("services") or [], rh, ip)
        h["source_tasks"] = _tasks_list(rh)
        if not h.get("os") and rh["os"]:
            h["os"] = rh["os"]
        if not (h.get("ip") or "").strip():  # backfill the blank ip from the matched scan
            h["ip"] = ip

    # scanned IPs with no curated entity → synthesise, ordered by IP
    def _ip_key(ip: str):
        try:
            return (0, ipaddress.ip_address(ip))
        except ValueError:
            return (1, ip)

    for ip in sorted((ip for ip in raw_hosts if ip not in matched), key=_ip_key):
        rh = raw_hosts[ip]
        hosts.append({
            "id": f"raw:{ip}", "label": ip, "ip": ip,
            "status": "scanned", "os": rh["os"] or "",
            "finding_count": 0, "services": _merge_services([], rh, ip), "webapps": [],
            "source_tasks": _tasks_list(rh),
        })

    # stable flat scan fields on every service once any scan is present
    for h in hosts:
        for s in h.get("services") or []:
            s.setdefault("server", None)
            s.setdefault("banner", None)

    d["hosts"] = hosts


# ── EASM mapping metadata (ai-pts mapping quickref) folded into hosts ──

def _merge_mapping_meta(d: Dict[str, Any], eng) -> None:
    """Enrich ``d['hosts'][]`` with EASM mapping metadata by IP.

    A mapping ``quickref.json`` (schema ``mapping-quickref/v1``) anywhere under
    ``raw/`` is an external asset-survey inventory: an ``ips[]`` array whose rows carry
    ``company`` / ``domains`` / ``is_cdn`` / ``is_private`` / ``port_count`` /
    ``alive_count`` per IP. We attach ``company`` / ``domain`` / ``is_cdn`` /
    ``is_private`` (+ ``easm_port_count`` / ``easm_alive_count``) to any host that
    matches by IP, and fold the mapping task id into ``source_tasks``.

    Enrichment only — the EASM inventory can be hundreds of mostly-unprobed IPs,
    so mapping-only IPs are NOT synthesised into host cards (that stays the job of
    curated HOST entities + the asset-scan merge). Once any mapping data is
    present every host carries the fields (null/empty when unmatched) for a stable
    shape. No-op when there is no mapping quickref, so non-EASM sessions are
    byte-identical. Across re-runs the first non-empty value per field wins; a
    single broken quickref is skipped with a warning."""
    raw_dir = eng.raw_dir
    if not raw_dir.is_dir():
        return

    by_ip: Dict[str, Any] = {}
    for qf in sorted(raw_dir.rglob("quickref.json")):
        try:
            qr = json.loads(qf.read_text(encoding="utf-8"))
        except Exception as exc:  # noqa: BLE001
            _warn(f"skipping {qf}: {exc}")
            continue
        if qr.get("schema") != "mapping-quickref/v1" and "ips" not in qr:
            continue  # not a mapping quickref
        task_id = qr.get("task_id")
        for row in qr.get("ips", []) or []:
            ip = (row.get("ip") or "").strip()
            if not ip:
                continue
            m = by_ip.setdefault(ip, {
                "company": "", "domain": "", "is_cdn": None, "is_private": None,
                "easm_port_count": None, "easm_alive_count": None, "source_tasks": set(),
            })
            if task_id is not None:
                m["source_tasks"].add(task_id)
            if not m["company"] and row.get("company"):
                m["company"] = row["company"]
            if not m["domain"] and row.get("domains"):
                m["domain"] = row["domains"]
            for f in ("is_cdn", "is_private"):
                if m[f] is None and isinstance(row.get(f), bool):
                    m[f] = row[f]
            for src, dst in (("port_count", "easm_port_count"), ("alive_count", "easm_alive_count")):
                if m[dst] is None and isinstance(row.get(src), int):
                    m[dst] = row[src]

    if not by_ip:
        return

    _META_KEYS = ("company", "domain", "is_cdn", "is_private",
                  "easm_port_count", "easm_alive_count")
    for h in d.get("hosts") or []:
        ip = (h.get("ip") or "").strip()
        if not ip:  # blank ip bullet — fall back to an IP-shaped label
            label = (h.get("label") or "").strip()
            ip = label if _ipish(label) else ""
        meta = by_ip.get(ip)
        if meta is None:
            for k in _META_KEYS:  # stable shape
                h.setdefault(k, "" if k in ("company", "domain") else None)
            continue
        for k in _META_KEYS:
            h[k] = meta[k]
        merged = set(h.get("source_tasks") or []) | meta["source_tasks"]
        h["source_tasks"] = sorted(merged, key=lambda t: (isinstance(t, str), t))


# ── View: hypotheses ─────────────────────────────────────────────────

def _build_hypotheses(idx, counts) -> Dict[str, Any]:
    archived = idx.archived_entity_ids()
    hypotheses, tasks = [], []
    n_arch_hyp = n_arch_task = 0
    for e in _live_entities(idx):
        try:
            b = e.bullets
            is_arch = e.id in archived
            if e.type == "HYPOTHESIS":
                hypotheses.append({
                    "id": e.id, "title": e.title,
                    "targets": _as_list(b.get("targets")),
                    "class": _as_str(b.get("class")),
                    "severity_guess": _as_str(b.get("severity_guess")),
                    "status": b.get("status") or "unknown",
                    "evidence": _as_list(b.get("evidence")),
                    "finding_id": _as_str(b.get("promoted_to")),
                    "archived": is_arch,
                })
                n_arch_hyp += is_arch
            elif e.type == "TASK":
                tasks.append({
                    "id": e.id, "title": e.title,
                    "hypothesis_id": _as_str(b.get("hypothesis")),
                    "skill": _as_str(b.get("skill")),
                    "playbook": _as_str(b.get("playbook")),
                    "status": b.get("status") or "unknown",
                    "evidence": _as_list(b.get("evidence")),
                    "archived": is_arch,
                })
                n_arch_task += is_arch
        except Exception as exc:  # noqa: BLE001
            _warn(f"skipping {e.id} in hypotheses: {exc}")
            continue
    # Active first, archived (resolved) last — the UI groups/hides on the flag.
    hypotheses.sort(key=lambda h: h["archived"])
    tasks.sort(key=lambda t: t["archived"])
    hs = counts["by_status"].get("hypothesis", {})
    ts = counts["by_status"].get("task", {})
    return {
        "hypotheses": hypotheses,
        "tasks": tasks,
        "summary": {
            "total_hypotheses": len(hypotheses),
            "verified": hs.get("verified", 0),
            "refuted": hs.get("refuted", 0),
            "untested": hs.get("untested", 0),
            "archived_hypotheses": n_arch_hyp,
            "total_tasks": len(tasks),
            "done": ts.get("done", 0),
            "pending": ts.get("pending", 0),
            "blocked": ts.get("blocked", 0),
            "archived_tasks": n_arch_task,
        },
    }


# ── Finding helpers: resolve related assets, collect evidence ids ─────

def _ipish(s: str) -> bool:
    try:
        ipaddress.ip_address(s)
        return True
    except ValueError:
        return False


def _host_display_ip(host) -> str:
    """A HOST's display IP: its ``ip`` bullet, or its title/label when that is
    itself a bare IP (the worker often puts the address only in the heading)."""
    ip = _as_str(host.bullets.get("ip"))
    if ip:
        return ip
    label = (host.title or "").strip()
    return label if _ipish(label) else ""


def _resolve_asset(by_id: Dict[str, Any], aid: str) -> Dict[str, Any]:
    """Resolve a related-asset ID to ``{id, type, url, title}`` for display.

    ``url`` is a human pointer: ENDPOINT ``"METHOD /path"``; PAGE/BUNDLE/WEBAPP
    its ``url`` bullet; SERVICE ``"ip:port/proto"`` (ip resolved via the SERVICE's
    ``host``→HOST); HOST its IP; DOMAIN its fqdn. An unknown id resolves to empty
    url/title so the reference still renders."""
    e = by_id.get(aid)
    if e is None:
        return {"id": aid, "type": "", "url": "", "title": ""}
    b = e.bullets
    t = e.type
    url = ""
    if t == "ENDPOINT":
        url = f"{_as_str(b.get('method'))} {_as_str(b.get('path'))}".strip()
    elif t in ("PAGE", "BUNDLE", "WEBAPP"):
        url = _as_str(b.get("url"))
    elif t == "SERVICE":
        host = by_id.get(_as_str(b.get("host")))
        ip = _host_display_ip(host) if host is not None and host.type == "HOST" else ""
        port, proto = _as_str(b.get("port")), _as_str(b.get("proto"))
        if ip and port:
            url = f"{ip}:{port}" + (f"/{proto}" if proto else "")
    elif t == "HOST":
        url = _host_display_ip(e)
    elif t == "DOMAIN":
        url = _as_str(b.get("fqdn"))
    return {"id": aid, "type": t.lower(), "url": url, "title": e.title}


def _finding_evidence_ids(e) -> List[str]:
    """A finding's evidence IDs: the ``evidence:`` frontmatter list UNIONed with
    any ``[[EVIDENCE-*]]`` wikilinks in the body (deduped, frontmatter first).

    Reading frontmatter alone misses evidence linked only in the body — e.g. the
    ``## Evidence`` section `kb promote` writes, or an inline reference in
    Reproduction. Both are authoritative ways to cite evidence, so we union them."""
    ids = _as_list(e.bullets.get("evidence"))
    seen = set(ids)
    for ref in find_wikilinks(e.body or ""):
        tgt = ref.target.strip()
        if tgt.upper().startswith("EVIDENCE-") and tgt not in seen:
            seen.add(tgt)
            ids.append(tgt)
    return ids


# ── View: findings (list) ────────────────────────────────────────────

def _build_findings(idx, counts) -> Dict[str, Any]:
    live = _live_entities(idx)
    by_id = {e.id: e for e in live}
    findings = []
    by_status: Counter = Counter()
    for e in live:
        if e.type != "FINDING":
            continue
        try:
            b = e.bullets
            related_ids = _as_list(fm_get(b, "related_endpoints"))
            # Triage status is optional frontmatter; legacy findings that predate
            # the field surface as the default so consumers always see a value.
            status = _as_str(b.get("status")) or FINDING_STATUS_DEFAULT
            by_status[status] += 1
            findings.append({
                "id": e.id, "title": e.title,
                "severity": b.get("severity") or "unknown",
                "status": status,
                "cvss_score": b.get("cvss_score"),
                "cvss_vector": _as_str(b.get("cvss_vector")),
                "related_endpoints": related_ids,
                "related_assets": [_resolve_asset(by_id, aid) for aid in related_ids],
                "hypothesis_id": _as_str(b.get("hypothesis")),
                "tags": _as_list(b.get("tags")),
                "created": _as_str(b.get("created")),
                "impact_summary": _first_paragraph(_extract_section(e.body or "", "Impact")),
                "evidence_ids": _finding_evidence_ids(e),
            })
        except Exception as exc:  # noqa: BLE001
            _warn(f"skipping {e.id} in findings: {exc}")
            continue
    findings.sort(key=lambda f: _SEV_ORDER.get(f["severity"], 99))
    return {
        "findings": findings,
        "by_severity": _ordered_severity(counts.get("findings_by_severity", {})),
        "by_status": dict(by_status),
    }


# ── View: report ─────────────────────────────────────────────────────

def _report_file(eng):
    """The engagement's report markdown — Chinese-named under report/ (glob; one expected)."""
    d = eng.report_dir
    if not d.is_dir():
        return None
    mds = sorted(d.glob("*.md"))
    return mds[0] if mds else None


def report_view(path: Path | None) -> Dict[str, Any]:
    """The `.api/report.json` document for one markdown file, or the empty view."""
    if path is None or not path.is_file():
        return {"exists": False, "content": "", "last_updated": "", "size": 0}
    try:
        content = path.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError) as exc:
        _warn(f"report read failed: {exc}")
        return {"exists": False, "content": "", "last_updated": "", "size": 0}
    st = path.stat()
    return {
        "exists": True,
        "content": content,
        "last_updated": datetime.fromtimestamp(st.st_mtime).isoformat(),
        "size": st.st_size,
    }


def _build_report(eng) -> Dict[str, Any]:
    return report_view(_report_file(eng))


def publish_report_view(eng_root: Path, report_path: Path | None) -> None:
    """Write only `.api/report.json`.

    `report validate` calls this when the gate passes, so the report is visible
    before the next `kb commit` runs a full export. A `None` path records
    `exists: false`.
    """
    api = Path(eng_root) / ".api"
    api.mkdir(parents=True, exist_ok=True)
    _write_json(api / "report.json", report_view(report_path))


# ── Detail files: findings/ and evidence/ ────────────────────────────

def _write_finding_details(api_dir: Path, idx) -> None:
    live = _live_entities(idx)
    by_id = {e.id: e for e in live}
    for e in live:
        if e.type != "FINDING":
            continue
        try:
            b = e.bullets
            body = e.body or ""
            related_ids = _as_list(fm_get(b, "related_endpoints"))
            _write_json(api_dir / "findings" / f"{e.id}.json", {
                "id": e.id, "title": e.title,
                "severity": b.get("severity") or "unknown",
                "status": _as_str(b.get("status")) or FINDING_STATUS_DEFAULT,
                "cvss_score": b.get("cvss_score"),
                "cvss_vector": _as_str(b.get("cvss_vector")),
                "related_endpoints": related_ids,
                "related_assets": [_resolve_asset(by_id, aid) for aid in related_ids],
                "tags": _as_list(b.get("tags")),
                # `content` is the authoritative, complete finding body — findings
                # are free-form agent markdown, so their section structure is not
                # guaranteed. impact/reproduction/recommendation below are a
                # best-effort convenience extraction (empty when the agent used
                # other / localized headings); consumers should prefer `content`.
                "content": body,
                "impact": _extract_section(body, "Impact"),
                "reproduction": _extract_section(body, "Reproduction"),
                "recommendation": _extract_section(body, "Recommendation"),
                "evidence_ids": _finding_evidence_ids(e),
            })
        except Exception as exc:  # noqa: BLE001
            _warn(f"skipping finding detail {e.id}: {exc}")
            continue


def _write_evidence_details(api_dir: Path, idx) -> None:
    for e in _live_entities(idx):
        if e.type != "EVIDENCE":
            continue
        try:
            b = e.bullets
            body = e.body or ""
            _write_json(api_dir / "evidence" / f"{e.id}.json", {
                "id": e.id, "title": e.title,
                "captured_at": _as_str(b.get("captured_at")),
                "actor": _as_str(b.get("actor")),
                "related_endpoint": _as_str(fm_get(b, "related_endpoint")),
                "claim": _extract_section(body, "Claim"),
                "probe": _extract_section(body, "Probe"),
                "body": body,
            })
        except Exception as exc:  # noqa: BLE001
            _warn(f"skipping evidence detail {e.id}: {exc}")
            continue


# ── Asset-memory harvest ─────────────────────────────────────────────
#
# Deterministic collection of the engagement's already-structured signals
# (waf-blocked NOTEs, transport recipes, pivot artifacts, blocked work, the
# auth posture) into .api/asset_memory_harvest.json. The server-side
# consolidation task reads this file when merging cross-session asset
# memory — no LLM discovery happens here and nothing is POSTed anywhere:
# harvest material only reaches memory via consolidation.

_HARVEST_MAX_SIGNALS = 60

# Cap on fingerprint signals so one wide sweep (a whole /24 of SERVICES) cannot
# starve the other harvest sources of slots.
_HOST_FINGERPRINT_MAX = 20

_HARVEST_STATEMENT_MAX = 300


def _truncate_statement(statement: str, limit: int = _HARVEST_STATEMENT_MAX) -> str:
    """Cut at a sentence boundary when the statement overflows.

    A mid-word hard slice (`statement[:300]`) put half-sentences into the
    merged memory (2026-09-14: `...新增 9 个命中:cmdi-00 的 00015/`). Prefer the
    last terminator within the window; hard-cut with an ellipsis when the
    boundary sits too early.
    """
    if len(statement) <= limit:
        return statement
    window = statement[:limit]
    cut = -1
    for sep in ("。", "；", "！", "？", "!", "?", ";", "."):
        idx = window.rfind(sep)
        cut = max(cut, idx)
    if cut >= limit // 2:
        return window[: cut + 1]
    return window[: limit - 1].rstrip() + "…"


# Workers write "no new recipe" bookkeeping into STATE ## Transport recipes —
# `(none) — 复用已有 <recipe>,无新手法` / `(none)  — 本 task 为普通 curl 明文请求`.
# Those are process logs, not knowledge; harvesting them produced the junk half
# of the 2026-09-14 merge (11 "复用已有…" entries landed in the memory store).
# integrate drops BARE `(none)` lines; this filter is the belt for legacy
# STATEs and for note-suffixed forms.
_NOOP_RECIPE_PREFIX_RE = re.compile(
    r"^(?:_?\((?:none|无)\)_?\s*[—–\-:：]?\s*|复用已有|无新签名|无新手法)",
    re.IGNORECASE,
)


def _is_noop_recipe_line(text: str) -> bool:
    """True for 'no new recipe / reused existing' bookkeeping lines."""
    return bool(_NOOP_RECIPE_PREFIX_RE.match((text or "").strip()))


def _asset_memory_harvest_signal(
    category: str, statement: str, anchor: str = "_asset",
    confidence: str = "medium", evidence_ref: str | None = None,
    tags: List[str] | None = None, slug: str | None = None,
) -> Dict[str, Any] | None:
    """Shape + guard one signal; returns None for secret-leaking junk."""
    from .. import asset_memory as _am

    statement = (statement or "").strip().replace("\n", " ")
    if len(statement) < 8:
        return None
    if _am.secret_leak(statement):
        return None  # never hand credential-shaped text to the memory store
    sig: Dict[str, Any] = {
        "category": category,
        "anchor": (anchor or "_asset")[:120],
        "statement": _truncate_statement(statement),
        "confidence": confidence,
        "evidence_ref": evidence_ref,
        "tags": (tags or [])[:6],
    }
    if slug:
        sig["slug"] = slug  # per-asset pre-attribution (host multi-IP harvests)
    return sig


def _build_asset_memory_harvest(
    eng, idx: Index, target: Dict[str, Any], state_text: str,
    assets_data: Dict[str, Any],
) -> Dict[str, Any] | None:
    from .. import asset_memory as _am

    if not _am.enabled():
        # Kill switch: remove the file outright. A bare skip would leave a
        # stale harvest from an earlier ENABLED export for the server to
        # consolidate at report time; the server reads a missing file and the
        # old empty shape identically (`readHarvest` → null).
        try:
            (eng.root / ".api" / "asset_memory_harvest.json").unlink(missing_ok=True)
        except OSError as exc:  # noqa: BLE001 — never fail the export
            _warn(f"harvest unlink failed: {exc}")
        return None

    from ..verbs.pivot import _current as _pivot_current

    assets = target_gate.collect_from_export(assets_data, target)
    signals: List[Dict[str, Any]] = []

    # 1. waf-blocked / WAF-feature NOTEs → defense knowledge
    for n in idx.by_type.get("NOTE", []):
        if getattr(n, "is_placeholder", False):
            continue
        title = (n.title or "").strip().lower()
        body = n.body or ""
        is_waf = (
            title.startswith("waf-blocked")
            or any(ln.strip().lower().startswith("waf-blocked:") for ln in body.splitlines())
            or any(
                ln.strip().lower().startswith("system-feature:") and "waf" in ln.lower()
                for ln in body.splitlines()
            )
        )
        if not is_waf:
            continue
        sig = _asset_memory_harvest_signal(
            "defense", body.strip() or title, evidence_ref=str(n.id), tags=["waf"],
        )
        if sig:
            signals.append(sig)

    # 2. STATE ## Transport recipes → transport knowledge. Skip "no new recipe"
    #    bookkeeping (`(none) — 复用已有 …,无新手法`) — see _is_noop_recipe_line.
    for line in _section_to_list(_extract_section(state_text, "Transport recipes")):
        content = re.sub(r"^transport-recipe:\s*", "", line, flags=re.IGNORECASE)
        if _is_noop_recipe_line(content):
            continue
        sig = _asset_memory_harvest_signal(
            "transport", content, tags=["transport-recipe"],
        )
        if sig:
            signals.append(sig)

    # 3. Pivot registry (latest-per-name) → transport / structural knowledge
    try:
        for name, rec in sorted(_pivot_current(eng).items()):
            kind = str(rec.get("kind") or "")
            category = "transport" if kind == "transport" else "vuln-structure"
            desc = str(rec.get("desc") or rec.get("run") or name)
            sig = _asset_memory_harvest_signal(
                category, f"pivot {name}: {desc}",
                evidence_ref=f"pivot/{name}",
                confidence="high" if rec.get("status") == "verified" else "medium",
                tags=["pivot", kind] if kind else ["pivot"],
            )
            if sig:
                signals.append(sig)
    except Exception as exc:  # noqa: BLE001 — pivot registry is optional input
        _warn(f"asset-memory harvest pivot scan failed: {exc}")

    # 4. Blocked hypotheses/tasks → dead-end knowledge. A blocked HYPOTHESIS and
    #    its probe TASK share title+reason (the task inherits both), so an
    #    emit-per-entity loop duplicated every blocked item (2026-09-14: 10
    #    pairs → 20 near-identical signals the merge could not dedupe). Group by
    #    normalized title, keep ONE signal, join the evidence ids.
    blocked: List[Dict[str, Any]] = []
    for etype in ("HYPOTHESIS", "TASK"):
        for e in idx.by_type.get(etype, []):
            status = str((e.bullets or {}).get("status") or "").strip().lower()
            if status != "blocked":
                continue
            bullets = e.bullets or {}
            reason = ""
            for key in ("blocker", "blocker-reason", "blocked-reason"):
                if bullets.get(key):
                    reason = str(bullets[key]).strip()
                    break
            blocked.append({
                "id": str(e.id),
                "title": (e.title or "").strip(),
                "reason": reason,
            })

    merged_blocked: Dict[str, Dict[str, Any]] = {}
    for item in blocked:
        key = re.sub(r"\s+", " ", item["title"]).strip().lower()
        grp = merged_blocked.get(key)
        if grp is None:
            merged_blocked[key] = {
                "title": item["title"], "reason": item["reason"],
                "ids": [item["id"]],
            }
        else:
            grp["ids"].append(item["id"])
            if not grp["reason"] and item["reason"]:
                grp["reason"] = item["reason"]

    for grp in merged_blocked.values():
        stmt = f"blocked: {grp['title']}"
        if grp["reason"]:
            stmt += f" — {grp['reason']}"
        sig = _asset_memory_harvest_signal(
            "dead-end", stmt, evidence_ref=" / ".join(grp["ids"]),
        )
        if sig:
            signals.append(sig)

    # 5. Auth posture → auth-fact
    m = re.search(r"^- Auth posture:\s*(.+)$", state_text, re.MULTILINE | re.IGNORECASE)
    if m:
        sig = _asset_memory_harvest_signal("auth-fact", f"Auth posture: {m.group(1).strip()}",
                                           confidence="high", tags=["auth-posture"])
        if sig:
            signals.append(sig)

    # ── Host-runtime sources (6–8). Web engagements never emit HOST/SERVICE/
    # CRED entities, so these yield zero signals there and the output above
    # stays unchanged.
    by_id = {e.id: e for e in _live_entities(idx)}

    def _target_ip(aid: str) -> str:
        """Resolve a related-asset id to a display IP (HOST itself, or the IP
        of the HOST a SERVICE hangs off)."""
        t = by_id.get(aid)
        if t is None:
            return ""
        if t.type == "HOST":
            return _host_display_ip(t)
        if t.type == "SERVICE":
            th = by_id.get(_as_str(t.bullets.get("host")))
            if th is not None and th.type == "HOST":
                return _host_display_ip(th)
        return ""

    # 6. SERVICE fingerprints → concept (conceptual identification, not a
    #    behavior quirk; change-detection baseline: a revisit re-verifies the
    #    version still matches before trusting the memory).
    fingerprints: List[Dict[str, Any]] = []
    for order, s in enumerate(idx.by_type.get("SERVICE", [])):
        if getattr(s, "is_placeholder", False):
            continue
        b = s.bullets
        product, version = _as_str(b.get("product")), _as_str(b.get("version"))
        if not product and not version:
            continue  # name alone is too weak to be a baseline
        ip = _target_ip(_as_str(b.get("host")))
        if not ip:
            continue  # no orphan attribution
        anchor = f"{_as_str(b.get('proto'))}/{_as_str(b.get('port'))}"
        banner = " ".join(x for x in (_as_str(b.get("name")), product, version) if x)
        fingerprints.append({
            "both": bool(product and version),
            "order": order,
            "sig": _asset_memory_harvest_signal(
                "concept", f"fingerprint: {ip} {anchor} = {banner}",
                anchor=anchor, evidence_ref=str(s.id), tags=["fingerprint"],
                slug=_am_slug({"value": ip}) or None,
            ),
        })
    fingerprints.sort(key=lambda f: (not f["both"], f["order"]))
    for f in fingerprints[:_HOST_FINGERPRINT_MAX]:
        if f["sig"]:
            signals.append(f["sig"])

    # 7. Refuted default/weak-credential hypotheses → dead-end knowledge
    #    (bruteforce / credential sweeps that came up empty on this host).
    for h in idx.by_type.get("HYPOTHESIS", []):
        b = h.bullets
        status = _as_str(b.get("status")).strip().lower()
        hclass = _as_str(b.get("class")).strip().lower()
        if status != "refuted" or hclass not in ("default-credentials", "weak-credentials"):
            continue
        slug = ""
        for aid in _as_list(b.get("targets")):
            ip = _target_ip(aid if isinstance(aid, str) else str(aid))
            if ip:
                slug = _am_slug({"value": ip})
                break
        sig = _asset_memory_harvest_signal(
            "dead-end", f"{hclass} sweep refuted: {(h.title or '').strip()}",
            evidence_ref=str(h.id), tags=["bruteforce"], slug=slug or None,
        )
        if sig:
            signals.append(sig)

    # 8. CRED inventory → auth-fact reuse-pattern signal. Metadata only — the
    #    value_hash is never read; the secret guard is the backstop for free-
    #    text `source:` fields.
    creds = [c for c in idx.by_type.get("CRED", [])
             if not getattr(c, "is_placeholder", False)]
    if creds:
        by_kind: Counter = Counter()
        reused = 0
        for c in creds:
            cb = c.bullets
            by_kind[_as_str(cb.get("kind")) or "unknown"] += 1
            if _as_str(cb.get("status")) in ("validated", "used-for"):
                reused += 1
        kinds = ", ".join(f"{k}×{n}" for k, n in by_kind.most_common())
        sig = _asset_memory_harvest_signal(
            "auth-fact",
            f"cred inventory: {len(creds)} captured ({kinds}), "
            f"{reused} validated/reused — check reuse pattern for cross-host login",
            confidence="medium", tags=["cred-inventory"],
        )
        if sig:
            signals.append(sig)
        for c in creds:
            cb = c.bullets
            if _as_str(cb.get("status")) not in ("validated", "used-for"):
                continue
            sig = _asset_memory_harvest_signal(
                "auth-fact",
                f"cred kind={_as_str(cb.get('kind'))} from {_as_str(cb.get('source'))} "
                f"{_as_str(cb.get('status'))} (reusable)",
                evidence_ref=str(c.id), tags=["cred"],
            )
            if sig:
                signals.append(sig)

    return {
        "generated_at": _now(),
        "engagement": eng.slug,
        "assets": [
            {"kind": a["kind"], "value": a["value"]}
            | {"slug": _am_slug(a)}
            for a in assets
        ],
        "signals": signals[:_HARVEST_MAX_SIGNALS],
    }


def _am_slug(a: Dict[str, str]) -> str:
    """Slug computed on THIS side so TS never has to reimplement it."""
    from .. import asset_memory as _am

    resolved = _am.resolve_slug(a["value"])
    return resolved[0] if resolved else ""


# ── Timeline backfill (migration only) ───────────────────────────────
# Old sessions predate the subagent-timeline; the server writes .api/timeline.json
# and never did for them, so the timeline panel is empty. During a RUNTIME
# MIGRATION only (env KB_MIGRATE_TIMELINE=1, set by the server's migrateOne), and
# only when there is NO timeline yet, synthesize one node per progress stage so
# old data renders. This is one-shot: once timeline.json exists, a later export /
# migration is a no-op, and a live session's real timeline is never touched.

_STAGE_STATUS_TO_NODE = {"complete": "finished", "active": "running", "pending": "pending"}
# Each progress stage → a real timeline task_type (drives the node's color and
# localized label 观察/推理/探测/报告) + a Chinese title, so synthesized nodes
# match real subagent nodes instead of a generic English "stage".
_STAGE_TO_NODE = {
    "recon": ("observe", "信息收集"),
    "threat-model": ("reason", "威胁建模"),
    "probe": ("probe", "漏洞验证"),
    "report": ("report", "报告生成"),
}


def _migrate_timeline_enabled() -> bool:
    return (os.environ.get("KB_MIGRATE_TIMELINE") or "").strip().lower() in (
        "1", "true", "yes", "on",
    )


def _maybe_backfill_timeline(api_dir: Path, progress: Dict[str, Any]) -> None:
    """Synthesize .api/timeline.json ({nodes:{}}) from the 4 progress stages.
    Best-effort; never raises. Guards: migration flag + timeline.json absent."""
    try:
        if not _migrate_timeline_enabled():
            return
        timeline_path = api_dir / "timeline.json"
        if timeline_path.exists():
            return  # real or previously-backfilled timeline — never clobber
        stages = (progress or {}).get("stages") or []
        if not stages:
            return
        last_updated = (progress or {}).get("last_updated") or _now()
        try:
            base = datetime.fromisoformat(str(last_updated).replace("Z", "+00:00"))
        except Exception:  # noqa: BLE001
            base = datetime.now()
        # Prefer the OLD session's per-stage progress summaries (often Chinese,
        # from the LLM progress_llm.json) over the deterministic English ones.
        old_summaries: Dict[str, str] = {}
        try:
            old = json.loads((api_dir / "progress_llm.json").read_text(encoding="utf-8"))
            for ost in (old.get("stages") or []):
                osid = str(ost.get("id") or "")
                osum = ost.get("summary")
                if osid and isinstance(osum, str) and osum.strip():
                    old_summaries[osid] = osum.strip()
        except Exception:  # noqa: BLE001
            pass
        nodes: Dict[str, Any] = {}
        for i, st in enumerate(stages):
            sid = str(st.get("id") or f"stage{i}")
            status = _STAGE_STATUS_TO_NODE.get(str(st.get("status")), "pending")
            task_type, title_zh = _STAGE_TO_NODE.get(sid, ("worker", st.get("label") or sid))
            node: Dict[str, Any] = {
                "id": f"stage-{sid}",
                "task_type": task_type,
                "description": title_zh,
                "result_zh": old_summaries.get(sid) or (st.get("summary") or ""),
                "status": status,
                # Ordered synthetic timestamps so /kb/timeline sorts recon→…→report.
                "started_at": (base + timedelta(seconds=i)).isoformat(),
            }
            if status == "finished":
                node["ended_at"] = str(last_updated)
            nodes[node["id"]] = node
        if nodes:
            _write_json(timeline_path, {"nodes": nodes})
    except Exception as exc:  # noqa: BLE001
        _warn(f"timeline backfill failed: {exc}")


# ── Orchestration ────────────────────────────────────────────────────

def export(eng):
    """Render the engagement to data/kb/<slug>/.api/ and run the target gate.

    Returns the ``GateResult`` (or ``None`` when the index could not be built /
    the gate errored), so the explicit ``kb export`` CLI can exit non-zero when
    the session is forbidden. Raises only on truly unexpected failures
    (auto_export swallows those for the commit hook)."""
    api_dir = eng.root / ".api"

    # If the index itself can't be built we still emit meta.json so the server
    # gets a fresh change signal rather than reading stale data forever.
    try:
        idx = build_index(eng)
    except Exception as exc:  # noqa: BLE001
        _warn(f"build_index failed: {exc}")
        try:
            api_dir.mkdir(parents=True, exist_ok=True)
            _write_json(api_dir / "meta.json", {"timestamp": _now(), "slug": eng.slug, "version": 1})
        except Exception:  # noqa: BLE001
            pass
        return

    counts = _counts(idx)
    target = _safe_read_target(eng)
    state_text = _safe_read_state(eng)

    api_dir.mkdir(parents=True, exist_ok=True)
    (api_dir / "findings").mkdir(exist_ok=True)
    (api_dir / "evidence").mkdir(exist_ok=True)

    # Build the assets view once — it feeds both assets.json and the target gate
    # (which counts distinct IP/host/domain across sessions).
    try:
        assets_data = _assets_view(idx, eng)
    except Exception as exc:  # noqa: BLE001
        assets_data = {"error": str(exc), "partial": True}
        _warn(f"assets view failed: {exc}")

    # Ownership map (entity id -> the subagent that created/touched it), derived
    # from events.jsonl, attached to every entity dict for the timeline UI's
    # per-node entity filter.
    owners = _ownership_map(eng)
    views = [
        ("progress", lambda: _build_progress(eng, idx, counts, target, state_text)),
        ("assets", lambda: assets_data),
        ("hypotheses", lambda: _build_hypotheses(idx, counts)),
        ("findings", lambda: _build_findings(idx, counts)),
        ("chains", lambda: _build_chains(idx)),
        ("report", lambda: _build_report(eng)),
        # Cross-session asset-memory harvest — feeds the server-side
        # consolidation task (.api/asset_memory_harvest.json).
        ("asset_memory_harvest",
         lambda: _build_asset_memory_harvest(eng, idx, target, state_text, assets_data)),
    ]
    # progress.json is owned by the LLM progress side-agent. The deterministic
    # export BOOTSTRAPS it and keeps it fresh until the model first takes over:
    # the LLM writes a STAGE-LESS summary, so an existing progress.json that
    # still carries a `stages` array is ours to refresh; once the LLM has
    # overwritten it (no `stages`), we back off and never clobber the model's
    # estimate. A migration always force-rewrites (to repair an old-format file).
    llm_owns_progress = False
    try:
        existing = json.loads((api_dir / "progress.json").read_text(encoding="utf-8"))
        llm_owns_progress = isinstance(existing, dict) and "stages" not in existing
    except Exception:  # noqa: BLE001
        llm_owns_progress = False  # absent/unreadable → safe to (re)write
    write_progress = _migrate_timeline_enabled() or not llm_owns_progress
    progress_data: Dict[str, Any] = {}
    for name, builder in views:
        try:
            data = builder()
        except Exception as exc:  # noqa: BLE001
            data = {"error": str(exc), "partial": True}
            _warn(f"{name} view failed: {exc}")
        if data is None:
            continue  # builder removed its own (stale) file — nothing to write
        if name == "progress" and isinstance(data, dict):
            progress_data = data  # still captured (for the migration timeline backfill)
            if not write_progress:
                continue  # LLM owns the live progress.json — don't clobber it
        _attach_ownership(data, owners)
        _write_json(api_dir / f"{name}.json", data)

    _write_finding_details(api_dir, idx)
    _write_evidence_details(api_dir, idx)

    # Backfill a subagent-timeline for OLD sessions — migration-only, one-shot.
    _maybe_backfill_timeline(api_dir, progress_data)

    # Central target gate: send this engagement's network assets to the localhost
    # gate service and record its verdict (good / blocked). The service owns all
    # state — dedup, the cumulative distinct-target count, the threshold; the kb
    # tool is a thin client. Best-effort: a gate failure never breaks the export.
    gate = None
    try:
        items = target_gate.collect_from_export(assets_data, target)
        gate = target_gate.check(eng.slug, items)
        _write_json(api_dir / "gate.json", gate.to_dict(eng.slug))
        if gate.blocked:
            _warn(_gate_banner(gate))
        # A definitive over-cap verdict arms the session-halt sentinel: the
        # PreToolUse hook (.claude/hooks/target-cap-halt.py) then denies every
        # subsequent tool call so the agent actually stops. This is the one
        # choke point every export path flows through — `kb commit`, the
        # orchestrator's `kb draft integrate`, and explicit `kb export` — so the
        # halt arms no matter who triggered the export, not only the worker
        # `kb commit` that returns exit 3.
        if target_gate.halt_enabled() and target_gate.blocks_session(gate):
            target_gate.write_halt_sentinel(eng.root, gate)
    except Exception as exc:  # noqa: BLE001 — the gate must never fail the export
        _warn(f"target gate failed: {exc}")
        gate = None

    # meta.json LAST — its mtime is the server's change signal.
    meta: Dict[str, Any] = {"timestamp": _now(), "slug": eng.slug, "version": 1}
    if gate is not None:
        meta["gate"] = {
            "blocked": gate.blocked, "enabled": gate.enabled,
            "total": gate.total, "threshold": gate.threshold,
        }
    _write_json(api_dir / "meta.json", meta)
    return gate


def _safe_read_target(eng) -> Dict[str, Any]:
    try:
        return read_target(eng.target_json) or {}
    except Exception as exc:  # noqa: BLE001
        _warn(f"target.json read failed: {exc}")
        return {}


def _safe_read_state(eng) -> str:
    p = eng.state_md
    if not p.exists():
        return ""
    try:
        return p.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError) as exc:
        _warn(f"STATE.md read failed: {exc}")
        return ""


def auto_export(eng):
    """Best-effort wrapper for the post-commit hook. Never raises. Returns the
    ``GateResult`` (or ``None`` on any failure) so the commit can fail on a
    definitive over-threshold verdict — see ``gate_blocks_commit``."""
    try:
        return export(eng)
    except Exception:  # noqa: BLE001 — a failed export must never fail a commit
        return None


def gate_blocks_commit(gate) -> bool:
    """Whether a gate result should make ``kb commit`` fail.

    Only a *definitive* over-threshold verdict blocks a commit. A transport /
    parse error (gate unreachable, timeout, garbled reply) must NEVER block a
    commit — even under fail-closed — so the agent can always persist its work
    when the gate is merely down. Errors carry ``gate.error``; a real block from
    the service does not."""
    return bool(gate is not None and gate.blocked and not gate.error)


def _gate_banner(gate) -> str:
    tot = gate.total if gate.total is not None else "?"
    thr = gate.threshold if gate.threshold is not None else "?"
    lines = [
        "TARGET GATE: session forbidden — cumulative distinct-target cap reached.",
        f"  distinct targets across all sessions: {tot} (cap {thr}).",
        f"  the gate service rejected this engagement's assets ({gate.url}).",
    ]
    if gate.reason:
        lines.append(f"  reason: {gate.reason}")
    lines.append("  stop this session; prune targets or raise the cap on the gate service.")
    return "\n".join(lines)


def cmd_export(args) -> int:
    """CLI entry point: `kb export`. Exit 3 when the target gate forbids the session."""
    eng = ctx.require(getattr(args, "engagement", None))
    gate = export(eng)
    if gate is not None and gate.blocked:
        print(f"[kb export] {_gate_banner(gate)}", file=sys.stderr)
        return 3
    return 0
