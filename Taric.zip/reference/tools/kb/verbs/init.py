"""kb init, kb current."""
from __future__ import annotations

import json
from pathlib import Path
from typing import List, Optional

from .. import ctx, git_helper
from ..ids import write_counters
from ..log import append_event, append_log
from ..parser import ENTITY_TYPES
from ..scope import parse_seed
from ..util import die, err, today_iso


def _scaffold(eng_root: Path, slug: str, target_url: str = "", notes: str = "",
              primary_objective: str = "", seeds: Optional[List[dict]] = None) -> None:
    primary_objective = (primary_objective or "").strip()
    # Directories
    for sub in [
        "auth", "wiki", "plan", "plan/archive",
        "record/findings", "record/evidence/artifacts",
        "raw", "report",
    ]:
        (eng_root / sub).mkdir(parents=True, exist_ok=True)
    # target.json — primary_objective is the canonical Primary Objective Lock
    # signal (empty string = no lock / full scope). `kb coverage` reads and
    # displays it; orchestrator/reason rules key the Lock off this field, not
    # off free-text STATE.md. `scope_in` seeds (host engagements) are structured
    # {kind, value}; web engagements rely on base_url + an empty scope_in.
    target = {
        "slug": slug,
        "base_url": target_url,
        "notes": notes,
        "primary_objective": primary_objective,
        "created": today_iso(),
        "scope_in": list(seeds or []),
        "scope_out": [],
        "counters": {t.lower(): 0 for t in ENTITY_TYPES},
    }
    (eng_root / "target.json").write_text(
        json.dumps(target, indent=2, ensure_ascii=False) + "\n", encoding="utf-8",
    )
    # STATE.md
    notes_line = f"- notes: {notes}\n" if notes else ""
    if primary_objective:
        focus_block = (
            f"- Primary Objective: {primary_objective}; close core "
            f"{primary_objective} tasks before global coverage / scanner expansion\n"
        )
    else:
        focus_block = "_(set when work begins)_\n"
    (eng_root / "STATE.md").write_text(
        "---\n"
        "type: state\n"
        f"last_updated: {today_iso()}\n"
        "---\n\n"
        f"# {slug} — STATE\n\n"
        "## Engagement\n"
        f"- target: {target_url}\n"
        f"- slug: {slug}\n"
        f"{notes_line}"
        "\n"
        f"## Active focus\n{focus_block}\n"
        "## Open questions\n_(none)_\n\n"
        "## Next actions\n_(none)_\n\n"
        "## Blockers\n_(none)_\n",
        encoding="utf-8",
    )
    # index.md
    (eng_root / "index.md").write_text(
        "---\n"
        "type: index\n"
        f"last_updated: {today_iso()}\n"
        "---\n\n"
        f"# {slug} — Index\n\n"
        "## Where we are\n_(updated by the agent)_\n\n"
        "## Wiki — by area\n_(none yet)_\n\n"
        "## Findings\n_(none yet)_\n\n"
        "## Gaps / Open questions\n_(none yet)_\n",
        encoding="utf-8",
    )
    # log.md (append_log will bootstrap on first call)
    # record/chains.md
    (eng_root / "record" / "chains.md").write_text(
        "---\n"
        "title: Attack Chains\n"
        "type: chains\n"
        f"last_updated: {today_iso()}\n"
        "---\n\n"
        f"# {slug} — Attack Chains\n\n_(none yet)_\n",
        encoding="utf-8",
    )
    # events.jsonl is created on first append_event.


def cmd_init(args) -> int:
    alias = getattr(args, "engagement_alias", None)
    if args.slug and alias and args.slug != alias:
        die(
            f"slug conflict: positional {args.slug!r} vs --engagement {alias!r}; "
            "pass only one",
            code=2,
        )
    slug = args.slug or alias
    if not slug:
        die(
            "init requires a slug — pass it positionally (e.g. `kb init springfield`) "
            "or via --engagement (e.g. `kb init --engagement springfield`)",
            code=2,
        )
    if not slug.replace("-", "").replace(".", "").replace("_", "").isalnum():
        die(f"invalid slug: {slug!r} (allowed: letters, digits, -, ., _)", code=2)

    force = bool(getattr(args, "force", False))
    root = ctx.kb_root() / slug

    # One active engagement per workspace. If one is already active (the
    # `.current` pointer resolves to a real engagement), refuse to init a
    # second one. `--force` clears the active engagement first (DESTRUCTIVE —
    # wipes its findings/evidence) and reinitializes in its place.
    current = ctx.read_current()
    current_root = (ctx.kb_root() / current) if current else None
    active = bool(current and current_root and current_root.exists())
    if active and not force:
        err(
            f"active engagement {current!r} already exists — kb refuses to init a "
            f"second engagement in the same workspace.\n"
            f"  test another target:  ask the user to start a NEW session "
            f"(each session gets its own clean workspace + kb) — do NOT --force this one away\n"
            f"  resume this one:      bin/kb current set {current}\n"
            f"  keep it, start fresh: mv data/kb/{current} {current}.bak "
            f"&& bin/kb init {slug}   "
            f"(moves the old engagement out of data/kb/ to ./{current}.bak — "
            f"findings/evidence preserved; no --force needed)\n"
            f"  discard & redo:       bin/kb init {slug} --force   "
            f"(PERMANENTLY DELETES data/kb/{current}/ — findings, evidence, everything)"
        )
        return 3
    if root.exists() and not force:
        err(f"engagement {slug!r} already exists at {root}")
        return 1

    if force:
        import shutil
        for victim in {p for p in (current_root, root) if p is not None and p.exists()}:
            shutil.rmtree(victim)
        ctx.clear_current()

    seeds: List[dict] = []
    for spec in (getattr(args, "seed", None) or []):
        try:
            seeds.append(parse_seed(spec))
        except ValueError as exc:
            die(f"invalid --seed {spec!r}: {exc}", code=2)
    root.mkdir(parents=True, exist_ok=False)
    _scaffold(root, slug, args.target or "", args.notes or "",
              getattr(args, "primary_objective", None) or "", seeds=seeds)
    ctx.write_current(slug)
    eng = ctx.Engagement(slug=slug, root=root)
    append_log(eng.log_md, "init", f"{slug} created", body=(args.notes or "").strip())
    append_event(eng.events_jsonl, verb="init", slug=slug)
    git_helper.init(root, slug)
    print(f"engagement {slug!r} created at {root.relative_to(ctx.repo_root())}")
    return 0


def cmd_current_show(args) -> int:
    cur = ctx.read_current()
    if not cur:
        err("no current engagement")
        return 1
    print(cur)
    return 0


def cmd_current_set(args) -> int:
    slug = args.slug
    root = ctx.kb_root() / slug
    if not root.exists():
        die(f"engagement {slug!r} not found at {root}", code=1)
    ctx.write_current(slug)
    print(f"current engagement: {slug}")
    return 0
