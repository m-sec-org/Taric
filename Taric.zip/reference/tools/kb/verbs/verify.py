"""kb verify — engagement state integrity check.

Walks files, re-derives counters from real IDs across the tree, reconciles
against target.json. Lightweight (no full lint — that's `kb health`).
"""
from __future__ import annotations

from typing import List

from .. import ctx
from ..ids import derive_counters_from_ids, read_counters, read_target, write_counters
from ..index import build_index
from ..lock import acquire
from ..parser import ENTITY_TYPES
from ..util import die, err


def cmd_verify(args) -> int:
    eng = ctx.require(args.engagement)
    quiet = bool(getattr(args, "quiet", False))
    issues: List[str] = []

    # 1. target.json well-formed and required keys present.
    if not eng.target_json.exists():
        issues.append("target.json missing")
    else:
        try:
            data = read_target(eng.target_json)
        except Exception as e:
            issues.append(f"target.json: invalid JSON: {e}")
            data = {}
        for key in ("slug", "created"):
            if key not in data:
                issues.append(f"target.json: missing key {key!r}")

    # 2. STATE.md exists.
    if not eng.state_md.exists():
        issues.append("STATE.md missing")

    # 3. Counter reconciliation.
    try:
        idx = build_index(eng)
    except Exception as e:
        issues.append(f"build_index failed: {e}")
        idx = None
    if idx is not None:
        real_ids = [e.id for e in idx.all_entities() if not e.is_placeholder]
        observed = derive_counters_from_ids(real_ids)
        stored = read_counters(eng.target_json)
        drift: List[str] = []
        for t in ENTITY_TYPES:
            if observed.get(t, 0) > stored.get(t, 0):
                drift.append(f"  {t}: stored={stored.get(t, 0)}, observed={observed.get(t, 0)}")
        if drift:
            if getattr(args, "fix", False):
                with acquire(eng.root):
                    merged = {t: max(stored.get(t, 0), observed.get(t, 0)) for t in ENTITY_TYPES}
                    write_counters(eng.target_json, merged)
                if not quiet:
                    print("counters rewritten from observed maxima.")
                # Drift resolved — don't surface it as an unresolved issue.
            else:
                issues.append(
                    "counter drift (stored < observed maxima):\n" + "\n".join(drift)
                    + "\n  (run `kb verify --fix` to rewrite counters)"
                )

    if issues:
        if not quiet:
            for msg in issues:
                err(f"verify: {msg}")
        return 1
    if not quiet:
        print("verify: clean")
    return 0
