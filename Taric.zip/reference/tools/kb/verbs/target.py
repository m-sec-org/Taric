"""kb target {show | set ...}."""
from __future__ import annotations

import json

from .. import ctx
from ..ids import read_target, write_target
from ..lock import acquire
from ..log import append_event, append_log


def cmd_target_show(args) -> int:
    eng = ctx.require(args.engagement)
    data = read_target(eng.target_json)
    print(json.dumps(data, indent=2, ensure_ascii=False))
    return 0


def cmd_target_set(args) -> int:
    eng = ctx.require(args.engagement)
    with acquire(eng.root):
        data = read_target(eng.target_json)
        changes = []
        if args.base_url is not None:
            data["base_url"] = args.base_url
            changes.append("base_url")
        if args.notes is not None:
            data["notes"] = args.notes
            changes.append("notes")
        if getattr(args, "primary_objective", None) is not None:
            # empty string clears the lock (full scope)
            data["primary_objective"] = args.primary_objective.strip()
            changes.append("primary_objective")
        if args.scope_in is not None:
            data["scope_in"] = [s.strip() for s in args.scope_in.split(",") if s.strip()]
            changes.append("scope_in")
        if args.scope_out is not None:
            data["scope_out"] = [s.strip() for s in args.scope_out.split(",") if s.strip()]
            changes.append("scope_out")
        if not changes:
            print("no changes")
            return 0
        write_target(eng.target_json, data)
        append_log(eng.log_md, "target set", ", ".join(changes), body="")
        append_event(eng.events_jsonl, verb="target_set", fields=changes)
    print(f"updated: {', '.join(changes)}")
    return 0
