"""kb promote <hypothesis-id> --severity <s>

Validate hypothesis + ≥1 evidence; create record/findings/FINDING-N.md;
update hypothesis status; update related endpoints.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import List

from .. import ctx, cvss
from ..ids import allocate_ids, read_counters, reconcile_counters, write_counters
from ..index import Index, build_index
from ..lock import acquire
from ..log import append_event, append_log
from ..parser import parse_id, serialize_frontmatter, split_frontmatter, parse_frontmatter
from ..schema import FINDING_STATUS_DEFAULT, fm_get
from ..util import die, today_iso


_VALID_SEVERITY = ("critical", "high", "medium", "low", "info")


def _coerce_id_list(v) -> List[str]:
    if v is None:
        return []
    if isinstance(v, list):
        return [str(x) for x in v if isinstance(x, str)]
    if isinstance(v, str):
        return [v]
    return []


def cmd_promote(args) -> int:
    eng = ctx.require(args.engagement)
    # CVSS is required: the vector computes cvss_score, while severity stays the
    # explicit GB/T 30279 rating (the two never derive each other, but both are
    # mandatory on a finding).
    vector = (getattr(args, "cvss_vector", None) or "").strip()
    if not vector:
        die(cvss.required_error("flag"), code=2)
    try:
        cvss_score = cvss.base_score(vector)
    except ValueError as exc:
        die(f"invalid --cvss-vector: {exc}", code=2)
    sev = getattr(args, "severity", None)
    if not sev:
        die("provide --severity (GB/T 30279 rating); --cvss-vector only computes cvss_score", code=2)
    if sev not in _VALID_SEVERITY:
        die(f"--severity must be one of {_VALID_SEVERITY}", code=2)
    hyp_id = args.hypothesis_id
    p = parse_id(hyp_id)
    if not p or p[0] != "HYPOTHESIS":
        die(f"expected HYPOTHESIS-NNN, got {hyp_id!r}", code=2)

    with acquire(eng.root):
        idx = build_index(eng)
        hyp = idx.by_id.get(hyp_id) or idx.placeholders.get(hyp_id)
        if not hyp:
            # Look in archive
            for f in idx.files:
                if f.rel_path.startswith("plan/archive/"):
                    for e in f.entities:
                        if e.id == hyp_id:
                            hyp = e
                            break
        if not hyp:
            die(f"hypothesis {hyp_id} not found", code=1)
        if hyp.is_placeholder:
            die(f"hypothesis {hyp_id} has a placeholder ID — run `kb commit` first", code=1)

        status = hyp.bullets.get("status")
        if status not in ("untested", "testing", "verified"):
            die(f"hypothesis status={status!r} — cannot promote (need untested/testing/verified)", code=1)

        targets = _coerce_id_list(hyp.bullets.get("targets"))
        if not targets:
            die(f"hypothesis {hyp_id} has no `targets` — cannot promote", code=1)

        # Count evidence referring to any of the target endpoints.
        relevant_evidence: List[str] = []
        for f in idx.files:
            if f.frontmatter.get("type") != "evidence":
                continue
            ep = fm_get(f.frontmatter, "related_endpoint")
            if isinstance(ep, str) and ep in targets:
                fid = f.frontmatter.get("id")
                if isinstance(fid, str):
                    relevant_evidence.append(fid)
        if not relevant_evidence:
            die(
                f"need ≥1 evidence entry pointing at targets {targets} (found 0). "
                "evidence-before-promote rule.",
                code=1,
            )

        # Allocate FINDING-N. Reserve the file path before persisting the counter
        # so a collision (handcrafted finding sitting at the next ID) doesn't
        # burn a counter slot.
        # Reconcile the counter against existing real IDs so a drifted counter
        # can't allocate an already-used FINDING id (see ids.reconcile_counters).
        real_ids = set(idx.by_id)
        for _d in (eng.findings_dir, eng.evidence_dir):
            if _d.is_dir():
                real_ids.update(p.stem for p in _d.glob("*.md"))
        counters = reconcile_counters(read_counters(eng.target_json), real_ids)
        new_ids = allocate_ids(counters, "FINDING", 1)
        finding_id = new_ids[0]
        find_path = eng.findings_dir / f"{finding_id}.md"
        eng.findings_dir.mkdir(parents=True, exist_ok=True)
        if find_path.exists():
            die(
                f"{find_path.relative_to(eng.root)} already exists — refusing to overwrite. "
                f"counters say next FINDING is {finding_id}, but the file is already there. "
                f"likely cause: a finding was created by hand without `kb promote`, leaving the "
                f"counter unsynced. inspect the file, move/rename it if it's stale, then retry.",
                code=1,
            )
        write_counters(eng.target_json, counters)
        title_seed = hyp.title or "verified vulnerability"
        tags = hyp.bullets.get("tags") or []
        if isinstance(tags, str):
            tags = [tags]
        skeleton = _finding_skeleton(
            finding_id=finding_id,
            title=title_seed,
            severity=sev,
            cvss_score=cvss_score,
            cvss_vector=vector,
            related_endpoints=targets,
            evidence_ids=relevant_evidence,
            hypothesis_id=hyp_id,
            tags=list(tags),
        )
        find_path.write_text(skeleton, encoding="utf-8")

        # Update the hypothesis: bump status, add promoted_to.
        _update_entity_bullets(
            hyp.source_file,
            hyp_id,
            {"status": "verified", "promoted_to": f"[[{finding_id}]]"},
        )

        # Update each related endpoint: status, verified_issue ref.
        for ep_id in targets:
            ep = idx.by_id.get(ep_id)
            if not ep or not ep.source_file:
                continue
            existing_related = ep.bullets.get("related")
            related_str = _append_wikilink(existing_related, finding_id)
            _update_entity_bullets(
                ep.source_file,
                ep_id,
                {"status": "verified-issue", "related": related_str},
            )

        # Log + events.
        append_event(
            eng.events_jsonl, verb="promote",
            hypothesis=hyp_id, finding=finding_id,
            severity=sev, cvss_score=cvss_score, cvss_vector=vector,
            related_endpoints=targets,
            evidence=relevant_evidence,
        )
        append_log(
            eng.log_md, "promote", f"{hyp_id} → {finding_id}",
            body=(
                f"Severity: {sev}.\n"
                f"Endpoints: {', '.join(f'[[{e}]]' for e in targets)}.\n"
                f"Evidence: {', '.join(f'[[{e}]]' for e in relevant_evidence)}.\n"
                f"\nFinding draft at `{find_path.relative_to(eng.root)}` — fill in Impact, "
                f"Reproduction, Recommendation, then `kb commit`."
            ),
        )

    if getattr(args, "json", False):
        print(json.dumps({
            "finding": finding_id,
            "file": str(find_path.relative_to(eng.root)).replace("\\", "/"),
            "hypothesis": hyp_id,
            "endpoints_updated": targets,
            "evidence": relevant_evidence,
            "severity": sev,
            "cvss_score": cvss_score,
            "cvss_vector": vector,
        }, indent=2, ensure_ascii=False))
        return 0
    print(f"promoted {hyp_id} → {finding_id}")
    print(f"file: {find_path.relative_to(eng.root)}")
    print(f"  fill in Impact / Reproduction / Recommendation, then `kb commit`.")
    return 0


def _finding_skeleton(
    finding_id: str, title: str, severity: str,
    related_endpoints: List[str], evidence_ids: List[str],
    hypothesis_id: str, tags: List[str],
    cvss_score=None, cvss_vector: str = "",
) -> str:
    fm = {
        "id": finding_id,
        "type": "finding",
        "title": title,
        "severity": severity,
        "status": FINDING_STATUS_DEFAULT,
        "cvss_score": cvss_score,
        "cvss_vector": cvss_vector,
        "related_endpoints": related_endpoints,
        "evidence": evidence_ids,
        "hypothesis": hypothesis_id,
        "tags": tags,
        "created": today_iso(),
        "last_updated": today_iso(),
    }
    head = serialize_frontmatter(fm)
    body = (
        f"\n# {title}\n\n"
        "## Impact\n_(agent fills in)_\n\n"
        "## Reproduction\n_(agent fills in: auth context, request, expected vs observed)_\n\n"
        "## Recommendation\n_(agent fills in)_\n\n"
        "## Evidence\n"
        + "".join(f"- [[{eid}]]\n" for eid in evidence_ids)
    )
    return head + body


def _update_entity_bullets(file_path: Path, entity_id: str, updates: dict) -> None:
    """Patch an entity's bullet block in `file_path`. Adds new bullets at the
    end of the block; updates existing keys in place. Preserves everything else.
    """
    text = file_path.read_text(encoding="utf-8")
    lines = text.splitlines(keepends=True)
    # Find the heading.
    import re as _re
    head_re = _re.compile(rf"^#{{1,6}}\s+{_re.escape(entity_id)}\s*[:\-—–]?\s*")
    bullet_re = _re.compile(r"^\s*[-*+]\s+([A-Za-z_][A-Za-z0-9_-]*)\s*[:=]\s*(.*)$")
    out: List[str] = []
    i = 0
    n = len(lines)
    patched = False
    while i < n:
        if not head_re.match(lines[i].rstrip("\n")):
            out.append(lines[i])
            i += 1
            continue
        # Found heading. Collect bullet block.
        out.append(lines[i])
        j = i + 1
        # Optional one blank line.
        if j < n and not lines[j].strip():
            out.append(lines[j])
            j += 1
        bullet_lines: List[str] = []
        while j < n:
            ln = lines[j]
            if not ln.strip():
                break
            if not bullet_re.match(ln.rstrip("\n")):
                break
            bullet_lines.append(ln)
            j += 1
        # Apply updates.
        seen_keys = set()
        new_bullets: List[str] = []
        for ln in bullet_lines:
            m = bullet_re.match(ln.rstrip("\n"))
            if not m:
                new_bullets.append(ln)
                continue
            key, val = m.group(1), m.group(2)
            if key in updates:
                new_val = updates[key]
                new_bullets.append(f"- {key}: {new_val}\n")
                seen_keys.add(key)
            else:
                new_bullets.append(ln)
        for key, val in updates.items():
            if key not in seen_keys:
                new_bullets.append(f"- {key}: {val}\n")
        out.extend(new_bullets)
        # Continue from j.
        i = j
        patched = True
        # No `break` — there may only be one heading match anyway.
    if patched:
        tmp = file_path.with_suffix(file_path.suffix + ".tmp")
        tmp.write_text("".join(out), encoding="utf-8")
        tmp.replace(file_path)


def _append_wikilink(existing, new_id: str) -> str:
    """Append [[new_id]] to a wikilink-list value. Normalizes every item to
    `[[X]]` form so output is consistent regardless of how the existing value
    was stored (parser may surface a single wikilink as a string, multiple as
    a list, and mixed-format prior values as a raw scalar).
    """
    new_link = f"[[{new_id}]]"

    if existing is None or existing == "":
        items: List[str] = []
    elif isinstance(existing, list):
        items = [_ensure_bracketed(x) for x in existing if x]
    else:
        # Single string — could be one wikilink, one bare ID, or comma-separated mix.
        parts = [p.strip() for p in str(existing).split(",") if p.strip()]
        items = [_ensure_bracketed(p) for p in parts]

    if new_link not in items:
        items.append(new_link)
    return ", ".join(items)


def _ensure_bracketed(s) -> str:
    """Wrap s in [[ ]] if not already. Strips pipe-form display if present."""
    s = str(s).strip()
    if s.startswith("[[") and s.endswith("]]"):
        return s
    if "|" in s:
        s = s.split("|", 1)[0].strip()
    return f"[[{s}]]"
