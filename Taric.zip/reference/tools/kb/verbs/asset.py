"""`kb asset` — record and recall cross-session per-asset knowledge.

Sub-commands
------------
``note``   append one raw entry to /data/asset-memory/raw/<slug>.jsonl.
           One fact per note; validated locally (enum/length/secret-guard)
           BEFORE the flock, so the lock is never held on rejected input.
``show``   read an asset's memory — digest (default, capped), or --raw.
           Optional filters narrow the digest AND --raw to anchor groups:
           ``--anchor PAT`` (glob), ``--narrow`` (derive the target's
           port/path), ``--kind host|web`` (anchor face). ``_asset`` is
           always kept; hidden groups are disclosed in the footer.
``list``   one line per asset with final/raw counts.
``recall`` rebuild STATE.md `## Prior knowledge` from scope-matched assets:
           pure pointer metadata (slug + count + category mix — never
           statements). Web: ≤6 cards ≤1KB. Host: full roster of every
           scope-matched asset (≤~2KB, format degrades before assets are
           hidden). Idempotent: safe to re-run after compaction wipes it.

``PENTEST_ASSET_MEMORY=0`` disables the WHOLE family at once (see
``cmd_asset_disabled``): every sub-command becomes a no-op that still exits 0,
and ``recall`` leaves STATE.md untouched.

Design constraints honored here:
* Fail-open — store problems warn on stderr and never break pentest work.
* The durable final files are written ONLY by the server-side consolidation
  task; this client reads them but never writes them.
"""

from __future__ import annotations

import json
import re
import sys
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import urlsplit

from .. import asset_memory as am
from .. import ctx
from ..lock import acquire
from ..log import append_event, append_log
from ..scope import contains
from ..util import die

# ---------------------------------------------------------------------------
# State.md section editing (## Prior knowledge) — mirrors state_hygiene.py's
# section slicing: heading → next H2.
# ---------------------------------------------------------------------------

SECTION_HEAD = "## Prior knowledge"
_NEXT_H2 = re.compile(r"^##\s+")


def _replace_section(body: str, new_section: str) -> str:
    """Replace `## Prior knowledge` in body (creating it before the first
    existing H2 other than itself, else appending at end)."""
    lines = body.splitlines()
    start = next((i for i, ln in enumerate(lines) if ln.strip() == SECTION_HEAD), None)

    if start is not None:
        end = next((j for j in range(start + 1, len(lines)) if _NEXT_H2.match(lines[j])), len(lines))
        return "\n".join(lines[:start] + new_section.splitlines() + lines[end:])

    # No section yet — insert before the first "actionable" H2 so orientation
    # info precedes tasks; fallback: append at EOF.
    insert_at = next(
        (
            i
            for i, ln in enumerate(lines)
            if i > 0 and _NEXT_H2.match(ln.strip()) and ln.strip() != SECTION_HEAD
        ),
        len(lines),
    )
    return "\n".join(lines[:insert_at]) + "\n" + "\n".join(new_section.splitlines()) + "\n" + "\n".join(lines[insert_at:])


def _target_from_args_or_target_json(args) -> str:
    """--target wins; otherwise fall back to target.json base_url."""
    t = getattr(args, "target", None)
    if t and str(t).strip():
        return str(t).strip()
    eng = ctx.require(args.engagement)
    try:
        from ..verbs.export_ import _safe_read_target  # local import avoids cycle

        data = _safe_read_target(eng)
    except Exception:  # noqa: BLE001
        data = {}
    base = str(data.get("base_url") or "").strip()
    if not base:
        die("no --target given and target.json has no base_url")
    return base


def _read_target_data(eng) -> Dict[str, Any]:
    try:
        from ..verbs.export_ import _safe_read_target

        return _safe_read_target(eng)
    except Exception:  # noqa: BLE001
        return {}


# ---------------------------------------------------------------------------
# Family-level kill switch (PENTEST_ASSET_MEMORY=0). Guarded at the `kb asset`
# dispatch entrance in cli.py, so every sub-command — present and future — is
# covered by construction (a per-command check is what decays).
#
# Exit 0 with the notice on STDOUT: the agent reads tool stdout, and a
# deliberately disabled subsystem must never break a caller's flow.
# In --json mode the notice moves to stderr so stdout stays parseable.
# ---------------------------------------------------------------------------

def cmd_asset_disabled(args) -> int:
    """No-op for the whole `kb asset` family while the kill switch is off.

    Deliberately does no store work AND no STATE.md work: containment lives at
    the read end (``show`` is inert too), so a stale `## Prior knowledge`
    roster left in STATE.md can never be dereferenced into statements."""
    action = str(getattr(args, "action", "") or "")
    notice = "asset memory disabled, skip this step"
    if getattr(args, "json", False):
        payload: Dict[str, Any] = {"disabled": True}
        if action == "list":
            payload["assets"] = []  # keep the enabled shape's container key
        elif action == "note":
            payload["recorded"] = False
        print(json.dumps(payload, ensure_ascii=False))
        print(notice, file=sys.stderr)
        return 0
    print(notice)
    return 0


# ---------------------------------------------------------------------------
# kb asset note
# ---------------------------------------------------------------------------

def cmd_asset_note(args) -> int:
    eng = ctx.require(args.engagement)
    try:
        slug, entry = am.build_note(
            value=args.target,
            category=args.category,
            statement=args.statement,
            anchor=args.anchor,
            evidence_ref=getattr(args, "evidence", None),
            confidence=args.confidence,
            tags=list(args.tag or []),
            engagement=eng.slug,
        )
    except ValueError as exc:
        die(str(exc), code=2)
        return 2  # unreachable

    n = am.append_notes([(slug, entry)])
    if n == 0:
        print(f"asset note NOT recorded (store unwritable?) target={slug}")
        return 0  # fail-open: report but don't fail the caller's flow
    print(f"asset note recorded: {slug} [{entry['category']}/{entry['confidence']}] {entry['anchor']}")
    if getattr(args, "json", False):
        print(json.dumps(entry, ensure_ascii=False))
    return 0


# ---------------------------------------------------------------------------
# kb asset show
# ---------------------------------------------------------------------------

# Ports a scheme implies when the target omits one — keeps `--narrow`
# meaningful for `ssh://10.0.0.5` / `https://host` (http/ws→80, https/wss→443,
# ssh→22; an explicit port always wins).
_SCHEME_PORTS = {"http": 80, "ws": 80, "https": 443, "wss": 443, "ssh": 22}


def _target_context(value: str) -> Tuple[Optional[int], str]:
    """(port, path) a target string carries for `--narrow` — explicit or
    scheme-implied. Mirrors target_gate._host_kind's parsing idioms: scheme'd
    URLs go through urlsplit; bare forms are cut at the first "/", and a
    single-colon trailing digit run reads as a port (IPv6 brackets keep their
    colons). Returns (None, "") when the target names neither."""
    s = str(value or "").strip().lower()
    if not s:
        return None, ""
    port: Optional[int] = None
    path = ""
    if "://" in s:
        parts = urlsplit(s)
        try:
            port = parts.port
        except ValueError:
            port = None  # non-numeric :port — treat as unnamed, never crash
        if port is None:
            port = _SCHEME_PORTS.get(parts.scheme or "")
        path = parts.path or ""
    else:
        head, slash, tail = s.partition("/")
        path = f"/{tail}" if slash else ""
        if head.startswith("["):  # [ipv6]:port
            end = head.find("]")
            rest = head[end + 1:] if end != -1 else ""
            if rest.startswith(":") and rest[1:].isdigit():
                port = int(rest[1:])
        elif head.count(":") == 1:
            maybe = head.split(":", 1)[1]
            if maybe.isdigit():
                port = int(maybe)
    if path in ("/", ""):
        path = ""
    return port, path


def _build_filters(args, value: str) -> Tuple[List[Tuple[str, Any]], bool]:
    """Assemble the `show` filter spec from the CLI flags (union of all
    selectors). Returns (filters, narrow_noop) — narrow_noop=True when
    --narrow was requested but the target names no port or path, so the
    caller can say so instead of leaving the full digest unexplained."""
    filters: List[Tuple[str, Any]] = []
    for pattern in getattr(args, "anchor", None) or []:
        if str(pattern).strip():
            filters.append(("pattern", str(pattern).strip()))
    for kind in getattr(args, "kind", None) or []:
        filters.append(("kind", kind))
    narrow_noop = False
    if getattr(args, "narrow", False):
        port, path = _target_context(value)
        if port is not None:
            filters.append(("port", port))
        if path:
            filters.append(("path", path))
        if port is None and not path:
            narrow_noop = True
    return filters, narrow_noop


def cmd_asset_show(args) -> int:
    value = _target_from_args_or_target_json(args)
    resolved = am.resolve_slug(value)
    if not resolved:
        die(f"'{value}' 不像可归一化的主机/域名/IP 目标", code=2)
    slug = resolved[0]

    filters, narrow_noop = _build_filters(args, value)

    doc = am.read_final(slug)
    if args.raw:
        rows = am.read_raw(slug, since=getattr(args, "since", None))
        if filters:
            # Same selection as the digest (incl. the always-kept _asset
            # baseline) — raw is a debug view, not a second contract.
            rows = [
                r for r in rows
                if am.anchor_kept(str(r.get("anchor") or am.DEFAULT_ANCHOR), filters)
            ]
        print(json.dumps({"slug": slug, "raw": rows}, ensure_ascii=False, indent=1))
        return 0

    if not doc or not doc.get("entries"):
        # The disabled case never reaches here — the family guard in cli.py
        # answers first, so this line is always about a live (if empty) memory.
        print("_(none — this asset has no cross-session memory yet)_")
        return 0

    print(am.render_digest(doc, filters=filters or None), end="")
    if narrow_noop:
        print("_(--narrow: target 无端口/路径,已按全量显示)_")
    return 0


# ---------------------------------------------------------------------------
# kb asset list
# ---------------------------------------------------------------------------

def cmd_asset_list(args) -> int:
    rows = am.list_assets()
    if getattr(args, "json", False):
        print(json.dumps({"assets": rows}, ensure_ascii=False))
        return 0
    if not rows:
        print("_(no asset memory yet)_")
        return 0
    for r in rows:
        print(
            f"{r['value']}  [{r['kind'] or '?'}] final={r['final_entries']} raw={r['raw_entries']}"
        )
    return 0


# ---------------------------------------------------------------------------
# kb asset recall — STATE.md prior-knowledge index (pure pointer metadata).
# Lines carry slug + count + category mix ONLY: statements live in the digest
# and reach a worker's context when it reads its own target — a resident
# statement would tax every dispatch AND anchor the agent to possibly-stale
# facts. Pointer metadata is expiry-neutral.
# ---------------------------------------------------------------------------

INDEX_CARD_MAX_CHARS = 120
MAX_CARDS = 6
CARD_BUDGET = 1000  # hard cap for the whole section body (web profile)

# Host roster: the roster IS the discovery mechanism (no per-asset tooling on
# host), and a /24 revisit can carry tens of remembered hosts — so the budget
# is wider, the line cap high, and overflow degrades the FORMAT stepwise
# (category mix → count → bare slug) instead of hiding whole assets first.
HOST_ROSTER_BUDGET = 2000
HOST_ROSTER_MAX_LINES = 40
CATEGORY_WEIGHT = {  # ranking + truncation survival: environment posture and
    # negative knowledge outrank concept facts and fingerprint quirks
    "defense": 3,
    "transport": 3,
    "dead-end": 2,
    "auth-fact": 2,
    "vuln-structure": 2,
    "concept": 1,
    "quirk": 1,
}


def _active_entries(doc: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Believed entries only — refuted tombstones never spend card budget."""
    return [
        e for e in doc.get("entries", []) if str(e.get("status", "active")) != "refuted"
    ]


def _category_counts(doc: Dict[str, Any]) -> str:
    counts: Dict[str, int] = {}
    for e in _active_entries(doc):
        c = str(e.get("category", "?"))
        counts[c] = counts.get(c, 0) + 1
    return " ".join(f"{k}×{v}" for k, v in sorted(counts.items()))


def _index_card(value: str, doc: Dict[str, Any]) -> Optional[str]:
    n = len(_active_entries(doc))
    if n == 0:
        return None  # an all-refuted graveyard gets no card slot
    line = f"- {value} — {n}条({_category_counts(doc)})"
    if len(line) > INDEX_CARD_MAX_CHARS:
        line = line[: INDEX_CARD_MAX_CHARS - 1].rstrip() + "…"
    return line


def _roster_score(doc: Dict[str, Any]) -> int:
    """Category-weighted memory size — ranks roster order and decides which
    lines survive truncation."""
    return sum(
        CATEGORY_WEIGHT.get(str(e.get("category", "?")), 1) for e in _active_entries(doc)
    )


def _roster_line(value: str, doc: Dict[str, Any], level: int) -> str:
    """Pointer line, degrading with `level`: 0 = slug+count+category mix,
    1 = slug+count, 2 = bare slug."""
    if level >= 2:
        return f"- {value}"
    n = len(_active_entries(doc))
    if level == 1:
        return f"- {value}:{n}"
    return f"- {value}:{n}条({_category_counts(doc)})"


def _scope_declared(target_data: Dict[str, Any]) -> bool:
    """True when target.json declares any scope input — `scope_in` (even an
    empty list, the post-init web shape) or `base_url`. An entirely undeclared
    scope fail-closes recall: with no boundary there is no isolation, so no
    asset may surface. (`kb init` always writes both fields, so hitting this
    means a hand-made or damaged target.json.)"""
    return target_data.get("scope_in") is not None or bool(target_data.get("base_url"))


def _scope_matched_docs(target_data: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Scope-filtered [{value, slug, doc}] with active memory, best first.
    Caller guarantees a declared scope (cmd_asset_recall fail-closes else)."""
    rows: List[Dict[str, Any]] = []
    for row in am.list_assets():
        ok, _reason = contains(target_data, row["value"])
        if not ok:
            continue  # scope isolation — no leakage across targets
        doc = am.read_final(row["slug"])
        if not doc or not _active_entries(doc):
            continue  # raw-only backlog and refuted graveyards earn no index line
        rows.append({"value": row["value"], "slug": row["slug"], "doc": doc})
    rows.sort(key=lambda r: (-_roster_score(r["doc"]), r["value"]))
    return rows


def _web_cards(target_data: Dict[str, Any]) -> List[str]:
    cards: List[str] = []
    for row in _scope_matched_docs(target_data):
        if len(cards) >= MAX_CARDS:
            break
        card = _index_card(row["value"], row["doc"])
        if card:
            cards.append(card)
    budget = CARD_BUDGET
    kept: List[str] = []
    for card in cards:
        if budget - (len(card) + 1) < 120 and kept:  # always keep at least one
            break
        kept.append(card)
        budget -= len(card) + 1
    return kept


def _host_roster(target_data: Dict[str, Any]) -> List[str]:
    """Every scope-matched asset, one pointer line each; overflow degrades the
    line format before it hides assets, and the tail gets a list pointer."""
    matched = _scope_matched_docs(target_data)
    visible = matched[:HOST_ROSTER_MAX_LINES]
    dropped = len(matched) - len(visible)
    if not visible:
        return []

    footer = f"- …另有 {dropped} 台 → `bin/kb asset list`" if dropped else ""
    for level in (0, 1, 2):
        lines = [_roster_line(r["value"], r["doc"], level) for r in visible]
        if footer:
            lines.append(footer)
        if len("\n".join(lines)) + 1 <= HOST_ROSTER_BUDGET:
            return lines
    # Bare slugs still overflow (pathological scope): hard-truncate, keep ≥1.
    kept: List[str] = []
    budget = HOST_ROSTER_BUDGET
    for r in visible:
        ln = _roster_line(r["value"], r["doc"], 2)
        if budget - (len(ln) + 1) < 0 and kept:
            break
        kept.append(ln)
        budget -= len(ln) + 1
    return kept


def cmd_asset_recall(args) -> int:
    eng = ctx.require(args.engagement)
    if not eng.state_md.exists():
        die("no STATE.md — run `kb init` first")
    target_data = _read_target_data(eng)
    from ..profiles import resolve_profile_name  # local import avoids import cost

    if not _scope_declared(target_data):
        # fail-closed, but keep the section deterministic for idempotent
        # rebuild — the hint names the fix so the session self-heals.
        section = (
            f"{SECTION_HEAD}\n"
            "> 跨会话先验 target.json 未声明 scope_in/base_url, 无 scope,"
            "recall failed (先 `kb init` 或补 scope, 再 `bin/kb asset recall`)\n"
            "_(none)_"
        )
        kept, label = [], "card(s)"
    else:
        if resolve_profile_name() == "host":
            kept = _host_roster(target_data)
            frame = (
                SECTION_HEAD,
                "> 跨会话先验名册（待复核假设索引）；详情 `bin/kb asset show --target <资产>`；本节可 `bin/kb asset recall` 重建",
            )
            label = "asset(s)"
        else:
            kept = _web_cards(target_data)
            frame = (
                SECTION_HEAD,
                "> 跨会话先验索引（待复核假设）；详情 `bin/kb asset show`；本节可 `bin/kb asset recall` 重建",
            )
            label = "card(s)"
        section = "\n".join(frame + tuple(kept)) if kept else (
            f"{SECTION_HEAD}\n> 跨会话先验索引；无匹配记忆（可 `bin/kb asset recall` 重建）\n_(none)_"
        )

    with acquire(eng.root):
        body_lines = eng.state_md.read_text(encoding="utf-8").splitlines()
        has_frontmatter = bool(body_lines) and body_lines[0].strip() == "---"
        if has_frontmatter:
            close = next((i for i in range(1, len(body_lines)) if body_lines[i].strip() == "---"), None)
            head = "\n".join(body_lines[: close + 1])
            body = "\n".join(body_lines[close + 1 :])
        else:
            head, body = "", "\n".join(body_lines)
        new_body = _replace_section(body.lstrip("\n"), section)
        content = (head + "\n" if head else "") + new_body
        if not content.endswith("\n"):
            content += "\n"
        eng.state_md.write_text(content, encoding="utf-8")

    append_log(eng.log_md, "asset recall", f"{len(kept)} prior-knowledge {label}")
    append_event(eng.events_jsonl, verb="asset_recall", cards=len(kept))
    print(f"prior knowledge updated: {len(kept)} {label}")
    return 0
