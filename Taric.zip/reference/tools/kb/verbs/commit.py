"""kb commit -m "<title>" [-m "<body>"]

Walks the tree, finds placeholder IDs, allocates real IDs, rewrites files
atomically, updates last_updated frontmatter, appends events + log.
"""
from __future__ import annotations

import json
import re
import shutil
import tempfile
from collections import defaultdict
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple

from .. import ctx, git_helper, plan_hygiene, state_hygiene
from ..ids import allocate_ids, format_id, read_counters, reconcile_counters, write_counters
from ..index import build_index
from ..lock import acquire
from ..log import append_event, append_log
from ..parser import (
    ENTITY_TYPES,
    ID_PAD,
    is_placeholder_id,
    parse_file,
    parse_id,
    serialize_frontmatter,
    split_frontmatter,
    parse_frontmatter,
    walk_engagement,
)
from ..profiles import active_profile
from ..util import die, err, today_iso
from ..validators.semantic_inventory import build_inventory, build_missing_type_warnings, validate_shape


# Match TYPE-N as a standalone token. Disallow extending alnum or `_-` chars.
_ID_TOKEN = re.compile(r"(?<![A-Za-z0-9_-])([A-Z]+-\d+)(?![A-Za-z0-9_-])")


def _id_in_string(s: str) -> List[str]:
    return [m.group(1) for m in _ID_TOKEN.finditer(s)]


def _find_placeholders_in_file(eng_root: Path, path: Path) -> Set[str]:
    """Find every placeholder ID referenced anywhere in a file (heading, bullet,
    body, frontmatter)."""
    text = path.read_text(encoding="utf-8")
    found = set()
    for tok in _id_in_string(text):
        if is_placeholder_id(tok):
            # Only valid types
            p = parse_id(tok)
            if p:
                found.add(tok)
    return found


def _file_should_be_scanned(rel: str) -> bool:
    if rel.startswith("raw/"):
        return False
    return rel.endswith(".md")


def cmd_commit(args) -> int:
    eng = ctx.require(args.engagement)
    msgs: List[str] = list(args.message or [])
    if not msgs:
        die("kb commit requires -m '<title>' (and optionally additional -m for body)", code=2)
    title = msgs[0].strip()
    body = "\n\n".join(m.rstrip() for m in msgs[1:]) if len(msgs) > 1 else ""

    with acquire(eng.root):
        # Phase 0: validate record/findings/ — every file must be the product
        # of `kb promote` (real FINDING-NNN id, frontmatter type=finding,
        # filename matches id). Handcrafted findings bypass evidence/severity
        # validation AND set up silent overwrites on the next promote.
        _validate_findings_dir(eng)

        # Phase 1: scan tree for placeholders, both as text tokens and as
        # entity declarations (heading- or frontmatter-based).
        placeholders_to_files: Dict[str, List[Path]] = defaultdict(list)
        all_files: List[Path] = []
        # Declarations: same placeholder may only be DECLARED in one file per commit.
        # heading-based and frontmatter-id-based declarations both live here.
        decls: Dict[str, List[Path]] = defaultdict(list)
        # File-id declarations only (FINDING-N.md / EVIDENCE-N.md) — we'll rename
        # the file itself when the id is renumbered.
        file_id_decls: Dict[Path, str] = {}

        for path in walk_engagement(eng.root):
            rel = str(path.relative_to(eng.root)).replace("\\", "/")
            if not _file_should_be_scanned(rel):
                continue
            all_files.append(path)
            raw = path.read_text(encoding="utf-8")
            # Token scan for any TYPE-N reference:
            for tok in _id_in_string(raw):
                if is_placeholder_id(tok) and parse_id(tok):
                    placeholders_to_files[tok].append(path)
            # Heading-declared entities:
            pf = parse_file(path, eng.root)
            for e in pf.entities:
                if e.is_placeholder:
                    decls[e.id].append(path)
            # Frontmatter-id-declared (standalone file entities):
            ftype = pf.frontmatter.get("type")
            fid = pf.frontmatter.get("id")
            if ftype in ("finding", "evidence") and isinstance(fid, str) and is_placeholder_id(fid):
                decls[fid].append(path)
                file_id_decls[path] = fid

        # Phase 2: when the same placeholder is declared in N>1 files (worker
        # restarted local placeholders at -1 in each new file), rewrite the
        # later files' copies to fresh unused placeholders. Refuses only when
        # a non-declaring file also references the duplicate token (ambiguous
        # which declaration the reference intended).
        if _autounique_placeholders(eng.root, decls, all_files):
            placeholders_to_files, decls, file_id_decls = _rescan(eng.root, all_files)

        # Semantic inventory shape errors must fail before ID rewrites/counter
        # updates; coverage-time closure remains a soft gate.
        _validate_semantic_inventory_shape(eng)

        # Body-content shape: entities that must carry a fenced code block (a
        # CHAIN's ```dot graph). Hard-gate before ID rewrites, same as above.
        _validate_entity_bodies(eng)

        # Per-endpoint sweep membership: every ENDPOINT must declare its sweep
        # tags (unauth_sweep / authz_sweep) so recall for the sweep universal
        # checks can never be dodged by leaving an endpoint untagged.
        _validate_sweep_tags(eng)

        if args.no_renumber or not decls:
            append_event(eng.events_jsonl, verb="commit", title=title,
                         files_touched=[], ids_allocated=[],
                         dispatch_id=ctx.dispatch_id())
            append_log(eng.log_md, "commit", title, body=body)
            git_helper.commit(eng.root, title, body)
            print(f"committed (no renumber): {title}")
            _print_post_commit_hints()
            from .export_ import auto_export, gate_blocks_commit, _gate_banner
            gate = auto_export(eng)
            if gate_blocks_commit(gate):
                err(f"[kb commit] {_gate_banner(gate)}")
                return 3
            return 0

        # Phase 3: allocate real IDs. Reconcile the counter against every real ID
        # already in the kb first, so a drifted counter can't renumber a
        # placeholder onto an existing real ID (see ids.reconcile_counters).
        real_ids = set(build_index(eng).by_id)
        counters = reconcile_counters(read_counters(eng.target_json), real_ids)
        by_type: Dict[str, List[str]] = defaultdict(list)
        for ph in decls.keys():
            p = parse_id(ph)
            if p:
                t, _, _ = p
                by_type[t].append(ph)
        renames: Dict[str, str] = {}
        for t, phs in by_type.items():
            phs.sort(key=lambda s: int(parse_id(s)[1]))
            real_ids = allocate_ids(counters, t, len(phs))
            for ph, real in zip(phs, real_ids):
                renames[ph] = real

        # Phase 4: rewrite files (substitute IDs + bump last_updated).
        files_to_rewrite: Set[Path] = set()
        for ph in renames:
            for f in placeholders_to_files.get(ph, []):
                files_to_rewrite.add(f)
        for path in sorted(files_to_rewrite):
            _rewrite_file(path, renames, today=today_iso())

        # Phase 4b: rename FINDING-N.md / EVIDENCE-N.md files whose frontmatter id changed.
        renamed_files: Dict[Path, Path] = {}
        for path, ph_id in file_id_decls.items():
            new_id = renames.get(ph_id)
            if not new_id:
                continue
            new_path = path.parent / f"{new_id}.md"
            if new_path == path:
                continue
            if new_path.exists():
                die(f"target path {new_path} already exists during rename", code=1)
            path.rename(new_path)
            renamed_files[path] = new_path

        # Phase 5: persist counters.
        write_counters(eng.target_json, counters)

        # Phase 6: log + events.
        # Translate any pre-rename paths in files_to_rewrite to their new locations.
        resolved = {renamed_files.get(p, p) for p in files_to_rewrite}
        files_rel = sorted(str(p.relative_to(eng.root)).replace("\\", "/") for p in resolved)
        ids_alloc = sorted(renames.values())
        append_event(eng.events_jsonl, verb="commit", title=title,
                     files_touched=files_rel, ids_allocated=ids_alloc, renames=renames,
                     dispatch_id=ctx.dispatch_id())
        append_log(eng.log_md, "commit", title, body=body)
        git_helper.commit(eng.root, title, body)

    # Refresh .api/ + run the target gate on the committed tree. A definitive
    # over-threshold verdict fails the commit (exit 3); a gate error never does.
    from .export_ import auto_export, gate_blocks_commit, _gate_banner
    gate = auto_export(eng)
    rc = 3 if gate_blocks_commit(gate) else 0

    if getattr(args, "json", False):
        print(json.dumps({
            "ids_allocated": ids_alloc,
            "files_touched": files_rel,
            "renames": renames,
            "gate_blocked": bool(gate is not None and gate.blocked),
        }, indent=2, ensure_ascii=False))
        if rc == 3:
            err(f"[kb commit] {_gate_banner(gate)}")
        return rc
    print(f"allocated: {' '.join(ids_alloc) if ids_alloc else '(none)'}")
    if files_rel:
        print(f"files touched ({len(files_rel)}):")
        for f in files_rel:
            print(f"  {f}")
    print("log entry written.")
    _print_post_commit_hints()
    state_hygiene.emit(eng)  # Layer 2 prune of drained follow-up leads + Layer 1 size banner
    plan_hygiene.emit(eng)   # nudge `bin/kb archive` when a plan file is large + mostly-closed
    if rc == 3:
        err(f"[kb commit] {_gate_banner(gate)}")
    return rc


def _validate_semantic_inventory_shape(eng) -> None:
    prof = active_profile()
    if not prof.semantic_inventory_note_type:
        return
    idx = build_index(eng)
    inventory = build_inventory(idx, prof, include_placeholders=True)
    warnings = build_missing_type_warnings(idx, prof, include_placeholders=True)
    issues = validate_shape(inventory, warnings, prof)
    blocking = [i for i in issues if i.get("severity") == "blocking"]
    if not blocking:
        return
    lines = ["semantic inventory schema error:"]
    for issue in blocking:
        field = issue.get("field")
        item = issue.get("item")
        where = f" {field}" if field else ""
        suffix = f" (got: {item})" if item is not None else ""
        lines.append(f"  {issue.get('note_id', '(unknown)')}{where}: {issue.get('issue')}{suffix}")
    die("\n".join(lines), code=3)


def _validate_entity_bodies(eng) -> None:
    """Reject any entity missing a required body fence — a CHAIN with no ```dot
    attack-path graph (schema.REQUIRED_FENCES). The report reuses that graph
    verbatim, so it must exist at creation. The error names each offending
    entity and shows the correct format so the agent can fix it in place."""
    from ..validators.entity_body import format_hint, missing_fences
    idx = build_index(eng)
    problems: List[Tuple[str, str, str]] = []   # (entity_id, location, lang)
    for e in idx.all_entities():
        for lang in missing_fences(e):
            rel = (str(e.source_file.relative_to(eng.root)).replace("\\", "/")
                   if e.source_file else "")
            loc = f"{rel}:{e.heading_line}" if rel else rel
            problems.append((e.id, loc, lang))
    if not problems:
        return
    lines = ["entity body validation failed:"]
    langs_seen: List[str] = []
    for eid, loc, lang in problems:
        where = f" ({loc})" if loc else ""
        lines.append(f"  {eid}{where}: body is missing a ```{lang} code block")
        if lang not in langs_seen:
            langs_seen.append(lang)
    for lang in langs_seen:
        lines.append("")
        lines.append(format_hint(lang))
    die("\n".join(lines), code=3)


def _validate_sweep_tags(eng) -> None:
    """Reject any ENDPOINT missing a sweep-membership tag (validators/sweep_tags.py).

    Every ENDPOINT must declare each profile-configured sweep tag with a valid
    value, so an endpoint can never enter the wiki without its sweep membership
    decided — the recall guarantee the sweep universal checks depend on. Safe
    default is `required`; `na(<reason>)` is the explicit opt-out. The error
    names each offending endpoint + the missing tag and shows the correct
    format, so the agent fixes it in place (strict-validator-guides-the-agent,
    like the draft / body / semantic-inventory gates). No-op on profiles with no
    sweep tags (host)."""
    tags = active_profile().sweep_endpoint_tags
    if not tags:
        return
    from ..validators import sweep_tags as st
    idx = build_index(eng)
    problems: List[Tuple[str, str, List[str]]] = []   # (entity_id, location, missing)
    for e in idx.by_type.get("ENDPOINT", []):
        miss = st.missing_tags(e, tags)
        if miss:
            rel = (str(e.source_file.relative_to(eng.root)).replace("\\", "/")
                   if e.source_file else "")
            loc = f"{rel}:{e.heading_line}" if rel else rel
            problems.append((e.id, loc, miss))
    if not problems:
        return
    lines = ["sweep-tag validation failed — every ENDPOINT must declare its sweep membership:"]
    for eid, loc, miss in problems:
        where = f" ({loc})" if loc else ""
        lines.append(f"  {eid}{where}: missing/invalid {', '.join(miss)}")
    lines.append("")
    lines.append("Add one bullet per tag inside each ENDPOINT block. Valid values:")
    lines.append("  required            # must be hit by the sweep (safe default; decide from path/method)")
    lines.append("  na(<reason>)        # genuinely not applicable, e.g. na(static asset, no auth)")
    lines.append("  blocked(<reason>)   # can't sweep yet, e.g. blocked(needs-contract)")
    lines.append("  enforced | missing  # set by the sweep runner after it runs — not at observe")
    lines.append("")
    lines.append("e.g.:")
    lines.append("  ### ENDPOINT-041: admin user list — POST /admin/system/user/list.json")
    lines.append("  - method: POST")
    lines.append("  - path: /admin/system/user/list.json")
    for t in tags:
        lines.append(f"  - {t}: required")
    die("\n".join(lines), code=3)


def _validate_findings_dir(eng) -> None:
    """Reject any handcrafted finding file. Findings are produced exclusively
    by `kb promote`, which allocates a real FINDING-NNN id and writes the
    skeleton at `record/findings/FINDING-NNN.md`. Anything else here is a
    bypass that will collide with the next promote."""
    findings_dir = eng.findings_dir
    if not findings_dir.exists():
        return
    counters = read_counters(eng.target_json)
    counter_max = counters.get("FINDING", 0)
    problems: List[str] = []
    for path in sorted(findings_dir.glob("*.md")):
        rel = path.relative_to(eng.root).as_posix()
        try:
            text = path.read_text(encoding="utf-8")
        except OSError as exc:
            problems.append(f"  {rel}: cannot read ({exc})")
            continue
        fm_text, _ = split_frontmatter(text)
        if fm_text is None:
            problems.append(f"  {rel}: no frontmatter (use `kb promote`)")
            continue
        fm = parse_frontmatter(fm_text)
        ftype = fm.get("type")
        fid = fm.get("id")
        if ftype != "finding":
            problems.append(f"  {rel}: frontmatter `type` is {ftype!r}, expected 'finding'")
            continue
        if not isinstance(fid, str):
            problems.append(f"  {rel}: missing or non-string `id`")
            continue
        parsed = parse_id(fid)
        if not parsed or parsed[0] != "FINDING" or parsed[2]:
            problems.append(
                f"  {rel}: `id: {fid}` is not a real FINDING-NNN. findings are only "
                f"created by `kb promote`, which assigns a real id."
            )
            continue
        # Filename must match id.
        expected_name = f"{fid}.md"
        if path.name != expected_name:
            problems.append(f"  {rel}: filename does not match `id: {fid}` (expected {expected_name})")
            continue
        # Counter must cover this id (otherwise next promote will collide).
        n = parsed[1]
        if n > counter_max:
            problems.append(
                f"  {rel}: `id: {fid}` exceeds the FINDING counter ({counter_max}). "
                f"the file was created without bumping the counter — next `kb promote` "
                f"will overwrite it. only `kb promote` may create findings."
            )
    if problems:
        die(
            "record/findings/ contains files not produced by `kb promote`:\n"
            + "\n".join(problems)
            + "\n\nFix: for each problem above, either (a) move the file out of "
              "record/findings/, then re-run the verified hypothesis through `kb promote` "
              "and edit the proper skeleton, or (b) if the file's content is correct and "
              "you just want it accepted as-is, manually align target.json `counters.finding` "
              "and the file's id+filename. Do not commit until clean.",
            code=1,
        )


def _rescan(eng_root: Path, all_files: List[Path]) -> Tuple[Dict[str, List[Path]], Dict[str, List[Path]], Dict[Path, str]]:
    """Re-walk the tree after auto-uniquify rewrites. Returns
    (placeholders_to_files, decls, file_id_decls)."""
    placeholders_to_files: Dict[str, List[Path]] = defaultdict(list)
    decls: Dict[str, List[Path]] = defaultdict(list)
    file_id_decls: Dict[Path, str] = {}
    for path in all_files:
        raw = path.read_text(encoding="utf-8")
        for tok in _id_in_string(raw):
            if is_placeholder_id(tok) and parse_id(tok):
                placeholders_to_files[tok].append(path)
        pf = parse_file(path, eng_root)
        for e in pf.entities:
            if e.is_placeholder:
                decls[e.id].append(path)
        ftype = pf.frontmatter.get("type")
        fid = pf.frontmatter.get("id")
        if ftype in ("finding", "evidence") and isinstance(fid, str) and is_placeholder_id(fid):
            decls[fid].append(path)
            file_id_decls[path] = fid
    return placeholders_to_files, decls, file_id_decls


def _autounique_placeholders(eng_root: Path, decls: Dict[str, List[Path]], all_files: List[Path]) -> bool:
    """If a placeholder TYPE-N is declared in multiple files, rewrite all but
    the lex-first file's copy to a fresh unused TYPE-K. The substitution is
    per-file (all occurrences of TYPE-N inside that file → TYPE-K), so a
    file's self-references to its own new entity follow the rename.

    Refuses to auto-fix when the duplicate token also appears in a file that
    does NOT declare it — that means a cross-file wikilink whose intended
    target is ambiguous, and silently picking one declaration would corrupt
    the reference.

    Returns True iff any file was rewritten (caller should re-scan)."""
    duplicates: Dict[str, List[Path]] = {}
    for ph, files in decls.items():
        uniq = sorted(set(files), key=lambda p: str(p))
        if len(uniq) > 1:
            duplicates[ph] = uniq
    if not duplicates:
        return False

    # Tokens currently appearing in each file (for cross-ref check) and per-type
    # used integers (so we don't pick a colliding new placeholder).
    file_tokens: Dict[Path, Set[str]] = {}
    used_per_type: Dict[str, Set[int]] = defaultdict(set)
    for f in all_files:
        toks: Set[str] = set()
        for tok in _id_in_string(f.read_text(encoding="utf-8")):
            if is_placeholder_id(tok):
                p = parse_id(tok)
                if p:
                    toks.add(tok)
                    used_per_type[p[0]].add(p[1])
        file_tokens[f] = toks

    rewrites: Dict[Path, Dict[str, str]] = defaultdict(dict)
    for ph, dup_files in duplicates.items():
        p = parse_id(ph)
        if not p:
            continue
        type_, _, _ = p
        external = sorted(
            (str(f.relative_to(eng_root)).replace("\\", "/") for f, toks in file_tokens.items()
             if ph in toks and f not in dup_files)
        )
        if external:
            dup_rel = sorted(str(f.relative_to(eng_root)).replace("\\", "/") for f in dup_files)
            die(
                f"placeholder {ph} is declared in multiple files {dup_rel} AND referenced "
                f"in {external}. cannot auto-uniquify safely — the references are ambiguous "
                f"(which declaration do they point to?).\n\n"
                f"Fix manually:\n"
                f"  1. pick which declaring file should keep `{ph}`.\n"
                f"  2. in the OTHER declaring file(s), rename `{ph}` to a fresh unused "
                f"placeholder (e.g. `{type_}-N` for some small N).\n"
                f"  3. in the referencing files {external}, update each `[[{ph}]]` to point "
                f"to whichever declaration you intended.\n"
                f"  4. DO NOT TOUCH any id with {ID_PAD}+ digits (those are real ids — "
                f"renaming them invalidates wikilinks, evidence/finding cross-refs, and "
                f"finding/evidence filenames across the entire engagement).",
                code=1,
            )
        for f in dup_files[1:]:
            new_n = _next_free_placeholder_int(used_per_type[type_])
            if new_n is None:
                die(
                    f"placeholder {ph} duplicated and no free placeholder slot "
                    f"(< {10 ** ID_PAD}) is available for type {type_}. split the commit "
                    f"into smaller pieces, or commit some files first.",
                    code=1,
                )
            new_ph = f"{type_}-{new_n}"
            rewrites[f][ph] = new_ph
            used_per_type[type_].add(new_n)

    for f, ren in rewrites.items():
        text = f.read_text(encoding="utf-8")
        new_text = _substitute_ids(text, ren)
        if new_text != text:
            tmp = f.with_suffix(f.suffix + ".tmp")
            tmp.write_text(new_text, encoding="utf-8")
            tmp.replace(f)
    return bool(rewrites)


def _next_free_placeholder_int(used: Set[int]) -> Optional[int]:
    for cand in range(1, 10 ** ID_PAD):
        if cand not in used:
            return cand
    return None


def _print_post_commit_hints() -> None:
    """Nudge the agent on the two state files commit doesn't touch."""
    print()
    print("hints:")
    print("  - STATE.md & index.md are the stigmergy comms layer — update them before commit if")
    print("    this round shifted state or discovered new info; future agents read them to know")
    print("    what's going on. Append to relevant sections, don't rewrite (reason curate does")
    print("    holistic index.md rebuilds).")
    print("  - md files in wiki/plan/record/ are updated in-place by kb commit — DO NOT rm them.")


def _rewrite_file(path: Path, renames: Dict[str, str], today: str) -> None:
    """Rewrite a file by substituting placeholder IDs with real IDs and updating
    `last_updated` frontmatter to today (if frontmatter present)."""
    text = path.read_text(encoding="utf-8")
    new_text = _substitute_ids(text, renames)
    new_text = _stamp_last_updated(new_text, today)
    if new_text == text:
        return
    # Atomic write via temp file.
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(new_text, encoding="utf-8")
    tmp.replace(path)


def _substitute_ids(text: str, renames: Dict[str, str]) -> str:
    """Replace each placeholder ID with its real ID throughout the text.

    Uses a single regex pass over standalone ID tokens — handles headings,
    wikilinks `[[X]]`, bullet values, frontmatter list members.
    """
    def repl(m: re.Match) -> str:
        tok = m.group(1)
        return renames.get(tok, tok)
    return _ID_TOKEN.sub(repl, text)


def _stamp_last_updated(text: str, today: str) -> str:
    fm_text, body = split_frontmatter(text)
    if fm_text is None:
        return text
    fm = parse_frontmatter(fm_text)
    if "last_updated" not in fm:
        return text
    fm["last_updated"] = today
    return serialize_frontmatter(fm) + body
