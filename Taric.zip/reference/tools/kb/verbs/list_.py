"""kb list [type] [--filter k=v] [--include-archived]."""
from __future__ import annotations

import json
import re
from typing import Any, Iterable, List, Optional

from .. import ctx, pool_hygiene, reprobe_hygiene
from ..index import build_index
from ..parser import ENTITY_TYPES


# The entity's "locator" — its identity at a glance (an endpoint's path, a
# service's host:port). Shown as a column in `kb list` so you don't have to
# `kb show` each one. Ordered fallback; SERVICE combines host:port.
_LOCATOR_KEYS = ("path", "url_path", "url", "fqdn", "ip")


def _locator(meta: dict) -> str:
    host, port = meta.get("host"), meta.get("port")
    if isinstance(host, str) and host.strip() and port not in (None, ""):
        return f"{host.strip()}:{port}"
    for k in _LOCATOR_KEYS:
        v = meta.get(k)
        if isinstance(v, str) and v.strip():
            return v.strip()
    return ""


def _dedup_fields(e) -> dict:
    """Type-specific fields that make `list --json` a usable dedup ledger — no
    `show` per entity. A HYPOTHESIS dedups on (targets, class); carrying those
    (+ status) lets a combiner prune duplicates from one compact call instead of
    reading the whole hypotheses.md. Parser already strips wikilinks, so targets
    are clean ids (or "system-wide")."""
    if e.type != "HYPOTHESIS":
        return {}
    tg = e.bullets.get("targets")
    targets = [tg] if isinstance(tg, str) else [t for t in tg if isinstance(t, str)] if isinstance(tg, list) else []

    def _s(k):
        v = e.bullets.get(k)
        return str(v).strip() if v not in (None, "") else None

    return {"targets": targets, "class": _s("class"), "status": _s("status")}


def _filter_match(entity_or_file_meta: dict, key: str, op: str, val: str) -> bool:
    actual = entity_or_file_meta.get(key)
    if actual is None:
        return False
    if isinstance(actual, list):
        if op == "=~":
            return any(re.search(val, str(x), re.IGNORECASE) for x in actual)
        return any(str(x) == val for x in actual)
    s = str(actual)
    if op == "=~":
        return bool(re.search(val, s, re.IGNORECASE))
    return s == val


def _parse_filters(raw: Iterable[str]) -> List[tuple]:
    """Returns list of (key, op, val). op is '=' or '=~' or '=' (presence)."""
    out: List[tuple] = []
    for f in raw:
        if "=~" in f:
            k, _, v = f.partition("=~")
            out.append((k.strip(), "=~", v.strip()))
        elif "=" in f:
            k, _, v = f.partition("=")
            out.append((k.strip(), "=", v.strip()))
        else:
            out.append((f.strip(), "=", ""))  # presence
    return out


def cmd_list(args) -> int:
    eng = ctx.require(args.engagement)
    idx = build_index(eng)
    type_arg = (args.type or "").upper() if args.type else None
    if type_arg:
        if type_arg == "TOPIC":
            return _list_topics(args, eng, idx)
        if type_arg not in ENTITY_TYPES:
            from ..util import die
            die(f"unknown type {args.type!r}", code=2)
    filters = _parse_filters(args.filter or [])
    archived = idx.archived_entity_ids()
    rows: List[dict] = []
    # Entities:
    for e in idx.all_entities():
        if e.is_placeholder:
            continue
        if type_arg and e.type != type_arg:
            continue
        if not args.include_archived and e.id in archived:
            continue
        meta = dict(e.bullets)
        # Inherit file frontmatter onto entities for filtering convenience.
        for f in idx.files:
            if any(en.id == e.id for en in f.entities):
                # Map workflow / tags from file frontmatter if not on bullets.
                if "workflow" not in meta and isinstance(f.frontmatter.get("workflow"), str):
                    meta["workflow"] = f.frontmatter["workflow"]
                break
        if not all(_filter_match(meta, k, op, v) for k, op, v in filters):
            continue
        rows.append({
            "kind": e.type,
            "id": e.id,
            "title": e.title,
            "locator": _locator(meta),
            **_dedup_fields(e),
            "file": _rel(e.source_file, eng.root),
        })
    # Topic-page rows when type is omitted:
    if type_arg is None:
        for slug, f in idx.topics.items():
            meta = dict(f.frontmatter)
            if not all(_filter_match(meta, k, op, v) for k, op, v in filters):
                continue
            rows.append({
                "kind": "TOPIC",
                "id": slug,
                "title": str(f.frontmatter.get("title", slug)),
                "file": f.rel_path,
            })

    if getattr(args, "json", False):
        print(json.dumps(rows, indent=2, ensure_ascii=False))
        return 0
    _print_rows(rows)
    if type_arg == "FINDING":
        reprobe_hygiene.emit(eng)  # generation-site: don't raise a new probe on a proven sink
    return 0 if rows else 0


def _list_topics(args, eng, idx) -> int:
    filters = _parse_filters(args.filter or [])
    rows: List[dict] = []
    for slug, f in idx.topics.items():
        meta = dict(f.frontmatter)
        if not all(_filter_match(meta, k, op, v) for k, op, v in filters):
            continue
        rows.append({
            "kind": "TOPIC",
            "id": slug,
            "title": str(f.frontmatter.get("title", slug)),
            "file": f.rel_path,
        })
    if getattr(args, "json", False):
        print(json.dumps(rows, indent=2, ensure_ascii=False))
        return 0
    _print_rows(rows)
    return 0


def _rel(p, root) -> str:
    try:
        return str(p.relative_to(root)).replace("\\", "/")
    except Exception:
        return str(p)


def _print_rows(rows: List[dict]) -> None:
    if not rows:
        return
    id_w = max(len(r["id"]) for r in rows)
    title_w = min(max(len(r["title"]) for r in rows), 70)
    has_cls = any(r.get("class") for r in rows)          # hypotheses: the dedup half you scan by
    has_loc = any(r.get("locator") for r in rows)
    cls_w = max((len(r.get("class") or "") for r in rows), default=0)
    # Locator (endpoint path etc.) goes LAST and un-truncated — the full path is
    # the point, its tail is the distinguishing part, and ragged-right avoids
    # padding gaps for mixed-length paths.
    file_w = max(len(r["file"]) for r in rows) if has_loc else 0
    for r in rows:
        title = r["title"] if len(r["title"]) <= title_w else r["title"][: title_w - 1] + "…"
        cols = [f"{r['id']:<{id_w}}", f"{title:<{title_w}}"]
        if has_cls:
            cols.append(f"{(r.get('class') or ''):<{cls_w}}")
        if has_loc:
            cols.append(f"{r['file']:<{file_w}}")
            cols.append(r.get("locator", ""))
        else:
            cols.append(r["file"])
        print("  ".join(cols))


# pending / stale also live here (small).

def cmd_pending(args) -> int:
    eng = ctx.require(args.engagement)
    idx = build_index(eng)
    archived = idx.archived_entity_ids()
    rows: List[dict] = []
    for e in idx.all_entities():
        if e.is_placeholder or e.id in archived:
            continue
        status = e.bullets.get("status")
        if e.type == "HYPOTHESIS" and status in ("untested", "testing"):
            rows.append({"kind": "HYPOTHESIS", "id": e.id, "title": e.title, "status": str(status),
                         "file": _rel(e.source_file, eng.root)})
        elif e.type == "TASK" and status in ("pending", "running"):
            rows.append({"kind": "TASK", "id": e.id, "title": e.title, "status": str(status),
                         "file": _rel(e.source_file, eng.root)})
    if getattr(args, "json", False):
        print(json.dumps(rows, indent=2, ensure_ascii=False))
        return 0
    if not rows:
        print("(none pending)")
        return 0
    id_w = max(len(r["id"]) for r in rows)
    st_w = max(len(r["status"]) for r in rows)
    for r in rows:
        title = r["title"][:70]
        print(f"{r['id']:<{id_w}}  {r['status']:<{st_w}}  {title}  {r['file']}")
    pool_hygiene.emit(eng, freed=False)  # >=2 pending → nudge fill-to-cap, not 1-at-a-time
    reprobe_hygiene.emit(eng)            # flag pending probes on an already-established (endpoint, class)
    return 0


def cmd_stale(args) -> int:
    import datetime as _dt
    eng = ctx.require(args.engagement)
    idx = build_index(eng)
    older = args.older_than or "7d"
    days = _parse_duration_days(older)
    cutoff = _dt.date.today() - _dt.timedelta(days=days)
    rows: List[dict] = []
    for f in idx.files:
        fm = f.frontmatter
        status = fm.get("status")
        if status not in ("in-progress", "stub"):
            continue
        lu = fm.get("last_updated")
        if not isinstance(lu, str):
            continue
        try:
            d = _dt.date.fromisoformat(lu[:10])
        except ValueError:
            continue
        if d < cutoff:
            rows.append({
                "file": f.rel_path,
                "status": str(status),
                "last_updated": lu,
                "title": str(fm.get("title", "")),
            })
    if getattr(args, "json", False):
        print(json.dumps(rows, indent=2, ensure_ascii=False))
        return 0
    if not rows:
        print("(no stale files)")
        return 0
    for r in rows:
        print(f"{r['last_updated']}  {r['status']:<12}  {r['file']}  — {r['title']}")
    return 0


def _parse_duration_days(s: str) -> int:
    s = s.strip().lower()
    if s.endswith("d"):
        return int(s[:-1])
    if s.endswith("w"):
        return int(s[:-1]) * 7
    return int(s)
