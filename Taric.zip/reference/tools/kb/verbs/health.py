"""kb health — lint rules over the engagement tree."""
from __future__ import annotations

import datetime as _dt
import json
import re
from collections import defaultdict
from pathlib import Path
from typing import Dict, List

from .. import ctx
from ..index import Index, build_index
from ..parser import (
    ENTITY_TYPES,
    find_wikilinks,
    parse_id,
    split_frontmatter,
)
from ..schema import LAYOUT_RULES, REQUIRED_BULLETS, REQUIRED_FRONTMATTER, fm_has


# Issue record.
def _issue(rule: str, severity: str, file: str = "", line: int = 0, message: str = "") -> dict:
    return {"rule": rule, "severity": severity, "file": file, "line": line, "message": message}


def cmd_health(args) -> int:
    eng = ctx.require(args.engagement)
    quiet = bool(getattr(args, "quiet", False))
    issues: List[dict] = []
    idx = build_index(eng)

    issues += _check_frontmatter(eng, idx)
    issues += _check_entities(idx)
    issues += _check_fences(idx)
    issues += _check_layout(eng, idx)
    issues += _check_wikilinks(idx)
    issues += _check_referential_integrity(idx)
    issues += _check_duplicates(idx)
    issues += _check_oversized(eng)
    issues += _check_undocumented_volume(idx)
    issues += _check_stale(idx)
    issues += _check_coverage_bullets(idx)

    if getattr(args, "json", False):
        print(json.dumps(issues, indent=2, ensure_ascii=False))
        return 3 if any(i["severity"] in ("error", "warning") for i in issues) else 0

    if not issues:
        if not quiet:
            print("health: clean")
        return 0
    if not quiet:
        by_sev = defaultdict(int)
        for i in issues:
            by_sev[i["severity"]] += 1
        summary = ", ".join(f"{k} {v}" for k, v in sorted(by_sev.items()))
        print(f"health: {len(issues)} issue(s) — {summary}")
        for i in issues:
            loc = i["file"] + (f":{i['line']}" if i["line"] else "")
            print(f"  [{i['severity']:<7}] {i['rule']:<25} {loc:<45} {i['message']}")
    has_real = any(i["severity"] in ("error", "warning") for i in issues)
    return 3 if has_real else 0


# ───────────────────────── Rules ─────────────────────────

def _check_frontmatter(eng, idx: Index) -> List[dict]:
    out: List[dict] = []
    for f in idx.files:
        # Reload raw text for detection of fully-missing frontmatter.
        raw = f.raw
        if not raw.startswith("---"):
            out.append(_issue("missing-frontmatter", "error", f.rel_path, 1,
                              "file has no YAML frontmatter"))
            continue
        ftype = f.frontmatter.get("type")
        if not ftype:
            out.append(_issue("missing-frontmatter", "error", f.rel_path, 1,
                              "frontmatter missing 'type' field"))
            continue
        required = REQUIRED_FRONTMATTER.get(str(ftype), [])
        for key in required:
            if not fm_has(f.frontmatter, key):
                out.append(_issue("missing-frontmatter", "error", f.rel_path, 1,
                                  f"frontmatter missing required key '{key}' for type '{ftype}'"))
    return out


def _check_entities(idx: Index) -> List[dict]:
    out: List[dict] = []
    for e in idx.all_entities():
        rel = e.source_file.relative_to(idx.eng.root) if e.source_file else None
        rel_s = str(rel).replace("\\", "/") if rel else ""
        required = REQUIRED_BULLETS.get(e.type, [])
        for k in required:
            if k not in e.bullets:
                out.append(_issue(
                    "missing-required-bullets", "error", rel_s, e.heading_line,
                    f"{e.id}: missing required bullet '{k}'",
                ))
    return out


def _check_fences(idx: Index) -> List[dict]:
    """A CHAIN (or any entity in schema.REQUIRED_FENCES) must carry its required
    body fence — a ```dot attack-path graph. `kb commit` hard-gates this; the
    lint catches any that slipped in via hand-edit."""
    from ..validators.entity_body import missing_fences
    out: List[dict] = []
    for e in idx.all_entities():
        rel = str(e.source_file.relative_to(idx.eng.root)).replace("\\", "/") if e.source_file else ""
        for lang in missing_fences(e):
            out.append(_issue(
                "missing-required-fence", "error", rel, e.heading_line,
                f"{e.id}: body must contain a ```{lang} code block",
            ))
    return out


def _check_layout(eng, idx: Index) -> List[dict]:
    out: List[dict] = []
    for e in idx.all_entities():
        rel = str(e.source_file.relative_to(idx.eng.root)).replace("\\", "/") if e.source_file else ""
        allowed = LAYOUT_RULES.get(e.type, [])
        if not any(rel.startswith(prefix) for prefix in allowed):
            out.append(_issue(
                "layout-violation", "error", rel, e.heading_line,
                f"{e.id}: allowed under {allowed}, found in {rel!r}",
            ))
    return out


def _check_wikilinks(idx: Index) -> List[dict]:
    out: List[dict] = []
    real_ids = set(idx.by_id.keys())
    placeholder_ids = set(idx.placeholders.keys())
    archived_ids = idx.archived_entity_ids()
    slugs = set(idx.topics.keys())
    for f in idx.files:
        for ref in find_wikilinks(f.raw):
            t = ref.target
            # Could be an entity ID or a topic slug.
            if t in real_ids or t in placeholder_ids or t in archived_ids:
                continue
            if t in slugs:
                continue
            # Allow ID-prefixed-with-slug, e.g. "ENDPOINT-7" but not in index — flag.
            out.append(_issue(
                "broken-wikilink", "error", f.rel_path, ref.line,
                f"[[{t}]] does not resolve",
            ))
    return out


def _check_referential_integrity(idx: Index) -> List[dict]:
    out: List[dict] = []
    real_ids = set(idx.by_id.keys()) | idx.archived_entity_ids()
    for f in idx.files:
        own_id = f.frontmatter.get("id")
        own_id = own_id if isinstance(own_id, str) else None
        # Frontmatter ID-list values:
        for k, v in f.frontmatter.items():
            if k == "id":
                continue  # the file's self-id is not a reference
            for s in _id_strings(v):
                if parse_id(s) and not parse_id(s)[2]:  # claimed real ID
                    if s not in real_ids:
                        out.append(_issue(
                            "referential-integrity", "error", f.rel_path, 1,
                            f"frontmatter {k} references missing entity {s}",
                        ))
        for e in f.entities:
            # Skip self-references when iterating a synthesized standalone-file entity:
            if e.heading_line == 0 and e.id == own_id:
                continue
            for k, v in e.bullets.items():
                if k == "id":
                    continue
                for s in _id_strings(v):
                    if parse_id(s) and not parse_id(s)[2]:
                        if s not in real_ids:
                            out.append(_issue(
                                "referential-integrity", "error",
                                f.rel_path, e.heading_line,
                                f"{e.id}: bullet {k} references missing entity {s}",
                            ))
    return out


def _id_strings(v) -> List[str]:
    """Yield ID-shaped strings from a scalar or list value."""
    out: List[str] = []
    if isinstance(v, list):
        for item in v:
            if isinstance(item, str) and parse_id(item):
                out.append(item)
    elif isinstance(v, str) and parse_id(v):
        out.append(v)
    return out


def _check_duplicates(idx: Index) -> List[dict]:
    out: List[dict] = []
    seen: Dict[str, str] = {}
    for f in idx.files:
        for e in f.entities:
            if e.is_placeholder:
                continue
            if e.id in seen and seen[e.id] != f.rel_path:
                out.append(_issue(
                    "duplicate-real-id", "error", f.rel_path, e.heading_line,
                    f"{e.id} also declared in {seen[e.id]}",
                ))
            else:
                seen[e.id] = f.rel_path
        # ID/filename match for FINDING/EVIDENCE files:
        ftype = f.frontmatter.get("type")
        fid = f.frontmatter.get("id")
        if ftype in ("finding", "evidence") and isinstance(fid, str):
            stem = Path(f.rel_path).stem
            if fid != stem:
                out.append(_issue(
                    "id-filename-mismatch", "error", f.rel_path, 1,
                    f"frontmatter id={fid!r} does not match filename stem={stem!r}",
                ))
    return out


def _check_oversized(eng) -> List[dict]:
    out: List[dict] = []
    for p in eng.root.rglob("*.md"):
        try:
            rel = str(p.relative_to(eng.root)).replace("\\", "/")
        except ValueError:
            continue
        if rel.startswith("raw/"):
            continue
        try:
            n = sum(1 for _ in p.open(encoding="utf-8"))
        except OSError:
            continue
        if n > 500:
            out.append(_issue(
                "oversized-file", "warning", rel, 0,
                f"{n} lines (>500) — consider splitting topic",
            ))
    return out


def _check_undocumented_volume(idx: Index) -> List[dict]:
    n = sum(
        1 for e in idx.all_entities()
        if not e.is_placeholder and e.bullets.get("status") == "undocumented"
    )
    if n > 20:
        return [_issue(
            "too-many-undocumented", "warning", "", 0,
            f"{n} entities at status:undocumented (>20) — triage time",
        )]
    return []


def _check_stale(idx: Index) -> List[dict]:
    out: List[dict] = []
    today = _dt.date.today()
    for f in idx.files:
        st = f.frontmatter.get("status")
        if st not in ("in-progress", "stub"):
            continue
        lu = f.frontmatter.get("last_updated")
        if not isinstance(lu, str):
            continue
        try:
            d = _dt.date.fromisoformat(lu[:10])
        except ValueError:
            continue
        if (today - d).days > 7:
            out.append(_issue(
                "stale-active", "warning", f.rel_path, 1,
                f"status={st!r} but last_updated={lu} (>7 days ago)",
            ))
    return out


# `coverage-skip:` / `coverage-block:` bullets carry per-rollup-category
# resolution annotations on entities. Format: `<cat> (<reason>)`, comma-
# separated; the category regex is profile-specific (OWASP cats for web,
# ATT&CK tactics for host). For `coverage-block:`, the reason must lead with
# `needs-user-input:` or `technical:` so the orchestrator's batch-report logic
# can pick the user-facing ones up at termination.
_BLOCK_PREFIX_RE = re.compile(r"^(needs-user-input|technical):", re.IGNORECASE)


def _check_coverage_bullets(idx: Index) -> List[dict]:
    from ..profiles import active_profile
    cov_item_re = active_profile().cov_item_re
    out: List[dict] = []
    for e in idx.all_entities():
        rel = str(e.source_file.relative_to(idx.eng.root)).replace("\\", "/") if e.source_file else ""
        skip = e.bullets.get("coverage-skip")
        if isinstance(skip, str) and skip.strip():
            for cat, reason in cov_item_re.findall(skip):
                if not reason.strip():
                    out.append(_issue(
                        "unjustified-coverage-skip", "info", rel, e.heading_line,
                        f"{e.id}: coverage-skip {cat} has no rationale",
                    ))
        block = e.bullets.get("coverage-block")
        if isinstance(block, str) and block.strip():
            for cat, reason in cov_item_re.findall(block):
                if not _BLOCK_PREFIX_RE.match(reason.strip()):
                    out.append(_issue(
                        "coverage-block-without-prefix", "info", rel, e.heading_line,
                        f"{e.id}: coverage-block {cat} rationale lacks "
                        f"'needs-user-input:' / 'technical:' prefix",
                    ))
    return out
