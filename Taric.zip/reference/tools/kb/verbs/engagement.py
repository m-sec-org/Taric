"""kb engagement set — write the engagement-level mode bullets on STATE.md's
`## Engagement` block, in one validated command.

These modes (Assessment / Destructive-op / OTP-assist) are the authoritative
per-engagement settings the whole runtime reads. They live as `- Key: value`
bullets in `STATE.md ## Engagement` (so `kb state` surfaces them generically —
see state.py `_engagement_extras`). Before this verb, bootstrap hand-appended
them as free-text lines, which drifts on a typo. This command updates the bullet
in place (or inserts it), validating the enum, so the value is always parseable.
"""
from __future__ import annotations

import re

from .. import ctx
from ..lock import acquire
from ..log import append_event, append_log
from ..util import die

# arg attr -> (canonical bullet label, allowed enum values)
MODE_SPECS = {
    "assessment_mode": ("Assessment mode", {"full", "focused", "verified-scan"}),
    "destructive_mode": ("Destructive-op mode", {"human-authorize", "auto-allow"}),
    "otp_assist": ("OTP-assist mode", {"assisted", "silent"}),
}


def _key_of(line: str):
    """Return the lower-cased key of a `[- ]Key: value` line, else None."""
    m = re.match(r"^-?\s*([^:]+):", line.strip())
    return m.group(1).strip().lower() if m else None


def cmd_engagement_set(args) -> int:
    eng = ctx.require(args.engagement)

    # Validate + collect requested changes BEFORE taking the lock.
    requested = []  # (label, value)
    for attr, (label, allowed) in MODE_SPECS.items():
        val = getattr(args, attr, None)
        if val is None:
            continue
        val = val.strip()
        if val not in allowed:
            die(f"invalid {label!r} value {val!r}; allowed: {', '.join(sorted(allowed))}")
        requested.append((label, val))
    if not requested:
        print("no changes")
        return 0

    with acquire(eng.root):
        if not eng.state_md.exists():
            die("no STATE.md — run `kb init` first")
        lines = eng.state_md.read_text(encoding="utf-8").splitlines()

        start = next((i for i, ln in enumerate(lines)
                      if ln.strip() == "## Engagement"), None)
        if start is None:
            die("no `## Engagement` block in STATE.md")
        end = next((j for j in range(start + 1, len(lines))
                    if lines[j].startswith("## ")), len(lines))

        changed = []
        for label, value in requested:
            newline = f"- {label}: {value}"
            hit = next((k for k in range(start + 1, end)
                        if _key_of(lines[k]) == label.lower()), None)
            if hit is not None:
                if lines[hit] != newline:
                    lines[hit] = newline
                    changed.append(label)
            else:
                # insert after the block's last non-blank line (keep bullets grouped)
                insert_at = end
                while insert_at - 1 > start and lines[insert_at - 1].strip() == "":
                    insert_at -= 1
                lines.insert(insert_at, newline)
                end += 1
                changed.append(label)

        if not changed:
            print("no changes")
            return 0
        eng.state_md.write_text("\n".join(lines) + "\n", encoding="utf-8")
        append_log(eng.log_md, "engagement set", ", ".join(changed), body="")
        append_event(eng.events_jsonl, verb="engagement_set", fields=changed)

    print(f"updated: {', '.join(changed)}")
    return 0
