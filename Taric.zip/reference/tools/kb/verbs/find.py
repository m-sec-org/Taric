"""kb find <substring> — fuzzy lookup over IDs, titles, slugs."""
from __future__ import annotations

import json
from typing import List, Tuple

from .. import ctx
from ..index import build_index


def _rank(query: str, field: str, kind: str) -> int:
    """Lower is better; 9999 means no match."""
    q = query.lower()
    fl = field.lower()
    if not fl:
        return 9999
    if kind == "id" and fl == q:
        return 0
    if kind == "slug" and fl == q:
        return 1
    if kind == "title" and fl.startswith(q):
        return 2
    if kind == "title" and q in fl:
        return 3
    if kind == "id" and q in fl:
        return 4
    if kind == "slug" and q in fl:
        return 5
    return 9999


def cmd_find(args) -> int:
    eng = ctx.require(args.engagement)
    idx = build_index(eng)
    q = args.query
    archived = idx.archived_entity_ids()
    rows: List[Tuple[int, dict]] = []
    # Entities (incl. archived — find spans the whole tree per spec).
    for e in idx.all_entities():
        if e.is_placeholder:
            continue
        rid = _rank(q, e.id, "id")
        rt = _rank(q, e.title, "title")
        r = min(rid, rt)
        if r < 9999:
            row = {
                "id": e.id,
                "title": e.title,
                "kind": e.type,
                "file": str(e.source_file.relative_to(eng.root)).replace("\\", "/") if e.source_file else "",
                "archived": e.id in archived,
            }
            rows.append((r, row))
    # Topic slugs:
    for slug, f in idx.topics.items():
        rs = _rank(q, slug, "slug")
        rt = _rank(q, str(f.frontmatter.get("title", "")), "title")
        r = min(rs, rt)
        if r < 9999:
            rows.append((r, {
                "id": slug,
                "title": str(f.frontmatter.get("title", slug)),
                "kind": "TOPIC",
                "file": f.rel_path,
                "archived": False,
            }))
    rows.sort(key=lambda x: (x[0], x[1]["id"]))
    rows = rows[:50]  # cap output

    if getattr(args, "json", False):
        print(json.dumps([r[1] for r in rows], indent=2, ensure_ascii=False))
        return 0
    if not rows:
        print("(no matches)")
        return 0
    id_w = max(len(r[1]["id"]) for r in rows)
    for _, r in rows:
        suffix = "  [archived]" if r["archived"] else ""
        title = r["title"][:70]
        print(f"{r['id']:<{id_w}}  {title}  {r['file']}{suffix}")
    return 0
