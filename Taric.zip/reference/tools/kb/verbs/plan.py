"""kb plan add — atomically append a batch of hypotheses, each with its tasks.

Agent-friendly alternative to hand-appending entity blocks with Read+Edit:
- reads a JSON batch (file arg, or stdin);
- validates the WHOLE batch and reports ALL problems at once — writes nothing
  on any error, so it's one fix pass, not a fail-per-retry loop;
- assigns fresh non-colliding placeholder IDs and wires each task to its parent
  hypothesis (`hypothesis: [[HYPOTHESIS-n]]`), so the agent never manages IDs;
- appends to plan/hypotheses.md + plan/tasks.md ATOMICALLY (temp file +
  os.replace, under the engagement lock) — no torn file, no EOF anchor.
Placeholders are resolved to real IDs by the next `bin/kb commit`.

Unknown JSON fields are ignored, so a richer object (close to the group-planner
digest) can be passed as-is.
"""
from __future__ import annotations

import json
import os
import re
import sys
from pathlib import Path
from typing import Any, Dict, List

from .. import ctx
from ..index import build_index
from ..lock import acquire
from ..profiles import active_profile
from ..util import die, err, today_iso
from ..validators.object_model import invalid_object_model_fields, missing_object_model_fields

_ID_RE = re.compile(r"^[A-Z]+-\d+$")
_PLACEHOLDER_RE = lambda typ: re.compile(rf"^### {typ}-(\d{{1,2}}):", re.M)


def _read_payload(args) -> Dict[str, Any]:
    src = getattr(args, "file", None)
    if src and src != "-":
        p = Path(src)
        if not p.exists():
            die(f"plan add: 文件不存在: {src}", code=2)
        text = p.read_text(encoding="utf-8")
    else:
        text = sys.stdin.read()
    if not text.strip():
        die("plan add: 输入为空(给一个 JSON 文件路径,或从 stdin 传入)", code=2)
    try:
        data = json.loads(text)
    except json.JSONDecodeError as e:
        die(f"plan add: 输入不是合法 JSON（{e}）;先 `jq empty` 自查再重跑", code=2)
    if isinstance(data, list):            # forgiving: a bare [...] is the hypotheses list
        data = {"hypotheses": data}
    if not isinstance(data, dict) or not isinstance(data.get("hypotheses"), list):
        die('plan add: 期望 {"hypotheses": [ {title, targets, class, severity_guess, '
            'rationale, tasks:[{actions}]} ]}(plan-digest 的 digest.json 即此形状)', code=2)
    return data


def _norm_targets(t) -> List[str]:
    items = t if isinstance(t, list) else [t]
    out: List[str] = []
    for x in items:
        s = str(x).strip()
        if not s:
            continue
        if s == "system-wide" or (s.startswith("[[") and s.endswith("]]")):
            out.append(s)
        else:
            out.append(f"[[{s}]]")
    return out


def _target_ids(t) -> List[str]:
    items = t if isinstance(t, list) else [t]
    return [s for s in (str(x).strip().strip("[]") for x in items) if s and s != "system-wide"]


def _next_placeholder(f: Path, typ: str) -> int:
    if not f.exists():
        return 1
    mx = 0
    for m in _PLACEHOLDER_RE(typ).finditer(f.read_text(encoding="utf-8")):
        mx = max(mx, int(m.group(1)))     # 1–2 digit = placeholder; real IDs are 3+ zero-padded
    return mx + 1


def _fmt_hypothesis(hid: str, h: Dict[str, Any]) -> str:
    L = [f"\n### {hid}: {str(h['title']).strip()}",
         f"- targets: {', '.join(_norm_targets(h['targets']))}",
         f"- class: {str(h['class']).strip()}"]
    if h.get("gbt_category"):
        L.append(f"- gbt_category: {str(h['gbt_category']).strip()}")
    L.append(f"- severity_guess: {str(h['severity_guess']).strip()}")
    if h.get("rating_basis"):
        L.append(f"- rating_basis: {str(h['rating_basis']).strip()}")
    if h.get("confidence"):
        L.append(f"- confidence: {str(h['confidence']).strip()}")
    if h.get("owasp"):
        L.append(f"- owasp: {str(h['owasp']).strip()}")
    if h.get("tags"):
        tags = h["tags"]
        L.append(f"- tags: {', '.join(map(str, tags)) if isinstance(tags, list) else str(tags)}")
    for key in ("object_type", "object_id_source", "owner_scope", "operation",
                "boundary", "control", "unique_variable", "verified_if", "refuted_if"):
        if h.get(key):
            L.append(f"- {key}: {str(h[key]).strip()}")
    L.append(f"- rationale: {str(h['rationale']).strip()}")
    L.append(f"- status: {str(h.get('status', 'untested')).strip()}")
    return "\n".join(L) + "\n"


def _fmt_task(tid: str, hid: str, t: Dict[str, Any], default_title: str) -> str:
    title = str(t.get("title") or default_title).strip()
    L = [f"\n### {tid}: {title}",
         f"- hypothesis: [[{hid}]]",
         f"- skill: {str(t.get('skill', 'probe')).strip()}"]
    if t.get("playbook"):
        L.append(f"- playbook: {str(t['playbook']).strip()}")
    L.append(f"- status: {str(t.get('status', 'pending')).strip()}")
    if t.get("auth_access"):  # web auth-material tasks (read|write|none); harmless when absent
        L.append(f"- auth_access: {str(t['auth_access']).strip()}")
    if t.get("affected_actors"):
        aa = t["affected_actors"]
        L.append(f"- affected_actors: {', '.join(map(str, aa)) if isinstance(aa, list) else str(aa)}")
    if t.get("preconds"):
        L.append(f"- preconds: {str(t['preconds']).strip()}")
    actions = t.get("actions") or t.get("body")
    if actions:
        L.append(f"- actions: {str(actions).strip()}")
    return "\n".join(L) + "\n"


def _atomic_append(f: Path, title: str, blocks: str) -> None:
    f.parent.mkdir(parents=True, exist_ok=True)
    if f.exists():
        content = f.read_text(encoding="utf-8")
        if not content.endswith("\n"):
            content += "\n"
        content += blocks
    else:
        content = f"---\ntitle: {title}\ntype: plan\nlast_updated: {today_iso()}\n---\n{blocks}"
    tmp = f.with_suffix(f.suffix + ".tmp")
    tmp.write_text(content, encoding="utf-8")
    os.replace(tmp, f)


def validate_batch(hyps: List[Any], known_ids, profile_name: str) -> List[str]:
    """Every per-hypothesis problem `plan add` would reject, as tagged strings.

    The single source of truth for "what plan add rejects" — `cmd_plan_add` calls
    it with the real kb index, and the plan-groups combiner (`plan-digest`) calls
    it with `known_ids=None` to preview the same verdict in `digest.md` BEFORE the
    batch reaches `plan add`. `known_ids=None` skips only the target-existence
    check (a caller without a kb index); every other check is identical.
    """
    errors: List[str] = []
    for i, h in enumerate(hyps):
        tag = f"hypotheses[{i}]" + (f" '{h.get('title')}'" if isinstance(h, dict) and h.get("title") else "")
        if not isinstance(h, dict):
            errors.append(f"{tag}: 不是对象")
            continue
        for k in ("title", "class", "severity_guess", "rationale"):
            if not str(h.get(k, "")).strip():
                errors.append(f"{tag}: 缺必填 `{k}`")
        tg = h.get("targets")
        if not tg:
            errors.append(f"{tag}: 缺 `targets`(实体 id 列表,或 \"system-wide\")")
        else:
            for tid in _target_ids(tg):
                if not _ID_RE.match(tid):
                    errors.append(f"{tag}: target `{tid}` 不是合法实体 id")
                elif known_ids is not None and tid not in known_ids:
                    errors.append(f"{tag}: target `{tid}` 在 kb 中不存在(先 observe / 用已读实体)")
        missing_object_fields = missing_object_model_fields(profile_name, h)
        if missing_object_fields:
            errors.append(
                f"{tag}: web 逻辑类 hypothesis 缺对象模型字段 "
                f"{', '.join('`' + field + '`' for field in missing_object_fields)}"
            )
        for violation in invalid_object_model_fields(profile_name, h):
            errors.append(f"{tag}: web 逻辑类对象模型约束: {violation}")
        tasks = h.get("tasks")
        if not isinstance(tasks, list) or not tasks:
            errors.append(f"{tag}: 每条假设必配 ≥1 task(否则 orphan 拦 gate)")
        else:
            for j, t in enumerate(tasks):
                if not isinstance(t, dict):
                    errors.append(f"{tag}.tasks[{j}]: 不是对象")
                elif not (str(t.get("actions") or t.get("body") or "").strip()
                          or str(t.get("title", "")).strip()):
                    errors.append(f"{tag}.tasks[{j}]: 至少给 `actions`(或 `title`)")
    return errors


def cmd_plan_add(args) -> int:
    eng = ctx.require(args.engagement)
    data = _read_payload(args)
    hyps = data["hypotheses"]
    if not hyps:
        die("plan add: hypotheses 为空", code=2)

    known = set(build_index(eng).by_id.keys())
    profile_name = active_profile().name
    errors = validate_batch(hyps, known, profile_name)

    if errors:
        err("plan add 被拒,未写入任何内容。逐条修好再重跑:")
        for n, e in enumerate(errors, 1):
            err(f"  {n}. {e}")
        sys.exit(2)

    hyp_file = eng.plan_dir / "hypotheses.md"
    task_file = eng.plan_dir / "tasks.md"
    added_h: List[str] = []
    added_t: List[str] = []
    with acquire(eng.root):
        hn = _next_placeholder(hyp_file, "HYPOTHESIS")
        tn = _next_placeholder(task_file, "TASK")
        h_blocks: List[str] = []
        t_blocks: List[str] = []
        for h in hyps:
            hid = f"HYPOTHESIS-{hn}"
            added_h.append(hid)
            h_blocks.append(_fmt_hypothesis(hid, h))
            h_title = str(h["title"]).strip()
            for t in h["tasks"]:
                tid = f"TASK-{tn}"
                added_t.append(tid)
                t_blocks.append(_fmt_task(tid, hid, t, h_title))
                tn += 1
            hn += 1
        _atomic_append(hyp_file, "Hypotheses", "".join(h_blocks))
        _atomic_append(task_file, "Tasks", "".join(t_blocks))

    if getattr(args, "json", False):
        print(json.dumps({"hypotheses": added_h, "tasks": added_t, "committed": False},
                         ensure_ascii=False))
    else:
        print(f"added {len(added_h)} hypotheses + {len(added_t)} tasks: "
              f"{added_h[0]}..{added_h[-1]}, {added_t[0]}..{added_t[-1]} "
              f"(placeholder — run `bin/kb commit` to assign real IDs)")
    return 0
