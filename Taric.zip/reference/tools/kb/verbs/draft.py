"""kb draft — per-Worker draft folder lifecycle for parallel-safe probe output.

Each probe Worker writes its output into `<eng>/.drafts/<worker>/`:

    handoff.md         — manifest: status flips, bullet appends, STATE/index
                          additions, summary. Frontmatter stamped with
                          `committed_at:` by `kb draft commit`.
    evidence-*.md      — evidence entities with placeholder IDs (local to draft).
    finding.md         — finding entity (if verdict=verified), placeholder ID.

The Worker never touches the canonical tree. After Worker returns successfully,
the orchestrator runs `kb draft integrate` which atomically:

  - allocates real IDs from the engagement counter,
  - rewrites cross-refs across all draft files,
  - moves files to canonical locations (`record/evidence/`, `record/findings/`),
  - applies status flips, bullet appends, STATE/index updates,
  - on finding: applies promote-side bookkeeping (endpoint flips, promoted_to),
  - appends log + event,
  - deletes the draft folder,
  - git-commits.

Subverbs:
  scaffold  — emit a finding skeleton into the draft folder
  commit    — validate draft; stamp committed_at on success
  integrate — orchestrator-side; validate + atomic apply under lock
  fail      — orchestrator-side; archive draft + write a NOTE; for 3-retry exits
"""
from __future__ import annotations

import json
import re
import shutil
from collections import defaultdict
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from .. import ctx, cvss, git_helper, pivot_hygiene, plan_hygiene, pool_hygiene, state_hygiene
from ..ids import allocate_ids, read_counters, reconcile_counters, write_counters
from ..index import build_index
from ..lock import acquire
from ..log import append_event, append_log
from ..parser import (
    is_placeholder_id,
    parse_frontmatter,
    parse_id,
    serialize_frontmatter,
    split_frontmatter,
)
from ..schema import (
    FINDING_STATUS_DEFAULT, REQUIRED_FRONTMATTER, STATUS_VALUES, fm_get, fm_has,
)
from ..util import die, err, now_isoZ, today_iso
from .promote import _append_wikilink, _update_entity_bullets


# Same regex as commit.py — TYPE-N as standalone token, not part of alnum/_/-.
_ID_TOKEN = re.compile(r"(?<![A-Za-z0-9_-])([A-Z]+-\d+)(?![A-Za-z0-9_-])")

_VALID_VERDICTS = ("verified", "refuted", "blocked", "failed", "done")
_VALID_SEVERITY = ("critical", "high", "medium", "low", "info")
_VALID_PROOF_TYPES = (
    "control-bypass", "access-control", "rate-limit", "config", "crypto",
    "info-disclosure", "static-code", "oob", "other",
)
_VALID_EVIDENCE_LEVELS = ("E1", "E2", "E3", "E4", "E5")
_VALID_VERIFICATION_RESULTS = ("confirmed", "partial", "refuted", "blocked")
_VALID_FINDING_DECISIONS = ("accept", "reject")

# Finding body sections that the agent must fill in.
_REQUIRED_FINDING_SECTIONS = ("Impact", "Reproduction", "Recommendation")
_REQUIRED_EVIDENCE_SECTIONS = (
    "Claim", "Test Design", "Evidence", "Interpretation", "Limitations"
)

# Placeholders we refuse to accept as filled prose.
_FILLIN_MARKERS = ("(fill in)", "(agent fills in)", "<fill in>", "TBD", "TODO")


# ───────────────────────── kb draft scaffold ─────────────────────────

def cmd_draft_scaffold(args) -> int:
    eng = ctx.require(args.engagement)
    kind = args.kind
    draft_dir = Path(args.draft_dir).resolve()
    draft_dir.mkdir(parents=True, exist_ok=True)
    if kind == "evidence":
        return _scaffold_evidence(args, eng, draft_dir)
    if kind == "handoff":
        return _scaffold_handoff(args, draft_dir)
    if kind != "finding":
        die(f"unknown scaffold kind: {kind!r} (supported: finding, evidence, handoff)", code=2)

    hyp_id = args.hypothesis
    if not hyp_id:
        die("--hypothesis (canonical HYPOTHESIS-NNN) is required for kind=finding", code=2)
    # CVSS is required: the vector computes cvss_score, while severity stays the
    # explicit GB/T 30279 rating (the two never derive each other, but both are
    # mandatory on a finding).
    vector = (getattr(args, "cvss_vector", None) or "").strip()
    if not vector:
        die(cvss.required_error("flag"), code=2)
    try:
        cvss_score = cvss.base_score(vector)
    except ValueError as exc:
        die(f"invalid --cvss-vector: {exc}", code=2)
    severity = getattr(args, "severity", None)
    if not severity:
        die("provide --severity (GB/T 30279 rating); --cvss-vector only computes cvss_score", code=2)
    if severity not in _VALID_SEVERITY:
        die(f"--severity must be one of {_VALID_SEVERITY}", code=2)
    p = parse_id(hyp_id)
    if not p or p[0] != "HYPOTHESIS":
        die(f"--hypothesis expected HYPOTHESIS-NNN, got {hyp_id!r}", code=2)
    if p[2]:
        die(f"{hyp_id} is a placeholder — scaffold requires a canonical hypothesis ID", code=2)

    # Look up hypothesis to seed frontmatter (targets, tags).
    idx = build_index(eng)
    hyp = idx.by_id.get(hyp_id)
    if not hyp:
        die(f"hypothesis {hyp_id} not found in canonical kb", code=1)
    targets = _coerce_id_list(hyp.bullets.get("targets"))
    if not targets:
        die(f"hypothesis {hyp_id} has no `targets` — cannot scaffold finding", code=1)
    tags = hyp.bullets.get("tags") or []
    if isinstance(tags, str):
        tags = [tags]
    title_seed = hyp.title or "verified vulnerability"

    finding_path = draft_dir / "finding.md"
    if finding_path.exists():
        die(f"{finding_path} already exists — refusing to overwrite", code=1)

    placeholder_n = _next_placeholder_int(draft_dir, "FINDING")
    placeholder_id = f"FINDING-{placeholder_n}"
    today = today_iso()

    fm = {
        "id": placeholder_id,
        "type": "finding",
        "title": title_seed,
        "severity": severity,
        "status": FINDING_STATUS_DEFAULT,
        "cvss_score": cvss_score,
        "cvss_vector": vector,
        "related_endpoints": targets,
        "evidence": [],
        "hypothesis": hyp_id,
        # Deepening seed (probe fills at accept): the reusable capability this
        # finding grants. Empty here so it's visible to fill; integrate requires
        # it non-empty (write `none` if the finding grants nothing reusable).
        "unlocks": "",
        "tags": list(tags),
        "created": today,
        "last_updated": today,
    }
    body = (
        f"\n# {title_seed}\n\n"
        "## Impact\n_(fill in)_\n\n"
        "## Reproduction\n_(fill in: auth context, request, expected vs observed)_\n\n"
        "## Recommendation\n_(fill in)_\n\n"
        "## Evidence\n_(fill in: list `[[EVIDENCE-N]]` wikilinks for each evidence file in this draft)_\n"
    )
    finding_path.write_text(serialize_frontmatter(fm) + body, encoding="utf-8")

    if getattr(args, "json", False):
        print(json.dumps({
            "path": str(finding_path),
            "placeholder_id": placeholder_id,
            "hypothesis": hyp_id,
            "severity": severity,
            "cvss_score": cvss_score,
            "cvss_vector": vector,
        }, ensure_ascii=False, indent=2))
        return 0
    print(f"scaffolded: {finding_path}")
    print(f"  placeholder id: {placeholder_id}")
    print(f"  fill in Impact / Reproduction / Recommendation, then `kb draft commit`.")
    return 0


def _scaffold_evidence(args, eng, draft_dir: Path) -> int:
    """Emit an evidence-N.md skeleton with the full frontmatter + all five proof
    sections + enum hints, so probe never hand-authors the shape from source.

    The file is lowercase `evidence-<n>.md` — the draft convention the commit
    validator globs (`_list_evidence_files`); the frontmatter `id` stays the
    uppercase `EVIDENCE-<n>` placeholder. Writing `EVIDENCE-<n>.md` would make the
    evidence invisible to `kb draft commit` on a case-sensitive filesystem."""
    n = _next_placeholder_int(draft_dir, "EVIDENCE")
    placeholder_id = f"EVIDENCE-{n}"
    ev_path = draft_dir / f"evidence-{n}.md"
    if ev_path.exists():
        die(f"{ev_path} already exists — refusing to overwrite", code=1)
    today = today_iso()
    related = (getattr(args, "related_endpoint", None) or "ENDPOINT-REPLACE-ME").strip()
    fm = {
        "id": placeholder_id,
        "type": "evidence",
        "title": "(fill in) one line — what this proves",
        "captured_at": now_isoZ(),
        "related_endpoint": related,
        "proof_type": "access-control",
        "evidence_level": "E3",
        "verification_result": "confirmed",
        "claim": "",
        "limitations": ["(fill in) what this evidence does NOT prove"],
        "artifacts": [],
        "created": today,
        "last_updated": today,
    }
    body = (
        "\n<!-- enums — proof_type: control-bypass|access-control|rate-limit|config|crypto|"
        "info-disclosure|static-code|oob|other · evidence_level: E1..E5 · verification_result: "
        "confirmed|partial|refuted|blocked. Set related_endpoint to the real entity. "
        "Full contract + proof_type mapping: `bin/kb schema evidence`. -->\n\n"
        "## Claim\n_(fill in: one precise sentence of what this evidence directly proves)_\n\n"
        "## Test Design\n- Control point:\n- Baseline / control request:\n"
        "- Trigger request:\n- Success criterion:\n\n"
        "## Evidence\n_(fill in: raw request / response / command output in fenced blocks "
        "— include baseline AND trigger)_\n\n"
        "## Interpretation\n_(fill in: why the observed response proves the claim)_\n\n"
        "## Limitations\n_(fill in: what this does NOT prove; missing auth / data / scope)_\n"
    )
    ev_path.write_text(serialize_frontmatter(fm) + body, encoding="utf-8")
    if getattr(args, "json", False):
        print(json.dumps({"path": str(ev_path), "placeholder_id": placeholder_id},
                         ensure_ascii=False, indent=2))
        return 0
    print(f"scaffolded: {ev_path}")
    print(f"  placeholder id: {placeholder_id}")
    print("  fill Claim / Test Design / Evidence / Interpretation / Limitations + set "
          "related_endpoint / claim, then `kb draft commit`.")
    print("  full contract: `bin/kb schema evidence`")
    return 0


def _scaffold_handoff(args, draft_dir: Path) -> int:
    """Emit a handoff.md skeleton: required frontmatter + every manifest section
    stub, so probe never hand-authors the shape from source. Optional sections
    carry guidance (no `-` lines → not parsed as entries), so an unfilled skeleton
    still commits once worker/task/verdict are set."""
    handoff_path = draft_dir / "handoff.md"
    if handoff_path.exists():
        die(f"{handoff_path} already exists — refusing to overwrite", code=1)
    task = (getattr(args, "task", None) or "").strip()
    fm = {
        "worker": "probe",
        "task": task,       # empty → `kb draft commit` flags it unless --task given
        "verdict": "",       # set verified|refuted|blocked|failed (verified needs finding.md)
    }
    body = (
        "\n<!-- verdict: verified|refuted|blocked|failed (verified REQUIRES a finding.md). "
        "`committed_at` is stamped by `kb draft commit` — leave it out. "
        "Full contract: `bin/kb schema handoff`. -->\n\n"
        "## Summary\n_(fill in: 2-3 lines — what you did and the verdict)_\n\n"
        "## Status flips\n"
        "one per line, REAL ids only, status from that type's enum — e.g.\n"
        "`- TASK-008: done`   `- HYPOTHESIS-012: refuted`\n\n"
        "## Bullet appends\n"
        "head is `<ENTITY-ID> <key>` (bare id, NOT wikilinked), then wikilink targets — e.g.\n"
        "`- TASK-008 evidence: [[EVIDENCE-1]], [[EVIDENCE-2]]`\n\n"
        "## Follow-up leads\n"
        "one deepen / lateral lead per line (integrate turns each into a deepen-lead NOTE)\n\n"
        "## STATE.md additions\n"
        "H3 sub-headings only: `### Blockers` / `### Background work` / `### Transport recipes`\n"
    )
    handoff_path.write_text(serialize_frontmatter(fm) + body, encoding="utf-8")
    if getattr(args, "json", False):
        print(json.dumps({"path": str(handoff_path)}, ensure_ascii=False, indent=2))
        return 0
    print(f"scaffolded: {handoff_path}")
    print("  set worker / task / verdict; fill Summary + the sections you use, then "
          "`kb draft commit`.")
    print("  full contract: `bin/kb schema handoff`")
    return 0


# ───────────────────────── kb draft commit ─────────────────────────

def cmd_draft_commit(args) -> int:
    eng = ctx.require(args.engagement)
    draft_dir = Path(args.draft_dir).resolve()
    handoff_path = draft_dir / "handoff.md"
    if not handoff_path.exists():
        die(f"handoff.md missing in {draft_dir}", code=1)

    # Normalize the finding's CVSS before validating: a `cvss_vector` computes
    # `cvss_score` only. `severity` is explicit (GB/T 30279) and must not drift
    # to CVSS score bands. This covers hand-authored finding.md (host probe).
    cvss_problem = _normalize_finding_cvss(draft_dir)

    problems = _validate_draft(draft_dir, eng)
    if cvss_problem:
        problems.insert(0, cvss_problem)
    if problems:
        err("draft validation failed:")
        for p in problems:
            err(f"  - {p}")
        err("\nFix the issues above, then re-run `kb draft commit`. Full contracts: "
            "`bin/kb schema handoff` (manifest + commit gate), `bin/kb schema evidence`, "
            "`bin/kb schema finding`.")
        return 1

    # Soft credential-lifecycle gate: warn with a fix runbook, do not fail commit.
    for warning in _credential_lifecycle_warnings(draft_dir, eng):
        err(warning)

    # Stamp committed_at into handoff frontmatter. Also capture the committing
    # subagent's dispatch_id here — this runs in the probe's shell (KB_DISPATCH_ID
    # set), whereas `draft integrate` runs in the orchestrator's shell (no
    # dispatch_id). Carrying it forward on the handoff lets integrate attribute
    # the resulting finding/evidence to the probe that produced it, uniform with
    # observe/reason. May be None for a main-agent run (then ownership stays as-is).
    fm, body = _load_handoff(handoff_path)
    fm["committed_at"] = now_isoZ()
    owner_dispatch_id = ctx.dispatch_id()
    if owner_dispatch_id:
        fm["owner_dispatch_id"] = owner_dispatch_id
    _save_handoff(handoff_path, fm, body)

    # A finding just cleared validation — nudge the worker to bank a reusable
    # exploit / transport artifact into `pivot/` (only complex, re-runnable ones).
    pivot_note = pivot_hygiene.banner(draft_dir)

    if getattr(args, "json", False):
        out = {"committed_at": fm["committed_at"]}
        if pivot_note:
            out["pivot_hint"] = True
        print(json.dumps(out, ensure_ascii=False))
        return 0
    print(f"ok — draft committed at {fm['committed_at']}")
    if pivot_note:
        print(pivot_note)
    return 0


# ───────────────────────── kb draft integrate ─────────────────────────

def cmd_draft_integrate(args) -> int:
    eng = ctx.require(args.engagement)
    draft_dir = Path(args.draft_dir).resolve()
    handoff_path = draft_dir / "handoff.md"
    if not handoff_path.exists():
        die(f"handoff.md missing in {draft_dir}", code=1)

    fm, body = _load_handoff(handoff_path)
    if not fm.get("committed_at"):
        die(
            f"draft at {draft_dir} is not committed (no `committed_at` in handoff.md). "
            f"Worker must run `kb draft commit` first.",
            code=1,
        )

    # Orchestrator-ack gate: integrate refuses unless main agent has read
    # handoff.md and appended an `## Orchestrator ack` section with content.
    # This forces the read-handoff step before destructive integrate.
    ack = _extract_section_body(body, "Orchestrator ack")
    if ack is None or not ack.strip():
        die(
            f"handoff.md at {draft_dir} is missing a non-empty `## Orchestrator ack` section.\n"
            f"\n"
            f"Before integrate, the orchestrator must Read handoff.md and append:\n"
            f"\n"
            f"    ## Orchestrator ack\n"
            f"    <one-line summary of verdict + next action>\n"
            f"\n"
            f"If the draft has a finding.md, also add these as BARE lines (no `- ` bullet, no quotes):\n"
            f"    finding_decision: accept        (or: reject)\n"
            f"    finding_reason: <one line>\n"
            f"    finding_evidence: EVIDENCE-1 EVIDENCE-2   (accept only; EVIDENCE-N ids only, no prose)\n"
            f"\n"
            f"This is a deliberate gate — it prevents dispatching the next task\n"
            f"without first understanding what the Worker just did.",
            code=1,
        )

    leads: List[str] = []
    lead_note_ids: List[str] = []
    with acquire(eng.root):
        # Re-validate under lock — canonical state might have shifted since Worker committed.
        problems = _validate_draft(draft_dir, eng)
        if problems:
            err("draft re-validation failed at integrate time:")
            for p in problems:
                err(f"  - {p}")
            return 1

        fm, body = _load_handoff(handoff_path)
        sections = _parse_handoff_sections(body)

        evidence_files = _list_evidence_files(draft_dir)
        finding_file = draft_dir / "finding.md" if (draft_dir / "finding.md").exists() else None

        idx = build_index(eng)

        finding_decision: Optional[str] = None
        finding_evidence: List[str] = []
        finding_reason = ""
        if finding_file is not None:
            f_fm, f_body = _load_md(finding_file)
            finding_decision, finding_evidence, finding_reason, admission_problems = (
                _parse_finding_admission(
                    ack, f_fm, f_body, evidence_files,
                )
            )
            if admission_problems:
                err("finding admission acknowledgement is invalid:")
                for problem in admission_problems:
                    err(f"  - {problem}")
                return 1

        # ─── 1. Allocate real IDs. Reconcile the counter against what already
        # exists first: a counter that drifted below the highest real ID (reset
        # target.json, restored record/, a prior partial integrate) would
        # otherwise re-allocate an existing ID and dead-loop on the move guard.
        real_ids = set(idx.by_id)
        for _d in (eng.evidence_dir, eng.findings_dir):
            if _d.is_dir():
                real_ids.update(p.stem for p in _d.glob("*.md"))
        counters = reconcile_counters(read_counters(eng.target_json), real_ids)
        renames: Dict[str, str] = {}

        # Evidence in lex order of filename for deterministic allocation.
        ev_placeholder_ids: List[str] = []
        for ef in evidence_files:
            ev_fm, _ev_body = _load_md(ef)
            ev_pid = ev_fm.get("id")
            if isinstance(ev_pid, str) and is_placeholder_id(ev_pid):
                ev_placeholder_ids.append(ev_pid)
        ev_real_ids = allocate_ids(counters, "EVIDENCE", len(ev_placeholder_ids))
        for ph, real in zip(ev_placeholder_ids, ev_real_ids):
            renames[ph] = real

        finding_real_id: Optional[str] = None
        if finding_file is not None and finding_decision == "accept":
            f_fm, _f_body = _load_md(finding_file)
            f_pid = f_fm.get("id")
            if not (isinstance(f_pid, str) and is_placeholder_id(f_pid)):
                die(f"{finding_file}: id must be a placeholder, got {f_pid!r}", code=1)
            finding_real_id = allocate_ids(counters, "FINDING", 1)[0]
            renames[f_pid] = finding_real_id

        # Follow-up leads → held as `deepen-lead:` NOTEs (durable) + queued in
        # STATE.md `## Follow-up leads`. Allocate real NOTE IDs now (alongside
        # evidence/finding) so the STATE queue reference is stable across commits.
        leads = _scan_follow_up_leads(body)
        lead_note_ids = allocate_ids(counters, "NOTE", len(leads)) if leads else []

        # ─── 2. Rewrite IDs in draft files (frontmatter values + body wikilinks).
        rewrite_paths = evidence_files + ([finding_file] if finding_real_id else [])
        for path in rewrite_paths:
            _substitute_ids_in_file(path, renames)

        # ─── 3. Move files into canonical paths.
        eng.evidence_dir.mkdir(parents=True, exist_ok=True)
        eng.findings_dir.mkdir(parents=True, exist_ok=True)

        moved_evidence: List[str] = []
        for ef, real_id in zip(evidence_files, ev_real_ids):
            dest = eng.evidence_dir / f"{real_id}.md"
            if dest.exists():
                die(f"target {dest} already exists during evidence move", code=1)
            ef.rename(dest)
            moved_evidence.append(real_id)

        moved_finding: Optional[str] = None
        if finding_file is not None and finding_real_id is not None:
            dest = eng.findings_dir / f"{finding_real_id}.md"
            if dest.exists():
                die(f"target {dest} already exists during finding move", code=1)
            finding_file.rename(dest)
            moved_finding = finding_real_id

        rejection_archive: Optional[str] = None
        rejection_note_id: Optional[str] = None
        if finding_file is not None and finding_decision == "reject":
            ts = datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")
            archive_root = eng.root / ".drafts" / "_rejected-findings"
            archive_root.mkdir(parents=True, exist_ok=True)
            archive_dir = archive_root / f"{ts}-{draft_dir.name}"
            suffix = 1
            while archive_dir.exists():
                archive_dir = archive_root / f"{ts}-{draft_dir.name}-{suffix}"
                suffix += 1
            archive_dir.mkdir()
            archived_finding = archive_dir / "finding.md"
            finding_file.rename(archived_finding)
            rejection_archive = archived_finding.relative_to(eng.root).as_posix()
            rejection_note_id = allocate_ids(counters, "NOTE", 1)[0]

        # ─── 4. Persist counters.
        write_counters(eng.target_json, counters)

        # ─── 5. Apply status flips + bullet appends from handoff.
        # (idx was built above, before the moves; the entities targeted by status
        # flips / bullet appends are pre-existing, so the pre-move snapshot is
        # correct — the just-moved evidence/finding are not flip targets.)
        status_flips = _parse_status_flips(sections.get("Status flips", ""))
        for entity_id, new_status in status_flips:
            _apply_status_flip(eng, idx, entity_id, new_status)

        bullet_appends = _parse_bullet_appends(
            sections.get("Bullet appends", ""), renames,
        )
        for entity_id, key, targets in bullet_appends:
            for tgt in targets:
                _apply_bullet_append(eng, idx, entity_id, key, tgt)

        # ─── 6. Promote-side bookkeeping for the finding.
        if moved_finding:
            hyp_id = fm.get("hypothesis")
            if isinstance(hyp_id, str):
                _apply_bullet_append(eng, idx, hyp_id, "promoted_to", moved_finding)
                # Endpoint flips + related links — read finding's targets after rename.
                f_path = eng.findings_dir / f"{moved_finding}.md"
                f_fm, f_body = _load_md(f_path)
                # Back-fill the `evidence:` frontmatter from the curated `## Evidence`
                # body wikilinks (IDs already remapped to real ones in step 2) when the
                # probe left the field empty. `kb draft scaffold-finding` seeds
                # `evidence: []` and asks the worker to list evidence only in the body,
                # so without this the structured field stays empty and every downstream
                # consumer (report, poc-author) has to re-derive it from prose.
                if not _coerce_id_list(fm_get(f_fm, "evidence")):
                    ev_sec = _extract_section_body(f_body, "Evidence") or ""
                    body_evs = list(dict.fromkeys(re.findall(r"EVIDENCE-\d+", ev_sec)))
                    if body_evs:
                        f_fm["evidence"] = body_evs
                        f_path.write_text(
                            serialize_frontmatter(f_fm) + f_body, encoding="utf-8")
                targets = _coerce_id_list(fm_get(f_fm, "related_endpoints"))
                for ep_id in targets:
                    _apply_status_flip(eng, idx, ep_id, "verified-issue")
                    _apply_bullet_append(eng, idx, ep_id, "related", moved_finding)

        # ─── 7. Apply STATE.md / index.md additions.
        state_additions = _parse_md_additions(sections.get("STATE.md additions", ""))
        index_additions = _parse_md_additions(sections.get("index.md additions", ""))
        # A probe may (wrongly) nest `Follow-up leads` under STATE.md / index.md
        # additions — strip it there so it is not double-written as raw text; the
        # canonical persist path is `_persist_follow_up_leads` below (deepen-lead
        # NOTE + STATE `## Follow-up leads` queue).
        for _adds in (state_additions, index_additions):
            for _k in [k for k in list(_adds) if _is_follow_up_key(k)]:
                _adds.pop(_k, None)
        if state_additions:
            _apply_section_additions(eng.state_md, state_additions)
        if index_additions:
            _apply_section_additions(eng.index_md, index_additions)

        # ─── 7b. Follow-up leads: hold each as a `deepen-lead:` NOTE (durable
        # content) and queue it in STATE.md `## Follow-up leads` (pending-handling
        # flag reason drains). Leads are NO LONGER transient.
        if leads:
            _persist_follow_up_leads(eng, leads, lead_note_ids, str(fm.get("task", "?")))

        if rejection_note_id and rejection_archive:
            _persist_rejected_finding_note(
                eng,
                rejection_note_id,
                worker=str(fm.get("worker", "?")),
                task=str(fm.get("task", "?")),
                hypothesis=str(fm.get("hypothesis", "?")),
                reason=finding_reason,
                archive=rejection_archive,
            )

        # ─── 8. Log + event.
        worker = fm.get("worker", "?")
        task = fm.get("task", "?")
        verdict = fm.get("verdict", "?")
        title = f"Integrated draft from {worker} (task={task}, verdict={verdict})"
        body_msg_lines = [
            f"Evidence allocated: {', '.join(moved_evidence) or '(none)'}",
        ]
        if moved_finding:
            body_msg_lines.append(f"Finding allocated: {moved_finding}")
        elif rejection_archive:
            body_msg_lines.append(f"Finding admission: rejected ({rejection_archive})")
        if status_flips:
            body_msg_lines.append("Status flips: " + ", ".join(f"{i}={s}" for i, s in status_flips))
        body_msg = "\n".join(body_msg_lines)

        append_event(
            eng.events_jsonl,
            verb="draft_integrate",
            worker=worker,
            task=task,
            verdict=verdict,
            evidence=moved_evidence,
            finding=moved_finding,
            status_flips=[i for i, _s in status_flips],
            dispatch_id=ctx.dispatch_id(),
            # The producing probe, captured on the handoff at `draft commit` time.
            # Distinct from `dispatch_id` above (the orchestrator, ~always None):
            # this is what attributes the finding/evidence to the probe subagent.
            owner_dispatch_id=fm.get("owner_dispatch_id"),
            renames=renames,
            finding_admission=(
                "accepted" if moved_finding else "rejected" if rejection_archive else "not-applicable"
            ),
            finding_evidence=[renames.get(eid, eid) for eid in finding_evidence],
            finding_reason=finding_reason or None,
            rejection_archive=rejection_archive,
        )
        append_log(eng.log_md, "draft_integrate", title, body=body_msg)

        # A probe's shared authenticated-read leases are scoped to its TASK-N.
        # Integration is the normal, deterministic task finalizer; only that
        # task's leases are removed, leaving concurrent readers untouched.
        # Only a draft that closed its canonical task may finalize that task's
        # readers. A worker-controlled handoff task string alone is insufficient.
        # Canonical state, not an optional handoff status-flip line, determines
        # whether finalization is safe. The lease also binds this cleanup to the
        # original draft path, so another draft cannot release it.
        final_task = build_index(eng).by_id.get(str(task))
        task_closed = (
            final_task is not None
            and final_task.bullets.get("status")
            in {"done", "verified", "refuted", "blocked", "failed", "abandoned"}
        )
        if task_closed:
            from .auth import _read_actor, _write_actor
            for actor_path in eng.auth_dir.glob("*.json"):
                actor_data = _read_actor(actor_path)
                read_leases = actor_data.get("read_leases")
                lease = read_leases.get(task) if isinstance(read_leases, dict) else None
                if not isinstance(lease, dict):
                    continue
                if lease.get("draft_dir") != str(draft_dir):
                    continue
                read_leases.pop(task)
                if read_leases:
                    actor_data["read_leases"] = read_leases
                else:
                    actor_data.pop("read_leases", None)
                _write_actor(actor_path, actor_data)
                append_event(
                    eng.events_jsonl,
                    verb="auth_read_lease",
                    actor=actor_path.stem,
                    task=task,
                    action="read-reap",
                    reason="task-integrated",
                    outcome="reaped",
                )

        # ─── 9. Delete draft folder.
        shutil.rmtree(draft_dir)

        # ─── 10. git auto-commit + refresh exported .api/*.json (same as `commit`).
        git_helper.commit(eng.root, title, body_msg)
        from .export_ import auto_export
        auto_export(eng)

    # Deepening is a judgement call, not a count. The trigger is a probe-reported
    # follow-up lead (a "this unlocks something chainable" signal), NOT every finding.
    # Leads were persisted above (deepen-lead NOTEs + STATE queue); the hint below
    # surfaces them to the orchestrator as a `<system-reminder>`.
    if getattr(args, "json", False):
        print(json.dumps({
            "evidence": moved_evidence,
            "finding": moved_finding,
            "renames": renames,
            "finding_admission": (
                "accepted" if moved_finding else "rejected" if rejection_archive else "not-applicable"
            ),
            "finding_evidence": [renames.get(eid, eid) for eid in finding_evidence],
            "rejection_archive": rejection_archive,
            "follow_up_leads": leads,
            "deepen_lead_notes": lead_note_ids,
            "deepen_hint": bool(leads),
        }, ensure_ascii=False, indent=2))
        return 0
    print(f"integrated: {title}")
    if moved_evidence:
        print(f"  evidence: {' '.join(moved_evidence)}")
    if moved_finding:
        print(f"  finding:  {moved_finding}")
    if leads:
        print("<system-reminder>")
        print("probe 上报了可深挖 / 可串链线索,已落为 deepen-lead NOTE 并入 STATE.md "
              "`## Follow-up leads` 待办队列:")
        for nid, lead in zip(lead_note_ids, leads):
            print(f"  · {nid}: {lead}")
        print("下一轮判断是否 dispatch reason 的 deepening(adjacent / escalate / chain "
              "三轴 + capability-to-surface)消化这些 NOTE。"
              "处理完由 reason 把对应 NOTE retire 并从 STATE `## Follow-up leads` 剪除。")
        print("</system-reminder>")
    state_hygiene.emit(eng)  # Layer 2 prune of drained follow-up leads + Layer 1 size banner
    plan_hygiene.emit(eng)   # nudge `bin/kb archive` when a plan file is large + mostly-closed
    pool_hygiene.emit(eng, freed=True)  # a probe slot just freed — nudge fill-to-cap, not 1-at-a-time
    return 0


# ───────────────────────── kb draft fail ─────────────────────────

def cmd_draft_fail(args) -> int:
    eng = ctx.require(args.engagement)
    draft_dir = Path(args.draft_dir).resolve()
    if not draft_dir.exists():
        die(f"draft directory not found: {draft_dir}", code=1)
    reason = (args.reason or "").strip()
    if not reason:
        die("--reason is required", code=2)

    with acquire(eng.root):
        original_draft_dir = str(draft_dir)
        # Move the draft to .drafts/_failed/<timestamp>-<basename>/
        ts = datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")
        failed_root = eng.root / ".drafts" / "_failed"
        failed_root.mkdir(parents=True, exist_ok=True)
        dest = failed_root / f"{ts}-{draft_dir.name}"
        # Defensive: avoid collisions.
        i = 1
        while dest.exists():
            dest = failed_root / f"{ts}-{draft_dir.name}-{i}"
            i += 1
        shutil.move(str(draft_dir), str(dest))

        # Read handoff if it survived (it's inside the moved folder now).
        handoff = dest / "handoff.md"
        task_id = ""
        worker = "?"
        if handoff.exists():
            fm, _ = _load_handoff(handoff)
            task_id = str(fm.get("task") or "")
            worker = str(fm.get("worker") or "?")

        # Write a NOTE entity into plan/notes.md describing the failure.
        notes_md = eng.plan_dir / "notes.md"
        rel_dest = dest.relative_to(eng.root).as_posix()
        n = _next_placeholder_int_in_file(notes_md, "NOTE")
        note_id = f"NOTE-{n}"
        related_line = f"- related: [[{task_id}]]\n" if task_id else ""
        worker_line = f"- worker: {worker}\n" if worker and worker != "?" else ""
        note_block = (
            f"\n### {note_id}: Draft integration failed for {worker}\n"
            f"- status: stale\n"
            f"{related_line}"
            f"{worker_line}"
            f"- archived_at: {rel_dest}\n"
            f"- reason: {reason}\n"
        )
        if not notes_md.exists():
            notes_md.write_text(
                "---\n"
                "title: Plan Notes\n"
                "type: plan\n"
                f"last_updated: {today_iso()}\n"
                "---\n\n"
                f"# {eng.slug} — Plan Notes\n"
                + note_block,
                encoding="utf-8",
            )
        else:
            with notes_md.open("a", encoding="utf-8") as fh:
                fh.write(note_block)

        title = f"Draft fail: {worker} (task={task_id or '?'}) → {rel_dest}"
        append_event(
            eng.events_jsonl,
            verb="draft_fail",
            worker=worker,
            task=task_id,
            archived_at=rel_dest,
            reason=reason,
        )
        append_log(eng.log_md, "draft_fail", title, body=reason)
        # Failure conclusively ends this exact worker draft. Reap only readers
        # bound to its original path; a replacement task can acquire afresh.
        from .auth import _read_actor, _write_actor
        for actor_path in eng.auth_dir.glob("*.json"):
            actor_data = _read_actor(actor_path)
            read_leases = actor_data.get("read_leases")
            if not isinstance(read_leases, dict):
                continue
            removed = [
                task for task, lease in read_leases.items()
                if isinstance(lease, dict) and lease.get("draft_dir") == original_draft_dir
            ]
            if not removed:
                continue
            for task in removed:
                read_leases.pop(task)
                append_event(eng.events_jsonl, verb="auth_read_lease", actor=actor_path.stem,
                             task=task, action="read-reap", reason="draft-failed", outcome="reaped")
            if read_leases:
                actor_data["read_leases"] = read_leases
            else:
                actor_data.pop("read_leases", None)
            _write_actor(actor_path, actor_data)
        git_helper.commit(eng.root, title, reason)

    if getattr(args, "json", False):
        print(json.dumps({
            "archived_at": rel_dest,
            "note": note_id,
        }, ensure_ascii=False))
        return 0
    print(f"archived: {rel_dest}")
    print(f"  note: {note_id}")
    return 0


# ═════════════════════════ helpers ═════════════════════════

def _load_md(path: Path) -> Tuple[Dict[str, Any], str]:
    text = path.read_text(encoding="utf-8")
    fm_text, body = split_frontmatter(text)
    fm = parse_frontmatter(fm_text) if fm_text is not None else {}
    return fm, body


def _normalize_finding_cvss(draft_dir: Path) -> Optional[str]:
    """If `finding.md` carries a `cvss_vector`, (re)compute `cvss_score` and
    write it back. No-op when there is no finding or no vector. Returns an error
    string on a malformed vector (so commit fails with a clear message) else None."""
    finding_path = draft_dir / "finding.md"
    if not finding_path.exists():
        return None
    fm, body = _load_md(finding_path)
    raw = fm.get("cvss_vector")
    vector = raw.strip() if isinstance(raw, str) else ""
    if not vector:
        return None
    try:
        score = cvss.base_score(vector)
    except ValueError as exc:
        return f"finding.md: invalid cvss_vector: {exc}"
    fm["cvss_score"] = score
    finding_path.write_text(serialize_frontmatter(fm) + body, encoding="utf-8")
    return None


def _load_handoff(path: Path) -> Tuple[Dict[str, Any], str]:
    return _load_md(path)


def _save_handoff(path: Path, fm: Dict[str, Any], body: str) -> None:
    path.write_text(serialize_frontmatter(fm) + body, encoding="utf-8")


def _coerce_id_list(v: Any) -> List[str]:
    if v is None:
        return []
    if isinstance(v, list):
        return [str(x).strip() for x in v if isinstance(x, str) and x.strip()]
    if isinstance(v, str):
        return [v.strip()] if v.strip() else []
    return []


def _list_evidence_files(draft_dir: Path) -> List[Path]:
    return sorted(p for p in draft_dir.glob("evidence-*.md"))


def _next_placeholder_int(draft_dir: Path, type_: str) -> int:
    """Find the next unused placeholder integer for `type_` inside the draft folder."""
    used: set = set()
    if draft_dir.exists():
        for p in draft_dir.glob("*.md"):
            try:
                text = p.read_text(encoding="utf-8")
            except OSError:
                continue
            for m in _ID_TOKEN.finditer(text):
                tok = m.group(1)
                parsed = parse_id(tok)
                if parsed and parsed[0] == type_ and parsed[2]:
                    used.add(parsed[1])
    for i in range(1, 100):
        if i not in used:
            return i
    die(f"no free placeholder slot < 100 for {type_} in {draft_dir}", code=1)
    return 0  # unreachable


def _next_placeholder_int_in_file(path: Path, type_: str) -> int:
    used: set = set()
    if path.exists():
        try:
            text = path.read_text(encoding="utf-8")
        except OSError:
            text = ""
        for m in _ID_TOKEN.finditer(text):
            tok = m.group(1)
            parsed = parse_id(tok)
            if parsed and parsed[0] == type_ and parsed[2]:
                used.add(parsed[1])
    for i in range(1, 100):
        if i not in used:
            return i
    return 99  # fallback; unlikely


# ──────────────── validation ────────────────

def _validate_draft(draft_dir: Path, eng) -> List[str]:
    """Run all checks. Return list of human-readable problems (empty = ok)."""
    problems: List[str] = []
    handoff_path = draft_dir / "handoff.md"
    if not handoff_path.exists():
        return [f"handoff.md missing in {draft_dir}"]

    fm, body = _load_handoff(handoff_path)
    # Frontmatter required fields.
    for field in ("worker", "task", "verdict"):
        if not fm.get(field):
            problems.append(f"handoff.md frontmatter missing `{field}`")
    verdict = fm.get("verdict")
    if verdict and verdict not in _VALID_VERDICTS:
        problems.append(f"handoff.md verdict={verdict!r} not in {_VALID_VERDICTS}")

    sections = _parse_handoff_sections(body)
    # Status flips must reference real IDs (canonical) that exist.
    idx = build_index(eng) if eng else None
    status_flips = _parse_status_flips(sections.get("Status flips", ""))
    if fm.get("blocker") == "auth-lease-violation":
        if verdict != "blocked":
            problems.append("auth-lease-violation requires verdict=blocked")
        if any(value in {"done", "verified", "refuted", "abandoned", "verified-issue"}
               for _, value in status_flips):
            problems.append("auth-lease-violation cannot retain terminal status flips")
        if (draft_dir / "finding.md").exists():
            problems.append("auth-lease-violation: retain evidence, defer finding promotion until recovery")
        if re.search(r"\b(promoted_to|related)\s*:", sections.get("Bullet appends", "")):
            problems.append("auth-lease-violation cannot retain finding association intents")
    for entity_id, value in status_flips:
        p = parse_id(entity_id)
        if not p:
            problems.append(f"status flip: invalid entity id {entity_id!r}")
            continue
        if p[2]:
            problems.append(f"status flip: {entity_id} is a placeholder (must be real)")
            continue
        if idx is not None and entity_id not in idx.by_id:
            problems.append(f"status flip: canonical entity {entity_id} not found")
            continue
        enum = STATUS_VALUES.get(p[0], [])
        if enum and value not in enum:
            problems.append(
                f"status flip: invalid status {value!r} for {p[0]} (allowed: {enum})"
            )

    # Bullet appends syntax check (targets may include draft placeholders).
    try:
        _parse_bullet_appends(sections.get("Bullet appends", ""), renames={})
    except ValueError as e:
        problems.append(f"bullet appends: {e}")

    # Evidence files: each must have required frontmatter + proof-chain sections.
    evidence_files = _list_evidence_files(draft_dir)
    for ef in evidence_files:
        ev_fm, ev_body = _load_md(ef)
        for req in REQUIRED_FRONTMATTER["evidence"]:
            if not fm_has(ev_fm, req):
                problems.append(f"{ef.name}: missing frontmatter field `{req}`")
        proof_type = ev_fm.get("proof_type")
        if proof_type and proof_type not in _VALID_PROOF_TYPES:
            problems.append(f"{ef.name}: proof_type={proof_type!r} not in {_VALID_PROOF_TYPES}")
        evidence_level = ev_fm.get("evidence_level")
        if evidence_level and evidence_level not in _VALID_EVIDENCE_LEVELS:
            problems.append(f"{ef.name}: evidence_level={evidence_level!r} not in {_VALID_EVIDENCE_LEVELS}")
        verification_result = ev_fm.get("verification_result")
        if verification_result and verification_result not in _VALID_VERIFICATION_RESULTS:
            problems.append(
                f"{ef.name}: verification_result={verification_result!r} not in {_VALID_VERIFICATION_RESULTS}"
            )
        claim = ev_fm.get("claim")
        if isinstance(claim, str) and not claim.strip():
            problems.append(f"{ef.name}: frontmatter field `claim` is empty")
        limitations = ev_fm.get("limitations")
        if limitations is not None and not isinstance(limitations, list):
            problems.append(f"{ef.name}: frontmatter field `limitations` must be a list")
        for section in _REQUIRED_EVIDENCE_SECTIONS:
            section_body = _extract_section_body(ev_body, section)
            if section_body is None:
                problems.append(f"{ef.name}: missing `## {section}` section")
                continue
            if not section_body.strip():
                problems.append(f"{ef.name}: `## {section}` is empty")
                continue
            low = section_body.lower()
            if any(m.lower() in low for m in _FILLIN_MARKERS):
                problems.append(
                    f"{ef.name}: `## {section}` still contains a fill-in placeholder"
                )
        ev_id = ev_fm.get("id")
        if isinstance(ev_id, str):
            pp = parse_id(ev_id)
            if not pp or pp[0] != "EVIDENCE":
                problems.append(f"{ef.name}: id={ev_id!r} is not an EVIDENCE id")
            elif not pp[2]:
                problems.append(f"{ef.name}: id={ev_id!r} must be a placeholder")
        ep = fm_get(ev_fm, "related_endpoint")
        if isinstance(ep, str) and idx is not None and ep not in idx.by_id:
            problems.append(f"{ef.name}: related_endpoint/related_asset {ep} not found in canonical kb")

    # Finding file (if present): full schema + body sections + prose filled in.
    finding_path = draft_dir / "finding.md"
    if verdict == "verified" and not finding_path.exists():
        problems.append("verdict=verified but finding.md is missing")
    if finding_path.exists():
        f_fm, f_body = _load_md(finding_path)
        for req in REQUIRED_FRONTMATTER["finding"]:
            if not fm_has(f_fm, req):
                problems.append(f"finding.md: missing frontmatter field `{req}`")
        f_id = f_fm.get("id")
        if isinstance(f_id, str):
            pp = parse_id(f_id)
            if not pp or pp[0] != "FINDING":
                problems.append(f"finding.md: id={f_id!r} is not a FINDING id")
            elif not pp[2]:
                problems.append(f"finding.md: id={f_id!r} must be a placeholder")
        sev = f_fm.get("severity")
        if sev and sev not in _VALID_SEVERITY:
            problems.append(f"finding.md: severity={sev!r} not in {_VALID_SEVERITY}")
        # CVSS is mandatory (a present-but-empty `cvss_vector` slips past the
        # REQUIRED_FRONTMATTER presence check above, so enforce non-emptiness here
        # with a message that tells the worker exactly how to supply it). Vector
        # syntax is validated separately by `_normalize_finding_cvss` at commit.
        cvss_vector = f_fm.get("cvss_vector")
        if not (isinstance(cvss_vector, str) and cvss_vector.strip()):
            problems.append(cvss.required_error("frontmatter"))
        # `status` is optional (auto-seeded by scaffold); if present it must be a
        # legal triage value so a hand-edit can't smuggle in a junk status.
        f_status = f_fm.get("status")
        _finding_status_enum = STATUS_VALUES.get("FINDING", [])
        if f_status and _finding_status_enum and f_status not in _finding_status_enum:
            problems.append(
                f"finding.md: status={f_status!r} not in {_finding_status_enum}"
            )
        hyp_ref = f_fm.get("hypothesis")
        if isinstance(hyp_ref, str) and idx is not None and hyp_ref not in idx.by_id:
            problems.append(f"finding.md: hypothesis {hyp_ref} not found in canonical kb")
        # Required body sections.
        for section in _REQUIRED_FINDING_SECTIONS:
            section_body = _extract_section_body(f_body, section)
            if section_body is None:
                problems.append(f"finding.md: missing `## {section}` section")
                continue
            if not section_body.strip():
                problems.append(f"finding.md: `## {section}` is empty")
                continue
            low = section_body.lower()
            if any(m.lower() in low for m in _FILLIN_MARKERS):
                problems.append(
                    f"finding.md: `## {section}` still contains a fill-in placeholder"
                )
        # Finding admission floor: the finding must cite at least one draft
        # Evidence that is both related and confirmed. A worker's labels are
        # structural prerequisites only; the orchestrator later judges whether
        # the raw proof supports the security claim.
        ep_targets = _coerce_id_list(fm_get(f_fm, "related_endpoints"))
        if not ep_targets:
            problems.append("finding.md: no related_endpoints / related_assets")
        else:
            cited_evidence = _finding_cited_evidence(f_fm, f_body)
            if not cited_evidence:
                problems.append("finding.md: no cited evidence in frontmatter or `## Evidence`")
            ev_hits = []
            for ef in evidence_files:
                ev_fm, _ = _load_md(ef)
                ev_id = ev_fm.get("id")
                if (
                    isinstance(ev_id, str)
                    and ev_id in cited_evidence
                    and fm_get(ev_fm, "related_endpoint") in ep_targets
                    and ev_fm.get("verification_result") == "confirmed"
                ):
                    ev_hits.append(ev_id)
            if not ev_hits:
                problems.append(
                    f"finding.md: no cited confirmed evidence points at any of {ep_targets} "
                    f"(admission floor: need ≥1)"
                )
        hyp_verified = False
        if isinstance(hyp_ref, str) and idx is not None:
            hyp = idx.by_id.get(hyp_ref)
            hyp_verified = bool(hyp and hyp.bullets.get("status") == "verified")
            hyp_verified = hyp_verified or any(
                entity_id == hyp_ref and value == "verified"
                for entity_id, value in status_flips
            )
        if not hyp_verified:
            problems.append(
                "finding.md: source hypothesis must already be verified or have a "
                "`verified` status flip in this draft"
            )

    return problems


# High-confidence password-mutation narrative (not mere field names / hashes).
_CRED_MUTATION_CLAIM = re.compile(
    r"(?is)("
    r"password\s*(overwrite|overwritten|reset|change[d]?|mutat\w*|覆写|修改|重置|改密)"
    r"|change[-_ ]?password|reset[-_ ]?password|newpassword|respwd"
    r"|账户接管|account\s*takeover"
    r"|password\s*=\s*[^\s\"']+|password%3d"
    r")"
)
_CRED_MUTATION_NONE = re.compile(
    r"(?im)^\s*credential_mutation\s*:\s*none\s*$"
)


def _credential_lifecycle_warnings(draft_dir: Path, eng) -> List[str]:
    """Soft gate: password-mutation claims should have auth_lifecycle events.

    Returns human-readable runbook warnings (empty = no gap). Never blocks commit.
    """
    handoff_path = draft_dir / "handoff.md"
    if not handoff_path.exists():
        return []
    fm, body = _load_handoff(handoff_path)
    if _CRED_MUTATION_NONE.search(body or ""):
        return []

    blobs: List[str] = []
    signals: List[str] = []
    for ef in _list_evidence_files(draft_dir):
        ev_fm, ev_body = _load_md(ef)
        text = f"{ev_fm.get('title', '')}\n{ev_fm.get('claim', '')}\n{ev_body}"
        if _CRED_MUTATION_CLAIM.search(text):
            blobs.append(text)
            signals.append(ef.name)
    finding_path = draft_dir / "finding.md"
    if finding_path.exists():
        f_fm, f_body = _load_md(finding_path)
        text = f"{f_fm.get('title', '')}\n{f_body}"
        if _CRED_MUTATION_CLAIM.search(text):
            blobs.append(text)
            signals.append("finding.md")
    if not signals:
        return []

    task = str(fm.get("task") or "").strip() or "<TASK-N>"
    lifecycle_actions: List[str] = []
    actors_hint: List[str] = []
    if eng is not None and eng.events_jsonl.exists():
        for line in eng.events_jsonl.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            try:
                ev = json.loads(line)
            except json.JSONDecodeError:
                continue
            if ev.get("verb") != "auth_lifecycle":
                continue
            if task != "<TASK-N>" and str(ev.get("task") or "") != task:
                continue
            action = str(ev.get("action") or "")
            if action:
                lifecycle_actions.append(action)
            actor = str(ev.get("actor") or "")
            if actor and actor not in actors_hint:
                actors_hint.append(actor)

    missing: List[str] = []
    if "reserve" not in lifecycle_actions:
        missing.append("auth_lifecycle reserve for this task")
    claims = "\n".join(blobs).lower()
    restoreish = any(
        k in claims
        for k in ("restore", "恢复", "改回", "original password", "原密码")
    )
    if restoreish and "password-verified" not in lifecycle_actions:
        missing.append(
            "password-verified after independent login "
            "(API restore alone is not verification)"
        )
    if not missing and lifecycle_actions:
        return []

    actor_state_lines: List[str] = []
    if eng is not None and eng.auth_dir.exists():
        for ap in sorted(eng.auth_dir.glob("*.json")):
            try:
                data = json.loads(ap.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                continue
            st = data.get("credential_state", "available")
            active = data.get("active_task") or "-"
            actor_state_lines.append(
                f"    {ap.stem}: credential_state={st} active_task={active}"
            )
    state_block = "\n".join(actor_state_lines) if actor_state_lines else "    (no auth/*.json)"
    actors = ", ".join(actors_hint) if actors_hint else "<affected-actor>"
    miss = "; ".join(missing) if missing else "lifecycle trail incomplete for mutation claim"
    return [
        "credential-lifecycle gap (soft warning — commit still succeeds)\n"
        f"  signal: {', '.join(signals)}\n"
        f"  task: {task}\n"
        f"  missing: {miss}\n"
        f"  actors seen in lifecycle events: {actors}\n"
        f"  current auth state:\n{state_block}\n"
        "  fix (pick one; then re-run is optional for soft mode):\n"
        "    A) not yet mutated: reserve each AFFECTED actor → mutate → "
        "independent login → password-verified → release|handover-required|"
        "mark-unknown|mark-locked\n"
        "    B) already mutated and current password known: reserve if available → "
        "independent login with CURRENT password (follow runtime evidence policy; "
        "do not copy secrets into logs or handoff) → password-verified → restore path or handover/release; "
        "do NOT change the password again only to satisfy this gate\n"
        "    C) actor leased by another task / not available: verdict=blocked; "
        "do not force reserve\n"
        "    D) evidence did not mutate passwords (read-only hash/field): narrow "
        "claim or add handoff line `credential_mutation: none`\n"
        "  do NOT: edit auth/*.json directly; do NOT invent candidate passwords"
    ]


# ──────────────── handoff parsing ────────────────

def _finding_cited_evidence(fm: Dict[str, Any], body: str) -> List[str]:
    """Return finding evidence references, preserving first-seen order."""
    ids = _coerce_id_list(fm_get(fm, "evidence"))
    evidence_section = _extract_section_body(body, "Evidence") or ""
    ids.extend(re.findall(r"EVIDENCE-\d+", evidence_section))
    return list(dict.fromkeys(ids))


def _parse_ack_fields(ack: str) -> Dict[str, str]:
    """Parse the compact key/value fields owned by the orchestrator ack.

    Tolerant of a natural markdown bullet (``- finding_decision: accept``) and
    wrapping quotes on the value: the ack lives inside a markdown section, so the
    orchestrator naturally writes bullets. Silently rejecting the bulleted form
    was the main integrate-retry trap (the parser saw key ``- finding_decision``,
    never matched, and reported the *value* as wrong).
    """
    fields: Dict[str, str] = {}
    for line in ack.splitlines():
        key, separator, value = line.partition(":")
        key = key.strip().lstrip("-*").strip()
        if separator and key in {"finding_decision", "finding_evidence", "finding_reason"}:
            fields[key] = value.strip().strip("'\"").strip()
    return fields


def _parse_finding_admission(
    ack: str,
    finding_fm: Dict[str, Any],
    finding_body: str,
    evidence_files: List[Path],
) -> Tuple[Optional[str], List[str], str, List[str]]:
    """Validate the three-state admission contract before any mutation.

    A malformed acknowledgement is a correctable command error, never an
    implicit rejection. Only a deliberate, well-formed reject is archived.
    """
    fields = _parse_ack_fields(ack)
    decision = fields.get("finding_decision", "")
    reason = fields.get("finding_reason", "")
    problems: List[str] = []
    if decision not in _VALID_FINDING_DECISIONS:
        problems.append(
            "`finding_decision` must be a bare line `finding_decision: accept` or "
            "`finding_decision: reject` (no leading `- ` bullet, no quotes on the value)"
        )
    if not reason:
        problems.append("`finding_reason` is required (bare line `finding_reason: <text>`)")

    raw_evidence = fields.get("finding_evidence", "")
    selected = re.findall(r"(?:EVIDENCE|evidence)-\d+", raw_evidence)
    if raw_evidence.strip() and not selected:
        problems.append(
            "`finding_evidence` must be only EVIDENCE-N ids (space/comma separated) — "
            "no prose; put the explanation in `finding_reason`"
        )
    if decision == "accept":
        unlocks = finding_fm.get("unlocks")
        if not (isinstance(unlocks, str) and unlocks.strip()):
            problems.append(
                "`unlocks:` is required on an accepted finding (frontmatter, free text) — "
                "the reusable capability this finding grants, e.g. "
                "`unlocks: leaks admin JWT usable on /nd/* APIs`; write `unlocks: none` if it "
                "grants nothing reusable. If it unlocks important future attack surface, also set "
                "`pivot:` to the concrete reusable artifact it yields (a pivot/ artifact, an auth/ "
                "actor, or a transport-recipe) so chaining is operational."
            )
        if not selected:
            problems.append("`finding_evidence` is required when finding_decision=accept")
        cited = set(_finding_cited_evidence(finding_fm, finding_body))
        evidence_by_id = {}
        for evidence_file in evidence_files:
            ev_fm, _ = _load_md(evidence_file)
            ev_id = ev_fm.get("id")
            if isinstance(ev_id, str):
                evidence_by_id[ev_id] = ev_fm
        related = set(_coerce_id_list(fm_get(finding_fm, "related_endpoints")))
        for evidence_id in selected:
            ev_fm = evidence_by_id.get(evidence_id)
            if evidence_id not in cited:
                problems.append(f"`finding_evidence` {evidence_id} is not cited by finding.md")
            if ev_fm is None:
                problems.append(f"`finding_evidence` {evidence_id} is not a draft evidence record")
                continue
            if ev_fm.get("verification_result") != "confirmed":
                problems.append(f"`finding_evidence` {evidence_id} is not verification_result=confirmed")
            if fm_get(ev_fm, "related_endpoint") not in related:
                problems.append(f"`finding_evidence` {evidence_id} is unrelated to finding endpoints/assets")
    elif selected:
        problems.append("`finding_evidence` is only valid when finding_decision=accept")

    return decision if decision in _VALID_FINDING_DECISIONS else None, selected, reason, problems


def _persist_rejected_finding_note(
    eng,
    note_id: str,
    *,
    worker: str,
    task: str,
    hypothesis: str,
    reason: str,
    archive: str,
) -> None:
    """Record a deliberate admission rejection without creating a finding."""
    notes_md = eng.plan_dir / "notes.md"
    related = f"- related: [[{task}]], [[{hypothesis}]]\n" if task and hypothesis else ""
    block = (
        f"\n### {note_id}: finding admission rejected\n"
        f"- status: closed\n"
        f"- worker: {worker}\n"
        f"{related}"
        f"- archive: {archive}\n"
        f"- reason: {reason}\n"
    )
    if not notes_md.exists():
        notes_md.write_text(
            "---\ntitle: Plan Notes\ntype: plan\n"
            f"last_updated: {today_iso()}\n---\n\n"
            f"# {eng.slug} — Plan Notes\n" + block,
            encoding="utf-8",
        )
    else:
        with notes_md.open("a", encoding="utf-8") as fh:
            fh.write(block)

def _parse_handoff_sections(body: str) -> Dict[str, str]:
    """Split body by H2 headings (`## Section name`); return dict[name → contents]."""
    out: Dict[str, str] = {}
    current: Optional[str] = None
    cur_lines: List[str] = []
    for ln in body.splitlines():
        m = re.match(r"^##\s+(.+?)\s*$", ln)
        if m:
            if current is not None:
                out[current] = "\n".join(cur_lines).strip("\n")
            current = m.group(1).strip()
            cur_lines = []
        else:
            cur_lines.append(ln)
    if current is not None:
        out[current] = "\n".join(cur_lines).strip("\n")
    return out


def _parse_status_flips(section: str) -> List[Tuple[str, str]]:
    """Lines like `- TASK-008: done` → [(TASK-008, done)]."""
    out: List[Tuple[str, str]] = []
    for ln in section.splitlines():
        ln = ln.strip()
        if not ln.startswith("-"):
            continue
        ln = ln.lstrip("-").strip()
        if ":" not in ln:
            continue
        eid, _, val = ln.partition(":")
        eid = eid.strip()
        val = val.strip()
        if not eid or not val:
            continue
        out.append((eid, val))
    return out


def _parse_bullet_appends(section: str, renames: Dict[str, str]) -> List[Tuple[str, str, List[str]]]:
    """Lines like:
         - TASK-008 evidence: [EVIDENCE-1, EVIDENCE-2]
       → [(TASK-008, evidence, [EVIDENCE-1, EVIDENCE-2])]
    `renames` maps placeholder IDs to real IDs; targets are mapped through it.
    """
    out: List[Tuple[str, str, List[str]]] = []
    for ln in section.splitlines():
        ln = ln.strip()
        if not ln.startswith("-"):
            continue
        ln = ln.lstrip("-").strip()
        # split on first ":"
        if ":" not in ln:
            continue
        head, _, tail = ln.partition(":")
        head_parts = head.split()
        if len(head_parts) != 2:
            raise ValueError(
                f"malformed bullet-append head: {head!r} — the part before the "
                f"first ':' must be exactly '<ENTITY-ID> <key>' (a bare id + a key), "
                f"e.g. `- TASK-008 evidence: [[EVIDENCE-1]], [[EVIDENCE-2]]`. "
                f"Common mistakes: wikilinking the id ([[HOST-001]] → write HOST-001) "
                f"or omitting the key. Wikilinks belong only after the ':' as targets."
            )
        entity_id, key = head_parts
        tail = tail.strip()
        # A list wrapper is distinct from a wikilink's double brackets.
        if (tail.startswith("[") and tail.endswith("]")
                and (not tail.startswith("[[") or tail.startswith("[[["))):
            tail = tail[1:-1]
        # Split targets by comma; tolerate [[X]] form.
        targets: List[str] = []
        for tok in (t.strip() for t in tail.split(",")):
            if not tok:
                continue
            if tok.startswith("[[") and tok.endswith("]]"):
                tok = tok[2:-2].strip()
            tok = renames.get(tok, tok)
            targets.append(tok)
        out.append((entity_id, key, targets))
    return out


# Placeholder tokens mark a section with no additions: `(none)`, `_(none)_`,
# `(无)`, `(empty)` … Workers habitually append a note after the token
# (`(none) — 复用已有 <recipe>,无新手法`, `_(none)_: 无阻塞`). A fullmatch-only
# check missed those suffixed forms, so they were applied to STATE.md and later
# harvested as junk memory signals (2026-09-14 asset-memory incident: 18
# "复用已有…" signals → 11 junk entries). Both forms skip now.
_PLACEHOLDER_NOTE_PREFIX_RE = re.compile(
    r"^_?\((?:none|无|empty|n/?a)\)_?\s*[—–\-:：,，]",
    re.IGNORECASE,
)


def _is_placeholder_line(content: str) -> bool:
    """True when a bullet carries only a placeholder (optionally followed by a
    separator + note) — i.e. 'no additions for this section'."""
    s = content.strip()
    if not s:
        return True
    if re.fullmatch(r"_?\([^()]{0,30}\)_?", s):
        return True
    return bool(_PLACEHOLDER_NOTE_PREFIX_RE.match(s))


def _parse_md_additions(section: str) -> Dict[str, List[str]]:
    """STATE.md / index.md additions section: H3 sub-headings each containing a
    list of bullet lines. Returns dict[sub-section-name → list of lines (incl. `- ` prefix)].
    Placeholder lines — bare (`(none)`, `_(none)_`) or with a trailing note
    (`(none) — …`) — are skipped.
    """
    out: Dict[str, List[str]] = defaultdict(list)
    current: Optional[str] = None
    for ln in section.splitlines():
        m = re.match(r"^###\s+(.+?)\s*$", ln)
        if m:
            current = m.group(1).strip()
            continue
        if current is None:
            continue
        s = ln.strip()
        if not s:
            continue
        # Strip leading bullet marker (-, *, +) + whitespace to inspect content.
        content = re.sub(r"^[-*+]\s*", "", s).strip()
        if _is_placeholder_line(content):
            continue
        if s.startswith(("-", "*", "+")):
            out[current].append(s)
    return dict(out)


def _lead_lines(section: str) -> List[str]:
    """Bullet content of a `Follow-up leads` section body. Placeholder lines like
    `(none)` are skipped."""
    out: List[str] = []
    for ln in section.splitlines():
        s = ln.strip()
        if not s.startswith(("-", "*", "+")):
            continue
        content = re.sub(r"^[-*+]\s*", "", s).strip()
        if _is_placeholder_line(content):
            continue
        out.append(content)
    return out


# A follow-up lead is a probe's "this finding unlocks something chainable" signal.
# On integrate each lead is HELD: persisted as a `deepen-lead:` NOTE (durable
# content) and queued in STATE.md `## Follow-up leads` (pending-handling flag that
# reason drains), plus surfaced to the orchestrator as a `<system-reminder>`. Probes
# place the section inconsistently (top-level `## Follow-up leads`, or a nested
# `### Follow-up leads` under STATE.md / index.md additions, with varied case/
# spacing), so the hint scan is location- and case-tolerant.
_FOLLOWUP_HEAD = re.compile(r"^#{2,4}\s+follow[\s-]?up\s+leads\s*$", re.IGNORECASE)


def _persist_follow_up_leads(eng, leads: List[str], note_ids: List[str], task: str) -> None:
    """Hold each probe follow-up lead so it is not lost after the draft is deleted:
    a `deepen-lead:` NOTE in plan/notes.md (durable content) + a queue line in
    STATE.md `## Follow-up leads` (pending-handling flag reason drains once the lead
    is processed / abandoned)."""
    notes_md = eng.plan_dir / "notes.md"
    blocks: List[str] = []
    state_lines: List[str] = []
    for nid, lead in zip(note_ids, leads):
        blocks.append(
            f"\n### {nid}: deepen-lead (probe follow-up)\n"
            f"- status: open\n"
            f"- source: probe follow-up lead (task={task})\n"
            f"\ndeepen-lead: {lead}\n"
        )
        state_lines.append(f"- [[{nid}]] {lead}")
    if not notes_md.exists():
        notes_md.write_text(
            "---\ntitle: Plan Notes\ntype: plan\n"
            f"last_updated: {today_iso()}\n---\n\n"
            f"# {eng.slug} — Plan Notes\n" + "".join(blocks),
            encoding="utf-8",
        )
    else:
        with notes_md.open("a", encoding="utf-8") as fh:
            fh.write("".join(blocks))
    _apply_section_additions(eng.state_md, {"Follow-up leads": state_lines})


def _is_follow_up_key(name: str) -> bool:
    """True if an additions sub-section name is a Follow-up leads heading (tolerant)."""
    return re.sub(r"[^a-z]", "", name.lower()) == "followupleads"


def _scan_follow_up_leads(body: str) -> List[str]:
    """Extract lead bullets from a `Follow-up leads` heading ANYWHERE in the handoff
    — top-level or nested, any level, case/spacing tolerant. Reliable regardless of
    where the probe put the section."""
    section: List[str] = []
    capturing = False
    for ln in body.splitlines():
        if _FOLLOWUP_HEAD.match(ln.strip()):
            capturing = True
            continue
        if capturing and ln.lstrip().startswith("#"):  # next heading ends the section
            capturing = False
        if capturing:
            section.append(ln)
    return _lead_lines("\n".join(section))


def _extract_section_body(body: str, section_name: str) -> Optional[str]:
    """Return the text between `## section_name` and the next H2, or None if not found."""
    lines = body.splitlines()
    head_re = re.compile(rf"^##\s+{re.escape(section_name)}\s*$")
    next_h2 = re.compile(r"^##\s+")
    start = None
    for i, ln in enumerate(lines):
        if head_re.match(ln):
            start = i + 1
            break
    if start is None:
        return None
    end = len(lines)
    for j in range(start, len(lines)):
        if next_h2.match(lines[j]):
            end = j
            break
    return "\n".join(lines[start:end])


# ──────────────── canonical mutation ────────────────

def _apply_status_flip(eng, idx, entity_id: str, value: str) -> None:
    ent = idx.by_id.get(entity_id)
    if not ent:
        die(f"status flip: canonical entity {entity_id} not found", code=1)
    if ent.heading_line == 0 or not ent.source_file:
        # Frontmatter-id entity (FINDING/EVIDENCE) — patch frontmatter directly.
        _patch_frontmatter_field(ent.source_file, "status", value)
        return
    _update_entity_bullets(ent.source_file, entity_id, {"status": value})


def _apply_bullet_append(eng, idx, entity_id: str, key: str, target: str) -> None:
    ent = idx.by_id.get(entity_id)
    if not ent:
        die(f"bullet append: canonical entity {entity_id} not found", code=1)
    if ent.heading_line == 0 or not ent.source_file:
        die(
            f"{entity_id} is a frontmatter-id entity; bullet append not supported here. "
            f"Use a NOTE instead.",
            code=1,
        )
    existing = ent.bullets.get(key)
    new_value = _append_wikilink(existing, target)
    _update_entity_bullets(ent.source_file, entity_id, {key: new_value})
    # Subsequent appends in this integration share the same index snapshot.
    ent.bullets[key] = new_value


def _patch_frontmatter_field(path: Path, key: str, value: Any) -> None:
    fm, body = _load_md(path)
    fm[key] = value
    fm["last_updated"] = today_iso()
    path.write_text(serialize_frontmatter(fm) + body, encoding="utf-8")


def _substitute_ids_in_file(path: Path, renames: Dict[str, str]) -> None:
    """Replace each placeholder TYPE-N token with its real ID across the file."""
    if not renames:
        return
    text = path.read_text(encoding="utf-8")
    def repl(m: re.Match) -> str:
        tok = m.group(1)
        return renames.get(tok, tok)
    new_text = _ID_TOKEN.sub(repl, text)
    if new_text != text:
        path.write_text(new_text, encoding="utf-8")


def _apply_section_additions(target_path: Path, additions: Dict[str, List[str]]) -> None:
    """For each (sub-section → lines), append the lines under `## sub-section` in
    the target file. Creates the section if missing. Replaces `_(none)_` /
    `_(none yet)_` placeholders when the section was empty."""
    if not target_path.exists():
        return
    text = target_path.read_text(encoding="utf-8")
    fm_text, body = split_frontmatter(text)
    head = (fm_text and f"---\n{fm_text}---\n") or ""
    new_body = body
    for section, lines in additions.items():
        new_body = _append_under_section(new_body, section, lines)
    # Bump last_updated.
    fm = parse_frontmatter(fm_text) if fm_text is not None else {}
    if "last_updated" in fm:
        fm["last_updated"] = today_iso()
        head = serialize_frontmatter(fm)
    target_path.write_text(head + new_body, encoding="utf-8")


def _append_under_section(body: str, section_name: str, lines: List[str]) -> str:
    """Find `## section_name` in body. Append `lines` just before the next H2
    (or at EOF). Replaces empty/_(none)_ placeholder content. Creates the section
    at EOF if missing."""
    if not lines:
        return body
    body_lines = body.splitlines()
    head_re = re.compile(rf"^##\s+{re.escape(section_name)}\s*$")
    next_h2 = re.compile(r"^##\s+")
    start = None
    for i, ln in enumerate(body_lines):
        if head_re.match(ln):
            start = i + 1
            break
    if start is None:
        # Create section at end.
        out = list(body_lines)
        if out and out[-1].strip():
            out.append("")
        out.append(f"## {section_name}")
        out.extend(lines)
        out.append("")
        return "\n".join(out) + ("\n" if not body.endswith("\n") else "")
    # Find end of section (next H2 or EOF).
    end = len(body_lines)
    for j in range(start, len(body_lines)):
        if next_h2.match(body_lines[j]):
            end = j
            break
    # Existing section content (between heading and next H2, trimmed).
    section_lines = body_lines[start:end]
    # Strip trailing blank lines for cleaner append.
    while section_lines and not section_lines[-1].strip():
        section_lines.pop()
    # If section is empty or only placeholder, replace.
    placeholder = (
        len(section_lines) == 1
        and section_lines[0].strip().startswith("_(")
        and section_lines[0].strip().endswith(")_")
    )
    if not section_lines or placeholder:
        section_lines = list(lines)
    else:
        section_lines.extend(lines)
    rebuilt = body_lines[:start] + section_lines + [""] + body_lines[end:]
    return "\n".join(rebuilt) + ("\n" if not body.endswith("\n") else "")
