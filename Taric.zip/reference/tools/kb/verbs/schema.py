"""`kb schema [<topic>]` — the agent's just-in-time entity-creation field manual.

Answers "how do I create/shape entity X?" scoped and short, so the agent queries
once instead of grepping the (former) 800-line reference doc or failing validation
and retrying. STRUCTURAL truth (required bullets / status values / required
frontmatter) is rendered live from `schema.py`; the prose (field meanings,
examples, gotchas, vocabularies) comes from `schema_docs.py`. Profile-aware: the
active profile (web / host) selects the topic set and the entity vocabulary.
"""
from __future__ import annotations

import json

from .. import schema as _schema
from .. import schema_docs
from ..profiles import active_profile
from ..util import err

# How each entity is created — the one piece schema.py can't express.
_CREATE = {
    "finding":    "probe — `kb draft scaffold <dir> finding --hypothesis HYPOTHESIS-N`, fill evidence, `kb draft commit`",
    "evidence":   "probe — write EVIDENCE-N.md under the draft_dir, `kb draft commit`",
    "hypothesis": "reason — `kb plan add <file.json>` (audit first)",
    "task":       "reason — `kb plan add <file.json>` (nested under its hypothesis)",
    "chain":      "reason deepening — add `### CHAIN-N` to record/chains.md, `kb commit`",
    "note":       "any — `### NOTE-N` + body in the relevant tier, `kb commit`",
    # web wiki entities
    "endpoint":   "observe/reason — `### ENDPOINT-N` + bullets in wiki/<workflow>.md, `kb commit`",
    "page":       "observe — `### PAGE-N` in wiki/<workflow>.md, `kb commit`",
    "route":      "observe — `### ROUTE-N` in wiki/<workflow>.md, `kb commit`",
    "bundle":     "observe — `### BUNDLE-N` in wiki/<workflow>.md, `kb commit`",
    "workflow":   "observe/reason — `### WORKFLOW-N` in wiki/<workflow>.md, `kb commit`",
    "topic":      "observe — new wiki/<slug>.md file frontmatter",
    # host wiki entities
    "host":       "observe — `### HOST-N` + bullets in wiki/hosts.md, `kb commit`",
    "domain":     "observe — `### DOMAIN-N` in wiki/domains.md, `kb commit`",
    "service":    "observe — `### SERVICE-N` in wiki/svc-<class>.md, `kb commit`",
    "webapp":     "observe/probe — `### WEBAPP-N` in wiki/svc-web.md (then delegate), `kb commit`",
    "cred":       "probe — `### CRED-N` (hash only) , `kb commit`; plaintext to auth/captured/",
}

# one-line role — what each entity IS (the index roster the agent reads first).
_ROLE = {
    "finding":    "a verified vulnerability",
    "evidence":   "raw request/response backing a finding",
    "hypothesis": "a testable vulnerability hypothesis",
    "task":       "one probe that verifies a hypothesis",
    "chain":      "verified findings linked into an attack chain",
    "note":       "a loose observation or lead",
    # web wiki entities
    "endpoint":   "a backend HTTP action",
    "page":       "a frontend page / UI entry",
    "route":      "a frontend route (SPA)",
    "bundle":     "a JS bundle",
    "workflow":   "a business flow across endpoints",
    "topic":      "a new wiki/<slug>.md file",
    # host wiki entities
    "host":       "one host (an IP)",
    "domain":     "a DNS name",
    "service":    "a (host, port, proto) service",
    "webapp":     "an HTTP service worth its own web pentest (delegated)",
    "cred":       "a credential / hash / token",
}

# per-profile overrides — only entities whose home file or meaning differs by
# profile (host WORKFLOW is a kill-chain stage in wiki/kill-chain.md, not a
# web-style business flow in wiki/<workflow>.md).
_OVERRIDE = {
    "host": {
        "workflow": {
            "role":   "a kill-chain stage narrative",
            "create": "reason/observe — `### WORKFLOW-N` in wiki/kill-chain.md, `kb commit`",
        },
        "chain": {"role": "verified findings linked into a kill-chain"},
    },
}


def _create_for(topic: str, profile: str) -> str:
    """The create-command for an entity, honoring any per-profile override."""
    return _OVERRIDE.get(profile, {}).get(topic, {}).get("create") or _CREATE.get(topic, "")


def _role_for(topic: str, profile: str) -> str:
    """The one-line role for an entity, honoring any per-profile override."""
    return _OVERRIDE.get(profile, {}).get(topic, {}).get("role") or _ROLE.get(topic, "")

# topic slug -> the entity TYPE whose structural spec to render (None = no entity spec).
_ENTITY_TYPE = {
    "finding": "FINDING", "evidence": "EVIDENCE", "hypothesis": "HYPOTHESIS",
    "task": "TASK", "chain": "CHAIN", "note": "NOTE",
    "endpoint": "ENDPOINT", "page": "PAGE", "route": "ROUTE", "bundle": "BUNDLE",
    "workflow": "WORKFLOW", "topic": None,
    "host": "HOST", "domain": "DOMAIN", "service": "SERVICE", "webapp": "WEBAPP",
    "cred": "CRED",
}

# a few topics whose prose lives under one shared key (web layering / host assets).
_PROSE_ALIAS = {"route": "page", "bundle": "page", "workflow": "page"}

# ordering for the index
_ENTITY_ORDER = ["finding", "evidence", "hypothesis", "task", "chain",
                 "endpoint", "page", "route", "bundle", "workflow",
                 "host", "domain", "service", "webapp", "cred", "topic", "note"]

# every entity a profile can create — the index lists ALL of these (each has a
# working `kb schema <type>`), so none is undiscoverable even without a prose key.
_PROFILE_ENTITIES = {
    "web":  ["finding", "evidence", "hypothesis", "task", "chain",
             "endpoint", "page", "route", "bundle", "workflow", "note", "topic"],
    "host": ["finding", "evidence", "hypothesis", "task", "chain",
             "host", "domain", "service", "webapp", "cred", "workflow", "note"],
}
_VOCAB_ORDER = ["class", "workflow-vocab", "targets", "service-class",
                "coverage", "coverage-rollup", "reading", "handoff",
                "credential-lifecycle", "deepening", "target-json", "health"]

# file-type -> REQUIRED_FRONTMATTER key, for the frontmatter-declared entities.
_FRONTMATTER_KEY = {"FINDING": "finding", "EVIDENCE": "evidence"}


def _frontmatter_fields(fkey: str, profile: str):
    """Required frontmatter for a file type, with host asset-ref aliasing applied
    (related_endpoints → related_assets) so host renders the name host writers use."""
    fields = _schema.REQUIRED_FRONTMATTER.get(fkey, [])
    if profile == "host":
        fields = [_schema.FRONTMATTER_ALIASES.get(f, f) for f in fields]
    return fields


def _structural(etype: str, profile: str) -> str:
    """Structural contract for an entity type, rendered live from schema.py."""
    if etype is None:
        return ""
    spec = _schema._ENTITY_SPECS.get(etype)
    lines = []
    fkey = _FRONTMATTER_KEY.get(etype)
    if fkey and fkey in _schema.REQUIRED_FRONTMATTER:
        req = ", ".join(_frontmatter_fields(fkey, profile))
        lines.append(f"required frontmatter: {req}")
    if spec:
        rb = spec.get("required_bullets") or []
        if rb:
            lines.append(f"required bullets: {', '.join(rb)}")
        sv = spec.get("status_values") or []
        if sv:
            lines.append(f"status values: {' · '.join(sv)}")
    return "\n".join(lines)


def _index(profile: str, topics: dict) -> str:
    ents = [t for t in _PROFILE_ENTITIES.get(profile, _ENTITY_ORDER) if t in _CREATE]
    vocab = [t for t in _VOCAB_ORDER if t in topics]
    # any topic not in either ordered list still shows under vocab
    seen = set(ents) | set(vocab)
    vocab += [t for t in sorted(topics) if t not in seen]
    out = [
        f"kb schema — how to shape any entity ({profile} profile).",
        "Run `bin/kb schema <topic>` for the full contract (required fields + example + gotchas).",
        "",
        "ENTITIES — what each is, and how to create it:",
    ]
    for t in ents:
        out.append(f"  {t:<11} {_role_for(t, profile)}")
        out.append(f"  {'':<11}   create: {_create_for(t, profile)}")
    out += ["", "VOCAB & CONVENTIONS:"]
    _blurb = {
        "class": "the tags / class controlled vocabulary",
        "workflow-vocab": "the workflow controlled vocabulary",
        "targets": "the system-wide sentinel for HYPOTHESIS.targets",
        "service-class": "the wiki-file grouping label",
        "coverage": "reading the coverage report (GAP OVERVIEW / --focus / --json)",
        "coverage-rollup": "how coverage rolls entities up (tactics + universal checks)",
        "reading": "querying the kb (list / show / grep / coverage)",
        "handoff": "probe→orchestrator handoff.md manifest + draft-commit gate",
        "credential-lifecycle": "auth/ actor states + TASK auth_access",
        "deepening": "chain-centric fields (unlocks / pivot / chain_terminal / frontier)",
        "target-json": "engagement metadata + Primary Objective Lock",
        "health": "`kb health` lint rules",
    }
    for t in vocab:
        out.append(f"  {t:<20} {_blurb.get(t, '')}")
    return "\n".join(out)


def cmd_schema(args) -> int:
    profile = getattr(active_profile(), "name", "web") or "web"
    topics = schema_docs.topics_for(profile)
    topic = (getattr(args, "topic", None) or "").strip().lower()
    want_json = getattr(args, "json", False)

    # ---- index (no topic) ----
    if not topic:
        if want_json:
            ents = [t for t in _PROFILE_ENTITIES.get(profile, _ENTITY_ORDER) if t in _CREATE]
            payload = {
                "profile": profile,
                "entities": ents,
                "topics": sorted(topics),
                "role": {t: _role_for(t, profile) for t in ents},
                "create": {t: _create_for(t, profile) for t in ents},
            }
            print(json.dumps(payload, indent=2, ensure_ascii=False))
        else:
            print(_index(profile, topics))
        return 0

    # ---- a specific topic ----
    prose_key = topic if topic in topics else _PROSE_ALIAS.get(topic)
    etype = _ENTITY_TYPE.get(topic)
    if prose_key is None and etype is None:
        err(f"unknown schema topic: {topic!r}")
        err("valid topics: " + ", ".join(sorted(topics)))
        return 2

    structural = _structural(etype, profile) if etype else ""
    prose = topics.get(prose_key, "") if prose_key else ""

    if want_json:
        payload = {"profile": profile, "topic": topic}
        if etype:
            spec = _schema._ENTITY_SPECS.get(etype, {})
            payload["entity_type"] = etype
            payload["required_bullets"] = spec.get("required_bullets") or []
            payload["status_values"] = spec.get("status_values") or []
            fkey = _FRONTMATTER_KEY.get(etype)
            if fkey:
                payload["required_frontmatter"] = _frontmatter_fields(fkey, profile)
            payload["role"] = _role_for(topic, profile)
            payload["create"] = _create_for(topic, profile)
        payload["doc"] = prose
        print(json.dumps(payload, indent=2, ensure_ascii=False))
        return 0

    parts = []
    if structural:
        header = f"== {etype} =="
        role = _role_for(topic, profile)
        create = _create_for(topic, profile)
        head = header + (f"  ({role})" if role else "")
        parts.append(head + "\n" + structural + (f"\ncreate: {create}" if create else ""))
    if prose:
        parts.append(prose)
    if not parts:
        parts.append(f"(no detail recorded for {topic!r})")
    print("\n\n".join(parts))
    return 0
