"""kb grep <regex> [--type T] — content search across entity blocks.

`kb list --filter` matches bullet metadata only; `kb find` matches ids/titles/
slugs. Neither searches entity *bodies*. This walks every entity's block
(heading + bullets + body, and the whole file for single-file FINDING/EVIDENCE)
and prints `ID  file:line  matched-line`, so a fact can be found by content —
ID-anchored — without grepping the raw markdown.
"""
from __future__ import annotations

import json
import re
from typing import List

from .. import ctx
from ..index import build_index
from ..parser import ENTITY_TYPES
from ..util import die

_MAX = 200  # cap output so a loose regex can't flood context; refine or fall back to grep


def _rel(p, root) -> str:
    try:
        return str(p.relative_to(root)).replace("\\", "/")
    except Exception:
        return str(p)


def cmd_grep(args) -> int:
    eng = ctx.require(args.engagement)
    try:
        pat = re.compile(args.pattern, re.IGNORECASE)
    except re.error as e:
        die(f"invalid regex {args.pattern!r}: {e}", code=2)
    type_arg = (args.type or "").upper() if args.type else None
    if type_arg and type_arg not in ENTITY_TYPES:
        die(f"unknown type {args.type!r}", code=2)
    idx = build_index(eng)
    archived = idx.archived_entity_ids()
    rows: List[dict] = []
    seen = set()
    for e in idx.all_entities():
        if e.is_placeholder:
            continue
        if type_arg and e.type != type_arg:
            continue
        if not getattr(args, "include_archived", False) and e.id in archived:
            continue
        base = e.heading_line or 1  # synthesized finding/evidence: raw_block == whole file → line 1
        for offset, line in enumerate((e.raw_block or "").splitlines()):
            if not pat.search(line):
                continue
            lineno = base + offset
            key = (e.id, lineno)
            if key in seen:
                continue
            seen.add(key)
            rows.append({
                "id": e.id,
                "type": e.type,
                "file": _rel(e.source_file, eng.root),
                "line": lineno,
                "text": line.strip(),
            })
    truncated = len(rows) > _MAX
    shown = rows[:_MAX]
    if getattr(args, "json", False):
        print(json.dumps({"matches": shown, "total": len(rows), "truncated": truncated},
                         indent=2, ensure_ascii=False))
        return 0
    if not rows:
        print("(no matches)")
        return 0
    id_w = max(len(r["id"]) for r in shown)
    for r in shown:
        print(f"{r['id']:<{id_w}}  {r['file']}:{r['line']}  {r['text']}")
    if truncated:
        print(f"… {len(rows) - _MAX} more match(es) — refine the regex (or fall back to grep for an exhaustive scan)")
    return 0
