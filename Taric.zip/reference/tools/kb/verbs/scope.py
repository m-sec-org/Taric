"""kb scope {contains | add} — scope membership check + runtime scope edits."""
from __future__ import annotations

import json

from .. import ctx
from ..ids import read_target, write_target
from ..lock import acquire
from ..log import append_event, append_log
from ..scope import contains, contains_origin, parse_seed
from ..util import die


def cmd_scope_contains(args) -> int:
    """Exit 0 if <target> is in scope, 3 if not. Workers gate external requests
    on this (scope.md / framework-host §10.2)."""
    eng = ctx.require(args.engagement)
    data = read_target(eng.target_json)
    checker = contains_origin if getattr(args, "strict_origin", False) else contains
    in_scope, reason = checker(data, args.target)
    if getattr(args, "json", False):
        print(json.dumps({"target": args.target, "in_scope": in_scope, "reason": reason},
                         ensure_ascii=False))
    else:
        print(f"{'IN-SCOPE' if in_scope else 'OUT-OF-SCOPE'}: {args.target}  ({reason})")
    return 0 if in_scope else 3


def cmd_scope_add(args) -> int:
    """Append a seed to scope_in (default) or scope_out."""
    try:
        seed = parse_seed(args.seed)
    except ValueError as exc:
        die(f"invalid --seed {args.seed!r}: {exc}", code=2)
    if getattr(args, "out", False) and getattr(args, "in_", False):
        die("pass only one of --in / --out", code=2)
    bucket = "scope_out" if getattr(args, "out", False) else "scope_in"
    eng = ctx.require(args.engagement)
    with acquire(eng.root):
        data = read_target(eng.target_json)
        lst = data.setdefault(bucket, [])
        if seed not in lst:
            lst.append(seed)
        write_target(eng.target_json, data)
        append_log(eng.log_md, "scope add", f"{bucket} += {seed['kind']}:{seed['value']}", body="")
        append_event(eng.events_jsonl, verb="scope_add", bucket=bucket,
                     kind=seed["kind"], value=seed["value"])
    print(f"{bucket} += {seed['kind']}:{seed['value']}")
    return 0
