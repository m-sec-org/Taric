"""kb archive [<id> | --auto]

Move resolved entries from plan/ to plan/archive/. Auto-sweep:
  HYPOTHESIS in {refuted, abandoned}, or {verified} with promoted_to set
  TASK in {done}
"""
from __future__ import annotations

import json
import re
from pathlib import Path
from typing import List, Optional, Tuple

from .. import ctx, git_helper
from ..index import build_index
from ..lock import acquire
from ..log import append_event, append_log
from ..parser import (
    Entity,
    parse_file,
    parse_id,
    parse_frontmatter,
    serialize_frontmatter,
    split_frontmatter,
)
from ..util import die, today_iso


_HEADING_RE = re.compile(r"^#{1,6}\s+([A-Z]+-\d+)\s*[:\-—–]?")


def _archive_target(eng, ent_type: str) -> Path:
    eng.plan_archive_dir.mkdir(parents=True, exist_ok=True)
    if ent_type == "HYPOTHESIS":
        return eng.plan_archive_dir / "hypotheses.md"
    if ent_type == "TASK":
        return eng.plan_archive_dir / "tasks.md"
    raise ValueError(f"no archive target for type {ent_type}")


def _ensure_archive_file(path: Path, title: str) -> None:
    if path.exists():
        return
    path.write_text(
        "---\n"
        f"title: {title}\n"
        "type: plan\n"
        f"last_updated: {today_iso()}\n"
        "---\n\n"
        f"# {title}\n",
        encoding="utf-8",
    )


def _is_auto_archivable(e: Entity) -> bool:
    if e.type == "HYPOTHESIS":
        st = e.bullets.get("status")
        if st in ("refuted", "abandoned"):
            return True
        if st == "verified" and e.bullets.get("promoted_to"):
            return True
        return False
    if e.type == "TASK":
        return e.bullets.get("status") == "done"
    return False


def _cut_entity_block(file_path: Path, entity_id: str) -> Optional[str]:
    """Cut the entity block (heading + bullets + body) from file_path. Returns the cut text."""
    text = file_path.read_text(encoding="utf-8")
    lines = text.splitlines(keepends=True)
    n = len(lines)
    i = 0
    while i < n:
        m = _HEADING_RE.match(lines[i].rstrip("\n"))
        if m and m.group(1) == entity_id:
            j = i + 1
            # Walk until the next heading.
            while j < n:
                if _HEADING_RE.match(lines[j].rstrip("\n")):
                    break
                j += 1
            cut = "".join(lines[i:j])
            # Remove from source file.
            new_lines = lines[:i] + lines[j:]
            new_text = "".join(new_lines)
            tmp = file_path.with_suffix(file_path.suffix + ".tmp")
            tmp.write_text(new_text, encoding="utf-8")
            tmp.replace(file_path)
            return cut
        i += 1
    return None


def _append_to_archive(arch_path: Path, block: str) -> None:
    """Append block to an archive file before any trailing whitespace."""
    if not arch_path.exists():
        return
    text = arch_path.read_text(encoding="utf-8")
    if not text.endswith("\n"):
        text += "\n"
    if not text.endswith("\n\n"):
        text += "\n"
    if not block.endswith("\n"):
        block += "\n"
    arch_path.write_text(text + block, encoding="utf-8")
    # Stamp last_updated.
    fm_text, body = split_frontmatter(arch_path.read_text(encoding="utf-8"))
    if fm_text is not None:
        fm = parse_frontmatter(fm_text)
        fm["last_updated"] = today_iso()
        arch_path.write_text(serialize_frontmatter(fm) + body, encoding="utf-8")


def cmd_archive(args) -> int:
    eng = ctx.require(args.engagement)
    targets: List[Tuple[Entity, Path]] = []  # (entity, source_file)

    with acquire(eng.root):
        idx = build_index(eng)

        if args.id:
            # Explicit single-id archive.
            target_id = args.id
            ent = idx.by_id.get(target_id)
            if not ent and target_id in idx.placeholders:
                die(f"{target_id} has a placeholder ID — run `kb commit` first", code=1)
            if not ent:
                die(f"entity {target_id} not found in active plan", code=1)
            if ent.type not in ("HYPOTHESIS", "TASK"):
                die(f"only HYPOTHESIS / TASK entities can be archived (got {ent.type})", code=1)
            # Source must be in plan/, not already archived.
            rel = str(ent.source_file.relative_to(eng.root)).replace("\\", "/")
            if not rel.startswith("plan/") or rel.startswith("plan/archive/"):
                die(f"{target_id} is not in active plan (lives in {rel!r})", code=1)
            targets.append((ent, ent.source_file))
        else:
            # Auto-sweep across plan/hypotheses.md and plan/tasks.md.
            for f in idx.files:
                rel = f.rel_path
                if rel != "plan/hypotheses.md" and rel != "plan/tasks.md":
                    continue
                for e in f.entities:
                    if _is_auto_archivable(e):
                        targets.append((e, f.path))

        if not targets:
            print("(nothing to archive)")
            return 0

        # Ensure archive files exist.
        _ensure_archive_file(eng.plan_archive_dir / "hypotheses.md", "Hypotheses (archive)")
        _ensure_archive_file(eng.plan_archive_dir / "tasks.md", "Tasks (archive)")

        moved: List[dict] = []
        # Process in document order — each cut shifts subsequent indices, so re-resolve.
        # Group by source file to do reads once per file.
        from collections import defaultdict as _dd
        by_file: dict = _dd(list)
        for ent, src in targets:
            by_file[src].append(ent.id)
        for src, ids in by_file.items():
            for eid in ids:
                # Re-cut from source after any prior cut to that file.
                ent_type = parse_id(eid)[0]
                arch_path = _archive_target(eng, ent_type)
                block = _cut_entity_block(src, eid)
                if block is None:
                    # Already gone (race) — skip.
                    continue
                _append_to_archive(arch_path, block)
                moved.append({"id": eid, "type": ent_type, "from": str(src.relative_to(eng.root)).replace("\\", "/"),
                              "to": str(arch_path.relative_to(eng.root)).replace("\\", "/")})

        # Stamp last_updated on the source files we cut from.
        for src in by_file.keys():
            text = src.read_text(encoding="utf-8")
            fm_text, body = split_frontmatter(text)
            if fm_text is not None:
                fm = parse_frontmatter(fm_text)
                fm["last_updated"] = today_iso()
                src.write_text(serialize_frontmatter(fm) + body, encoding="utf-8")

        title = f"archived {len(moved)} entries" if moved else "archive (no-op)"
        body_lines = [f"- [[{m['id']}]] from `{m['from']}` → `{m['to']}`" for m in moved]
        body = "\n".join(body_lines)
        append_log(eng.log_md, "archive", title, body=body)
        append_event(eng.events_jsonl, verb="archive", moved=moved)
        git_helper.commit(eng.root, f"archive: {title}", body)
        from .export_ import auto_export
        auto_export(eng)

    if getattr(args, "json", False):
        print(json.dumps({"moved": moved}, indent=2, ensure_ascii=False))
        return 0
    print(f"archived {len(moved)} entries")
    for m in moved:
        print(f"  {m['id']}  {m['from']} → {m['to']}")
    return 0
