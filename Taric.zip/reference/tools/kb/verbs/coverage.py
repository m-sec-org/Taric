"""kb coverage — per-entity coverage gate + OWASP breakdown view.

Four blocks:
  1. Per-entity coverage  (each ENDPOINT/WORKFLOW/PAGE/BUNDLE: gap or covered)
  2. Universal checks      (static checklist; covered by a `system-wide` hypothesis whose
                            title/rationale/class text contains the check's slug tokens,
                            or skipped via a `universal-skip: <slug>` NOTE)
  3. Conditional features  (NOTE slug `system-feature: <name>`; reason promotes)
  4. Business scenarios    (static checklist; covered by a `class: <slug>` hypothesis,
                            skipped via a `scenario-skip: <slug>` NOTE)

Gate blocks on any entity with zero hypothesis + zero skip + zero block (block 1),
or any universal / conditional / scenario gap (blocks 2/3/4). The per-OWASP
breakdown is a *view* for breadth analysis — it does not gate.

Alongside the gate (a pass/fail FLOOR) each entity carries a coverage-quality SCORE
(finding 1.0 / probed 0.9 / planned 0.5 / blocked 0.3 / skip·gap 0.0 — see SCORE_*).
The gate asks "disposed?", the score asks "actually tested?". A skip earns nothing,
so the agent's objective is to MAXIMISE the score, not merely open the gate.

Plan-integrity input (also gates): EVERY non-archived hypothesis must have a task
referencing it, whatever its status. A hypothesis with no task is an "orphan" —
either it can never be probed (untested) or it was closed without one ever running
(refuted/verified/blocked flipped on paper). Closing a hypothesis does NOT exempt
it; relabeling untested→refuted to dodge the check is the exact gap this closes.
Orphans block the gate until they get a task (if you will not test it, it belongs
as a coverage-skip / NOTE, not a hypothesis). Only archival exempts a hypothesis.
"""
from __future__ import annotations

import json
import re
from collections import defaultdict
from typing import Any, Dict, List, Optional, Set, Tuple

from .. import ctx, reprobe_hygiene
from ..index import Index, build_index
from ..parser import Entity, ParsedFile
from ..profiles import active_profile
from ..validators.semantic_inventory import (
    build_inventory as build_semantic_inventory,
    build_missing_type_warnings,
    validate_closure,
    validate_shape,
)


# Rollup taxonomy, universal checks, scenarios, the coverage-item regex, gated
# entity types, display bullets and hints all live in the active coverage
# profile (tools/kb/profiles/{web,host}.py — see docs/framework-host §13.1).
# This module is taxonomy-blind: it reads `active_profile()` and never names a
# web-specific construct (OWASP cat, login scenario, …) directly.

SYSTEM_WIDE_SENTINEL = "system-wide"
SYSTEM_FEATURE_PREFIX = "system-feature:"
SCENARIO_SKIP_PREFIX = "scenario-skip:"
UNIVERSAL_SKIP_PREFIX = "universal-skip:"
DEEPEN_LEAD_PREFIX = "deepen-lead:"


# ───────────────────────── Bullet parsing ─────────────────────────

_COV_BULLET_LINE_RE = re.compile(
    r"^\s*[-*+]\s+coverage-(skip|block)\s*[:=]\s*(.*)$", re.MULTILINE
)


def _parse_coverage_items(value: Any) -> List[Tuple[str, str]]:
    if not isinstance(value, str) or not value.strip():
        return []
    return [(cat, reason.strip()) for cat, reason in active_profile().cov_item_re.findall(value)]


def _collect_coverage_bullets(entity) -> Tuple[Dict[str, str], Dict[str, str], List[dict]]:
    """Return (skips, blocks, malformed) by scanning raw_block for ALL
    coverage-skip / coverage-block bullet lines.

    `malformed` lists bullets that matched the coverage-skip/block PREFIX but
    parsed to ZERO items (wrong / missing `<category>(reason)`). Today those are
    dropped silently, so the entity reads as un-disposed with no visible cause and
    the agent re-runs / reads source to figure out why its skip 'did nothing'. We
    surface them instead."""
    skips: Dict[str, str] = {}
    blocks: Dict[str, str] = {}
    malformed: List[dict] = []
    for m in _COV_BULLET_LINE_RE.finditer(entity.raw_block or ""):
        kind, value = m.group(1), m.group(2).strip()
        items = _parse_coverage_items(value)
        if not items:
            malformed.append({"kind": kind, "value": value})
            continue
        bucket = skips if kind == "skip" else blocks
        for cat, reason in items:
            bucket.setdefault(cat, reason)
    return skips, blocks, malformed


def _block_kind(reason: str) -> Tuple[Optional[str], str]:
    m = re.match(r"^(needs-user-input|technical)\s*:\s*(.*)$", reason.strip(), re.IGNORECASE)
    if not m:
        return None, reason.strip()
    return m.group(1).lower(), m.group(2).strip()


# ───────────────────────── Per-entity build ─────────────────────────

def _file_workflow(f: ParsedFile) -> Optional[str]:
    # The grouping axis is profile-defined: web reads `workflow` (logical area),
    # host reads `service-class`. Falls back to entity type when the file carries
    # no such frontmatter (see _overview_group_key).
    wf = f.frontmatter.get(active_profile().overview_group_field)
    return wf if isinstance(wf, str) else None


def _hypotheses_targeting(idx: Index) -> Dict[str, List[Entity]]:
    # Archived hypotheses still count: a refuted/verified hyp gets auto-swept to
    # plan/archive/ on resolution, but the entity it tested stays covered.
    out: Dict[str, List[Entity]] = defaultdict(list)
    for h in idx.by_type.get("HYPOTHESIS", []):
        if h.is_placeholder:
            continue
        targets = h.bullets.get("targets")
        ids: List[str] = []
        if isinstance(targets, list):
            ids = [t for t in targets if isinstance(t, str)]
        elif isinstance(targets, str):
            ids = [targets]
        for tid in ids:
            out[tid].append(h)
    return out


def _has_finding_for_hyp(idx: Index, hyp_id: str) -> bool:
    archived = idx.archived_entity_ids()
    for f in idx.by_type.get("FINDING", []):
        if f.id in archived:
            continue
        ref = f.bullets.get("hypothesis")
        if ref == hyp_id:
            return True
        if isinstance(ref, list) and hyp_id in ref:
            return True
    return False


def _classify_hypothesis_rollup(h: Entity) -> Optional[str]:
    cls = h.bullets.get("class")
    if isinstance(cls, str):
        return active_profile().tag_to_rollup.get(cls.strip().lower())
    return None


# ── Coverage-quality score ─────────────────────────────────────────────────
# The gate (has_coverage) only asks "was this entity disposed at all?" — a skip
# counts the same as a probed finding. The SCORE asks the real question: "how
# much genuine testing happened?" A skip earns nothing, so converting a skip or
# gap into a probed hypothesis is the single biggest gain. The agent's objective
# is to MAXIMISE this score, not merely to open the gate (which is only a floor).
# Weights are universal — every profile shares the same disposition semantics.
SCORE_FINDING = 1.0      # verified finding on the entity
SCORE_TESTED = 0.9       # hypothesis probed (refuted / tested-clean) — real test, no finding
SCORE_HYPOTHESIS = 0.5   # hypothesis planned but not yet probed
SCORE_BLOCK = 0.3        # genuinely blocked (needs-user-input / technical) — not tested
SCORE_SKIP = 0.0         # skip / gap — nothing tested; earns nothing


def _entity_score(state: str, hyps, blocks) -> float:
    """Per-entity coverage-quality score (weights above). `state` already encodes
    finding/tested; below that, untested-hyp > block > skip/gap."""
    if state == "finding":
        return SCORE_FINDING
    if state == "tested":
        return SCORE_TESTED
    if hyps:            # covered by an untested hypothesis
        return SCORE_HYPOTHESIS
    if blocks:          # blocked, no hypothesis
        return SCORE_BLOCK
    return SCORE_SKIP   # only skip(s), or a bare gap


def build_per_entity_block(idx: Index) -> List[dict]:
    """One record per wiki entity. Gate state is entity-level; OWASP breakdown
    is a view sub-field for breadth analysis, not a gate input."""
    out: List[dict] = []
    prof = active_profile()
    rollup_order = prof.rollup_order
    hyp_by_target = _hypotheses_targeting(idx)
    archived = idx.archived_entity_ids()

    for f in idx.files:
        if not f.rel_path.startswith("wiki/"):
            continue
        wf = _file_workflow(f)
        for e in f.entities:
            if e.type not in prof.gated_entity_types:
                continue
            if e.is_placeholder or e.id in archived:
                continue

            all_hyps = hyp_by_target.get(e.id, [])
            skips, blocks, malformed = _collect_coverage_bullets(e)

            # Some entity types are covered only by a SPECIFIC hypothesis class
            # (e.g. host WEBAPP → `web-app-pentest` delegation). A hypothesis of
            # any other class targeting the entity does not count toward the gate;
            # only a matching-class hyp (or an explicit skip/block) resolves it.
            required_class = prof.required_hyp_class_map.get(e.type)
            if required_class:
                rc = required_class.strip().lower()
                hyps = [h for h in all_hyps
                        if str(h.bullets.get("class", "")).strip().lower() == rc]
                # Near-miss: hyps that DO target the entity but with the wrong
                # class — the agent aimed at it and missed the class binding.
                # Carry id + actual class so the render can name them instead of
                # printing a bare count.
                offclass_hyps = [
                    {"id": h.id, "class": (str(h.bullets.get("class", "")).strip() or None)}
                    for h in all_hyps
                    if str(h.bullets.get("class", "")).strip().lower() != rc
                ]
                offclass_count = len(offclass_hyps)
            else:
                hyps = all_hyps
                offclass_hyps = []
                offclass_count = 0

            # Rollup breakdown — categorise hypotheses by rollup category.
            cats_with_hyps: Dict[str, List[Entity]] = defaultdict(list)
            for h in hyps:
                cat = _classify_hypothesis_rollup(h)
                if cat:
                    cats_with_hyps[cat].append(h)

            # Build per-cat breakdown (view only, not gating).
            owasp_breakdown: Dict[str, dict] = {}
            interesting_cats = set(cats_with_hyps.keys()) | set(skips.keys()) | set(blocks.keys())
            for cat in sorted(interesting_cats, key=lambda c: rollup_order.index(c) if c in rollup_order else 99):
                matching = cats_with_hyps.get(cat, [])
                if matching:
                    if any(h.bullets.get("status") == "verified" and _has_finding_for_hyp(idx, h.id) for h in matching):
                        cell_state = "finding"
                    elif any(h.bullets.get("status") in ("tested-clean", "refuted") for h in matching):
                        cell_state = "tested"
                    else:
                        cell_state = "hyp"
                    owasp_breakdown[cat] = {"state": cell_state, "hypothesis_count": len(matching)}
                elif cat in skips:
                    owasp_breakdown[cat] = {"state": "skip", "skip_reason": skips[cat]}
                elif cat in blocks:
                    kind, residual = _block_kind(blocks[cat])
                    owasp_breakdown[cat] = {"state": "blocked", "block_kind": kind, "block_reason": residual or blocks[cat]}

            # Entity-level state — the GATE input.
            has_coverage = bool(hyps or skips or blocks)
            if not has_coverage:
                state = "gap"
            elif any(h.bullets.get("status") == "verified" and _has_finding_for_hyp(idx, h.id) for h in hyps):
                state = "finding"
            elif any(h.bullets.get("status") in ("tested-clean", "refuted") for h in hyps):
                state = "tested"
            else:
                state = "covered"

            score = _entity_score(state, hyps, blocks)

            row = {
                "entity_id": e.id,
                "entity_type": e.type,
                "entity_title": e.title,
                "workflow": wf,
                "state": state,
                "score": score,
                "hypothesis_count": len(hyps),
                "skip_count": len(skips),
                "block_count": len(blocks),
                "required_class": required_class,
                "offclass_hypothesis_count": offclass_count,
                "offclass_hyps": offclass_hyps,
                "malformed_coverage_bullets": malformed,
                prof.breakdown_key: owasp_breakdown,
            }
            for b in prof.display_bullets:
                row[b] = e.bullets.get(b)
            out.append(row)
    return out


# ───────────────────────── Universal block ─────────────────────────

def _sweep_tag_aggregate(idx: Index, tag_key: str) -> dict:
    """Aggregate a per-endpoint sweep tag (validators/sweep_tags.py) across the
    real ENDPOINTs. `open` = endpoints still `required`/`blocked` (keep the check
    open); `ran` = count the sweep disposed (enforced/missing); `missing` = the
    subset that turned into findings. Malformed values are left to the commit
    gate — ignored here."""
    from ..validators import sweep_tags as st
    open_eps: List[Tuple[str, str]] = []
    missing_eps: List[str] = []
    terminal_eps: List[str] = []   # blocked(technical: …) — swept, untestable, recorded
    ran = 0
    for e in idx.by_type.get("ENDPOINT", []):
        if e.is_placeholder:
            continue
        val = e.bullets.get(tag_key)
        if st.state_of(val) is None:
            continue
        if st.is_open(val):
            open_eps.append((e.id, str(val).strip()))
        elif st.is_terminal_block(val):
            terminal_eps.append(e.id)
        elif st.is_ran(val):
            ran += 1
            if st.is_missing(val):
                missing_eps.append(e.id)
    return {"open": open_eps, "ran": ran, "missing": missing_eps, "terminal": terminal_eps}


def build_universal_block(idx: Index) -> List[dict]:
    out: List[dict] = []
    sys_hyps: List[Entity] = []
    for h in idx.by_type.get("HYPOTHESIS", []):
        if h.is_placeholder:
            continue
        targets = h.bullets.get("targets")
        if targets == SYSTEM_WIDE_SENTINEL or (isinstance(targets, list) and SYSTEM_WIDE_SENTINEL in targets):
            sys_hyps.append(h)

    # universal-skip NOTEs: slug -> reason line (mirrors scenario-skip).
    archived = idx.archived_entity_ids()
    skipped: Dict[str, str] = {}
    for n in idx.by_type.get("NOTE", []):
        if n.is_placeholder or n.id in archived:
            continue
        text = (n.title or "") + "\n" + (n.body or "")
        if UNIVERSAL_SKIP_PREFIX in text:
            val = text.split(UNIVERSAL_SKIP_PREFIX, 1)[1].strip().splitlines()[0].strip()
            slug = val.split("(")[0].strip().lower()
            if slug:
                skipped.setdefault(slug, val)

    for chk in active_profile().universal_checks:
        slug = chk["slug"]
        tokens = [t for t in slug.lower().split("-") if t]

        # Sweep checks bound to a per-endpoint tag (§ sweep-via-universal-checks):
        # closure is driven by the endpoint ledger, not a system-wide hypothesis.
        # A universal-skip NOTE still wins (no privileged surface). While any
        # tagged endpoint is required/blocked the check stays OPEN; once the
        # per-area sweep has disposed every tagged endpoint it closes. Only when
        # nothing has run AND nothing is open do we fall through to the legacy
        # system-wide-hypothesis closure (keeps empty-tree / no-endpoint behavior).
        tag_key = chk.get("endpoint_tag")
        if tag_key:
            if slug in skipped:
                out.append({**chk, "state": "skip", "hypothesis": None, "reason": skipped[slug]})
                continue
            agg = _sweep_tag_aggregate(idx, tag_key)
            if agg["open"]:
                out.append({**chk, "state": "gap", "hypothesis": None,
                            "open_endpoints": agg["open"]})
                continue
            if agg["ran"] > 0 or agg["terminal"]:
                # Every tagged endpoint is disposed: enforced/missing (ran) or a
                # recorded, terminal blocked(technical: …). The check CLOSES — a
                # permanently-untestable endpoint is recorded, not a wedge that
                # holds the exit gate open forever.
                state = "finding" if agg["missing"] else "tested"
                out.append({**chk, "state": state, "hypothesis": None,
                            "swept_endpoints": agg["ran"], "missing_endpoints": agg["missing"],
                            "blocked_terminal": agg["terminal"]})
                continue
            # else: no endpoints have run and none are open → legacy path below.

        match: Optional[Entity] = None
        for h in sys_hyps:
            body_ish = " ".join(str(h.bullets.get(k, "")) for k in ("rationale", "class"))
            haystack = (h.title + " " + body_ish).lower()
            if all(tok in haystack for tok in tokens):
                match = h
                break
        if match is None:
            if slug in skipped:
                out.append({**chk, "state": "skip", "hypothesis": None, "reason": skipped[slug]})
            else:
                out.append({**chk, "state": "gap", "hypothesis": None})
            continue
        status = match.bullets.get("status")
        has_finding = _has_finding_for_hyp(idx, match.id)
        if status == "verified" and has_finding:
            state = "finding"
        elif status in ("tested-clean", "refuted"):
            state = "tested"
        else:
            state = "hyp"
        # Lifecycle gate: checks flagged require_tested demand the sweep actually
        # ran + was analyzed, so a matched-but-untested hypothesis (state "hyp")
        # is still a gap — only tested/finding (or a universal-skip) clears it.
        if chk.get("require_tested") and state == "hyp":
            out.append({**chk, "state": "gap", "hypothesis": match.id, "hypothesis_status": status})
            continue
        out.append({**chk, "state": state, "hypothesis": match.id, "hypothesis_status": status})
    return out


# ───────────────────────── Conditional block (unchanged) ─────────────────────────

def build_conditional_block(idx: Index) -> List[dict]:
    out: List[dict] = []
    archived = idx.archived_entity_ids()

    sys_hyps: List[Entity] = []
    for h in idx.by_type.get("HYPOTHESIS", []):
        if h.is_placeholder:
            continue
        targets = h.bullets.get("targets")
        if targets == SYSTEM_WIDE_SENTINEL or (isinstance(targets, list) and SYSTEM_WIDE_SENTINEL in targets):
            sys_hyps.append(h)

    for n in idx.by_type.get("NOTE", []):
        if n.is_placeholder or n.id in archived:
            continue
        title = n.title or ""
        slug_match = None
        if SYSTEM_FEATURE_PREFIX in title:
            slug_match = title.split(SYSTEM_FEATURE_PREFIX, 1)[1].strip()
        elif n.body and SYSTEM_FEATURE_PREFIX in n.body:
            for ln in n.body.splitlines():
                if SYSTEM_FEATURE_PREFIX in ln:
                    slug_match = ln.split(SYSTEM_FEATURE_PREFIX, 1)[1].strip()
                    break
        if slug_match is None:
            continue
        feature = slug_match.split(",")[0].strip() or slug_match
        status = n.bullets.get("status")
        promoted = n.bullets.get("promoted_to")

        if status == "retired":
            retire_reason = n.bullets.get("retire-reason") or n.bullets.get("retire_reason")
            out.append({
                "note_id": n.id, "feature": feature, "state": "retired",
                "hypothesis": None, "reason": retire_reason or "",
            })
            continue

        hyp_id: Optional[str] = None
        if isinstance(promoted, str):
            hyp_id = promoted
        elif isinstance(promoted, list) and promoted:
            hyp_id = promoted[0] if isinstance(promoted[0], str) else None

        if hyp_id is None:
            for h in sys_hyps:
                hay = " ".join(str(h.bullets.get(k, "")) for k in ("rationale", "class")).lower() + " " + h.title.lower()
                if feature.lower() in hay:
                    hyp_id = h.id
                    break

        if hyp_id is None:
            out.append({"note_id": n.id, "feature": feature, "state": "gap", "hypothesis": None})
            continue

        hyp = idx.by_id.get(hyp_id)
        if hyp is None:
            out.append({"note_id": n.id, "feature": feature, "state": "gap", "hypothesis": hyp_id})
            continue
        status = hyp.bullets.get("status")
        has_finding = _has_finding_for_hyp(idx, hyp.id)
        if status == "verified" and has_finding:
            state = "finding"
        elif status in ("tested-clean", "refuted"):
            state = "tested"
        else:
            state = "hyp"
        out.append({"note_id": n.id, "feature": feature, "state": state,
                    "hypothesis": hyp.id, "hypothesis_status": status})
    return out


# ───────────────────────── Scenario block ─────────────────────────

def build_scenario_block(idx: Index) -> List[dict]:
    out: List[dict] = []
    archived = idx.archived_entity_ids()

    # Hypotheses grouped by their `class` tag (non-archived).
    hyps_by_class: Dict[str, List[Entity]] = defaultdict(list)
    for h in idx.by_type.get("HYPOTHESIS", []):
        if h.is_placeholder or h.id in archived:
            continue
        cls = h.bullets.get("class")
        if isinstance(cls, str):
            hyps_by_class[cls.strip().lower()].append(h)

    # scenario-skip NOTEs: slug -> reason line.
    skipped: Dict[str, str] = {}
    for n in idx.by_type.get("NOTE", []):
        if n.is_placeholder or n.id in archived:
            continue
        text = (n.title or "") + "\n" + (n.body or "")
        if SCENARIO_SKIP_PREFIX in text:
            val = text.split(SCENARIO_SKIP_PREFIX, 1)[1].strip().splitlines()[0].strip()
            slug = val.split("(")[0].strip().lower()
            if slug:
                skipped.setdefault(slug, val)

    for sc in active_profile().scenarios:
        slug = sc["slug"]
        matching = hyps_by_class.get(slug, [])
        if matching:
            if any(h.bullets.get("status") == "verified" and _has_finding_for_hyp(idx, h.id) for h in matching):
                state = "finding"
            elif any(h.bullets.get("status") in ("tested-clean", "refuted") for h in matching):
                state = "tested"
            else:
                state = "hyp"
            out.append({**sc, "state": state, "hypothesis_count": len(matching)})
        elif slug in skipped:
            out.append({**sc, "state": "skip", "hypothesis_count": 0, "reason": skipped[slug]})
        else:
            out.append({**sc, "state": "gap", "hypothesis_count": 0})
    return out


# ───────────────────────── Semantic inventory advisory ─────────────────────────


def build_semantic_inventory_advisory(idx: Index) -> List[dict]:
    return build_semantic_inventory(idx, active_profile())


def build_semantic_inventory_warnings(idx: Index) -> List[dict]:
    return build_missing_type_warnings(idx, active_profile())


def build_semantic_inventory_issues(inventory: List[dict], warnings: List[dict]) -> List[dict]:
    prof = active_profile()
    return validate_shape(inventory, warnings, prof) + validate_closure(inventory)


def summarize_semantic_inventory_issues(issues: List[dict], enabled: bool) -> dict:
    if not enabled:
        return {"gate": "not-applicable", "blocking": 0, "warnings": 0}
    blocking = sum(1 for i in issues if i.get("severity") == "blocking")
    warnings = sum(1 for i in issues if i.get("severity") != "blocking")
    return {"gate": "blocked" if blocking else "open", "blocking": blocking, "warnings": warnings}


# Hint text (human + JSON) lives in the active profile.


# ───────────────────────── Summary + gate ─────────────────────────

def _summarize_per_entity(rows: List[dict]) -> Dict[str, int]:
    s = {"total": len(rows), "finding": 0, "tested": 0, "covered": 0, "gap": 0}
    for r in rows:
        st = r["state"]
        s[st] = s.get(st, 0) + 1
    s["resolved"] = s["finding"] + s["tested"] + s["covered"]
    earned = sum(r.get("score", 0.0) for r in rows)
    s["score"] = round(earned, 1)
    s["score_max"] = s["total"]
    s["score_pct"] = round(100 * earned / s["total"]) if s["total"] else 0
    return s


def _summarize_universal(rows: List[dict]) -> Dict[str, int]:
    s = {"total": len(rows), "covered": 0, "gap": 0}
    for r in rows:
        if r["state"] == "gap":
            s["gap"] += 1
        else:
            s["covered"] += 1
    return s


def _summarize_conditional(rows: List[dict]) -> Dict[str, int]:
    s = {"total": len(rows), "covered": 0, "retired": 0, "gap": 0}
    for r in rows:
        st = r["state"]
        if st == "gap":
            s["gap"] += 1
        elif st == "retired":
            s["retired"] += 1
        else:
            s["covered"] += 1
    return s


def _summarize_scenario(rows: List[dict]) -> Dict[str, int]:
    s = {"total": len(rows), "covered": 0, "skip": 0, "gap": 0}
    for r in rows:
        st = r["state"]
        if st == "gap":
            s["gap"] += 1
        elif st == "skip":
            s["skip"] += 1
        else:
            s["covered"] += 1
    return s


def _blocked_needs_user_input(per_entity: List[dict]) -> List[dict]:
    prof = active_profile()
    out: List[dict] = []
    for e in per_entity:
        nui_cats: List[str] = []
        nui_reason: Optional[str] = None
        for cat, cell in e.get(prof.breakdown_key, {}).items():
            if cell.get("state") == "blocked" and cell.get("block_kind") == "needs-user-input":
                nui_cats.append(cat)
                nui_reason = cell.get("block_reason")
        if nui_cats:
            out.append({"entity_id": e["entity_id"], prof.rollup_cat_key: sorted(nui_cats),
                        "reason": nui_reason or ""})
    return out


# ───────────────────────── Orphan hypotheses (plan integrity) ─────────────────────────
# An `untested` / `testing` (non-archived) hypothesis that NO task references can
# never be probed. Without this, a bare `class:` umbrella hypothesis clears its
# per-entity / scenario block while the flow is never actually tested — the gate
# reads "covered" but nothing ran. So an orphan blocks the gate too: every
# actionable hypothesis must have a task, or be closed (refuted/abandoned).

def _task_hyp_refs(task: Entity) -> List[str]:
    v = task.bullets.get("hypothesis")
    items = v if isinstance(v, list) else ([v] if isinstance(v, str) and v.strip() else [])
    return [s.strip().strip("[]") for s in items if isinstance(s, str)]


def build_orphan_block(idx: Index) -> List[dict]:
    archived = idx.archived_entity_ids()
    referenced: Set[str] = set()
    for t in idx.by_type.get("TASK", []):
        for s in _task_hyp_refs(t):
            referenced.add(s)
    out: List[dict] = []
    for h in idx.by_type.get("HYPOTHESIS", []):
        if h.is_placeholder or h.id in archived:
            continue
        # EVERY hypothesis must carry a task, regardless of status. A refuted /
        # verified / blocked hypothesis with no task was closed without one ever
        # running — paper-closure to dodge the gate. Only archival exempts it.
        if h.id in referenced:
            continue
        rel = ""
        if h.source_file is not None:
            rel = str(h.source_file.relative_to(idx.eng.root)).replace("\\", "/")
        out.append({"id": h.id, "status": h.bullets.get("status") or "?",
                    "title": h.title or "", "file": rel, "line": h.heading_line})
    return out


# ───────────────────────── Gap overview + focus (view layer) ─────────────────────────
# The GAP OVERVIEW is a compact, always-shown worklist: per-entity gaps grouped by
# workflow (host: asset type) + one line per static section. It is the agent's cheap
# global scan — read it, pick ONE slice, then drill in with `--focus <slice>`. `--focus`
# filters the DETAILED body only; the overview + SUMMARY + EXIT GATE always render in
# full and always reflect the whole engagement, so a filtered view can never hide the gate.

# Section keywords accepted by --focus (besides workflow / asset-type group labels).
_FOCUS_SECTIONS = {"universal", "scenario", "conditional", "semantic", "orphans", "leads"}
_FOCUS_ALL_ENTITY = {"entity", "per-entity"}
_OVERVIEW_ID_CAP = 12  # inline gap ids per group before "… +N more"


def _overview_group_key(row: dict) -> str:
    """Group per-entity rows by workflow, falling back to entity type (host assets
    usually carry no workflow). Taxonomy-blind: one code path for web + host."""
    return (row.get("workflow") or row.get("entity_type") or "(no workflow)")


def build_gap_overview(per_entity: List[dict], universal: List[dict],
                       conditional: List[dict], scenario: List[dict],
                       semantic_summary: dict, orphans: List[dict],
                       leads: List[dict], frontiers: List[dict],
                       unplaced: List[dict], prof) -> dict:
    groups: Dict[str, dict] = {}
    for e in per_entity:
        key = _overview_group_key(e)
        g = groups.setdefault(key, {"name": key, "total": 0, "resolved": 0, "gap": 0,
                                    "gap_ids": [], "score": 0.0})
        g["total"] += 1
        g["score"] += e.get("score", 0.0)
        if e["state"] == "gap":
            g["gap"] += 1
            g["gap_ids"].append(e["entity_id"])
        else:
            g["resolved"] += 1
    for g in groups.values():
        g["score"] = round(g["score"], 1)
    workflows = [groups[k] for k in sorted(groups)]

    uni_gaps = [f"#{r['id']} {r['slug']}" for r in universal if r["state"] == "gap"]
    sc_gaps = [r["slug"] for r in scenario if r["state"] == "gap"]
    cd_gaps = [r["feature"] for r in conditional if r["state"] == "gap"]
    sections = {
        "universal": {"total": len(universal), "gap": len(uni_gaps), "gap_labels": uni_gaps},
        "scenario": {"total": len(scenario), "gap": len(sc_gaps), "gap_labels": sc_gaps},
        "conditional": {"total": len(conditional), "gap": len(cd_gaps), "gap_labels": cd_gaps},
        "orphans": {"count": len(orphans), "ids": [o["id"] for o in orphans]},
        "leads": {"count": len(leads), "ids": [ld["id"] for ld in leads]},
        "frontiers": {"count": len(frontiers), "ids": [f"{fr['chain_id']}/{fr['hyp_id']}" for fr in frontiers]},
        "unplaced": {"count": len(unplaced), "ids": [u["id"] for u in unplaced]},
    }
    if prof.semantic_inventory_note_type:
        sections["semantic"] = {"applicable": True, "gate": semantic_summary["gate"],
                                "blocking": semantic_summary["blocking"]}
    else:
        sections["semantic"] = {"applicable": False}
    earned = round(sum(e.get("score", 0.0) for e in per_entity), 1)
    total = len(per_entity)
    score = {"earned": earned, "max": total,
             "pct": round(100 * earned / total) if total else 0}
    return {"workflows": workflows, "sections": sections, "score": score}


GAP_OVERVIEW_CAPTION = (
    "GAP OVERVIEW — your worklist AND score board. The goal is to MAXIMISE the coverage "
    "score, not merely empty this list: a skip clears a gap but earns 0, so genuine testing "
    "is what moves the number. Each GAP is an OPEN item — close it with a hypothesis + task "
    "(best), a block, or an honest coverage-skip. Pick ONE slice, then drill in:  "
    "bin/kb coverage --focus <name>"
)


def _render_gap_overview(overview: dict, prof) -> List[str]:
    lines: List[str] = [GAP_OVERVIEW_CAPTION]
    sc = overview.get("score") or {}
    if sc.get("max"):
        lines.append(f"  COVERAGE SCORE: {sc['earned']:.1f} / {sc['max']} ({sc['pct']}%)  "
                     "← raise this. skip·gap=0, plan=0.5, probed=0.9, finding=1.0; "
                     "turning a skip or gap into a probed test is the biggest single gain.")
    lines.append(f"  per-entity by {prof.overview_group_label}:")
    if not overview["workflows"]:
        lines.append("    (no entities yet)")
    for g in overview["workflows"]:
        pct = round(100 * g["score"] / g["total"]) if g["total"] else 0
        head = f"    {g['name']:<20} {g['total']:>3}e  score {g['score']:>5.1f} ({pct:>3}%)"
        if g["gap"]:
            lines.append(f"{head}  {g['gap']:>3} GAP → --focus {g['name']}")
        else:
            lines.append(f"{head}    0 gap ✓")

    s = overview["sections"]

    def _sec(label: str, sec: dict) -> str:
        if sec["gap"]:
            return f"  {label:<12} {sec['total']:>3} items  {sec['gap']:>2} GAP → " + " · ".join(sec["gap_labels"])
        return f"  {label:<12} {sec['total']:>3} items   0 gap ✓"

    lines.append(_sec("universal:", s["universal"]))
    lines.append(_sec("scenario:", s["scenario"]))
    if s["conditional"]["total"]:
        lines.append(_sec("conditional:", s["conditional"]))
    sem = s["semantic"]
    if sem.get("applicable"):
        if sem["gate"] == "blocked":
            lines.append(f"  {'semantic:':<12} BLOCKED ({sem['blocking']} blocking)")
        else:
            lines.append(f"  {'semantic:':<12} ok ✓")
    for key, label in (("orphans", "orphans:"), ("leads", "leads:"),
                       ("frontiers", "frontiers:"), ("unplaced", "unplaced:")):
        sec = s[key]
        if sec["count"]:
            lines.append(f"  {label:<12} {sec['count']} → " + " ".join(sec["ids"][:_OVERVIEW_ID_CAP]))
        else:
            lines.append(f"  {label:<12} 0 ✓")
    return lines


def resolve_focus(focus_list: Optional[List[str]], overview: dict, prof
                  ) -> Optional[Tuple[Set[str], Set[str], bool]]:
    """Parse --focus selectors into (workflow_labels_lower, section_keywords, all_entity).
    Returns None when no focus is given (full output). Dies (exit 2) on an unknown
    selector, listing the valid slices for THIS engagement so the message is discovery."""
    if not focus_list:
        return None
    from ..util import die
    labels = {g["name"].lower(): g["name"] for g in overview["workflows"]}
    wf: Set[str] = set()
    secs: Set[str] = set()
    all_entity = False
    for raw in focus_list:
        tok = (raw or "").strip().lower()
        if tok in _FOCUS_ALL_ENTITY:
            all_entity = True
        elif tok in _FOCUS_SECTIONS:
            if tok == "semantic" and not overview["sections"]["semantic"].get("applicable"):
                die(f"--focus semantic: the {prof.name} profile has no semantic inventory", code=2)
            secs.add(tok)
        elif tok in labels:
            wf.add(tok)
        else:
            valid = sorted(labels.values()) + sorted(_FOCUS_SECTIONS | _FOCUS_ALL_ENTITY)
            die(f"--focus {raw!r}: unknown slice. Valid for this engagement: {', '.join(valid)}", code=2)
    return wf, secs, all_entity


def build_follow_up_lead_block(idx: Index) -> List[dict]:
    """Probe-reported follow-up leads, held as `deepen-lead:` NOTEs by
    `kb draft integrate` (draft.py `_persist_follow_up_leads`). Each OPEN lead is a
    plan-integrity gap: probe surfaced a chainable signal that reason has not yet
    turned into a hypothesis/task (or retired). Open leads block the gate — same
    role as orphan hypotheses — until reason drains them (status flips off `open`)."""
    out: List[dict] = []
    archived = idx.archived_entity_ids()
    for n in idx.by_type.get("NOTE", []):
        if n.is_placeholder or n.id in archived:
            continue
        body = n.body or ""
        is_lead = (n.title or "").strip().lower().startswith("deepen-lead") or any(
            ln.strip().lower().startswith(DEEPEN_LEAD_PREFIX) for ln in body.splitlines()
        )
        if not is_lead:
            continue
        if str(n.bullets.get("status") or "open").strip().lower() != "open":
            continue  # retired / stale / resolved → reason has drained it
        lead_text = ""
        for ln in body.splitlines():
            s = ln.strip()
            if s.lower().startswith(DEEPEN_LEAD_PREFIX):
                lead_text = s[len(DEEPEN_LEAD_PREFIX):].strip()
                break
        rel = ""
        if n.source_file is not None:
            rel = str(n.source_file.relative_to(idx.eng.root)).replace("\\", "/")
        out.append({"id": n.id, "lead": lead_text, "file": rel, "line": n.heading_line})
    return out


# Chain-centric deepening completeness (deepening-chain-centric-redesign Part 3.5).
# A chain hop is OPEN while its frontier hypothesis is untested/testing/pending;
# verified folds into the spine, refuted is a dead branch, blocked is parked.
_OPEN_FRONTIER_STATUS = {"untested", "testing", "pending", ""}


def build_open_frontier_block(idx: Index) -> List[dict]:
    """Each CHAIN's `frontier:` lists projected next-hop `[[HYPOTHESIS-N]]`; a hop is
    OPEN (blocks the gate) while its hypothesis is untested/testing/pending. Status is
    DERIVED from the hypothesis (single source of truth) — no status stored on the line."""
    out: List[dict] = []
    archived = idx.archived_entity_ids()
    for c in idx.by_type.get("CHAIN", []):
        if c.is_placeholder or c.id in archived:
            continue
        fr = c.bullets.get("frontier")
        hyp_ids = fr if isinstance(fr, list) else ([fr] if fr else [])
        for hid in hyp_ids:
            h = idx.by_id.get(hid) or idx.placeholders.get(hid)
            st = str((h.bullets.get("status") if h else "") or "").strip().lower()
            if h is None or st in _OPEN_FRONTIER_STATUS:
                rel = ""
                if c.source_file is not None:
                    rel = str(c.source_file.relative_to(idx.eng.root)).replace("\\", "/")
                out.append({"chain_id": c.id, "hyp_id": hid,
                            "title": (h.title if h else "(unresolved hypothesis)"),
                            "file": rel, "line": c.heading_line})
    return out


def build_finding_placement_block(idx: Index) -> List[dict]:
    """Every verified FINDING must be PLACED — a member of some `CHAIN.findings` spine
    OR flagged `chain-terminal: true` in its frontmatter. An unplaced finding means
    deepening has not considered it yet; it blocks the gate (unplaced by construction
    when a finding is fresh → forces one deepening pass, no marker/ledger needed)."""
    archived = idx.archived_entity_ids()
    placed: Set[str] = set()
    for c in idx.by_type.get("CHAIN", []):
        if c.is_placeholder or c.id in archived:
            continue
        fs = c.bullets.get("findings")
        for fid in (fs if isinstance(fs, list) else ([fs] if fs else [])):
            placed.add(fid)
    out: List[dict] = []
    for f in idx.by_type.get("FINDING", []):
        if f.is_placeholder or f.id in archived:
            continue
        if str(f.bullets.get("status") or "").strip().lower() == "false-positive":
            continue  # triaged out — not a live finding to place
        if f.id in placed:
            continue
        # single-file FINDING frontmatter is synthesized into .bullets (index.py).
        # Frontmatter keys must be underscore (the parser drops hyphenated keys),
        # so the placement flag is `chain_terminal` (not `chain-terminal`).
        if str(f.bullets.get("chain_terminal") or "").strip().lower() in ("true", "yes", "1"):
            continue
        rel = ""
        if f.source_file is not None:
            rel = str(f.source_file.relative_to(idx.eng.root)).replace("\\", "/")
        out.append({"id": f.id, "title": (f.title or f.bullets.get("title") or ""),
                    "file": rel, "line": f.heading_line})
    return out


# A coherent kill-chain (initial access → escalation → lateral/impact) rarely runs
# past ~this many findings; well beyond it almost always means independent attack
# paths were crammed into one CHAIN.
OVERSIZED_CHAIN_THRESHOLD = 10


def build_oversized_chain_block(idx: Index) -> List[dict]:
    """Advisory (NOT a gate input): flag chains whose `findings:` spine is unusually
    long — likely over-merged. Deepening should split the independent paths into their
    own CHAINs (see its new-chain-vs-merge rule). Never affects the exit code."""
    out: List[dict] = []
    archived = idx.archived_entity_ids()
    for c in idx.by_type.get("CHAIN", []):
        if c.is_placeholder or c.id in archived:
            continue
        fs = c.bullets.get("findings")
        n = len(fs) if isinstance(fs, list) else (1 if fs else 0)
        if n > OVERSIZED_CHAIN_THRESHOLD:
            rel = ""
            if c.source_file is not None:
                rel = str(c.source_file.relative_to(idx.eng.root)).replace("\\", "/")
            out.append({"chain_id": c.id, "title": c.title, "count": n,
                        "file": rel, "line": c.heading_line})
    return out


def _gate_blocked(pe_sum, uv_sum, cd_sum, sc_sum, orphan_count: int = 0,
                  lead_count: int = 0, frontier_count: int = 0,
                  unplaced_count: int = 0) -> Tuple[bool, int]:
    n = (pe_sum.get("gap", 0) + uv_sum.get("gap", 0)
         + cd_sum.get("gap", 0) + sc_sum.get("gap", 0))
    return (n > 0 or orphan_count > 0 or lead_count > 0
            or frontier_count > 0 or unplaced_count > 0, n)


# ───────────────────────── Render ─────────────────────────

def _render_human(per_entity: List[dict], universal: List[dict], conditional: List[dict],
                  scenario: List[dict], semantic_inventory: List[dict], semantic_inventory_warnings: List[dict],
                  semantic_inventory_issues: List[dict], semantic_summary: dict,
                  pe_sum, uv_sum, cd_sum, sc_sum, blocked_users,
                  orphans: Optional[List[dict]] = None, primary_objective: str = "",
                  leads: Optional[List[dict]] = None,
                  frontiers: Optional[List[dict]] = None,
                  unplaced: Optional[List[dict]] = None,
                  oversized: Optional[List[dict]] = None,
                  overview: Optional[dict] = None,
                  focus: Optional[Tuple[Set[str], Set[str], bool]] = None) -> str:
    orphans = orphans or []
    leads = leads or []
    frontiers = frontiers or []
    unplaced = unplaced or []
    oversized = oversized or []
    prof = active_profile()
    lines: List[str] = []

    # Focus gating — decide which DETAILED sections render. The overview, SUMMARY
    # and EXIT GATE ignore this entirely (always full + global), so a filtered view
    # can never hide the gate or shrink its verdict.
    _SEC_KEYS = ("universal", "conditional", "scenario", "orphans", "leads", "semantic")
    if focus is None:
        # Default view is a compact global scan. The per-entity endpoint body scales
        # with engagement size, so it is NOT dumped by default — read the GAP OVERVIEW,
        # then drill into ONE slice with `--focus <workflow>` (or `--focus entity` for
        # the whole per-entity body). Static sections + SUMMARY + EXIT GATE still render.
        show_pe, pe_rows = False, []
        sec_on = {k: True for k in _SEC_KEYS}
    else:
        f_wf, f_secs, f_all_entity = focus
        if f_all_entity:
            show_pe, pe_rows = True, per_entity
        elif f_wf:
            show_pe = True
            pe_rows = [e for e in per_entity if _overview_group_key(e).lower() in f_wf]
        else:
            show_pe, pe_rows = False, []
        sec_on = {k: (k in f_secs) for k in _SEC_KEYS}

    lines.append(f"COVERAGE PROFILE: {prof.name}")
    lines.append("")

    # Primary Objective Lock banner — canonical, machine-backed (target.json).
    # Doubles as the reason-facing reminder: under a Lock, only objective-scoped
    # gaps must close, NOT the global gate. (Verb-neutral: the specific reason
    # task_input is a runtime-prompt concern, not the tool's to prescribe.)
    if primary_objective:
        lines.append(f"PRIMARY OBJECTIVE LOCK: {primary_objective}  (active)")
        lines.append(f"  → close the '{primary_objective}' objective, then report. "
                     "Gaps outside the objective are ADVISORY — record them in the "
                     "report scope / post-report curation; they do NOT block the report.")
        lines.append(f"  → reason: plan only within the '{primary_objective}' scope — "
                     "do NOT clear the global gate or raise universal / adjacent-workflow "
                     "gaps as new mainline tasks. Check only what the objective report needs.")
    else:
        lines.append("PRIMARY OBJECTIVE LOCK: (none — full-scope engagement)")
        lines.append("  → OBJECTIVE: push the COVERAGE SCORE as high as you can — every entity "
                     "probed to a finding or a clean result. A skip or gap scores 0, so an "
                     "ignored / skipped entity is lost score, not 'done'.")
        lines.append("  → the EXIT GATE below is only the FLOOR (nothing left undisposed); "
                     "clearing it is necessary but NOT the goal. Keep converting skips / blocks / "
                     "plans into probed tests to raise the score, then report.")
    lines.append("")

    # GAP OVERVIEW — the always-shown worklist / global scan (never filtered).
    if overview is not None:
        lines.extend(_render_gap_overview(overview, prof))
        lines.append("")

    if focus is not None:
        shown = sorted([g for g in ((f_all_entity and ["all per-entity"]) or [])]
                       + sorted(f_wf) + sorted(f_secs))
        lines.append(f"FILTERED VIEW: {', '.join(shown) or '(nothing selected)'}  "
                     "— detailed sections below are a partial slice; the GAP OVERVIEW above "
                     "and the SUMMARY / EXIT GATE below are always the FULL engagement.")
        lines.append("")

    if show_pe:
        lines.append("PER-ENTITY COVERAGE")
        if not pe_rows:
            lines.append("  (no entities in this slice)" if focus is not None else "  (no entities yet)")
        else:
            by_workflow: Dict[str, List[dict]] = defaultdict(list)
            for e in pe_rows:
                by_workflow[e.get("workflow") or "(no workflow)"].append(e)
            for wf, entities in sorted(by_workflow.items()):
                lines.append("")
                lines.append(f"  Workflow: {wf}")
                for e in sorted(entities, key=lambda x: x["entity_id"]):
                    head_parts = [e["entity_id"]]
                    shown = [str(e[b]) for b in prof.display_bullets if e.get(b)]
                    if shown:
                        head_parts += shown
                    elif e.get("entity_title"):
                        head_parts.append(e["entity_title"])
                    head = "  ".join(head_parts)

                    # Rollup breakdown inline
                    owasp_parts: List[str] = []
                    for cat in prof.rollup_order:
                        cell = e.get(prof.breakdown_key, {}).get(cat)
                        if cell:
                            cs = cell["state"]
                            if cs == "skip":
                                owasp_parts.append(f"{cat} skip")
                            elif cs == "blocked":
                                owasp_parts.append(f"{cat} blocked")
                            else:
                                owasp_parts.append(f"{cat} {cs}")
                    owasp_str = " · ".join(owasp_parts) if owasp_parts else "—"
                    counts = f"{e['hypothesis_count']}hyp {e['skip_count']}skip {e['block_count']}block"
                    suffix = ""
                    rc = e.get("required_class")
                    if rc and e["state"] == "gap":
                        suffix = f"  → needs a `class: {rc}` hypothesis (or coverage-skip/block)"
                        offh = e.get("offclass_hyps") or []
                        if offh:
                            named = ", ".join(
                                f"{h['id']}(class:{h['class'] or '—'})" for h in offh[:3]
                            )
                            more = "" if len(offh) <= 3 else f" +{len(offh) - 3} more"
                            suffix += (f"; {named}{more} target it but class ≠ `{rc}`, "
                                       "so they do NOT satisfy the gate")
                    lines.append(f"    {head:<55} {e['state']:<10} ({owasp_str})  {counts}{suffix}")
                    # Silently-dropped coverage-skip/block bullets — surface why the
                    # disposition 'did nothing' so the agent fixes syntax instead of
                    # reading source to find the parse rule.
                    for mb in (e.get("malformed_coverage_bullets") or []):
                        val = mb["value"] if len(mb["value"]) <= 50 else mb["value"][:47] + "…"
                        lines.append(
                            f"      ↳ IGNORED `coverage-{mb['kind']}: {val}` — parsed 0 items; "
                            f"expected `<category>(reason)`, e.g. `{prof.rollup_order[0]}(reason)`"
                        )
        lines.append("")

        lines.append(f"  {prof.rollup_label} rollup — which `tags:` each category covers:")
        for cat in prof.rollup_order:
            tags = " · ".join(sorted(prof.rollup_to_tags.get(cat, ())))
            lines.append(f"    {cat}: {tags}")
        lines.append("")

    elif focus is None:
        # Compact global scan: point to the drill-in path instead of dumping every endpoint.
        lines.append("PER-ENTITY COVERAGE  — endpoint detail suppressed in the global scan "
                     "(it scales with #endpoints). Pick a slice from the GAP OVERVIEW above, "
                     "then `--focus <workflow>` for that slice's endpoints (or `--focus entity` "
                     "for the full per-entity body).")
        lines.append("")

    # UNIVERSAL
    if sec_on["universal"]:
        lines.append("UNIVERSAL CHECKS")
        for r in universal:
            if r["state"] == "gap":
                mark = "[ ]"
                if r.get("open_endpoints"):
                    # Endpoint-ledger sweep: named endpoints still owe the sweep.
                    eps = r["open_endpoints"]
                    sample = ", ".join(f"{eid}({val})" for eid, val in eps[:6])
                    more = "" if len(eps) <= 6 else f", +{len(eps)-6} more"
                    tail = (f"GAP — {len(eps)} endpoint(s) still owe this sweep: {sample}{more}. "
                            f"Run the per-area sweep to advance each to enforced / missing. "
                            f"`blocked(needs-…)` = owed (needs contract / actor / peer) → keeps this "
                            f"check open, orchestrator acquires it. Only if an endpoint is GENUINELY "
                            f"untestable (500 state / WAF / no data baseline) tag it "
                            f"`blocked(technical: <why>)` — that is recorded and CLOSES it (no silent "
                            f"close of an owed gap)")
                elif r.get("hypothesis"):
                    # require_tested check: hypothesis exists but is not yet tested.
                    tail = (f"GAP — {r['hypothesis']} exists but status="
                            f"{r.get('hypothesis_status') or 'untested'}; run the sweep + "
                            f"collect/analyze results to advance it to tested")
                else:
                    toks = ", ".join(t for t in r["slug"].split("-") if t)
                    tail = (f"GAP — raise a `targets: system-wide` hypothesis whose "
                            f"title/rationale/class contains all of: {toks} "
                            f"(matched as text, NOT `tags:`); or NOTE `universal-skip: {r['slug']} (reason)`")
                if r.get("hint"):
                    tail += f"\n        HINT: {r['hint']}"
            elif r["state"] == "skip":
                mark = "[-]"
                tail = f"SKIP — {r.get('reason') or '(no reason)'}"
            elif not r.get("hypothesis") and r.get("swept_endpoints") is not None:
                # Endpoint-ledger sweep closed off the tags (no system-wide hyp).
                mark = "[✓]"
                miss = r.get("missing_endpoints") or []
                term = r.get("blocked_terminal") or []
                if miss:
                    tail = (f"swept {r['swept_endpoints']} endpoint(s) — {len(miss)} missing "
                            f"→ FINDING ({', '.join(miss[:5])})")
                else:
                    tail = f"swept {r['swept_endpoints']} endpoint(s) clean"
                if term:
                    tail += (f" · {len(term)} blocked(technical) recorded untestable "
                             f"({', '.join(term[:3])})")
            else:
                mark = "[✓]"
                tail = f"{r['hypothesis']} → {r.get('hypothesis_status') or r['state']}"
            lines.append(f"  {mark} {r['id']}. {r['name']:<40} {tail}")
        lines.append("")

    # CONDITIONAL
    if sec_on["conditional"]:
        lines.append("CONDITIONAL SYSTEM FEATURES")
        if not conditional:
            lines.append("  (none detected)")
        else:
            for r in conditional:
                if r["state"] == "gap":
                    tail = "GAP — no hypothesis, no retire"
                elif r["state"] == "retired":
                    tail = f"RETIRED — {r.get('reason') or '(no reason)'}"
                else:
                    tail = f"{r['hypothesis']} → {r.get('hypothesis_status') or r['state']}"
                lines.append(f"  {r['note_id']:<10} system-feature: {r['feature']:<30} {tail}")
        lines.append("")

    # SCENARIOS
    if sec_on["scenario"]:
        lines.append("BUSINESS SCENARIOS")
        for r in scenario:
            if r["state"] == "gap":
                mark = "[ ]"
                tail = (f"GAP — raise a `class: {r['slug']}` hypothesis, "
                        f"or NOTE `scenario-skip: {r['slug']} (reason)`")
            elif r["state"] == "skip":
                mark, tail = "[-]", f"SKIP — {r.get('reason') or '(no reason)'}"
            else:
                mark, tail = "[✓]", f"{r['hypothesis_count']} hyp → {r['state']}"
            lines.append(f"  {mark} {r['id']}. {r['name']:<40} {tail}")
        lines.append("")

    # ORPHAN HYPOTHESES (plan integrity — any hypothesis with no task, any status)
    if sec_on["orphans"]:
        lines.append("ORPHAN HYPOTHESES (no task references them — every hypothesis MUST have a task, any status)")
        if not orphans:
            lines.append("  (none)")
        else:
            for o in orphans:
                loc = o["file"] + (f":{o['line']}" if o.get("line") else "")
                lines.append(f"  {o['id']:<16} {o['status']:<9} {o['title'][:48]:<48} {loc}")
        lines.append("")

    # OPEN FOLLOW-UP LEADS (plan integrity — probe deepen-lead NOTEs not yet drained)
    if sec_on["leads"]:
        lines.append("OPEN FOLLOW-UP LEADS (probe deepen-lead NOTEs — convert to hypothesis or retire)")
        if not leads:
            lines.append("  (none)")
        else:
            for ld in leads:
                loc = ld["file"] + (f":{ld['line']}" if ld.get("line") else "")
                lines.append(f"  {ld['id']:<16} {(ld.get('lead') or '')[:56]:<56} {loc}")
        lines.append("")

    # OPEN CHAIN FRONTIERS (chain-centric deepening — unverified hops still to walk)
    lines.append("OPEN CHAIN FRONTIERS (unverified hops — verify the hypothesis, or the chain blocks)")
    if not frontiers:
        lines.append("  (none)")
    else:
        for fr in frontiers:
            loc = fr["file"] + (f":{fr['line']}" if fr.get("line") else "")
            lines.append(f"  {fr['chain_id']:<12} {fr['hyp_id']:<16} {(fr.get('title') or '')[:40]:<40} {loc}")
    lines.append("")

    # UNPLACED FINDINGS (verified finding not in a chain and not chain-terminal → run deepening)
    lines.append("UNPLACED FINDINGS (not in any chain, not chain-terminal — deepen: chain it or mark chain-terminal)")
    if not unplaced:
        lines.append("  (none)")
    else:
        for u in unplaced:
            loc = u["file"] + (f":{u['line']}" if u.get("line") else "")
            lines.append(f"  {u['id']:<16} {(u.get('title') or '')[:52]:<52} {loc}")
    lines.append("")

    # OVERSIZED CHAINS (advisory — does not affect exit code). Only shown when triggered.
    if oversized:
        lines.append(f"OVERSIZED CHAINS (advisory — >{OVERSIZED_CHAIN_THRESHOLD} findings, likely over-merged; split independent paths into separate CHAINs)")
        for oc in oversized:
            loc = oc["file"] + (f":{oc['line']}" if oc.get("line") else "")
            lines.append(f"  {oc['chain_id']:<12} {oc['count']:>3} findings  {(oc.get('title') or '')[:44]:<44} {loc}")
        lines.append("")

    # SEMANTIC INVENTORY ADVISORY (non-gating)
    if sec_on["semantic"] and prof.semantic_inventory_note_type:
        label = prof.semantic_inventory_label or "SEMANTIC INVENTORY"
        lines.append(f"{label} (advisory — does not affect exit code)")
        if not semantic_inventory:
            lines.append("  (none)")
        else:
            for inv in semantic_inventory:
                target = inv.get("target") or "(no target)"
                pattern = inv.get("pattern") or "(no pattern)"
                counts = (f"{inv['covered_count']} covered, {inv['refuted_count']} refuted, "
                          f"{inv['selected_count']} selected, {inv['missing_count']} missing, "
                          f"{inv['deferred_count']} deferred, {inv['blocked_count']} blocked, "
                          f"{inv['skipped_count']} skipped")
                lines.append(f"  {inv['note_id']:<10} {target:<18} tier={inv.get('tier') or '?'} pattern={pattern} ({counts})")
                for item in inv.get("slots", {}).get("slots_selected", []):
                    lines.append(f"    SELECTED: {item}")
                for item in inv.get("slots", {}).get("slots_missing", []):
                    lines.append(f"    MISSING: {item}")
        if semantic_inventory_issues:
            lines.append(f"  Semantic inventory gate: {semantic_summary['gate'].upper()} "
                         f"({semantic_summary['blocking']} blocking, {semantic_summary['warnings']} warning)")
            for i in semantic_inventory_issues:
                label = "BLOCKING" if i.get("severity") == "blocking" else "WARNING"
                lines.append(f"    {label} {i['note_id']}: {i['issue']}")
        else:
            lines.append(f"  Semantic inventory gate: {semantic_summary['gate'].upper()} "
                         f"({semantic_summary['blocking']} blocking, {semantic_summary['warnings']} warning)")
        lines.append("")

    # SUMMARY
    lines.append("SUMMARY")
    lines.append(
        f"  per-entity:  {pe_sum['total']} entities | "
        f"{pe_sum['resolved']} resolved | {pe_sum['gap']} gap | "
        f"SCORE {pe_sum['score']}/{pe_sum['score_max']} ({pe_sum['score_pct']}%)"
    )
    lines.append(
        f"  universal:   {uv_sum['total']} checks | {uv_sum['covered']} covered | {uv_sum['gap']} gap"
    )
    lines.append(
        f"  conditional: {cd_sum['total']} feats  | {cd_sum['covered']} covered | "
        f"{cd_sum['retired']} retired | {cd_sum['gap']} gap"
    )
    lines.append(
        f"  scenarios:   {sc_sum['total']} items  | {sc_sum['covered']} covered | "
        f"{sc_sum['skip']} skip | {sc_sum['gap']} gap"
    )
    lines.append(
        f"  orphans:     {len(orphans)} hypotheses with no task (any status)"
    )
    lines.append(
        f"  leads:       {len(leads)} open follow-up leads (deepen-lead NOTEs)"
    )
    lines.append(
        f"  frontiers:   {len(frontiers)} open chain frontiers (unverified hops)"
    )
    lines.append(
        f"  unplaced:    {len(unplaced)} verified findings not in a chain / not chain-terminal"
    )
    gate_blocked, n_gaps = _gate_blocked(pe_sum, uv_sum, cd_sum, sc_sum, len(orphans), len(leads), len(frontiers), len(unplaced))
    lines.append("")
    if gate_blocked:
        parts = []
        if n_gaps:
            parts.append(f"{n_gaps} unresolved gaps")
        if orphans:
            parts.append(f"{len(orphans)} orphan hypotheses")
        if leads:
            parts.append(f"{len(leads)} open follow-up leads")
        if frontiers:
            parts.append(f"{len(frontiers)} open chain frontiers")
        if unplaced:
            parts.append(f"{len(unplaced)} unplaced findings")
        lines.append(f"  EXIT GATE: BLOCKED ({'; '.join(parts)})")
        if primary_objective:
            lines.append(f"    NOTE: Primary Objective Lock '{primary_objective}' active — "
                         "these gaps are ADVISORY for the objective report. Defer "
                         "non-objective gaps to report scope / post-report curation; "
                         "do not expand outside the objective to clear the global gate.")
    else:
        lines.append("  EXIT GATE: OPEN")

    if blocked_users:
        lines.append("  BLOCKED ENTITIES (needs-user-input, reported at termination):")
        for b in blocked_users:
            cats = ",".join(b[prof.rollup_cat_key])
            lines.append(f"    {b['entity_id']} {cats} — {b['reason']}")

    # HOW TO CLEAR GAPS — copy-paste worked examples, shown only for the gap types
    # currently present AND in the shown slice. Keeps agents from guessing bullet /
    # tag / frontmatter syntax (and from seeing recipes for sections a --focus hid).
    present = {
        "per-entity": (sum(1 for e in pe_rows if e["state"] == "gap") if show_pe else 0),
        "universal": (uv_sum.get("gap", 0) if sec_on["universal"] else 0),
        "conditional": (cd_sum.get("gap", 0) if sec_on["conditional"] else 0),
        "scenario": (sc_sum.get("gap", 0) if sec_on["scenario"] else 0),
        "orphan": (len(orphans) if sec_on["orphans"] else 0),
        "follow-up-lead": (len(leads) if sec_on["leads"] else 0),
    }
    recipes = [(k, txt) for k, txt in getattr(prof, "gap_examples", ()) if present.get(k)]
    if recipes:
        lines.append("")
        lines.append("HOW TO CLEAR GAPS (copy-paste templates for the gap types above)")
        for _kind, txt in recipes:
            lines.append("")
            for tln in txt.rstrip("\n").split("\n"):
                lines.append(("  " + tln) if tln else "")

    lines.append("")
    lines.append(prof.hint_human)
    return "\n".join(lines)


# ───────────────────────── Entry ─────────────────────────

def cmd_coverage(args) -> int:
    eng = ctx.require(args.engagement)
    from ..ids import read_target
    primary_objective = (read_target(eng.target_json).get("primary_objective") or "").strip()
    idx = build_index(eng)

    per_entity = build_per_entity_block(idx)
    universal = build_universal_block(idx)
    conditional = build_conditional_block(idx)
    scenario = build_scenario_block(idx)
    semantic_inventory = build_semantic_inventory_advisory(idx)
    semantic_inventory_warnings = build_semantic_inventory_warnings(idx)
    semantic_inventory_issues = build_semantic_inventory_issues(semantic_inventory, semantic_inventory_warnings)
    semantic_summary = summarize_semantic_inventory_issues(semantic_inventory_issues, bool(active_profile().semantic_inventory_note_type))

    orphans = build_orphan_block(idx)
    leads = build_follow_up_lead_block(idx)
    frontiers = build_open_frontier_block(idx)
    unplaced = build_finding_placement_block(idx)
    oversized = build_oversized_chain_block(idx)   # advisory only, never gates

    pe_sum = _summarize_per_entity(per_entity)
    uv_sum = _summarize_universal(universal)
    cd_sum = _summarize_conditional(conditional)
    sc_sum = _summarize_scenario(scenario)
    blocked_users = _blocked_needs_user_input(per_entity)
    gate_blocked, n_gaps = _gate_blocked(pe_sum, uv_sum, cd_sum, sc_sum, len(orphans), len(leads), len(frontiers), len(unplaced))

    overview = build_gap_overview(per_entity, universal, conditional, scenario,
                                  semantic_summary, orphans, leads, frontiers, unplaced, active_profile())

    if getattr(args, "check", False):
        return 3 if gate_blocked else 0

    if getattr(args, "json", False):
        # --focus filters the human view only; JSON stays complete (machines don't
        # truncate). The overview is emitted so tools can render the same worklist.
        out = {
            "gap_overview": overview,
            "per_entity": per_entity,
            "universal": universal,
            "conditional": conditional,
            "scenario": scenario,
            "semantic_inventory": semantic_inventory,
            "semantic_inventory_warnings": semantic_inventory_warnings,
            "semantic_inventory_issues": semantic_inventory_issues,
            "orphan_hypotheses": orphans,
            "follow_up_leads": leads,
            "open_chain_frontiers": frontiers,
            "unplaced_findings": unplaced,
            "oversized_chains": oversized,
            "summary": {
                "profile": active_profile().name,
                "primary_objective": primary_objective or None,
                "per_entity": pe_sum,
                "universal": uv_sum,
                "conditional": cd_sum,
                "scenario": sc_sum,
                "orphan_hypotheses": len(orphans),
                "follow_up_leads": len(leads),
                "open_chain_frontiers": len(frontiers),
                "unplaced_findings": len(unplaced),
                "oversized_chains": len(oversized),
                "exit_gate": "blocked" if gate_blocked else "open",
                "unresolved_gaps": n_gaps,
                "semantic_inventory_gate": semantic_summary["gate"],
                "semantic_inventory_blockers": semantic_summary["blocking"],
                "semantic_inventory_warnings": semantic_summary["warnings"],
                "blocked_needs_user_input": blocked_users,
            },
            "hints": list(active_profile().hints_json),
        }
        print(json.dumps(out, indent=2, ensure_ascii=False))
        return 0

    focus = resolve_focus(getattr(args, "focus", None), overview, active_profile())

    if not getattr(args, "quiet", False):
        print(_render_human(per_entity, universal, conditional, scenario,
                            semantic_inventory, semantic_inventory_warnings,
                            semantic_inventory_issues, semantic_summary,
                            pe_sum, uv_sum, cd_sum, sc_sum, blocked_users,
                            orphans, primary_objective, leads, frontiers, unplaced, oversized, overview, focus))
        reprobe_hygiene.emit(eng)  # deepening reads coverage as its queue: flag already-established root causes here
    return 0
