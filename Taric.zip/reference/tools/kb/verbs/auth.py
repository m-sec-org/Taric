"""kb auth credentials / session / lifecycle / show — per-actor auth records.

Layout: <eng>/auth/<actor>.json
{
  "actor": "admin1",
  "user": "...",
  "password": "...",
  "email": "...",
  "mobile": "...",
  "note": "...",
   "credential_state": "available",
  "sessions": [{"captured_at": "...", "cookie": "...", "bearer": "...", "headers": {...}}]
}

The password field is the current independently verified password. Lifecycle
commands are the only path for a password-change probe to update it.
"""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

from .. import ctx
from ..index import build_index
from ..lock import acquire
from ..log import append_event, append_log
from ..parser import parse_frontmatter, split_frontmatter
from ..util import die, now_isoZ


_LEGACY_STATES = {
    "stable": "available",
    "reserved": "leased",
    "password-change-in-progress": "leased",
    "customer-handover-required": "handover-required",
}


def _state(data: Dict[str, Any]) -> str:
    """Read legacy actor records through the compact lease-state vocabulary."""
    return _LEGACY_STATES.get(data.get("credential_state", "available"),
                              data.get("credential_state", "available"))


def _require_actor_task(data: Dict[str, Any], task: str, action: str) -> None:
    if data.get("active_task") != task:
        die(f"cannot {action}: actor is reserved by {data.get('active_task')!r}, not {task!r}", code=3)


def _record_auth_impact(data: Dict[str, Any], task: str, action: str,
                        outcome: str, reason: Optional[str] = None) -> None:
    impact = {
        "task": task,
        "action": action,
        "outcome": outcome,
        "recorded_at": now_isoZ(),
    }
    if reason:
        impact["reason"] = reason
    data["last_auth_impact"] = impact


def _read_leases(data: Dict[str, Any]) -> Dict[str, Dict[str, str]]:
    """Return the task-keyed shared reader map, normalizing old actor records."""
    leases = data.get("read_leases")
    if leases is None:
        return {}
    if not isinstance(leases, dict):
        die("invalid read_leases in actor record", code=1)
    return leases


def _write_conflict_message(data: Dict[str, Any], actor: str) -> str:
    readers = _read_leases(data)
    if not readers:
        return f"cannot reserve actor {actor!r}: credential_state={_state(data)}"
    active = ", ".join(
        f"{task}({record.get('action', 'authenticated-read')})"
        for task, record in sorted(readers.items())
    )
    return (
        f"cannot reserve write lease for actor {actor!r}: active read leases: {active}. "
        "Do not force reserve; wait for the bound draft to integrate or fail."
    )


def _require_pending_task(eng, task: str) -> None:
    """Read leases only belong to a real task that is still in flight."""
    entity = build_index(eng).by_id.get(task)
    status = entity.bullets.get("status") if entity else None
    if entity and entity.type == "TASK" and status == "pending":
        return
    die(
        f"cannot acquire read lease for {task!r}: canonical task must exist and be pending "
        f"(status={status!r})",
        code=3,
    )
def _lifecycle_password(args) -> str:
    """Read lifecycle secrets from stdin so they never appear in argv or logs."""
    if not getattr(args, "password_stdin", False):
        die("--password-stdin is required for password lifecycle actions", code=2)
    password = sys.stdin.readline().rstrip("\r\n")
    if not password:
        die("password stdin was empty", code=2)
    return password


def _actor_path(eng, actor: str) -> Path:
    if not re.fullmatch(r"[A-Za-z0-9_.-]+", actor):
        die(f"invalid actor name {actor!r}", code=2)
    eng.auth_dir.mkdir(parents=True, exist_ok=True)
    return eng.auth_dir / f"{actor}.json"


def _read_actor(p: Path) -> Dict[str, Any]:
    if not p.exists():
        return {"actor": p.stem, "sessions": []}
    return json.loads(p.read_text(encoding="utf-8"))


def _write_actor(p: Path, data: Dict[str, Any]) -> None:
    p.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def cmd_auth_credentials(args) -> int:
    eng = ctx.require(args.engagement)
    kind = getattr(args, "kind", None) or "password"
    with acquire(eng.root):
        p = _actor_path(eng, args.actor)
        data = _read_actor(p)
        data["actor"] = args.actor
        data["kind"] = kind
        # password kind keeps user/password; key/token kinds record their
        # reference instead. Only store what was provided (host actors may have
        # an ssh-key or api-token rather than a username/password).
        if args.user is not None:
            data["user"] = args.user
        if args.password is not None:
            data["password"] = args.password
        if getattr(args, "token", None) is not None:
            data["token"] = args.token
        if getattr(args, "file", None) is not None:
            data["key_file"] = args.file
        if args.email is not None:
            data["email"] = args.email
        if args.mobile is not None:
            data["mobile"] = args.mobile
        if args.note is not None:
            data["note"] = args.note
        data.setdefault("sessions", [])
        data.setdefault("credential_state", "available")
        _write_actor(p, data)
        append_event(eng.events_jsonl, verb="auth_credentials", actor=args.actor, kind=kind)
        append_log(eng.log_md, "auth credentials",
                   f"actor {args.actor} (kind={kind})", body=(args.note or ""))
    print(f"recorded {kind} credentials for actor {args.actor!r}")
    return 0


def cmd_auth_lifecycle(args) -> int:
    """Apply one validated actor credential lifecycle transition."""
    eng = ctx.require(args.engagement)
    action = args.action
    with acquire(eng.root):
        p = _actor_path(eng, args.actor)
        if not p.exists():
            die(f"actor {args.actor!r} not found", code=1)
        data = _read_actor(p)
        legacy_state = data.get("credential_state")
        state = _state(data)
        # Persist the compact vocabulary on the next successful lifecycle write.
        data["credential_state"] = state
        if legacy_state == "password-change-in-progress":
            # That legacy state was entered only after independent verification.
            data.setdefault("lease_has_verified_password", True)
        task = args.task

        if action == "reserve":
            if state != "available":
                die(f"cannot reserve actor {args.actor!r}: credential_state={state}", code=3)
            if _read_leases(data):
                die(_write_conflict_message(data, args.actor), code=3)
            data["credential_state"] = "leased"
            data["active_task"] = task
            data["active_auth_action"] = args.auth_action
            _record_auth_impact(data, task, args.auth_action, "reserved")
        elif action == "password-verified":
            if state != "leased":
                die(f"cannot record verified password: credential_state={state}", code=3)
            _require_actor_task(data, task, "record verified password")
            data["password"] = _lifecycle_password(args)
            data["last_login_verified_at"] = now_isoZ()
            data["lease_has_verified_password"] = True
            _record_auth_impact(data, task, data.get("active_auth_action", "password-change"),
                                "new-password-verified")
        elif action == "handover-required":
            if state != "leased" or not data.get("lease_has_verified_password"):
                die(f"cannot require handover: credential_state={state}; a verified password is required", code=3)
            _require_actor_task(data, task, "require handover")
            data["credential_state"] = "handover-required"
            _record_auth_impact(data, task, data.get("active_auth_action", "password-change"),
                                "original-password-restore-failed", args.reason)
            data.pop("active_task", None)
            data.pop("active_auth_action", None)
            data.pop("lease_has_verified_password", None)
        elif action in {"mark-locked", "mark-unknown"}:
            if state != "leased":
                die(f"cannot mark actor {action.removeprefix('mark-')}: credential_state={state}", code=3)
            _require_actor_task(data, task, action)
            data["credential_state"] = action.removeprefix("mark-")
            _record_auth_impact(data, task, data.get("active_auth_action", "auth-impact"),
                                data["credential_state"], args.reason)
            data.pop("active_task", None)
            data.pop("active_auth_action", None)
            data.pop("lease_has_verified_password", None)
        elif action == "release":
            if state != "leased":
                die(f"cannot release actor: credential_state={state}", code=3)
            _require_actor_task(data, task, "release")
            data["credential_state"] = "available"
            _record_auth_impact(data, task, data.get("active_auth_action", "auth-impact"), "released")
            data.pop("active_task", None)
            data.pop("active_auth_action", None)
            data.pop("lease_has_verified_password", None)
        else:
            die(f"unknown auth lifecycle action {action!r}", code=2)

        _write_actor(p, data)
        append_event(eng.events_jsonl, verb="auth_lifecycle", actor=args.actor,
                     task=task, action=action, credential_state=data["credential_state"])
        append_log(eng.log_md, "auth lifecycle",
                   f"actor {args.actor}; task {task}; action {action}; state {data['credential_state']}", body="")
    print(f"actor {args.actor!r}: credential_state={data['credential_state']}")
    return 0


def cmd_auth_read_lease(args) -> int:
    """Acquire or precisely reap a shared authenticated-read lease."""
    eng = ctx.require(args.engagement)
    action = args.action
    with acquire(eng.root):
        p = _actor_path(eng, args.actor)
        if not p.exists():
            die(f"actor {args.actor!r} not found", code=1)
        data = _read_actor(p)
        state = _state(data)
        data["credential_state"] = state
        leases = _read_leases(data)
        task = args.task

        if action == "read-acquire":
            _require_pending_task(eng, task)
            if args.auth_action != "authenticated-read":
                die("read-acquire --action must be authenticated-read", code=2)
            draft_dir = Path(args.draft_dir).resolve()
            drafts_root = (eng.root / ".drafts").resolve()
            if not draft_dir.is_dir() or drafts_root not in draft_dir.parents:
                die(
                    "--draft-dir must be an existing directory under this engagement's .drafts/",
                    code=2,
                )
            handoff = draft_dir / "handoff.md"
            if not handoff.exists():
                die("read-acquire requires draft_dir/handoff.md with the assigned task", code=2)
            handoff_fm = parse_frontmatter(split_frontmatter(
                handoff.read_text(encoding="utf-8")
            )[0])
            if handoff_fm.get("task") != task:
                die(
                    f"read-acquire draft handoff task must be {task!r}, got "
                    f"{handoff_fm.get('task')!r}",
                    code=2,
                )
            if state != "available":
                die(
                    f"cannot acquire read lease for actor {args.actor!r}: "
                    f"credential_state={state}",
                    code=3,
                )
            if task in leases:
                die(f"task {task!r} already holds a read lease for actor {args.actor!r}", code=3)
            leases[task] = {
                "action": args.auth_action,
                "acquired_at": now_isoZ(),
                "draft_dir": str(draft_dir),
            }
            data["read_leases"] = leases
            outcome = "acquired"
        else:
            die(f"unknown auth read lease action {action!r}", code=2)

        _write_actor(p, data)
        append_event(
            eng.events_jsonl,
            verb="auth_read_lease",
            actor=args.actor,
            task=task,
            action=action,
            auth_action=getattr(args, "auth_action", None),
            draft_dir=(str(Path(args.draft_dir).resolve()) if action == "read-acquire" else None),
            reason=getattr(args, "reason", None),
            outcome=outcome,
        )
        append_log(
            eng.log_md,
            "auth read lease",
            f"actor {args.actor}; task {task}; action {action}; outcome {outcome}",
            body="",
        )
    print(f"actor {args.actor!r}: read lease {outcome} for task {task!r}")
    return 0


def cmd_auth_captured_add(args) -> int:
    """Move a target-side captured credential plaintext into auth/captured/,
    keyed to its CRED-N entity (framework-host §12). Plaintext lives only here;
    wiki/creds.md holds a pointer + hash."""
    eng = ctx.require(args.engagement)
    src = Path(args.file)
    if not src.exists():
        die(f"--file {args.file!r} not found", code=2)
    cred_id = args.cred_id
    secret = src.read_text(encoding="utf-8", errors="replace")
    with acquire(eng.root):
        cap_dir = eng.auth_dir / "captured"
        cap_dir.mkdir(parents=True, exist_ok=True)
        rec = {
            "cred_id": cred_id,
            "captured_at": now_isoZ(),
            "source_file": str(src),
            "secret": secret,
        }
        if getattr(args, "note", None):
            rec["note"] = args.note
        _write_actor(cap_dir / f"{cred_id}.json", rec)
        append_event(eng.events_jsonl, verb="auth_captured", cred_id=cred_id)
        append_log(eng.log_md, "auth captured", f"{cred_id} ← {src.name}", body="")
    print(f"stored captured plaintext for {cred_id} in auth/captured/")
    return 0


def cmd_auth_session(args) -> int:
    eng = ctx.require(args.engagement)
    headers: Dict[str, str] = {}
    for h in (args.header or []):
        if ":" not in h:
            die(f"--header must be 'Key: Value' (got {h!r})", code=2)
        k, _, v = h.partition(":")
        headers[k.strip()] = v.strip()
    sess = {
        "captured_at": now_isoZ(),
        "cookie": args.cookie,
        "bearer": args.bearer,
        "headers": headers,
    }
    with acquire(eng.root):
        p = _actor_path(eng, args.actor)
        data = _read_actor(p)
        # newest first: most recent session is sessions[0]
        data.setdefault("sessions", []).insert(0, sess)
        data.setdefault("credential_state", "available")
        _write_actor(p, data)
        append_event(eng.events_jsonl, verb="auth_session", actor=args.actor)
        append_log(eng.log_md, "auth session", f"actor {args.actor}", body="captured")
    print(f"appended session for actor {args.actor!r}")
    return 0


def _annotate(data: Dict[str, Any]) -> Dict[str, Any]:
    """Tag multi-session actors with a reminder so JSON consumers pick the
    newest. Sessions are newest-first, so sessions[0] is the latest."""
    if len(data.get("sessions") or []) > 1:
        data["sessions_note"] = "newest-first; sessions[0] is the latest — prefer it"
    return data


def cmd_auth_show(args) -> int:
    eng = ctx.require(args.engagement)
    if args.actor:
        p = _actor_path(eng, args.actor)
        if not p.exists():
            die(f"actor {args.actor!r} not found", code=1)
        data = _read_actor(p)
        if getattr(args, "json", False):
            print(json.dumps(_annotate(data), indent=2, ensure_ascii=False))
        else:
            _print_actor(data)
        return 0
    actors: List[Dict[str, Any]] = []
    for p in sorted(eng.auth_dir.glob("*.json")):
        actors.append(_read_actor(p))
    if getattr(args, "json", False):
        print(json.dumps([_annotate(d) for d in actors], indent=2, ensure_ascii=False))
        return 0
    if not actors:
        print("(no actors recorded)")
        return 0
    for d in actors:
        _print_actor(d)
        print()
    return 0


def _print_actor(data: Dict[str, Any]) -> None:
    print(f"actor: {data.get('actor')}")
    if data.get("kind"):
        print(f"  kind: {data['kind']}")
    print(f"  credential_state: {_state(data)}")
    if data.get("active_task"):
        print(f"  active_task: {data['active_task']}")
    readers = _read_leases(data)
    if readers:
        print("  read_leases:")
        for task, record in sorted(readers.items()):
            print(f"    {task}: {record.get('action', 'authenticated-read')}")
    if data.get("last_login_verified_at"):
        print(f"  last_login_verified_at: {data['last_login_verified_at']}")
    if data.get("key_file"):
        print(f"  key_file: {data['key_file']}")
    if data.get("token"):
        print("  token: <set>")
    if "user" in data:
        print(f"  user: {data['user']}")
    if "password" in data:
        pw = data["password"]
        masked = (pw[0] + "*" * max(0, len(pw) - 1)) if pw else ""
        print(f"  password: {masked}")
    if data.get("email"):
        print(f"  email: {data['email']}")
    if data.get("mobile"):
        print(f"  mobile: {data['mobile']}")
    if data.get("note"):
        print(f"  note: {data['note']}")
    sessions = data.get("sessions") or []
    print(f"  sessions: {len(sessions)}")
    if sessions:
        last = sessions[0]  # newest first
        print(f"    latest: {last.get('captured_at')}")
        if last.get("cookie"):
            print(f"      cookie: <set, len={len(last['cookie'])}>")
        if last.get("bearer"):
            print(f"      bearer: <set, len={len(last['bearer'])}>")
        for k, v in (last.get("headers") or {}).items():
            print(f"      header {k}: <set, len={len(str(v))}>")
        if len(sessions) > 1:
            print("    note: sessions are newest-first; prefer the latest (above).")
