"""kb pivot — shared, worker-writable store of reusable operational artifacts.

Unlike the rest of the kb tree, ANY worker may add / reuse here. It holds runnable
capability, not knowledge entities and not immutable deliverables:

  pivot/
  ├── index.jsonl        append-only registry (source of truth; latest-per-name wins)
  ├── index.md           human table, regenerated from index.jsonl on every write
  ├── implant/           C2 pivot deploy records + re-establish scripts
  ├── transport/         request crypto / sign / encrypt-decrypt scripts (runnable)
  └── exploit/           working RCE / SSRF / SSTI / pivot POCs (re-runnable)

Admission is deliberately narrow (see the required CLI fields): pivot holds a
RUNNABLE artifact that WORKED against THIS engagement's target and that another
worker would re-run to save real work. Notes, observations, half-working attempts,
generic payloads, and scanner output do NOT belong here — they live in wiki NOTE /
plan / record / raw.

Subcommands:
  add   — register an artifact: copy the file into pivot/<kind>/, append a record
  list  — derive-on-read discovery (latest state per name); --kind / --json filters
  show  — one artifact's metadata + path, so a worker can cat / run it
  set   — append a status / note update for an existing artifact

The registry is append-only under the engagement lock; `set` appends a new record
and reads fold to the latest per name, so concurrent workers never clobber state.
Credential redline still applies: scripts reference `auth/` (via `needs`), never
hardcode captured plaintext.
"""
from __future__ import annotations

import json
import re
import shutil
from pathlib import Path
from typing import Dict, List, Optional

from .. import ctx, git_helper
from ..lock import acquire
from ..log import append_event, append_log
from ..util import die, now_isoZ

KINDS = ("implant", "transport", "exploit")
STATUSES = ("verified", "unverified", "stale", "blocked")


def _index_jsonl(eng) -> Path:
    return eng.pivot_dir / "index.jsonl"


def _index_md(eng) -> Path:
    return eng.pivot_dir / "index.md"


def _slugify(s: str) -> str:
    s = re.sub(r"[^a-zA-Z0-9._-]+", "-", (s or "").strip().lower())
    return s.strip("-.") or "artifact"


def _read_records(eng) -> List[dict]:
    path = _index_jsonl(eng)
    if not path.exists():
        return []
    out: List[dict] = []
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            out.append(json.loads(line))
        except json.JSONDecodeError:
            continue
    return out


def _current(eng) -> Dict[str, dict]:
    """Fold the append-only log to the latest record per name; drop tombstones."""
    cur: Dict[str, dict] = {}
    for r in _read_records(eng):
        name = r.get("name")
        if not name:
            continue
        cur[name] = r
    return {n: r for n, r in cur.items() if not r.get("deleted")}


def _append_record(eng, record: dict) -> None:
    eng.pivot_dir.mkdir(parents=True, exist_ok=True)
    with _index_jsonl(eng).open("a", encoding="utf-8") as f:
        f.write(json.dumps(record, ensure_ascii=False) + "\n")


def _regen_index_md(eng) -> None:
    cur = _current(eng)
    lines = [
        "# Pivot — reusable operational artifacts",
        "",
        "_Auto-generated from `pivot/index.jsonl` by `bin/kb pivot`. Any worker can "
        "`pivot add` / `pivot list` / `pivot show` / `pivot set`._",
        "",
    ]
    for kind in KINDS:
        rows = sorted((r for r in cur.values() if r.get("kind") == kind),
                      key=lambda r: r.get("name", ""))
        lines.append(f"## {kind}")
        if not rows:
            lines.append("- _(none)_")
        for r in rows:
            bits = [f"**{r.get('name')}**", f"[{r.get('status', 'unverified')}]"]
            if r.get("target"):
                bits.append(f"target={r['target']}")
            bits.append(f"`{r.get('path', '')}`")
            if r.get("run"):
                bits.append(f"run: `{r['run']}`")
            if r.get("needs"):
                bits.append(f"needs: {r['needs']}")
            if r.get("desc"):
                bits.append(f"— {r['desc']}")
            lines.append("- " + " · ".join(bits))
        lines.append("")
    _index_md(eng).write_text("\n".join(lines), encoding="utf-8")


def cmd_pivot_add(args) -> int:
    eng = ctx.require(args.engagement)
    kind = args.kind
    if kind not in KINDS:
        die(f"--kind must be one of {KINDS} (got {kind!r})", code=2)
    src = Path(args.file)
    if not src.is_file():
        die(f"--file not found: {args.file}", code=1)
    status = getattr(args, "status", None) or "unverified"
    if status not in STATUSES:
        die(f"--status must be one of {STATUSES} (got {status!r})", code=2)

    name = _slugify(args.name) if getattr(args, "name", None) else _slugify(src.stem)
    ext = src.suffix
    rel = f"pivot/{kind}/{name}{ext}"
    dest = eng.root / rel

    with acquire(eng.root):
        cur = _current(eng)
        if name in cur and not getattr(args, "force", False):
            die(f"pivot artifact {name!r} already exists ({cur[name].get('path')}). "
                f"Use --force to overwrite, `pivot set` to update status, or pick a new --name.",
                code=1)
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dest)
        # Scripts / implants are meant to run — keep the executable bit.
        if ext in (".sh", ".py", ".bin", "") or kind == "implant":
            try:
                dest.chmod(dest.stat().st_mode | 0o111)
            except OSError:
                pass

        record = {
            "op": "add",
            "name": name,
            "kind": kind,
            "path": rel,
            "target": getattr(args, "target", None) or None,
            "run": getattr(args, "run", None) or None,
            "desc": getattr(args, "desc", None) or None,
            "status": status,
            "needs": getattr(args, "needs", None) or None,
            "task": getattr(args, "task", None) or None,
            "ts": now_isoZ(),
        }
        _append_record(eng, record)
        _regen_index_md(eng)
        append_log(eng.log_md, "pivot", f"add {kind}/{name}",
                   body=f"- `{rel}` [{status}]" + (f" target={record['target']}" if record["target"] else ""))
        append_event(eng.events_jsonl, verb="pivot", op="add", name=name, kind=kind, path=rel)
        git_helper.commit(eng.root, f"pivot: add {kind}/{name}", f"{rel} [{status}]")

    if getattr(args, "json", False):
        print(json.dumps(record, ensure_ascii=False, indent=2))
        return 0
    print(f"added {kind}/{name} -> {rel} [{status}]")
    return 0


def cmd_pivot_list(args) -> int:
    eng = ctx.require(args.engagement)
    cur = _current(eng)
    kind_filter = getattr(args, "kind", None)
    rows = [r for r in cur.values() if not kind_filter or r.get("kind") == kind_filter]
    rows.sort(key=lambda r: (r.get("kind", ""), r.get("name", "")))

    if getattr(args, "json", False):
        print(json.dumps(rows, ensure_ascii=False, indent=2))
        return 0
    if not rows:
        print("(pivot empty)" if not kind_filter else f"(no {kind_filter} artifacts)")
        return 0
    for r in rows:
        head = f"{r.get('kind', '?'):<9} {r.get('name', ''):<24} [{r.get('status', 'unverified')}]"
        if r.get("target"):
            head += f"  target={r['target']}"
        print(head)
        print(f"    path: {r.get('path', '')}")
        if r.get("run"):
            print(f"    run:  {r['run']}")
        if r.get("needs"):
            print(f"    needs: {r['needs']}")
        if r.get("desc"):
            print(f"    {r['desc']}")
    return 0


def cmd_pivot_show(args) -> int:
    eng = ctx.require(args.engagement)
    cur = _current(eng)
    r = cur.get(args.name)
    if not r:
        die(f"pivot artifact {args.name!r} not found (see `bin/kb pivot list`)", code=1)
    if getattr(args, "json", False):
        print(json.dumps(r, ensure_ascii=False, indent=2))
        return 0
    for k in ("name", "kind", "status", "target", "path", "run", "needs", "desc", "task", "ts"):
        if r.get(k) is not None:
            print(f"{k}: {r[k]}")
    return 0


def cmd_pivot_set(args) -> int:
    eng = ctx.require(args.engagement)
    status = getattr(args, "status", None)
    note = getattr(args, "note", None)
    if not status and not note:
        die("provide --status and/or --note", code=2)
    if status and status not in STATUSES:
        die(f"--status must be one of {STATUSES} (got {status!r})", code=2)

    with acquire(eng.root):
        cur = _current(eng)
        r = cur.get(args.name)
        if not r:
            die(f"pivot artifact {args.name!r} not found (see `bin/kb pivot list`)", code=1)
        updated = dict(r)
        updated["op"] = "set"
        if status:
            updated["status"] = status
        if note:
            updated["desc"] = note
        updated["ts"] = now_isoZ()
        _append_record(eng, updated)
        _regen_index_md(eng)
        append_log(eng.log_md, "pivot", f"set {r.get('kind')}/{args.name}",
                   body=f"- status={updated.get('status')}" + (f" note={note}" if note else ""))
        append_event(eng.events_jsonl, verb="pivot", op="set", name=args.name,
                     status=updated.get("status"))
        git_helper.commit(eng.root, f"pivot: set {args.name}", f"status={updated.get('status')}")

    print(f"updated {args.name} -> status={updated.get('status')}")
    return 0
