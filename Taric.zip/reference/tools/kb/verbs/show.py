"""kb show <id> — print entity body + frontmatter + inbound refs."""
from __future__ import annotations

import json
from typing import Optional

from .. import ctx
from ..index import Index, build_index, inbound_refs
from ..parser import ENTITY_TYPES
from ..util import die


def _find_entity(idx: Index, id_: str):
    if id_ in idx.by_id:
        return idx.by_id[id_], "real"
    if id_ in idx.placeholders:
        return idx.placeholders[id_], "placeholder"
    # Check archived entities by scanning files under plan/archive/
    for f in idx.files:
        if not f.rel_path.startswith("plan/archive/"):
            continue
        for e in f.entities:
            if e.id == id_:
                return e, "archived"
    return None, None


def cmd_show(args) -> int:
    eng = ctx.require(args.engagement)
    idx = build_index(eng)  # built ONCE; multiple ids reuse it (one round-trip, N entities)
    ids = args.id if isinstance(args.id, list) else [args.id]
    as_json = getattr(args, "json", False)
    rc = 0
    for n, target in enumerate(ids):
        ent, source = _find_entity(idx, target)
        # Topic-page lookup if not entity:
        topic = None
        if ent is None:
            topic = idx.topics.get(target)
        if ent is None and topic is None:
            if len(ids) == 1:
                die(f"not found: {target}", code=1)  # unchanged single-id behavior
            print(f"not found: {target}")            # batch: report the miss, keep going
            rc = 1
            continue
        if len(ids) > 1 and not as_json and n:
            print("\n" + "=" * 72 + "\n")             # separator between entities in a batch
        if as_json:
            _show_json(eng, idx, ent, topic, source)
        elif topic is not None:
            _show_topic(eng, idx, topic)
        else:
            _show_entity(eng, idx, ent, source)
    return rc


def _show_topic(eng, idx, f) -> int:
    print(f.raw)
    print(f"\nsource: {f.rel_path}\n")
    refs = inbound_refs(idx, f.rel_path)  # not strictly the right key — recompute by slug below
    # Inbound: any wikilink whose target == slug.
    slug = f.rel_path[len("wiki/"):-len(".md")] if f.rel_path.startswith("wiki/") else f.rel_path
    rows = []
    from ..parser import find_wikilinks
    for ff in idx.files:
        for ref in find_wikilinks(ff.raw):
            if ref.target == slug:
                rows.append({"id": "(file)", "file": ff.rel_path, "via": "body"})
    if rows:
        print("## Referenced by")
        for r in rows:
            print(f"  {r['id']}  {r['file']}  {r['via']}")
    return 0


def _show_entity(eng, idx, ent, source) -> int:
    print(ent.raw_block.rstrip())
    src = str(ent.source_file.relative_to(eng.root)).replace("\\", "/") if ent.source_file else ""
    print(f"\nsource: {src}" + (f"  ({source})" if source != "real" else ""))
    refs = inbound_refs(idx, ent.id)
    if refs:
        print("\n## Referenced by")
        id_w = max(len(r["id"]) for r in refs)
        for r in refs:
            print(f"  {r['id']:<{id_w}}  {r['file']}  {r['via']}")
    return 0


def _show_json(eng, idx, ent, topic, source) -> int:
    if topic is not None:
        out = {
            "kind": "TOPIC",
            "slug": topic.rel_path[len("wiki/"):-len(".md")] if topic.rel_path.startswith("wiki/") else topic.rel_path,
            "file": topic.rel_path,
            "frontmatter": topic.frontmatter,
            "body": topic.body,
        }
        print(json.dumps(out, indent=2, ensure_ascii=False))
        return 0
    out = {
        "id": ent.id,
        "type": ent.type,
        "is_placeholder": ent.is_placeholder,
        "title": ent.title,
        "bullets": ent.bullets,
        "body": ent.body,
        "file": str(ent.source_file.relative_to(eng.root)).replace("\\", "/") if ent.source_file else None,
        "source": source,
        "referenced_by": inbound_refs(idx, ent.id),
    }
    print(json.dumps(out, indent=2, ensure_ascii=False))
    return 0
