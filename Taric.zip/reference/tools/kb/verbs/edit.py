"""kb status set <id> <value>
   kb bullet append <id> <key> <wikilink> [<wikilink> ...]
   kb bullet set    <id> <key> <value>

Per-entity edit primitives. Modify a single entity's bullet block in place.
No log entry written — these are file-edit shortcuts that compose with the
next `kb commit`. The lock is acquired so concurrent writers don't race.

`bullet append` is wikilink-list semantics: targets are validated as TYPE-N,
deduplicated, and normalized to `[[X]], [[Y]]` form. Use for `evidence`,
`promoted_to`, `targets`, `related`, etc.

`bullet set` writes any scalar value verbatim. Use for `coverage-skip`,
`coverage-block`, `retire-reason`, or any free-form bullet that is not a
wikilink list. Overwrites the existing value.

Status values are validated against schema.STATUS_VALUES when the entity
type has an enum; entities with no enum (e.g. NOTE) accept any string.

`bullet append` / `bullet set` are heading-bullet only. `status set` also
supports FINDING — a frontmatter-id entity (declared in file frontmatter, not
via a heading) whose type carries a status enum — by patching the `status:`
frontmatter field in place (the user-facing finding-triage command, e.g.
`kb status set FINDING-003 false-positive`). Frontmatter-id entities WITHOUT a
status enum (EVIDENCE) are still rejected, since they have no status to flip.
"""
from __future__ import annotations

import json

from .. import ctx
from ..index import build_index
from ..lock import acquire
from ..parser import (
    parse_frontmatter,
    parse_id,
    serialize_frontmatter,
    split_frontmatter,
)
from ..schema import STATUS_VALUES
from ..util import die, today_iso
from .promote import _append_wikilink, _update_entity_bullets


# ───────────────────────── kb status set ─────────────────────────

def cmd_status_set(args) -> int:
    eng = ctx.require(args.engagement)
    entity_id = args.id
    value = args.value

    parsed = parse_id(entity_id)
    if not parsed:
        die(f"invalid entity id: {entity_id!r}", code=2)
    entity_type, _, is_placeholder = parsed
    if is_placeholder:
        die(
            f"{entity_id} is a placeholder ID. run `kb commit` first to allocate "
            f"a real ID, then flip status.",
            code=2,
        )

    enum = STATUS_VALUES.get(entity_type, [])
    if enum and value not in enum:
        die(
            f"invalid status {value!r} for {entity_type}. "
            f"allowed: {enum}",
            code=2,
        )

    with acquire(eng.root):
        idx = build_index(eng)
        ent = _resolve_entity(idx, entity_id)
        if not ent:
            die(f"entity {entity_id} not found", code=1)
        if ent.heading_line == 0 or not ent.source_file:
            # Frontmatter-id entity (FINDING/EVIDENCE). Only entities whose type
            # declares a status enum (FINDING) carry a triage status; patch the
            # `status:` frontmatter field directly. EVIDENCE has no enum → reject.
            if not enum:
                die(
                    f"{entity_id} is a frontmatter-id entity with no status field. "
                    f"`kb status set` supports heading-bullet entities and FINDING.",
                    code=1,
                )
            _patch_frontmatter_status(ent.source_file, value)
        else:
            _update_entity_bullets(ent.source_file, entity_id, {"status": value})

        # Unlike bullet append/set (which compose with a following `kb commit`),
        # `status set` is a standalone user command — notably finding triage,
        # which is not followed by a commit. Regenerate the `.api/*.json` export
        # so the UI-facing views (findings.json + findings/<id>.json) reflect the
        # new status immediately. Best-effort like the commit hook: never fails
        # the edit, never blocked by the target gate (auto_export swallows both).
        from .export_ import auto_export
        auto_export(eng)

    if getattr(args, "json", False):
        print(json.dumps({"id": entity_id, "status": value}, ensure_ascii=False))
        return 0
    print(f"{entity_id}  status: {value}")
    return 0


# ───────────────────────── kb bullet append ─────────────────────────

def cmd_bullet_append(args) -> int:
    eng = ctx.require(args.engagement)
    entity_id = args.id
    key = args.key
    # `wikilink` is nargs="+" → always a list. Also tolerate a single string
    # in case a caller invokes the function directly with a scalar.
    raw = args.wikilink
    if isinstance(raw, str):
        raw = [raw]

    # Allow callers to pass comma-separated forms inside one arg too
    # (e.g. "HYPOTHESIS-013, HYPOTHESIS-014"). Split on top-level commas
    # so each target is validated individually.
    targets: list = []
    for item in raw:
        for part in str(item).split(","):
            p = part.strip()
            if p:
                targets.append(p)
    if not targets:
        die("no wikilink targets given", code=2)

    parsed = parse_id(entity_id)
    if not parsed:
        die(f"invalid entity id: {entity_id!r}", code=2)
    if parsed[2]:
        die(
            f"{entity_id} is a placeholder ID. run `kb commit` first.",
            code=2,
        )

    inners: list = []
    for t in targets:
        inner = t
        if inner.startswith("[[") and inner.endswith("]]"):
            inner = inner[2:-2]
        if not parse_id(inner):
            die(
                f"invalid wikilink target: {t!r} — expected TYPE-N or [[TYPE-N]]",
                code=2,
            )
        inners.append(inner)
    # Note: we do NOT validate the target exists in the index. Placeholder
    # targets (e.g. EVIDENCE-1 freshly written) are common and legitimate;
    # `kb commit` will renumber and resolve them.

    with acquire(eng.root):
        idx = build_index(eng)
        ent = _resolve_entity(idx, entity_id)
        if not ent:
            die(f"entity {entity_id} not found", code=1)
        if ent.heading_line == 0 or not ent.source_file:
            die(
                f"{entity_id} is a frontmatter-id entity. "
                f"`kb bullet append` only supports heading-bullet entities.",
                code=1,
            )
        new_value = ent.bullets.get(key)
        for inner in inners:
            new_value = _append_wikilink(new_value, inner)
        _update_entity_bullets(ent.source_file, entity_id, {key: new_value})

    if getattr(args, "json", False):
        print(json.dumps(
            {"id": entity_id, "key": key, "value": new_value},
            ensure_ascii=False,
        ))
        return 0
    print(f"{entity_id}  {key}: {new_value}")
    return 0


# ───────────────────────── kb bullet set ─────────────────────────

def cmd_bullet_set(args) -> int:
    """Write a scalar bullet verbatim. No wikilink validation.

    Use for bullets whose value is structured but not a wikilink list, e.g.
    `coverage-skip: A02 (static JS bundle, no crypto to test)` or
    `retire-reason: superseded by HYPOTHESIS-014`.
    """
    eng = ctx.require(args.engagement)
    entity_id = args.id
    key = args.key
    value = args.value

    parsed = parse_id(entity_id)
    if not parsed:
        die(f"invalid entity id: {entity_id!r}", code=2)
    if parsed[2]:
        die(
            f"{entity_id} is a placeholder ID. run `kb commit` first.",
            code=2,
        )

    with acquire(eng.root):
        idx = build_index(eng)
        ent = _resolve_entity(idx, entity_id)
        if not ent:
            die(f"entity {entity_id} not found", code=1)
        if ent.heading_line == 0 or not ent.source_file:
            die(
                f"{entity_id} is a frontmatter-id entity. "
                f"`kb bullet set` only supports heading-bullet entities.",
                code=1,
            )
        _update_entity_bullets(ent.source_file, entity_id, {key: value})

    if getattr(args, "json", False):
        print(json.dumps(
            {"id": entity_id, "key": key, "value": value},
            ensure_ascii=False,
        ))
        return 0
    print(f"{entity_id}  {key}: {value}")
    return 0


# ───────────────────────── helpers ─────────────────────────

def _patch_frontmatter_status(source_file, value: str) -> None:
    """Set the `status:` field in a frontmatter-id entity's YAML header (FINDING),
    stamping `last_updated`. Mirrors draft.py's `_patch_frontmatter_field` but
    kept local so `kb status set` has no dependency on the draft integration path.
    """
    text = source_file.read_text(encoding="utf-8")
    fm_text, body = split_frontmatter(text)
    fm = parse_frontmatter(fm_text) if fm_text is not None else {}
    fm["status"] = value
    fm["last_updated"] = today_iso()
    tmp = source_file.with_suffix(source_file.suffix + ".tmp")
    tmp.write_text(serialize_frontmatter(fm) + body, encoding="utf-8")
    tmp.replace(source_file)


def _resolve_entity(idx, entity_id):
    """Look up an entity by real ID, including in archived files."""
    ent = idx.by_id.get(entity_id)
    if ent:
        return ent
    for f in idx.files:
        if f.rel_path.startswith("plan/archive/"):
            for e in f.entities:
                if e.id == entity_id:
                    return e
    return None
