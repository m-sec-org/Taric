"""Prose for `kb schema` — the agent's just-in-time entity-creation field manual.

This carries the human prose the field manual serves (field meanings, examples,
conventions, gotchas). The STRUCTURAL truth (required bullets, status values,
required frontmatter) is NOT duplicated here — the `schema` verb renders it live
from `schema.py`, so the two can never drift.

Topics are markdown strings keyed by slug. `COMMON` applies to every profile;
`WEB` / `HOST` add profile-specific topics (and may override a COMMON topic).
The `schema` verb merges COMMON with the active profile's map, renders the
structural contract from `schema.py`, then appends the topic's prose.
"""
from __future__ import annotations

# ─────────────────────────────────────────────────────────────────────────
# COMMON — entity contracts and conventions shared by web + host.
# ─────────────────────────────────────────────────────────────────────────

COMMON = {

"reading": """\
# Reading / querying the kb

Prefer these over grepping raw markdown — fast, ID-anchored, and they don't dump
whole files into context. grep stays valid for what the CLI can't express.

- `bin/kb list <type> --filter status=<s>` — entities by status / field; `--filter key=~<regex>`, repeatable.
- `bin/kb show ID1 ID2 …` — one or more entities in a single call.
- `bin/kb find <query>` — fuzzy match over ids / titles / slugs.
- `bin/kb grep <regex> [--type <T>]` — content search across entity bodies; prints `ID  file:line  matched-line`.
- `bin/kb state` — counts + the `## Engagement` facts (Assessment mode / OTP-assist / Auth posture).
- `bin/kb coverage` — per-entity gaps + `OPEN FOLLOW-UP LEADS` (open `deepen-lead` NOTEs).
- `bin/kb schema [<topic>]` — this manual: how to shape any entity (run with no arg for the index).
""",

"coverage": """\
# Reading the coverage report — `bin/kb coverage`

`bin/kb coverage` opens with a **`GAP OVERVIEW`** worklist: per-entity gaps grouped
by `workflow` (each group shows total / resolved / gap **counts** + a
`--focus <workflow>` drill-in hint — gapped ids are NOT inlined, they live in the
focused view), then one line each for universal / scenario / conditional /
semantic / orphans / leads. That overview plus `SUMMARY` / `EXIT GATE` is the
**whole default output — the per-entity body is suppressed unless you `--focus`**
(it scales with #endpoints). Read the overview first, pick one slice, drill in.

`--focus <slice>` (repeatable) prints only that slice's detailed section: a
`workflow` name → just that workflow's per-entity rows; or a section keyword
`universal | scenario | conditional | semantic | orphans | leads | entity`.
`GAP OVERVIEW`, `SUMMARY`, and `EXIT GATE` always render in full and stay global —
`--focus` filters the body only, never the gate verdict or the exit code, so a
filtered view can't cause a premature termination. `--focus` is human-view only;
`--json` ignores it and returns the complete payload. Unknown slice → exit 2 and
the valid slices for the engagement. (Host groups by asset type —
`HOST | SERVICE | WEBAPP | DOMAIN` — and has no `semantic` slice.)

`--check` sets the exit code from `summary.exit_gate` (0 = open, non-zero =
blocked), for scripting the termination gate.

## `--json` schema (ignores `--focus`; returns the whole payload)

```jsonc
{
  // compact worklist, mirrors the human GAP OVERVIEW (present regardless of --focus):
  "gap_overview": {
    "workflows": [{ "name": "user-management", "total": 12, "resolved": 8,
                    "gap": 4, "gap_ids": ["ENDPOINT-034", "..."] }],
    "sections": {
      "universal":   { "total": 9, "gap": 2, "gap_labels": ["#4 cors", "#9 poc-scan"] },
      "scenario":    { "total": 3, "gap": 1, "gap_labels": ["login"] },
      "conditional": { "total": 0, "gap": 0, "gap_labels": [] },
      "semantic":    { "applicable": true, "gate": "blocked", "blocking": 3 },  // web only
      "orphans":     { "count": 0, "ids": [] },
      "leads":       { "count": 1, "ids": ["NOTE-033"] }
    }
  },
  "per_entity": [                          // flat list of cells — NOT a dict
    {
      "state": "gap" | "hyp" | "hyp+" | "tested" | "finding" | "skip" | "blocked",
      "entity_id": "ENDPOINT-007",
      "entity_type": "ENDPOINT" | "WORKFLOW" | "PAGE" | "BUNDLE",  // host: HOST|SERVICE|WEBAPP|DOMAIN
      "entity_title": "admin user lookup",
      "method": "GET" | null,              // ENDPOINT only
      "path":   "/api/admin/users/{id}" | null,
      "workflow": "user-management" | null,
      "owasp": "A01" | "..." | "A10",      // field is `owasp`, not `category`/`cat`
      "required": true | false,            // false ⇒ row exists only for a hyp/skip/block
      "applicable_tags": ["idor", "bola"],
      "skip_reason":  "...",               // state == "skip" only
      "block_kind":   "needs-user-input" | "technical" | null,   // state == "blocked" only
      "block_reason": "..."
    }
  ],
  "universal":   [{ "id": 1, "name": "...", "slug": "https-hsts", "owasp": "A05",
                    "state": "gap" | "hyp" | "tested" | "finding",
                    "hypothesis": "HYPOTHESIS-007" | null,
                    "hypothesis_status": "untested" | "..." | null }],
  "conditional": [{ "note_id": "NOTE-007", "feature": "waf",
                    "state": "gap" | "hyp" | "tested" | "finding" | "retired",
                    "hypothesis": "HYPOTHESIS-009" | null, "reason": "..." }],
  "semantic_inventory": [ /* web only; capability-inventory slot rollup */ ],
  // Plan-integrity: untested/testing hypotheses with no task referencing them.
  // These block the gate (can never be probed) — give each a task or close it.
  "orphan_hypotheses": [
    { "id": "HYPOTHESIS-043", "status": "untested" | "testing",
      "title": "...", "file": "plan/hypotheses.md", "line": 337 }
  ],
  "summary": {
    "primary_objective": "login" | null,  // Primary Objective Lock slug; null = full scope
    "per_entity":  { "total": N, "finding": N, "tested": N, "hyp": N,
                     "hyp_plus": N, "skip": N, "blocked": N, "gap": N, "covered": N },
    "universal":   { "total": 8, "covered": N, "gap": N },
    "conditional": { "total": N, "covered": N, "retired": N, "gap": N },
    "orphan_hypotheses": N,                // >0 ⇒ gate blocked
    "exit_gate": "open" | "blocked",       // what `--check` turns into the exit code
    "unresolved_gaps": N,                  // coverage-block gap count (orphans block separately)
    "semantic_inventory_gate": "open" | "blocked" | "not-applicable",  // soft gate (web)
    "blocked_needs_user_input": [
      { "entity_id": "ENDPOINT-007", "owasp": ["A01", "A04"], "reason": "..." }
    ]
  }
}
```

`semantic_inventory_gate` is a SOFT gate for reason's terminal sweep — it does not
change `summary.exit_gate` / the `--check` exit code. `UNPLACED FINDINGS` (a
verified finding neither in a `CHAIN.findings` spine nor `chain_terminal: true`)
and `OPEN CHAIN FRONTIERS` (open `CHAIN.frontier` hops) both block the hard gate.

## Resolving a per-entity gap

An entity's per-entity gap closes when ONE of these holds:

- a HYPOTHESIS targets it — the normal path (plan a probe); OR
- it carries a `coverage-skip: <OWASP-CAT>(<reason>)` bullet — the vuln class is
  structurally inapplicable (no user input / static asset / anonymous by design).
  Set it: `bin/kb bullet set <ENTITY-ID> coverage-skip "A01(no ownership boundary)"`.
  The `(reason)` is REQUIRED — empty → health `unjustified-coverage-skip`; OR
- it carries a `coverage-block: <needs-user-input:|technical:> <reason>` bullet —
  the class applies but is operationally blocked. The prefix is REQUIRED
  (missing → health `coverage-block-without-prefix`); `needs-user-input:` blocks
  surface to the user, `technical:` blocks close the gate on the record.

skip / block are ONLY for genuinely inapplicable / blocked entities — never for
untested-but-testable (that stays a gap until a hypothesis + probe covers it).
""",

"handoff": """\
# HANDOFF — the probe → orchestrator manifest (draft_dir/handoff.md)

Every probe writes ONE handoff.md in its draft_dir; `kb draft commit` validates it
and stamps `committed_at`; the orchestrator then `kb draft integrate`s it. Start
from a skeleton: `bin/kb draft scaffold <draft_dir> handoff`.

Required frontmatter:
- `worker:` — the worker kind (probe)
- `task:` — the TASK-N being resolved
- `verdict:` — verified | refuted | blocked | failed | done
  (`verified` REQUIRES a finding.md in the draft — see below)
`committed_at:` is stamped by `kb draft commit` — leave it blank.
`owner_dispatch_id:` is stamped by `kb draft commit` too (the probe's dispatch id,
captured in the probe's shell so integrate can attribute the finding to it) — leave
it blank.

Body sections (H2; all optional unless noted):
- `## Summary` — 2–3 lines: what you did and the verdict.
- `## Status flips` — one per line `- <ENTITY-ID>: <status>` (REAL ids only, never
  placeholders; status from that type's enum): `- TASK-008: done`,
  `- HYPOTHESIS-012: refuted`.
- `## Bullet appends` — append wikilink(s) to an entity's bullet. Head is exactly
  `<ENTITY-ID> <key>` (a BARE id + a key — do NOT wikilink the id), then `:`, then
  the wikilink targets: `- TASK-008 evidence: [[EVIDENCE-1]], [[EVIDENCE-2]]`.
- `## Follow-up leads` — one lead per line; integrate turns each into a durable
  `deepen-lead:` NOTE + a STATE `## Follow-up leads` queue entry.
- `## STATE.md additions` — H3 sub-headings the orchestrator applies to STATE:
  `### Blockers` / `### Background work` / `### Transport recipes` (probe writes NO
  index.md, and no other STATE sections).
- `## Orchestrator ack` — added by the ORCHESTRATOR at integrate, not by you.

## What `kb draft commit` checks — get it right the first time
- handoff frontmatter has worker / task / verdict; verdict is in the enum.
- Status-flip ids are real (not placeholders) + exist; the status is valid for that type.
- Each EVIDENCE-N.md has the required frontmatter + all five body sections, filled
  (no `(fill in)` / TODO left) — full contract: `bin/kb schema evidence`.
- verdict=verified ⇒ finding.md exists, has Impact / Reproduction / Recommendation
  filled, and cites ≥1 evidence. Admission floor: a cited *confirmed* evidence must
  point (`related_endpoint`) at one of the finding's `related_endpoints`. Full
  contract: `bin/kb schema finding`.
- refuted / blocked / failed need NO finding.md — just the handoff (+ any evidence).
""",

"credential-lifecycle": """\
# Actor credential lifecycle

`auth/<actor>.json` is the only current-credential record. Its `password` field
means the password that most recently completed an independent login. Do not copy
secrets into `STATE.md`, NOTE, or logs. Handoff secret handling follows the selected
runtime's new-credential transfer contract; otherwise reference the actor and auth
record instead of duplicating reusable credentials. Evidence preservation likewise
follows the runtime policy; auth remains the reusable credential fact source, not a
requirement to relocate raw evidence. Records
without `credential_state` / `read_leases` are `available` with no readers.

| State | Meaning |
|---|---|
| `available` | Independently verified current password; may have shared `read_leases`. |
| `leased` | One `TASK-N` holds the exclusive write lease for bounded login / credential-impact work. |
| `handover-required` | A current password was verified but must be handed to the user. |
| `locked` | A defense locked / cooled down the account; do not reuse it. |
| `unknown` | Credential outcome not independently verified; do not disclose a candidate password. |

Local `bin/kb auth show` is unlocked. For a known target-side authenticated read
that cannot change auth availability:
`bin/kb auth read-acquire --actor <actor> --task <TASK-N> --action authenticated-read --draft-dir <assigned-draft>`
— multiple readers may coexist; only that bound draft's integration / `kb draft
fail` reaps its reader. For password mutation, recovery, bad-credential batch,
lockout risk, logout/revocation, or unknown login/auth side effect, take the
exclusive write lease `bin/kb auth reserve --actor <actor> --task <TASK-N> --action <action>`.
A write lease protects password + auth availability only — NOT arbitrary business
writes (file write, CRUD, config, codegen, path traversal). While write-leased,
`password-verified --password-stdin` after each independent login, then finish
with `release` / `handover-required` / `mark-unknown` / `mark-locked`.

TASK optional bullet `auth_access`:

| Value | Meaning | Lease |
|---|---|---|
| *(omit)* | Local `auth show` / no authenticated target request | none |
| `read` | Authenticated read that cannot change password/lockout/session | `read-acquire` on the actor |
| `write` | Password mutation, recovery, binding change, logout-all / token revoke, lockout risk, or unknown login/auth side effect | exclusive `reserve` per affected actor |
| `none` | Authenticated business mutation NOT changing password/lockout/session | no auth lease |

`none` is the negation of read/write, not a fourth class. Do NOT mark `write`
only because the request writes a file, row, config, or generated code.
`affected_actors` is required for `write` (cross-account IDOR includes the victim).
Web planning lists all reader and writer actors in `affected_actors`, with each
actor's access and side effects in existing `actions` / `preconds`; a mixed task
uses `auth_access: write`, but only its writer actors are reserved. Plan the whole
task, including baseline, verification and recovery, before the first request.
These are planning conventions, not an enforced scheduler or new lifecycle states.
""",

"hypothesis": """\
# HYPOTHESIS — a testable vulnerability claim (plan/hypotheses.md)

Declared as a heading entity with a placeholder id (`### HYPOTHESIS-1: …`);
`bin/kb commit` assigns the real id. Reason creates these (via `bin/kb plan add`).

`severity_guess` is the **GB/T 30279-2020 technical severity guess** for
scheduling — NOT a CVSS band. Also carry `gbt_category`, `rating_basis`,
`confidence` when known. CVSS is recorded only on verified findings.

```markdown
### HYPOTHESIS-1: BOLA on admin user lookup
- targets: [[ENDPOINT-7]]              # entity id(s), or the literal `system-wide` (see `schema targets`)
- class: authz-horizontal              # a tag from the class vocab (`schema class`)
- gbt_category: code/authorization/access-control
- severity_guess: high
- rating_basis: 预估访问路径=网络; 触发要求=低; 权限需求=低; 交互条件=不需要; C=严重; I=无; A=无
- confidence: medium
- rationale: path param exposes arbitrary user id; no ownership check observed.
- status: untested
```

## Web logic hypothesis contract (conditional)

For a non-`system-wide` hypothesis whose `class` is `authz-horizontal`,
`authz-vertical`, `idor`, `bola`, `rbac`, `business-logic`, `workflow-bypass`,
or `race-condition`, `bin/kb plan add` REQUIRES these structured bullets (host
hypotheses, non-logic classes, and system-wide sweeps keep the generic schema):

```markdown
- object_type: AsyncExportTask
- object_id_source: admin export task list baseline
- owner_scope: creator-user
- operation: download
- boundary: ownership
- control: selector-swap
- unique_variable: taskId
- verified_if: low-priv receives the admin export file bytes
- refuted_if: same recipe is ownership-filtered or rejected
```

- `object_id_source` must be a legitimate baseline/UI/known-test-data source;
  `enumerate` / `guess` / `range` / `construct` / `predict` are rejected.
- `boundary` and `control` are a strict pair: `ownership → selector-swap`,
  `role → actor-swap`, `state → state-swap`, `trusted-value → value-swap`,
  `invariant → concurrency`. `unique_variable` is the sole changed variable.
- `verified_if` / `refuted_if` describe semantic evidence, not bare HTTP codes.
- Enforced at `plan add` for new hypotheses; does not retroactively block commit.
""",

"task": """\
# TASK — one probe of one hypothesis (plan/tasks.md)

Heading entity, placeholder id; `bin/kb commit` assigns the real id and (via
`bin/kb plan add`) auto-links it to its hypothesis. `skill:` defaults to `probe`.

```markdown
### TASK-1: use user_a token to probe admin user lookup
- hypothesis: [[HYPOTHESIS-1]]
- status: pending
- preconds: user_a session captured; admin session captured
- actions: replay GET /api/admin/users/<admin_id> with user_a token; compare to admin baseline
```

Optional bullets:
- `playbook:` — when the `class` has a Task-generation contract in `playbooks/INDEX.md`.
- `auth_access: read|write|none` + `affected_actors:` — see `schema credential-lifecycle`.
- `serves_chain: [[CHAIN-N]]` — set by deepening so probe carries the chain context.
""",

"finding": """\
# FINDING — a verified vulnerability (record/findings/FINDING-N.md)

A single-file entity: id in frontmatter (must match the filename stem), NOT a
heading bullet. Created by **probe** via `bin/kb draft scaffold … finding` then
`bin/kb draft commit`; the orchestrator merges it with `kb draft integrate`.
`status:` is auto-seeded — never type it.

```yaml
---
id: FINDING-001                  # must match filename stem
type: finding
title: BOLA on admin user lookup
severity: high                   # GB/T 30279-2020: critical|high|medium|low; NOT derived from CVSS
status: to-fix                   # OPTIONAL triage lifecycle, auto-seeded; user-owned
cvss_score: 7.1                  # COMPUTED from cvss_vector (don't hand-edit)
cvss_vector: CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:H/I:L/A:N   # optional score reference
gbt_category: code/authorization/access-control
gbt_technical_severity: high
gbt_composite_severity: high
gbt_rating_basis: 访问路径=网络; 触发要求=低; 权限需求=低; 交互条件=不需要; C=严重; I=一般; A=无
related_endpoints: [ENDPOINT-007]
evidence: [EVIDENCE-003, EVIDENCE-004]   # ≥1 required; ≥2 from different attempts preferred
hypothesis: HYPOTHESIS-005
unlocks: leaks confAdmin JWT usable on /nd/* admin APIs   # REQUIRED on an accepted finding (see below)
tags: [authz-horizontal, idor]
created: 2026-04-26
last_updated: 2026-04-27
---
```

Severity: `cvss_vector` computes `cvss_score` (scoring reference only). `severity`
uses GB/T 30279-2020 — prefer `gbt_composite_severity`, else `gbt_technical_severity`.

`status:` enum (English ⇒ Chinese gloss for the report): `to-fix` 待修复 ·
`risk-accepted` 接受风险 · `fixed` 已修复 · `false-positive` 误报. The human
triages via `bin/kb status set FINDING-N <value>`. The agent normally leaves it.

Deepening fields — see `schema deepening` (`unlocks` / `pivot` / `chain_terminal`).
`unlocks:` is REQUIRED on an accepted finding (free text — the reusable capability
it grants; write `unlocks: nothing reusable` if none).
""",

"evidence": """\
# EVIDENCE — the proof behind a finding (record/evidence/EVIDENCE-N.md)

Single-file entity, id in frontmatter (matches filename stem). One EVIDENCE = one
logical proof (may span setup → trigger → verify, or actor comparisons). Written
by probe under its `draft_dir`; `kb draft commit` validates it.

```yaml
---
id: EVIDENCE-001
type: evidence
title: Admin user lookup with arbitrary id — HTTP 200
captured_at: 2026-04-26T14:32:00Z
actor: user_a                    # actor name from auth/
related_endpoint: ENDPOINT-007
proof_type: access-control        # control-bypass|access-control|rate-limit|config|crypto|info-disclosure|static-code|oob|other
evidence_level: E3                # E1=line E2=manual E3=non-destructive PoC E4=authorized impact E5=controlled chain
verification_result: confirmed    # confirmed|partial|refuted|blocked
claim: "user_a can read admin user 42 despite lacking admin role"
limitations:
  - "Only one target object was tested"
artifacts: [artifacts/EVIDENCE-001.har]
created: 2026-04-26
last_updated: 2026-04-26
---
```

The body MUST preserve the proof chain (all five sections are required — a
missing `## Limitations` is the most common `draft commit` failure):

```markdown
## Claim
One precise sentence describing what this evidence directly proves.

## Test Design
- Control point:
- Expected behavior:
- Baseline / control request:
- Trigger request:
- Success criterion:

## Evidence
Raw request / response / command output in fenced blocks. Include baseline AND trigger.

## Interpretation
Why the observed response proves / partially proves / refutes / blocks the claim.

## Limitations
What this evidence does NOT prove; missing auth/data/scope constraints.
```

`proof_type` is the CATEGORY of proof, not the vuln class — pick from the enum:
authz / IDOR / BOLA / RBAC / CSRF / open-redirect → `access-control` or
`control-bypass`; XSS / SQLi readout / path traversal / any data leak →
`info-disclosure`; missing rate-limit / lockout → `rate-limit`; headers / cookie
flags / debug config → `config`; TLS / JWT / crypto → `crypto`; SAST / bundle
finding → `static-code`; out-of-band (SSRF / blind) → `oob`; anything else →
`other`. (There is no `xss` / `sqli` / `csrf` proof_type — those are `class:` on
the hypothesis, not proof_type on the evidence.)
""",

"chain": """\
# CHAIN — an end-to-end attack path (record/chains.md)

Stitches **≥2 already-verified findings** (or ≥1 finding + a `frontier:` hop) into
one path. All CHAINs share `record/chains.md` (file frontmatter `type: chains`).
Created by the reason **deepening** task (not probe). Heading entity, placeholder
id, `bin/kb commit` assigns the real id. Body MUST carry one ```dot graph + one
narrative paragraph (a missing `dot` fence hard-fails `kb commit`).

```markdown
### CHAIN-1: Anonymous info-disclosure → admin token → full admin takeover
- findings: [[FINDING-003]], [[FINDING-007]]   # verified spine: ordered; order = attack path
- frontier: [[HYPOTHESIS-030]]                 # optional projected next hop(s), each a [[HYPOTHESIS-N]]
- entry: unauthenticated GET /api/config leaks an admin JWT
- impact: full administrative account takeover
- severity: critical
- stages: info-disclosure -> credential-access -> privilege-escalation

​```dot
// fig-id: chain-1
digraph chain1 {
  rankdir=LR; node [shape=box, style=rounded];
  entry  [label="unauth GET /api/config", color=red];
  f3     [label="leak admin JWT (FINDING-003)"];
  f7     [label="admin API takeover (FINDING-007)"];
  impact [label="full admin takeover", shape=doubleoctagon];
  entry -> f3 -> f7 -> impact;
}
​```

<one narrative paragraph: how finding A unlocks finding B …>
```

- `findings:` is the verified spine only. A lone finding with no frontier is not a
  chain — mark that finding `chain_terminal: true` instead (see `schema deepening`).
- `frontier:` = not-yet-verified next hops, each `[[HYPOTHESIS-N]]`. A hop is OPEN
  while its hypothesis is `untested`/`testing` (blocks the exit gate); `verified` →
  fold its finding into `findings:` and drop; `refuted` → drop; `blocked` → parked.
  Status is DERIVED from the hypothesis — none is written on the `frontier:` line.
- **Unverified steps must be disclosed:** draw them dashed (`style=dashed`,
  `(unverified)` label) and say "possible, not yet verified" + what blocks it.
""",

"note": """\
# NOTE — observations, leads, and structured ledgers (wiki/ | plan/ | record/)

Free-form by default (`### NOTE-1: title` + optional `- status:` bullet + body).
Three NOTEs carry conventions the tooling reads:

## system-feature: NOTE
Target-wide feature warranting a system-wide hypothesis (WAF / request signing /
encrypted payloads / required custom header / client-side crypto). Title starts
`system-feature: <name>`. Reason must promote it to a system-wide hypothesis or
retire it (with `retire-reason:`) before the coverage gate opens.

```markdown
### NOTE-1: system-feature: request-signing
- status: open

Detected X-Sign HMAC header on every authenticated request; algorithm undocumented.
```
Common slugs: `waf` · `request-signing` · `payload-encryption` · `required-custom-header` · `client-crypto-code`.

## deepen-lead NOTE
`kb draft integrate` records each probe follow-up lead (from the handoff's
`## Follow-up leads`) as a `deepen-lead:` NOTE and queues a pointer in `STATE.md
## Follow-up leads`. Durable input to the deepening loop; reason consumes then
retires it (status → `stale`) and drops the STATE line.

```markdown
### NOTE-N: deepen-lead (probe follow-up)
- status: open
- source: probe follow-up lead (task=TASK-012)

deepen-lead: axis: chain; lead: response echoes admin JWT; capability: likely admin API; target_hint: /api/admin/*
```

## capability-inventory NOTE
For a Tier 0 endpoint/workflow with multiple security-relevant semantic slots.
`- type: capability-inventory` is REQUIRED (a title mention without the bullet
hard-fails `kb commit`). One NOTE per Tier 0 pattern; `pattern:` must be an exact
Tier 0 Pattern Catalog name from threat-modeling.md (e.g. `Generic CRUD / sqlid
router`, `Upload / file management`). Observe writes the facts-only form; reason
owns slot disposition.

```markdown
### NOTE-1: capability inventory for [[ENDPOINT-47]] upload service
- type: capability-inventory
- status: open
- target: [[ENDPOINT-47]]
- tier: 0
- pattern: Upload / file management
- capabilities: accepts-file-upload, returns-filePath, uploaded-files-publicly-readable
- slots_selected:
  - extension-type-server-execution ([[HYPOTHESIS-031]] -> [[TASK-022]])
- slots_covered:
  - actor-authz-vertical ([[FINDING-022]])
- slots_missing:
  - content-browser-rendering
```
Slot fields: `slots_selected` (in a hyp/task, not yet closed) · `slots_covered`
(verified) · `slots_refuted` · `slots_missing` (need disposition) · `slots_deferred`
· `slots_blocked` · `slots_skipped`. Each slot item = a lowercase kebab-case slug +
optional KB refs / prose in parens. Omit empty fields (no `[]`, `none`, `n/a`).
Keep first-wave `slots_selected` to ~3-4, prioritizing RCE / privesc / takeover.
A `refuted` hypothesis closes only its slot (→ `slots_refuted`), not the endpoint.
""",

"deepening": """\
# Deepening fields (chain-centric — computed by `bin/kb coverage`)

- **`FINDING.unlocks`** (frontmatter, free text) — the reusable capability this
  finding grants (e.g. `unlocks: leaks confAdmin JWT usable on /nd/* APIs`). Set
  by probe; REQUIRED on an accepted finding. Seeds deepening's capability→surface
  matching; no controlled vocab.
- **`FINDING.pivot`** (frontmatter, optional) — a plain reference to a concrete
  reusable artifact (a `pivot/` artifact, an `auth/` actor, a `transport-recipe`).
  Plain string, NOT a `[[wikilink]]` (frontmatter mangles `[[ ]]`).
- **`FINDING.chain_terminal`** (frontmatter, bool, **underscore key**) — set by
  deepening once the finding chains nowhere. A verified finding is *placed* iff it
  is in some `CHAIN.findings` spine OR carries `chain_terminal: true`; otherwise
  `bin/kb coverage` lists it under `UNPLACED FINDINGS` and blocks the gate.
- **`CHAIN.frontier`** (bullet) — the open-hop list (see `schema chain`).
- **`TASK.serves_chain`** (bullet, optional) — `[[CHAIN-N]]`; set by deepening on a
  hop task so probe is dispatched with the chain context.

The exit gate blocks while any CHAIN has an open frontier OR any verified finding
is unplaced.
""",

"target-json": """\
# target.json — engagement metadata (CLI-maintained, never hand-edit)

| Field | Meaning |
|---|---|
| `slug` / `base_url` / `notes` | identity + one-line goal (set by `kb init`) |
| `scope_in` / `scope_out` | host/URL allow & deny lists; recursion into a new web origin uses `bin/kb scope contains --strict-origin <url>`. Plain containment (`scope contains` / asset recall) matches by hostname/IP: a host/fqdn/url seed (incl. base_url) matches the single IP it names (port-independent); a domain seed does not match an IP (no DNS resolution) |
| `counters` | per-entity-type real-ID counters (auto) |
| `primary_objective` | Primary Objective Lock slug (e.g. `login`); empty = full scope |

## Primary Objective Lock (`primary_objective`)
The canonical machine-readable signal that the engagement is scoped to one flow.
- Set at bootstrap: `bin/kb init <slug> --target <url> --notes "<goal>" --primary-objective login`
- Change/clear later: `bin/kb target set --primary-objective login` (empty string clears → full scope)
- Read: `bin/kb coverage` prints a `PRIMARY OBJECTIVE LOCK:` banner; `--json` carries `summary.primary_objective`.
- Gate semantics: does NOT change `coverage --check` exit codes; when active, non-objective gaps are deferred to report scope, not silently skipped.
- NOT a vulnerability preference: "重点关注逻辑漏洞/越权" is full-scope emphasis (store in STATE `## Active focus`), not a Lock. Only a concrete business flow/area goes here.
""",

"health": """\
# `kb health` lint rules

| Rule | Severity | Trigger |
|---|---|---|
| `broken-wikilink` | error | `[[X]]` resolves to nothing |
| `layout-violation` | error | Entity type in wrong tier folder |
| `missing-frontmatter` | error | No frontmatter, or a required field missing |
| `duplicate-real-id` | error | Same real ID in two files |
| `id-filename-mismatch` | error | FINDING/EVIDENCE frontmatter `id` ≠ filename stem |
| `missing-required-bullets` | error | Entity missing a required bullet |
| `missing-required-fence` | error | Body lacks a required fence (CHAIN with no ```dot). `kb commit` also hard-gates this. |
| `referential-integrity` | error | Frontmatter list references a non-existent entity |
| `unused-tag` | warning | Tag not in the class vocabulary |
| `unused-workflow` | warning | `workflow:` not in the workflow vocabulary |
| `stale-active` | warning | `status: in-progress` but `last_updated` > 7 days |
| `too-many-undocumented` | warning | > 20 entities at `status: undocumented` |
| `oversized-file` | warning | File > 500 lines |
| `orphan-topic` | info | Topic page has no inbound wikilinks |
| `endpoint-no-hypothesis` | info | Endpoint with no hypothesis targeting it |
| `unjustified-coverage-skip` | info | `coverage-skip:` item with empty `(...)` rationale |
| `coverage-block-without-prefix` | info | `coverage-block:` rationale missing `needs-user-input:` / `technical:` prefix |
""",

}

# ─────────────────────────────────────────────────────────────────────────
# WEB — web-runtime attack-surface entities and vocabularies.
# ─────────────────────────────────────────────────────────────────────────

WEB = {

"topic": """\
# Topic page frontmatter (wiki/<slug>.md)

One file per `workflow`; all its ENDPOINT / PAGE / ROUTE / BUNDLE / WORKFLOW /
NOTE entities live in it.

```yaml
---
title: Admin User Management
type: topic
workflow: user-management        # from the workflow vocab — see `schema workflow-vocab`
tags: [authz-vertical, idor]     # from the class vocab — see `schema class`
status: in-progress              # stub | in-progress | stable | stale
created: 2026-04-27
last_updated: 2026-04-27         # kb commit bumps this automatically
---
```

`index.md` / `STATE.md` frontmatter is just `type: index|state` + `last_updated`.
""",

"endpoint": """\
# ENDPOINT — a backend HTTP action (wiki/<workflow>.md)

Heading entity + bullets. Sweep-membership tags are REQUIRED — `bin/kb commit`
refuses any ENDPOINT missing `unauth_sweep` or `authz_sweep` (the #1 commit
failure). Born at observe; the sweep runner advances them after it runs.

```markdown
### ENDPOINT-41: admin user list — POST /admin/system/user/list.json
- method: POST
- path: /admin/system/user/list.json
- status: documented
- unauth_sweep: required
- authz_sweep: required
```

Sweep tags gate the two system-wide read-comparison sweeps:

| Tag | Sweep | Observe sets to |
|---|---|---|
| `unauth_sweep` | Unauthenticated-access (strip session, replay, diff vs authed baseline) | `required` (default) or `na(<reason>)` |
| `authz_sweep` | Vertical / function-level authz (replay as lower-priv, diff vs high-priv baseline) | `required` (default) or `na(<reason>)` |

Values (case-insensitive): `required` (safe default — `/admin/*` → required, static
asset → `na`) · `na(<reason>)` · `blocked(needs-<x>)` (can't sweep yet — needs
contract / actor / peer) · `blocked(technical: <why>)` (swept but untestable —
500 / WAF / no baseline; terminal, closes the check) · `enforced` (control present)
· `missing` (control absent → FINDING). Observe sets only `required` / `na(…)`;
the sweep runner sets the rest. Coverage keeps a sweep's universal check OPEN while
any endpoint is `required` or `blocked(needs-…)`.

## Optional coverage bullets (ENDPOINT / WORKFLOW / PAGE / BUNDLE)

| Bullet | Meaning | User-visible? |
|---|---|---|
| `coverage-skip:` | OWASP category genuinely n/a (permanent) | no |
| `coverage-block:` | Category applies but can't test now (must lead with `needs-user-input:` or `technical:`) | `needs-user-input:` → batch-reported at termination |

```markdown
- coverage-skip: A03 (read-only, no user input), A01 (anonymous by design)
- coverage-block: A01 (needs-user-input: admin creds for tenant_a not provided)
```

Set via `bin/kb bullet set ENDPOINT-007 coverage-skip "A03 (read-only), A01 (anonymous)"`
(avoids wikilink validation). `bullet append` is for wikilink-list bullets.
""",

"page": """\
# PAGE / ROUTE / BUNDLE / WORKFLOW — attack-surface layering (wiki/<workflow>.md)

Use these together, not as substitutes:

| Type | Meaning | Typical hypothesis target |
|---|---|---|
| PAGE | Frontend route / UI entry point | route guard, anonymous access, clickjacking / open redirect |
| ROUTE | A client-side route (SPA) | route guard, UI-only exposure |
| ENDPOINT | Backend HTTP action / data read-write | authz, IDOR, injection, upload/export, parameter tampering (see `schema endpoint`) |
| BUNDLE | A JS bundle | source of leaked endpoints / secrets / logic |
| WORKFLOW | Business scenario spanning pages/endpoints/state | workflow bypass, cross-step replay, state binding, cross-actor/tenant logic |

`WORKFLOW` may carry optional relationship bullets — `pages:`, `endpoints:`,
`bundles:`, `source:` (free-form wikilink lists); required schema stays only
`starts_at` + `status`. (`schema route` / `bundle` / `workflow` all show here.)
""",

"class": """\
# `tags:` / `class:` controlled vocabulary

Applied to topic pages (file frontmatter) and entities (bullet metadata / a
HYPOTHESIS `class`). Multiple allowed on `tags:`; one on `class:`.

- **Auth / session:** `authn` `session` `login` `registration` `password-recovery` `mfa-bypass` `jwt` `oauth` `sso` `weak-password` `username-enum` `rate-limit` `captcha-bypass` `auth-bypass`
- **Authorization:** `authz-vertical` `authz-horizontal` `idor` `bola` `rbac`
- **Injection:** `sqli` `nosqli` `xss` `command-injection` `ssti` `xxe` `xpath` `xpath-injection` `ldap-injection`
- **Server-side:** `ssrf` `rce` `deserialization` `path-traversal` `file-upload`
- **Client-side:** `csrf` `clickjacking` `open-redirect` `cors-misconfig` `postmessage`
- **Cryptography:** `weak-crypto` `hardcoded-secret` `crypto-misuse`
- **Info disclosure:** `info-disclosure` `debug-exposure` `verbose-error`
- **Business logic:** `workflow-bypass` `race-condition` `business-logic`
- **Config / hygiene:** `headers-missing` `cookie-flags`
- **Surface tags (not vuln classes):** `admin` `public` `api` `graphql` `webhook` `legacy`

`login` · `registration` · `password-recovery` double as business-scenario slugs
(a hypothesis with that `class` clears the matching coverage scenario). The full
OWASP-to-tags rollup, STRIDE sweep, and hypothesis quality criteria are in
`docs/threat-modeling.md`; A01/A04 logic flaws also load `docs/logic-object-model.md`.
""",

"workflow-vocab": """\
# `workflow:` controlled vocabulary

One value per topic page — the closest fit. Free-form is allowed but `kb health`
warns; prefer the list.

- **Auth & identity:** `login` `registration` `password-recovery` `password-change` `mfa-enrollment` `mfa-challenge` `email-verification` `account-recovery` `account-deletion` `logout` `session-management`
- **Authorization:** `permission-management` `team-management` `impersonation` `delegation`
- **Admin / moderation:** `admin-console` `user-management` `audit-log` `content-moderation` `system-config`
- **Profile / account:** `profile-edit` `account-settings` `api-keys`
- **Payment / billing:** `payment-checkout` `payment-refund` `subscription-management` `billing`
- **Content:** `content-create` `content-edit` `content-delete` `content-share` `comment` `reaction`
- **Files:** `upload` `download` `import-export`
- **Search & nav:** `search` `listing`
- **Messaging:** `direct-message` `notification` `email-trigger`
- **Integration / API:** `oauth-flow` `webhook-receive` `webhook-config` `api-public` `third-party-integration`
- **Infrastructure:** `gateway` `auth-middleware` `healthcheck` `debug-endpoints`
""",

"targets": """\
# `targets:` sentinel for system-wide hypotheses

HYPOTHESIS normally carries `targets: [[ENDPOINT-N]]`. For hypotheses applying to
the engagement as a whole — universal hygiene checks (cookie flags, security
headers, file-leakage sweep) and conditional system features — use the literal
string sentinel `targets: system-wide`:

```markdown
### HYPOTHESIS-1: cookies missing HttpOnly+Secure+SameSite
- targets: system-wide
- class: cookie-flags
- severity_guess: medium
- rationale: investigate session cookie flags across all post-login endpoints
- status: untested
```

`system-wide` is the only non-entity-ID value permitted on `targets:`. The
`referential-integrity` check ignores it; `bin/kb coverage` uses it for the
universal-checks and conditional-features blocks.
""",

}

# ─────────────────────────────────────────────────────────────────────────
# HOST — host/network-runtime entities + vocab. Keys that also exist in COMMON
# (finding / evidence / chain / hypothesis) OVERRIDE it with host-flavored refs.
# ─────────────────────────────────────────────────────────────────────────

_HOST_ASSETS = """\
# Attack-surface assets (wiki/) — HOST / DOMAIN / SERVICE / WEBAPP / CRED

Heading entities + bullets, grouped into `wiki/` files by `service_class`
(see `schema service-class`). `bin/kb schema <type>` shows this for any of them.

| Entity | Required bullets | status values | Notes |
|---|---|---|---|
| **HOST** | `ip`, `status` | undocumented · documented · alive · dead | one IP. `ip:` must be the real IP, not just in the title |
| **DOMAIN** | `fqdn`, `status` | undocumented · documented · resolves · nxdomain | any DNS name; `parent:` optional (present = subdomain); `resolves_to:` lists IPs |
| **SERVICE** | `host`, `port`, `proto`, `status` | undocumented · documented · untested · tested-clean · verified-issue | `(host, port, proto)` triple; `name:`/`product:`/`version:` from fingerprinting |
| **WEBAPP** | `url`, `status` | undocumented · documented · delegated · returned | an HTTP(S) app worth a web pentest; `delegated` is a sticky terminal state (see web-delegation) |
| **CRED** | `kind`, `value_hash`, `source`, `status` | discovered · validated · expired · used-for | store only a hash / redacted digest — plaintext goes to `auth/captured/<id>.json` |

Three things are NOT entities: CIDR ranges (→ `target.json.scope_in`; new internal
ones → `discovered-segment:` NOTE), ASNs (→ `pivot-candidate:` NOTE), TLS certs
(→ `cert-pivot:` NOTE listing SANs).
"""

HOST = {

"host": _HOST_ASSETS, "domain": _HOST_ASSETS, "service": _HOST_ASSETS,
"webapp": _HOST_ASSETS, "cred": _HOST_ASSETS,

"hypothesis": """\
# HYPOTHESIS — a testable vuln/exploit claim (plan/hypotheses.md)

Heading entity, placeholder id (`bin/kb commit` assigns the real id). Reason
creates these via `bin/kb plan add`.

```markdown
### HYPOTHESIS-1: default credentials on jenkins
- targets: [[SERVICE-7]]           # HOST / SERVICE / WEBAPP / CRED / DOMAIN id(s), or `system-wide`
- class: default-credentials        # ATT&CK / classic-service class (see `schema class`)
- severity_guess: high
- rating_basis: 预估访问路径=网络; 触发要求=低; 权限需求=无; 交互条件=不需要; C=严重; I=严重; A=一般
- confidence: medium
- rationale: jenkins login accepts admin/admin per banner + version.
- status: untested
```

`severity_guess` is the GB/T 30279-2020 technical severity guess (scheduling),
not CVSS. Add `gbt_category` / `rating_basis` / `confidence` when known. High-value
classes (credential reuse / lateral, key-service unauth) get their own hypothesis
per key SERVICE; only naturally-global classes (default-cred spray, SNMP community,
poc-scan sweep) use `targets: system-wide`.
""",

"finding": """\
# FINDING — a verified vuln / foothold (record/findings/FINDING-N.md)

Single-file entity; id in frontmatter (matches filename stem). Created by probe
via `bin/kb draft scaffold … finding` + `bin/kb draft commit`. `status:` auto-seeded.

```yaml
---
id: FINDING-001
type: finding
title: default credentials on jenkins (SERVICE-007)
severity: high                   # GB/T 30279-2020: critical|high|medium|low
cvss_vector: CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:L   # optional; computes cvss_score
gbt_category: config/authentication/default-credentials
gbt_technical_severity: high
related_assets: [SERVICE-007, HOST-003]   # HOST/SERVICE/WEBAPP/CRED — multi-type, multi-id
evidence: [EVIDENCE-003]                  # ≥1 required
hypothesis: HYPOTHESIS-005
unlocks: admin on jenkins → script console RCE → host foothold   # REQUIRED on an accepted finding
tags: [default-credentials, exposed-mgmt-port]
created: 2026-04-26
last_updated: 2026-04-27
---
```

`related_assets` (list) is the host analogue of the web `related_endpoints`.
Recommended GBT fields: `gbt_category` / `gbt_exploitability_level` /
`gbt_impact_level` / `gbt_technical_severity` / `gbt_environment_level` /
`gbt_composite_severity` / `gbt_rating_basis`. `status:` triage enum (user-owned):
`to-fix` · `risk-accepted` · `fixed` · `false-positive` (set via `kb status set`).
See `schema deepening` for `unlocks` / `pivot` / `chain_terminal`.
""",

"evidence": """\
# EVIDENCE — the proof behind a finding (record/evidence/EVIDENCE-N.md)

Single-file entity, id in frontmatter. Written by probe under its `draft_dir`;
`kb draft commit` validates it. `related_asset:` is a SINGLE asset id (host
analogue of the web `related_endpoint`).

```yaml
---
id: EVIDENCE-001
type: evidence
title: jenkins admin/admin login — HTTP 200 dashboard
captured_at: 2026-04-26T14:32:00Z
actor: operator
related_asset: SERVICE-007
proof_type: control-bypass        # control-bypass|access-control|rate-limit|config|crypto|info-disclosure|static-code|oob|other
evidence_level: E3                # E1..E5
verification_result: confirmed    # confirmed|partial|refuted|blocked
claim: "jenkins accepts default admin/admin and renders the authenticated dashboard"
limitations:
  - "Did not exercise the script console (RCE) — access proof only"
artifacts: [artifacts/EVIDENCE-001.txt]
created: 2026-04-26
last_updated: 2026-04-26
---
```

Body MUST carry the five sections (a missing `## Limitations` is the most common
`draft commit` failure): `## Claim` / `## Test Design` / `## Evidence` /
`## Interpretation` / `## Limitations`. See `schema evidence`-body guidance below.

## Test Design / Evidence / Interpretation / Limitations
- Test Design: control point · expected behavior · baseline · trigger · success criterion.
- Evidence: raw request/response/command output in fenced blocks (baseline + trigger).
- Interpretation: why the output proves / partially proves / refutes / blocks the claim.
- Limitations: what it does NOT prove; missing scope/data constraints.
""",

"chain": """\
# CHAIN — a kill-chain (record/chains.md)

Stitches **≥2 verified findings** (or ≥1 finding + a `frontier:` hop) into one
kill-chain. Created by the reason **deepening** task. Shares `record/chains.md`.
Body MUST carry one ```dot graph + one narrative (a missing `dot` fence hard-fails
`kb commit`). Uses kill-chain stages for `stages:` (see `schema workflow-vocab`).

```markdown
### CHAIN-1: 外网弱口令 → 横向 DB → 域凭据
- findings: [[FINDING-003]], [[FINDING-007]]   # verified spine, ordered = kill-chain
- frontier: [[HYPOTHESIS-030]]                 # optional next hop(s), each a [[HYPOTHESIS-N]]
- entry: jenkins 默认口令 getshell
- impact: 拿到域管理员 hash,可 DCSync
- severity: critical
- stages: initial-access -> lateral-movement -> credential-access

​```dot
// fig-id: chain-1
digraph chain1 {
  rankdir=LR; node [shape=box, style=rounded];
  entry  [label="jenkins 默认口令 getshell", color=red];
  hostb  [label="横向到 DB 主机 (FINDING-003)", shape=box3d];
  cred   [label="dump 域管理员 hash (FINDING-007)", shape=note];
  impact [label="DCSync 拿下域", shape=doubleoctagon];
  entry -> hostb -> cred -> impact;
}
​```

<narrative: how A leads to B>
```

`frontier:` = not-yet-verified hops (each `[[HYPOTHESIS-N]]`); status derived from
the hypothesis (`untested`/`testing` = open, blocks the gate; `verified` → fold in;
`refuted` → drop; `blocked` → parked). Unverified steps drawn dashed + narrated as
"推测,尚未验证". A lone finding with no frontier → mark it `chain_terminal: true`.
""",

"workflow-vocab": """\
# `workflow:` controlled vocabulary — kill-chain stages

`recon-passive` · `recon-active` · `enumeration` · `vulnerability-scan` ·
`initial-access` · `execution` · `persistence` (PoC only) · `privilege-escalation`
· `lateral-movement` · `credential-access` · `discovery` · `exfiltration` (PoC only).

A WORKFLOW ties together SERVICEs / CREDs / FINDINGs along the kill-chain; the
narrative lives in `wiki/kill-chain.md`.
""",

"workflow": """\
# WORKFLOW — a kill-chain stage narrative (wiki/kill-chain.md)

Heading entity; required bullets `starts_at` + `status`. Ties together the
SERVICEs / CREDs / FINDINGs of one kill-chain stage; `workflow:` uses the
kill-chain stage vocab (see `bin/kb schema workflow-vocab`). Ungrouped and out of
per-entity coverage.
""",

"class": """\
# `tags:` / `class:` controlled vocabulary (host vuln classes)

`default-credentials` · `weak-credentials` · `anonymous-access` ·
`unauthenticated-rce` · `public-cve` · `smb-relay` · `kerberoast` · `asreproast` ·
`dcsync` · `pass-the-hash` · `unauth-redis` · `unauth-mongo` ·
`unauth-elasticsearch` · `unauth-jenkins` · `unauth-docker-api` ·
`exposed-mgmt-port` · `default-snmp-community` · `ssh-weak-cipher` ·
`telnet-exposed` · `ftp-anon` · `smtp-open-relay` · `patch-missing` · `eol-os`.

Planning classes also include: `unauthenticated-access` · `public-cve: <CVE>` ·
`weak-protocol` · `web-app-pentest` (must delegate) · `pivot-via-cred` (lateral) ·
`system-wide`.
""",

"service-class": """\
# `service_class:` — the wiki-file grouping label

Each `wiki/` attack-surface file's frontmatter carries `service_class: <class>`.
One label drives three things: coverage GAP OVERVIEW grouping, `--focus <class>`
slicing, and reason planning's group clustering.

- **Service classes (SERVICE / WEBAPP):** `web` · `smb-ad` (SMB/LDAP/Kerberos/DC) ·
  `db` (mysql/mssql/postgres/redis/mongo…) · `remote` (ssh/rdp/vnc/telnet) ·
  `mgmt` (jenkins/k8s/docker/snmp/ipmi/panels) · `mail` · `dns` · `infra-other`.
- **Container layer:** `host` (HOST file `hosts.md`; split `hosts/<segment>.md` when
  many) · `domain` (DOMAIN file `domains.md`).

Files with no `service_class` (a flat `services.md`, or `creds.md`/`notes.md`/
`kill-chain.md`) fall back to asset-type grouping.
""",

"coverage-rollup": """\
# coverage rollup — MITRE ATT&CK tactic

`bin/kb coverage` rolls per-entity gaps up by ATT&CK tactic: `recon` /
`initial-access` / `execution` / `persistence` / `priv-esc` / `lateral` /
`cred-access` / `exfil`. The per-entity gate applies to HOST / SERVICE / WEBAPP /
DOMAIN — each gated asset needs ≥1 hypothesis / skip / block.

**universal checks (whole-scope hygiene sweep, 7):** weak-protocols · default-snmp
· mgmt-public-iface · patch-eol · unauth-services · weak-tls · **poc-scan**. Each is
closed by a `targets: system-wide` hypothesis whose text contains the slug token, or
a `universal-skip: <slug>` NOTE. `poc-scan` is the lifecycle-gate exception: its
closing hypothesis must reach `refuted`/`verified`+finding (the sweep really ran +
was analyzed), not sit at `untested`.
""",

"note": COMMON["note"],   # host uses the same NOTE conventions (deepen-lead / system-feature / capability-inventory) + cert-pivot / pivot-candidate / discovered-segment / cred-spray-target prefixes

}


def topics_for(profile: str) -> dict:
    """COMMON merged with the active profile's topic map (profile wins on a clash)."""
    merged = dict(COMMON)
    merged.update(HOST if profile == "host" else WEB)
    return merged
