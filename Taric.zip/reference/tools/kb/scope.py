"""Scope model — seed parsing + containment.

A *seed* is `{"kind": <kind>, "value": <str>, ...}` where kind ∈ SEED_KINDS.
`target.json` carries `scope_in` / `scope_out` as lists of seeds; legacy web
engagements may hold bare strings there (a URL / host), which normalize to a
seed via `as_seed()`. The engagement's `base_url`, if set, is an implicit
in-scope host.

Containment (`contains`) answers "is <target> in scope?":
  - scope_out wins over scope_in (opt-out priority, framework-host §3)
  - IP / CIDR matched with the stdlib `ipaddress` module
  - domain seeds match the apex and (by default) its subdomains
  - host/fqdn/url seeds (base_url included) match the exact IP they name —
    hostname extraction parity with the host family, port-blind; domain
    seeds never match IPs (no DNS resolution in this module)
This module is the single source of truth for the rule — Workers call
`kb scope contains` rather than writing their own regex (framework-host §10.2).

Strict-origin containment is an opt-in web recursion gate. URL seeds and
base_url match only the same scheme/host/effective port; host/domain/IP/CIDR
seeds permit HTTP(S) only on that scheme's default port. A non-default port
therefore requires an explicit URL seed.
"""
from __future__ import annotations

import ipaddress
from typing import Any, Dict, List, Tuple
from urllib.parse import urlsplit

SEED_KINDS = ("cidr", "ip", "domain", "fqdn", "url", "host")


# ───────────────────────── Seed parsing / normalization ─────────────────────────

def parse_seed(spec: str) -> Dict[str, Any]:
    """Parse a `kind:value` spec (or a bare value → inferred kind) into a seed.

    `cidr:10.0.0.0/24`, `domain:example.com`, `url:https://x` — and bare
    `10.0.0.0/24` / `example.com` / `https://x` infer their kind. The `kind:`
    prefix is only honored when `kind` is a known SEED_KIND, so a bare URL
    (`https://…`, whose scheme also contains `:`) is not mis-split.
    """
    spec = (spec or "").strip()
    if not spec:
        raise ValueError("empty seed spec")
    head, sep, rest = spec.partition(":")
    if sep and head in SEED_KINDS:
        value = rest.strip()
        if not value:
            raise ValueError(f"seed {spec!r} has empty value")
        return {"kind": head, "value": value}
    return {"kind": _infer_kind(spec), "value": spec}


def _infer_kind(value: str) -> str:
    if "://" in value:
        return "url"
    try:
        ipaddress.ip_address(value)
        return "ip"
    except ValueError:
        pass
    if "/" in value:
        try:
            ipaddress.ip_network(value, strict=False)
            return "cidr"
        except ValueError:
            pass
    return "domain"


def as_seed(entry: Any) -> Dict[str, Any]:
    """Normalize a scope_in/out entry (dict or legacy bare string) to a seed."""
    if isinstance(entry, dict) and "value" in entry:
        kind = entry.get("kind") or _infer_kind(str(entry["value"]))
        return {**entry, "kind": kind}
    if isinstance(entry, str):
        try:
            return parse_seed(entry)
        except ValueError:
            return {"kind": "host", "value": entry}
    return {"kind": "host", "value": str(entry)}


# ───────────────────────── Query classification ─────────────────────────

def _host_of(value: str) -> str:
    if "://" in value:
        return (urlsplit(value).hostname or "").lower()
    return value.split("/", 1)[0].lower()


def _origin_of(value: str) -> Tuple[str, str, int] | None:
    if "://" not in value:
        return None
    parsed = urlsplit(value)
    scheme = parsed.scheme.lower()
    host = (parsed.hostname or "").lower()
    if scheme not in ("http", "https") or not host:
        return None
    try:
        port = parsed.port or (443 if scheme == "https" else 80)
    except ValueError:
        return None
    return scheme, host, port


def _classify_query(q: str) -> Tuple[str, str]:
    """Return (family, value) where family ∈ {'ip','cidr','host'}."""
    q = (q or "").strip()
    try:
        ipaddress.ip_address(q)
        return "ip", q
    except ValueError:
        pass
    if "/" in q and "://" not in q:
        try:
            ipaddress.ip_network(q, strict=False)
            return "cidr", q
        except ValueError:
            pass
    return "host", _host_of(q)


# ───────────────────────── Matching ─────────────────────────

def _match(family: str, value: str, seed: Dict[str, Any]) -> bool:
    sk, sv = seed["kind"], str(seed["value"])
    if family in ("ip", "cidr"):
        try:
            if sk == "cidr":
                net = ipaddress.ip_network(sv, strict=False)
                if family == "ip":
                    return ipaddress.ip_address(value) in net
                q = ipaddress.ip_network(value, strict=False)
                return q.version == net.version and q.subnet_of(net)
            if sk == "ip":
                return family == "ip" and ipaddress.ip_address(value) == ipaddress.ip_address(sv)
            # host/fqdn/url seeds (URL-valued base_url included) admit the
            # exact IP they name — same hostname extraction the host family
            # already does, port-blind (strict port discipline lives in
            # contains_origin). domain seeds never match IPs
            if sk in ("host", "fqdn", "url") and family == "ip":
                return ipaddress.ip_address(value) == ipaddress.ip_address(_host_of(sv))
        except ValueError:
            return False
        return False
    # host family — compare hostnames
    sh = _host_of(sv)
    if not value or not sh:
        return False
    if sk == "domain":
        if seed.get("include_subdomains", True):
            return value == sh or value.endswith("." + sh)
        return value == sh
    if sk in ("fqdn", "host", "url"):
        return value == sh
    return False


def _effective_scope_in(target_data: Dict[str, Any]) -> List[Dict[str, Any]]:
    seeds = [as_seed(s) for s in target_data.get("scope_in", [])]
    base = target_data.get("base_url")
    if isinstance(base, str) and base.strip():
        # base_url host is implicitly in scope (web semantics, scope.md).
        seeds.append({"kind": "host", "value": base.strip()})
    return seeds


def _effective_scope_in_strict(target_data: Dict[str, Any]) -> List[Dict[str, Any]]:
    seeds = [as_seed(s) for s in target_data.get("scope_in", [])]
    base = target_data.get("base_url")
    if isinstance(base, str) and base.strip():
        seeds.append({"kind": "url", "value": base.strip()})
    return seeds


def _match_strict_origin(origin: Tuple[str, str, int], seed: Dict[str, Any]) -> bool:
    scheme, host, port = origin
    sk, sv = seed["kind"], str(seed["value"])
    if sk == "url":
        seed_origin = _origin_of(sv)
        return seed_origin == origin

    # Host-like seeds intentionally retain their existing hostname/subdomain
    # semantics, but only on the queried scheme's standard web port.
    if port != (443 if scheme == "https" else 80):
        return False
    if sk in ("domain", "fqdn", "host"):
        return _match("host", host, seed)
    if sk in ("ip", "cidr"):
        try:
            ipaddress.ip_address(host)
        except ValueError:
            return False
        return _match("ip", host, seed)
    return False


def contains(target_data: Dict[str, Any], query: str) -> Tuple[bool, str]:
    """Return (in_scope, reason). scope_out wins over scope_in."""
    family, value = _classify_query(query)
    for s in (as_seed(s) for s in target_data.get("scope_out", [])):
        if _match(family, value, s):
            return False, f"matched scope_out {s['kind']}:{s['value']}"
    for s in _effective_scope_in(target_data):
        if _match(family, value, s):
            return True, f"matched scope_in {s['kind']}:{s['value']}"
    return False, "no scope_in match"


def contains_origin(target_data: Dict[str, Any], query: str) -> Tuple[bool, str]:
    """Strict HTTP(S) origin containment for recursively discovered services."""
    origin = _origin_of((query or "").strip())
    if origin is None:
        return False, "strict origin check requires an absolute http(s) URL"
    for s in (as_seed(s) for s in target_data.get("scope_out", [])):
        if _match_strict_origin(origin, s):
            return False, f"matched scope_out {s['kind']}:{s['value']}"
    for s in _effective_scope_in_strict(target_data):
        if _match_strict_origin(origin, s):
            return True, f"matched strict scope_in {s['kind']}:{s['value']}"
    return False, "no strict origin scope_in match"
