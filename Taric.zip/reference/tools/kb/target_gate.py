"""Central target gate — localhost API client (no local state).

`kb export` collects the engagement's network assets (IP / host / domain) and
POSTs them to a localhost **gate service**. That service owns *all* the state
and policy — deduplication, the cumulative distinct-target count across every
session, and the threshold — and replies whether this session is still within
budget (``good``) or over the cap (``blocked``). The kb tool holds no database;
it is a thin client that sends the assets and reads one bit back.

Wire contract
-------------
``POST <PENTEST_TARGET_GATE_URL>``  (default ``http://127.0.0.1:80/api/v1/target/check``)

    request  (application/json)::

        {"engagement": "<slug>",
         "source": "kb-export",
         "timestamp": "<iso8601 utc>",
         "assets": [{"kind": "ip|domain", "value": "<normalized>"}, ...]}

    reply    (the gate service owns dedup + counting + policy; the verdict is
             wrapped in a ``{code, message, result}`` envelope, code 2000 = ok)::

        200 {"code": 2000, "message": "success",
             "result": {"blocked": false, "total": 42, "threshold": 100}}   -> good
        200 {"code": 2000, "message": "success",
             "result": {"blocked": true, "total": 101, "threshold": 100,
                        "reason": "distinct-target cap exceeded"}}           -> forbidden

    The parser unwraps ``result`` (a non-2000 ``code`` is treated as an error).
    It is otherwise tolerant: a flat body, ``blocked`` (bool), ``allowed`` (bool,
    inverted), a ``status`` string (``ok``/``good``/``allowed`` vs
    ``blocked``/``forbidden``/``denied``/``exceeded``), and an HTTP ``403`` are
    all understood. ``total``/``count`` and ``threshold``/``limit`` are surfaced
    for the banner when present.

Reliability
-----------
* **Bounded timeout** (``PENTEST_TARGET_GATE_TIMEOUT``, default 120s) — the call
  fails open after the timeout rather than hanging a ``kb commit`` / ``kb export``
  forever.
* **Fail-open by default** (``PENTEST_TARGET_GATE_FAILMODE=open|closed``): a gate
  service that is down, slow, or returns something unparseable must not brick
  every engagement. The miss is written to the audit trail (stderr always; a
  file too when ``PENTEST_TARGET_GATE_AUDIT`` is set) and the session proceeds.
  ``closed`` flips that to deny-on-error for hard enforcement.
* **Disabled** entirely with ``PENTEST_TARGET_GATE=0`` — then ``check`` is a
  no-op that always reports *good* (and makes no network call).
"""
from __future__ import annotations

import ipaddress
import json
import os
import sys
import urllib.error
import urllib.request
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import urlsplit

from .scope import as_seed

DEFAULT_URL = "http://127.0.0.1:80/api/v1/target/check"
DEFAULT_TIMEOUT = 120.0


# ── Configuration (read per-call so tests / operators can retune freely) ──

def _env(name: str, default: str = "") -> str:
    return (os.environ.get(name) or default).strip()


def gate_url() -> str:
    return _env("PENTEST_TARGET_GATE_URL", DEFAULT_URL)


def enabled() -> bool:
    return _env("PENTEST_TARGET_GATE", "1").lower() not in ("0", "false", "no", "off", "")


def failmode() -> str:
    return "closed" if _env("PENTEST_TARGET_GATE_FAILMODE", "open").lower() == "closed" else "open"


def timeout() -> float:
    try:
        t = float(_env("PENTEST_TARGET_GATE_TIMEOUT", str(DEFAULT_TIMEOUT)))
        return t if t > 0 else DEFAULT_TIMEOUT
    except ValueError:
        return DEFAULT_TIMEOUT


def _audit(msg: str) -> None:
    """Fail-open events must leave a trail. Always stderr; also a file when
    PENTEST_TARGET_GATE_AUDIT points at one. Never raises."""
    line = f"[kb target-gate] {datetime.now(timezone.utc).isoformat()} {msg}"
    try:
        print(line, file=sys.stderr)
    except Exception:  # noqa: BLE001
        pass
    path = _env("PENTEST_TARGET_GATE_AUDIT")
    if not path:
        return
    try:
        p = os.path.expanduser(path)
        d = os.path.dirname(p)
        if d:
            os.makedirs(d, exist_ok=True)
        with open(p, "a", encoding="utf-8") as fh:
            fh.write(line + "\n")
    except Exception:  # noqa: BLE001 — logging must never break the gate
        pass


# ── Result ────────────────────────────────────────────────────────────

@dataclass
class GateResult:
    blocked: bool
    enabled: bool
    url: str
    total: Optional[int] = None
    threshold: Optional[int] = None
    reason: str = ""
    error: Optional[str] = None
    sent: int = 0

    def to_dict(self, engagement: str) -> Dict[str, Any]:
        return {
            "blocked": self.blocked,
            "enabled": self.enabled,
            "total": self.total,
            "threshold": self.threshold,
            "reason": self.reason,
            "error": self.error,
            "assets_sent": self.sent,
            "engagement": engagement,
            "gate_url": self.url,
            "timestamp": datetime.now().isoformat(),
        }


# ── Session-halt sentinel ─────────────────────────────────────────────
#
# A *definitive* over-cap verdict must do more than fail one `kb commit`: the
# whole session has to stop touching the target. `export()` drops a `.HALTED`
# sentinel in the engagement root the first time the gate says blocked; the
# PreToolUse hook `.claude/hooks/target-cap-halt.py` sees it and denies every
# subsequent tool call — so the agent cannot keep running regardless of what it
# tries next. This exists because "kb commit failed, please stop" was unreliable:
# the exit-3 looked like the *coverage* gate's `BLOCKED` (which means "keep
# testing"), so the agent kept going. Enforcing at the harness layer does not
# depend on the model cooperating. Writing is best-effort and never raises — a
# failed sentinel must not brick the commit that persists the agent's work.

HALT_SENTINEL_NAME = ".HALTED"


def halt_enabled() -> bool:
    """Whether a definitive block arms the session-halt sentinel. On by default;
    ``PENTEST_TARGET_HALT=0`` keeps the gate advisory (commit still exits 3, but
    the session is not disabled)."""
    return _env("PENTEST_TARGET_HALT", "1").lower() not in ("0", "false", "no", "off", "")


def blocks_session(gate: Optional[GateResult]) -> bool:
    """A *definitive* over-cap verdict — the only thing that halts a session. A
    transport/parse error (``gate.error``) never halts (fail-open + audit), same
    rule the commit gate uses."""
    return bool(gate is not None and gate.blocked and not gate.error)


def write_halt_sentinel(root: Any, gate: GateResult) -> None:
    """Arm the session-halt sentinel in the engagement root. Best-effort; never
    raises. Idempotent — re-armed with a fresh timestamp on every blocked
    export."""
    try:
        path = os.path.join(str(root), HALT_SENTINEL_NAME)
        payload = {
            "halted": True,
            "reason": gate.reason or "distinct-target cap exceeded",
            "total": gate.total,
            "threshold": gate.threshold,
            "gate_url": gate.url,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
        with open(path, "w", encoding="utf-8") as fh:
            json.dump(payload, fh, ensure_ascii=False, indent=2)
    except Exception:  # noqa: BLE001 — arming the halt must never break a commit
        _audit(f"failed to write halt sentinel (reason={gate.reason!r})")


# ── Asset extraction (from the export assets view + target.json scope) ──

def _host_kind(value: Any) -> Optional[Tuple[str, str]]:
    """Normalize a URL / host:port / bare host / IP to ``(kind, canonical)``.

    Returns ``("ip", <compressed>)`` for an address, ``("domain", <host>)`` for
    a hostname (lower-cased, scheme/path/port stripped), or ``None`` when there
    is nothing host-like to register."""
    s = str(value or "").strip().lower()
    if not s:
        return None
    if "://" in s:
        s = urlsplit(s).hostname or ""
    else:
        s = s.split("/", 1)[0]
    if not s:
        return None
    if s.startswith("["):  # [ipv6]:port
        end = s.find("]")
        if end != -1:
            s = s[1:end]
    elif s.count(":") == 1:  # host:port / ipv4:port (a lone colon, not ipv6)
        head, _, tail = s.partition(":")
        if tail.isdigit():
            s = head
    if not s:
        return None
    try:
        return "ip", ipaddress.ip_address(s).compressed
    except ValueError:
        return "domain", s


def collect_from_export(assets: Optional[Dict[str, Any]],
                        target: Optional[Dict[str, Any]]) -> List[Dict[str, str]]:
    """Distinct network assets (only IP and domain) for this engagement.

    Sources, all deduped by canonical value:
      * ``target.json`` — ``base_url`` host + every ``scope_in`` seed
        (CIDR seeds are skipped — we track individual IPs and domains, not ranges)
      * the export ``assets`` view — HOST ``ip`` (and IP-shaped labels), DOMAIN
        ``fqdn``, WEBAPP/PAGE ``url`` hostnames

    ``scope_out`` is intentionally ignored (explicitly excluded targets are not
    "involved"). Endpoint paths carry no host, so they ride on ``base_url``.
    """
    out: Dict[str, Dict[str, str]] = {}

    def add_host(value: Any) -> None:
        r = _host_kind(value)
        if r:
            out[r[1]] = {"kind": r[0], "value": r[1]}

    def add_seed(seed: Any) -> None:
        s = as_seed(seed)
        # Only individual IPs and domains count — CIDR ranges are not tracked.
        if s.get("kind") == "cidr":
            return
        value = str(s.get("value", "")).strip().lower()
        if value:
            add_host(value)

    target = target or {}
    if target.get("base_url"):
        add_host(target["base_url"])
    for seed in target.get("scope_in") or []:
        add_seed(seed)

    assets = assets or {}
    for h in assets.get("hosts") or []:
        ip = str(h.get("ip") or "").strip()
        if ip:
            add_host(ip)
        label = str(h.get("label") or "").strip()
        if label and _host_kind(label) and _host_kind(label)[0] == "ip":
            add_host(label)  # host card titled with a bare IP but no ip: bullet
        for wa in h.get("webapps") or []:
            if wa.get("url"):
                add_host(wa["url"])
    for d in assets.get("domains") or []:
        if d.get("fqdn"):
            add_host(d["fqdn"])
    for wf in assets.get("workflows") or []:
        for pg in wf.get("pages") or []:
            if pg.get("url"):
                add_host(pg["url"])

    return sorted(out.values(), key=lambda x: (x["kind"], x["value"]))


# ── HTTP (stdlib only; monkeypatch point for tests) ──────────────────────

def _urlopen(req: urllib.request.Request, tmo: float) -> Tuple[int, str]:
    """POST and return ``(http_status, body_text)``. An HTTP error status
    (403/429/5xx) is a *response*, not an exception here — it is returned so the
    caller can interpret 403 as "blocked". Only transport failures (connection
    refused, timeout, DNS) propagate to the caller's fail-open handler."""
    try:
        with urllib.request.urlopen(req, timeout=tmo) as resp:
            return resp.getcode(), resp.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        body = ""
        try:
            body = e.read().decode("utf-8", "replace")
        except Exception:  # noqa: BLE001
            pass
        return e.code, body


def _interpret(status: int, p: Dict[str, Any]
               ) -> Tuple[Optional[bool], Optional[int], Optional[int], str]:
    """Map (http status, parsed body) → (blocked|None, total, threshold, reason).

    ``blocked is None`` means "unrecognized" — the caller applies the fail-mode."""
    # The gate service wraps the verdict in a ``{code, message, result:{...}}``
    # envelope (code 2000 = success). Unwrap ``result`` when present; a non-2000
    # code means the check didn't run → treat as an error (fail-mode). A flat
    # body (no ``result``) is still honored, for tolerance.
    if isinstance(p.get("result"), dict):
        code = p.get("code")
        if isinstance(code, int) and code != 2000:
            return None, None, None, str(p.get("message") or f"gate returned code {code}")
        p = p["result"]

    total = p.get("total")
    if not isinstance(total, int):
        total = p.get("count") if isinstance(p.get("count"), int) else None
    threshold = p.get("threshold")
    if not isinstance(threshold, int):
        threshold = p.get("limit") if isinstance(p.get("limit"), int) else None
    reason = str(p.get("reason") or p.get("message") or "")

    if status == 403:
        return True, total, threshold, reason or "gate service returned 403"
    if 200 <= status < 300:
        if isinstance(p.get("blocked"), bool):
            return p["blocked"], total, threshold, reason
        if isinstance(p.get("allowed"), bool):
            return (not p["allowed"]), total, threshold, reason
        st = str(p.get("status", "")).lower()
        if st in ("blocked", "forbidden", "deny", "denied", "over", "exceeded"):
            return True, total, threshold, reason
        if st in ("ok", "good", "allowed", "pass", "within"):
            return False, total, threshold, reason
        return None, total, threshold, reason
    return None, total, threshold, reason


def _on_error(url: str, sent: int, exc: Any) -> GateResult:
    fail_closed = failmode() == "closed"
    verb = "fail-closed → BLOCK" if fail_closed else "fail-open → ALLOW"
    _audit(f"{verb}: {exc} (url={url})")
    return GateResult(
        blocked=fail_closed, enabled=True, url=url,
        reason=f"gate unreachable ({exc})", error=str(exc), sent=sent,
    )


def check(engagement: str, items: List[Dict[str, str]]) -> GateResult:
    """Ask the gate service whether this session may proceed.

    Sends ``items`` to the localhost service and returns its verdict. Never
    raises: any transport/parse failure resolves via the configured fail-mode
    (default allow) and is audited. When the gate is disabled, returns *good*
    without touching the network."""
    url = gate_url()
    if not enabled() or not url:
        return GateResult(blocked=False, enabled=False, url=url,
                          reason="gate disabled", sent=len(items))

    payload = json.dumps({
        "engagement": engagement or "",
        "source": "kb-export",
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "assets": items,
    }).encode("utf-8")
    req = urllib.request.Request(
        url, data=payload, method="POST",
        headers={"Content-Type": "application/json", "Accept": "application/json"},
    )

    try:
        status, body = _urlopen(req, timeout())
    except Exception as exc:  # noqa: BLE001 — transport failure → fail-mode
        return _on_error(url, len(items), exc)

    try:
        parsed = json.loads(body) if body.strip() else {}
        if not isinstance(parsed, dict):
            parsed = {}
    except Exception:  # noqa: BLE001
        parsed = {}

    blocked, total, threshold, reason = _interpret(status, parsed)
    if blocked is None:
        return _on_error(url, len(items),
                         f"unrecognized gate response (http {status})")
    return GateResult(blocked=blocked, enabled=True, url=url, total=total,
                      threshold=threshold, reason=reason, sent=len(items))
