"""Probe-pool fill reminder — a just-in-time `<system-reminder>` nudging the
orchestrator to fill its probe pool to the concurrency cap instead of topping it
up one probe at a time.

Why this exists (measured, run aadf26ad): the orchestrator ran the probe pool at
~0.85 average depth against a cap of 5 — a slot was free 98% of the run, yet on
65% of its dispatching wake-ups it launched exactly ONE probe. The static
"fill to cap" rule in CLAUDE.md was present but skimmed past (and decays under
compaction). This surfaces the nudge at the two dispatch-decision sites, fresh
each call:
  • `bin/kb draft integrate` — a probe just finished, a slot just freed.
  • `bin/kb pending`         — the "what to run next" query, right before dispatch.

Note on counts: TASK `status=running` is not maintained in practice (tasks go
pending -> done via draft-integrate), so `pending` here can include in-flight
probes. We therefore do NOT claim a precise free-slot count — we surface the
pending count and delegate the free-slot arithmetic to the orchestrator
(`TaskListBackground` lists the probes actually running). The message is a
"fill to cap, don't top up one" directive, correct regardless of that count.
"""
from __future__ import annotations

from typing import Optional

from .index import build_index

POOL_CAP = 5


def _pending_tasks(eng) -> int:
    """Count TASK entities in status=pending (launchable-ish; see module note)."""
    idx = build_index(eng)
    archived = idx.archived_entity_ids()
    n = 0
    for e in idx.by_type.get("TASK", []):
        if e.is_placeholder or e.id in archived:
            continue
        if e.bullets.get("status") == "pending":
            n += 1
    return n


def banner(eng, freed: bool = False) -> Optional[str]:
    """`<system-reminder>` nudging a fill-to-cap dispatch, or None.

    freed=True (a slot just opened, from draft-integrate): fire whenever >=1 task
    waits. freed=False (the `pending` query): fire only when >=2 could run — no
    point nudging "fill" when a single task is all there is.
    """
    n = _pending_tasks(eng)
    if n < (1 if freed else 2):
        return None
    lead = ("A probe just finished — a pool slot is now free."
            if freed else
            f"{n} probe task(s) pending — enough to run several in parallel.")
    return "\n".join([
        "<system-reminder>",
        f"{lead} Probe pool cap is {POOL_CAP}, and it is almost never full.",
        f"Fill it to cap NOW, in THIS turn: dispatch one Agent(task_type=probe) per FREE slot",
        f"(free = {POOL_CAP} − probes currently running; TaskListBackground lists the running ones),",
        "each on a DIFFERENT endpoint. Do NOT dispatch a single probe and yield — top the pool up.",
        "(If the pool is already full / nothing is launchable, do nothing.)",
        "</system-reminder>",
    ])


def emit(eng, freed: bool = False) -> None:
    b = banner(eng, freed)
    if b:
        print(b)
