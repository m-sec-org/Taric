"""Markdown parsing — frontmatter, entities, wikilinks.

Frontmatter: tiny YAML-like reader handling scalars, inline lists [a, b, c],
ISO dates as strings, and quoted strings. Caller-shaped — we don't try to
implement YAML in full.

Entities: heading `### TYPE-N: title` followed by a metadata bullet block.
First non-bullet, non-blank line ends the metadata.

Wikilinks: `[[target]]` and `[[target|display]]`. External `[label](url)` is
markdown and not touched here.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Iterator, List, Optional, Tuple, Union


# ───────────────────────── Entity types ─────────────────────────

# Source of truth for entity types and ID padding lives in schema.py.
# Re-exported here so existing `from .parser import ENTITY_TYPES` calls work.
from .schema import ENTITY_TYPES, ID_PAD  # noqa: F401


def format_id(type_: str, n: int) -> str:
    """Real, committed entity ID: zero-padded to ID_PAD digits minimum."""
    return f"{type_.upper()}-{n:0{ID_PAD}d}"


def is_placeholder_id(id_: str) -> bool:
    m = re.fullmatch(r"([A-Z]+)-(\d+)", id_)
    if not m:
        return False
    return len(m.group(2)) < ID_PAD


def parse_id(id_: str) -> Optional[Tuple[str, int, bool]]:
    """Returns (type, n, is_placeholder) or None."""
    m = re.fullmatch(r"([A-Z]+)-(\d+)", id_)
    if not m:
        return None
    type_ = m.group(1)
    if type_ not in ENTITY_TYPES:
        return None
    digits = m.group(2)
    return type_, int(digits), len(digits) < ID_PAD


# ───────────────────────── Frontmatter ─────────────────────────

_FM_OPEN = "---"


def split_frontmatter(text: str) -> Tuple[Optional[str], str]:
    """Return (frontmatter_text or None, body_text). Frontmatter must start at line 1."""
    if not text.startswith(_FM_OPEN):
        return None, text
    lines = text.splitlines(keepends=True)
    if not lines or lines[0].strip() != _FM_OPEN:
        return None, text
    for i in range(1, len(lines)):
        if lines[i].strip() == _FM_OPEN:
            fm = "".join(lines[1:i])
            body = "".join(lines[i + 1:])
            return fm, body
    return None, text  # unterminated; treat as no frontmatter


def parse_frontmatter(fm_text: str) -> Dict[str, Any]:
    """Parse a small YAML subset.

    Supports: `key: scalar`, `key: [a, b, c]`, `key:` followed by `- item`
    block lines, quoted strings ("..." or '...'), and basic comments (# ...).
    """
    out: Dict[str, Any] = {}
    if fm_text is None:
        return out
    lines = fm_text.splitlines()
    i = 0
    n = len(lines)
    while i < n:
        line = lines[i]
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            i += 1
            continue
        m = re.match(r"^([A-Za-z_][A-Za-z0-9_]*)\s*:\s*(.*)$", line)
        if not m:
            i += 1
            continue
        key = m.group(1)
        val_str = m.group(2).strip()
        # Block list:
        if val_str == "":
            items: List[Any] = []
            j = i + 1
            while j < n:
                ls = lines[j].strip()
                if ls.startswith("- "):
                    items.append(_parse_scalar(ls[2:].strip()))
                    j += 1
                else:
                    break
            out[key] = items
            i = j
            continue
        # Inline list:
        if val_str.startswith("[") and val_str.endswith("]"):
            inner = val_str[1:-1].strip()
            if not inner:
                out[key] = []
            else:
                out[key] = [_parse_scalar(p.strip()) for p in _split_top_commas(inner)]
            i += 1
            continue
        out[key] = _parse_scalar(val_str)
        i += 1
    return out


def _parse_scalar(s: str) -> Any:
    s = s.strip()
    # Strip line comments only when not quoted.
    if not (s.startswith('"') or s.startswith("'")):
        if "#" in s:
            # Naive — comments after value require space before #.
            idx = s.find(" #")
            if idx >= 0:
                s = s[:idx].strip()
    if (s.startswith('"') and s.endswith('"')) or (s.startswith("'") and s.endswith("'")):
        return s[1:-1]
    # Try int/float — but ID-like strings (ENDPOINT-7) aren't numeric.
    if re.fullmatch(r"-?\d+", s):
        return int(s)
    if re.fullmatch(r"-?\d+\.\d+", s):
        return float(s)
    if s.lower() in ("true", "false"):
        return s.lower() == "true"
    if s.lower() in ("null", "~", ""):
        return None
    return s


def _split_top_commas(s: str) -> List[str]:
    """Split on commas not inside [[...]] or quotes."""
    parts: List[str] = []
    depth = 0
    in_q: Optional[str] = None
    cur: List[str] = []
    i = 0
    while i < len(s):
        c = s[i]
        if in_q:
            cur.append(c)
            if c == in_q:
                in_q = None
            i += 1
            continue
        if c in ('"', "'"):
            in_q = c
            cur.append(c)
            i += 1
            continue
        if c == "[" and i + 1 < len(s) and s[i + 1] == "[":
            depth += 1
            cur.append(s[i:i + 2])
            i += 2
            continue
        if c == "]" and i + 1 < len(s) and s[i + 1] == "]":
            depth = max(0, depth - 1)
            cur.append(s[i:i + 2])
            i += 2
            continue
        if c == "," and depth == 0:
            parts.append("".join(cur).strip())
            cur = []
            i += 1
            continue
        cur.append(c)
        i += 1
    if cur:
        parts.append("".join(cur).strip())
    return parts


def serialize_frontmatter(d: Dict[str, Any]) -> str:
    """Emit YAML for our restricted schema. Stable order: insertion order."""
    out: List[str] = ["---"]
    for k, v in d.items():
        out.append(f"{k}: {_emit_value(v)}")
    out.append("---")
    return "\n".join(out) + "\n"


def _emit_value(v: Any) -> str:
    if v is None:
        return "null"
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, (int, float)):
        return str(v)
    if isinstance(v, list):
        return "[" + ", ".join(_emit_value(x) for x in v) + "]"
    s = str(v)
    # Quote if it looks problematic for our parser:
    if "#" in s or s.startswith(("[", "{")) or s.strip() != s:
        s2 = s.replace('"', '\\"')
        return f'"{s2}"'
    return s


# ───────────────────────── Entities ─────────────────────────

# Heading: `### TYPE-N: title` (heading level 1-6; separator may be `:`/`-`/`—`/`–` or none)
_HEADING_RE = re.compile(
    r"^(?P<hashes>#{1,6})\s+(?P<id>[A-Z]+-\d+)\s*[:\-—–]?\s*(?P<title>.*)$"
)
_BULLET_RE = re.compile(r"^\s*[-*+]\s+([A-Za-z_][A-Za-z0-9_-]*)\s*[:=]\s*(.*)$")


@dataclass
class Entity:
    id: str  # may be a placeholder ("ENDPOINT-7") or real ("ENDPOINT-007")
    type: str
    n: int
    is_placeholder: bool
    title: str
    bullets: Dict[str, Any] = field(default_factory=dict)
    body: str = ""
    source_file: Optional[Path] = None
    heading_line: int = 0  # 1-based line number where heading starts
    end_line: int = 0      # 1-based line number where entity ends (exclusive)
    raw_heading: str = ""  # the original heading line incl. trailing newline
    raw_block: str = ""    # entire entity block (heading+bullets+body) verbatim


def _fenced_line_flags(lines: List[str]) -> List[bool]:
    """Mark lines that sit INSIDE a fenced code block (``` or ~~~), delimiter
    lines included. A `### ENTITY-N`-looking line quoted inside an evidence /
    finding / chain body must not be minted as a real entity, nor terminate the
    body that quotes it."""
    flags = [False] * len(lines)
    fence: Optional[str] = None
    for idx, raw in enumerate(lines):
        stripped = raw.lstrip()
        is_fence = stripped.startswith("```") or stripped.startswith("~~~")
        if fence is None:
            if is_fence:
                fence = stripped[:3]
                flags[idx] = True
        else:
            flags[idx] = True
            if is_fence and stripped.startswith(fence):
                fence = None
    return flags


def find_entities(body_text: str, source_file: Optional[Path] = None) -> List[Entity]:
    """Walk body, return entities in document order."""
    lines = body_text.splitlines(keepends=True)
    n = len(lines)
    in_code = _fenced_line_flags(lines)
    entities: List[Entity] = []
    i = 0
    while i < n:
        if in_code[i]:
            i += 1
            continue
        m = _HEADING_RE.match(lines[i].rstrip("\n"))
        if not m:
            i += 1
            continue
        id_ = m.group("id")
        parsed = parse_id(id_)
        if not parsed:
            i += 1
            continue
        type_, num, is_ph = parsed
        title = m.group("title").strip()
        heading_line = i + 1
        # Walk bullets:
        j = i + 1
        bullets: Dict[str, Any] = {}
        # Skip pure-blank lines BEFORE first bullet only if we want to tolerate?
        # Spec: "bullet block IMMEDIATELY under the heading" — strict. Blank line
        # ends the block. We accept a single blank line between heading and
        # first bullet for ergonomics.
        if j < n and not lines[j].strip():
            j += 1
        while j < n:
            ln = lines[j].rstrip("\n")
            if not ln.strip():
                # Blank line ends bullet block.
                break
            bm = _BULLET_RE.match(ln)
            if not bm:
                break
            key, val = bm.group(1), bm.group(2).strip()
            bullets[key] = _parse_bullet_value(val)
            j += 1
        # Body until next heading or EOF (a heading quoted inside a code fence
        # does not terminate the body):
        body_start = j
        while j < n:
            if not in_code[j] and _HEADING_RE.match(lines[j].rstrip("\n")):
                break
            j += 1
        body = "".join(lines[body_start:j]).strip("\n")
        ent = Entity(
            id=id_,
            type=type_,
            n=num,
            is_placeholder=is_ph,
            title=title,
            bullets=bullets,
            body=body,
            source_file=source_file,
            heading_line=heading_line,
            end_line=j + 1,
            raw_heading=lines[i],
            raw_block="".join(lines[i:j]),
        )
        entities.append(ent)
        i = j
    return entities


def _parse_bullet_value(s: str) -> Any:
    """Bullet values support inline lists, comma-separated wikilinks, and scalars."""
    s = s.strip()
    if not s:
        return ""
    if s.startswith("[") and s.endswith("]") and "[[" not in s:
        inner = s[1:-1].strip()
        if not inner:
            return []
        return [_parse_scalar(p.strip()) for p in _split_top_commas(inner)]
    # Comma-separated wikilinks: [[X]], [[Y]]
    if s.startswith("[[") and ("]]" in s):
        parts = _split_top_commas(s)
        if all(p.startswith("[[") and p.endswith("]]") for p in parts) and len(parts) > 1:
            return [_strip_wikilink(p) for p in parts]
        if len(parts) == 1 and parts[0].startswith("[[") and parts[0].endswith("]]"):
            return _strip_wikilink(parts[0])
    return _parse_scalar(s)


def _strip_wikilink(s: str) -> str:
    """`[[X]]` or `[[X|display]]` → `X`."""
    inner = s.strip()
    if inner.startswith("[[") and inner.endswith("]]"):
        inner = inner[2:-2]
    if "|" in inner:
        inner = inner.split("|", 1)[0]
    return inner.strip()


# ───────────────────────── Wikilinks ─────────────────────────

_WIKILINK_RE = re.compile(r"\[\[([^\[\]\|]+)(?:\|([^\[\]]+))?\]\]")


@dataclass
class WikilinkRef:
    target: str  # e.g. "ENDPOINT-7" or "admin-user-management"
    display: Optional[str]
    line: int
    col: int


def find_wikilinks(text: str) -> List[WikilinkRef]:
    refs: List[WikilinkRef] = []
    for line_no, ln in enumerate(text.splitlines(), start=1):
        for m in _WIKILINK_RE.finditer(ln):
            refs.append(WikilinkRef(
                target=m.group(1).strip(),
                display=(m.group(2).strip() if m.group(2) else None),
                line=line_no,
                col=m.start() + 1,
            ))
    return refs


# ───────────────────────── File model ─────────────────────────

@dataclass
class ParsedFile:
    path: Path                       # absolute path
    rel_path: str                    # relative to engagement root
    frontmatter: Dict[str, Any]
    body: str
    entities: List[Entity]
    raw: str                         # full original text


def parse_file(path: Path, eng_root: Path) -> ParsedFile:
    raw = path.read_text(encoding="utf-8")
    fm_text, body = split_frontmatter(raw)
    fm = parse_frontmatter(fm_text) if fm_text is not None else {}
    rel = str(path.relative_to(eng_root)).replace("\\", "/")
    ents = find_entities(body, source_file=path)
    return ParsedFile(path=path, rel_path=rel, frontmatter=fm, body=body, entities=ents, raw=raw)


def walk_engagement(eng_root: Path) -> Iterator[Path]:
    """Yield every .md file under the engagement, except the transient dirs `raw/`
    and `.drafts/`. Neither is committed kb: `raw/` holds scanner dumps, `.drafts/`
    holds uncommitted probe staging (placeholder IDs, pre-integrate layout). health,
    coverage and the index must not count them — they are noise until integrated."""
    for p in sorted(eng_root.rglob("*.md")):
        try:
            rel = p.relative_to(eng_root)
        except ValueError:
            continue
        first = rel.parts[0] if rel.parts else ""
        if first in ("raw", ".drafts"):
            continue
        yield p
