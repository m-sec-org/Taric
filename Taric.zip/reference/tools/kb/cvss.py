"""CVSS v3.x Base-score calculator — deterministic, spec-exact.

Used by `kb promote` so a finding's score is *computed from* its CVSS vector
rather than typed by hand (vector and score can never drift). Only the Base
metric group is implemented (Temporal/Environmental are out of scope). Accepts
`CVSS:3.0` and `CVSS:3.1` vectors; uses the v3.1 Roundup.

Reference: FIRST CVSS v3.1 Specification §7 (formulas) and Appendix A (Roundup).
"""
from __future__ import annotations

import math
from typing import Dict, Tuple

# Base metric coefficients (spec §7.4).
_AV = {"N": 0.85, "A": 0.62, "L": 0.55, "P": 0.20}
_AC = {"L": 0.77, "H": 0.44}
_UI = {"N": 0.85, "R": 0.62}
_CIA = {"H": 0.56, "L": 0.22, "N": 0.0}
# Privileges Required is scored relative to Scope.
_PR_UNCHANGED = {"N": 0.85, "L": 0.62, "H": 0.27}
_PR_CHANGED = {"N": 0.85, "L": 0.68, "H": 0.50}

_REQUIRED = ("AV", "AC", "PR", "UI", "S", "C", "I", "A")
_ALLOWED = {
    "AV": set(_AV), "AC": set(_AC), "PR": {"N", "L", "H"}, "UI": set(_UI),
    "S": {"U", "C"}, "C": set(_CIA), "I": set(_CIA), "A": set(_CIA),
}


def parse_vector(vector: str) -> Dict[str, str]:
    """Parse `CVSS:3.x/AV:N/...` into {metric: value} for the Base group.

    Raises ValueError on a bad version prefix, an unknown metric value, or a
    missing required Base metric. Non-Base metrics (E, RL, CR, …) are ignored.
    """
    if not isinstance(vector, str) or not vector.strip():
        raise ValueError("empty CVSS vector")
    parts = vector.strip().split("/")
    if parts[0].upper() not in ("CVSS:3.0", "CVSS:3.1"):
        raise ValueError(f"unsupported version prefix {parts[0]!r} (need CVSS:3.0/3.1)")
    metrics: Dict[str, str] = {}
    for seg in parts[1:]:
        if not seg:
            continue
        if ":" not in seg:
            raise ValueError(f"malformed metric segment {seg!r}")
        k, v = seg.split(":", 1)
        k, v = k.upper(), v.upper()
        if k in _ALLOWED:  # ignore non-Base metrics silently
            if v not in _ALLOWED[k]:
                raise ValueError(f"invalid value {v!r} for metric {k}")
            metrics[k] = v
    missing = [m for m in _REQUIRED if m not in metrics]
    if missing:
        raise ValueError(f"missing required Base metric(s): {', '.join(missing)}")
    return metrics


def _roundup(x: float) -> float:
    """CVSS v3.1 Roundup: the smallest 1-decimal number >= x (Appendix A)."""
    i = round(x * 100000)
    if i % 10000 == 0:
        return i / 100000.0
    return (math.floor(i / 10000) + 1) / 10.0


def base_score(vector: str) -> float:
    """Compute the CVSS Base score (0.0–10.0) from a vector string."""
    m = parse_vector(vector)
    scope_changed = m["S"] == "C"
    pr = (_PR_CHANGED if scope_changed else _PR_UNCHANGED)[m["PR"]]
    iss = 1 - (1 - _CIA[m["C"]]) * (1 - _CIA[m["I"]]) * (1 - _CIA[m["A"]])
    if scope_changed:
        impact = 7.52 * (iss - 0.029) - 3.25 * (iss - 0.02) ** 15
    else:
        impact = 6.42 * iss
    if impact <= 0:
        return 0.0
    expl = 8.22 * _AV[m["AV"]] * _AC[m["AC"]] * pr * _UI[m["UI"]]
    raw = 1.08 * (impact + expl) if scope_changed else (impact + expl)
    return _roundup(min(raw, 10.0))


def severity_band(score: float) -> str:
    """Map a Base score to the kb severity vocab (CVSS 'None' → 'info')."""
    if score <= 0:
        return "info"
    if score < 4.0:
        return "low"
    if score < 7.0:
        return "medium"
    if score < 9.0:
        return "high"
    return "critical"


def score_and_severity(vector: str) -> Tuple[float, str]:
    """Convenience: (base_score, severity_band) for a vector string."""
    s = base_score(vector)
    return s, severity_band(s)


# A syntactically valid Base vector, shown verbatim in the "CVSS is required"
# errors so the agent sees the exact format to supply. It is only an example of
# the shape — the writer must pick AV/AC/PR/UI/S/C/I/A to match the real finding.
EXAMPLE_VECTOR = "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H"


def required_error(where: str) -> str:
    """Uniform 'CVSS is required for a finding' message that also tells the
    agent exactly how to fix it. `where` selects the fix phrasing:
      - 'flag'        → pass the CLI flag (kb draft scaffold / kb promote)
      - 'frontmatter' → add the key to a hand-authored finding.md
    """
    if where == "flag":
        fix = f"pass --cvss-vector '{EXAMPLE_VECTOR}'"
    else:
        fix = (f"add a `cvss_vector: {EXAMPLE_VECTOR}` line to the finding "
               f"frontmatter (or re-scaffold with "
               f"`kb draft scaffold <dir> finding … --cvss-vector '<vector>'`)")
    return (
        "CVSS is required for a finding — " + fix + ". "
        "Choose AV/AC/PR/UI/S/C/I/A to match THIS finding; cvss_score is computed "
        "from the vector, while severity stays the explicit GB/T 30279 rating."
    )
