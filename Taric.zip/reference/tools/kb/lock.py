"""Engagement-level file lock for mutations.

Cooperative lock via a file at <eng>/.kb-lock containing the holder's PID.
Stale locks (PID dead) are cleared automatically. No fcntl — works on WSL/Win.
"""
from __future__ import annotations

import errno
import os
import time
from contextlib import contextmanager
from pathlib import Path

from .util import die


_DEFAULT_TIMEOUT_S = 30
_POLL_INTERVAL_S = 0.1


def _pid_alive(pid: int) -> bool:
    if pid <= 0:
        return False
    try:
        os.kill(pid, 0)
    except OSError as e:
        if e.errno == errno.ESRCH:
            return False
        if e.errno == errno.EPERM:
            return True  # exists but we lack permission to signal
        return False
    return True


def _read_lock(path: Path) -> int:
    try:
        s = path.read_text().strip()
        return int(s.split()[0]) if s else 0
    except (OSError, ValueError):
        return 0


def _try_acquire(path: Path) -> bool:
    """O_CREAT|O_EXCL — succeed iff lock didn't exist."""
    try:
        fd = os.open(str(path), os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o644)
    except FileExistsError:
        return False
    try:
        os.write(fd, f"{os.getpid()}\n".encode())
    finally:
        os.close(fd)
    return True


@contextmanager
def acquire(eng_root: Path, timeout_s: int = _DEFAULT_TIMEOUT_S):
    """Context manager acquiring the engagement lock."""
    lock_path = eng_root / ".kb-lock"
    deadline = time.time() + timeout_s
    while True:
        if _try_acquire(lock_path):
            break
        # Lock exists — check if holder is still alive.
        holder = _read_lock(lock_path)
        if holder and not _pid_alive(holder):
            try:
                lock_path.unlink()
            except OSError:
                pass
            continue
        if time.time() >= deadline:
            die(
                f"could not acquire engagement lock at {lock_path} "
                f"(held by pid {holder or '?'} for >{timeout_s}s)",
                code=1,
            )
        time.sleep(_POLL_INTERVAL_S)
    try:
        yield
    finally:
        try:
            lock_path.unlink()
        except OSError:
            pass


def clear_stale(eng_root: Path) -> bool:
    """Clear lock if holder PID is dead. Returns True if cleared."""
    lock_path = eng_root / ".kb-lock"
    if not lock_path.exists():
        return False
    holder = _read_lock(lock_path)
    if holder and _pid_alive(holder):
        return False
    try:
        lock_path.unlink()
        return True
    except OSError:
        return False
