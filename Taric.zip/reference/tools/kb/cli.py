"""Argparse dispatch for the kb CLI."""
from __future__ import annotations

import argparse
import sys
from typing import Optional

from . import ctx
from .util import die


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="kb", description="kb — pentest engagement wiki CLI")
    p.add_argument("--engagement", help="override the current engagement slug")
    p.add_argument("--profile", choices=["web", "host"], default=None,
                   help="coverage profile override (default: kb.profile marker, else web)")
    sub = p.add_subparsers(dest="verb", required=True)

    # init
    s = sub.add_parser("init", help="create a new engagement")
    s.add_argument("slug", nargs="?", default=None,
                   help="engagement slug (data/kb/<slug>/)")
    s.add_argument("--engagement", dest="engagement_alias", default=None,
                   help="alias for the positional slug (so `--engagement <slug>` also works)")
    s.add_argument("--target", help="base URL for the engagement", default=None)
    s.add_argument("--seed", action="append", default=None,
                   help="kind:value scope_in seed (repeatable; host engagements) — "
                        "e.g. --seed cidr:10.0.0.0/24 --seed domain:example.com")
    s.add_argument("--notes", help="freeform notes", default=None)
    s.add_argument("--primary-objective", dest="primary_objective", default=None,
                   help="lock the engagement to one business flow / area "
                        "(slug, e.g. 'login'); empty = full scope")
    s.add_argument("--force", action="store_true",
                   help="clear the current active engagement (DELETES its data) "
                        "and reinitialize in its place")

    # current
    cs = sub.add_parser("current", help="read or set the current engagement pointer")
    cs_sub = cs.add_subparsers(dest="action", required=True)
    cs_sub.add_parser("show", help="print the current engagement slug")
    cur_set = cs_sub.add_parser("set", help="switch the current engagement")
    cur_set.add_argument("slug")

    # state / stats
    st = sub.add_parser("state", help="orientation: counts, recent log")
    st.add_argument("--json", action="store_true")
    sts = sub.add_parser("stats", help="machine-readable counts")
    sts.add_argument("--json", action="store_true")  # always json; flag accepted for symmetry

    # target
    t = sub.add_parser("target", help="inspect or amend target.json")
    t_sub = t.add_subparsers(dest="action", required=True)
    t_sub.add_parser("show", help="print target.json")
    t_set = t_sub.add_parser("set", help="amend target.json")
    t_set.add_argument("--base-url", default=None)
    t_set.add_argument("--notes", default=None)
    t_set.add_argument("--primary-objective", dest="primary_objective", default=None,
                       help="set/change the Primary Objective Lock slug; "
                            "pass empty string to clear (full scope)")
    t_set.add_argument("--scope-in", default=None, help="comma-separated")
    t_set.add_argument("--scope-out", default=None, help="comma-separated")

    # engagement (mode settings on STATE.md ## Engagement)
    eg = sub.add_parser("engagement", help="set engagement-level modes on STATE.md ## Engagement")
    eg_sub = eg.add_subparsers(dest="action", required=True)
    eg_set = eg_sub.add_parser("set", help="set assessment / destructive-op / OTP-assist mode (any subset)")
    eg_set.add_argument("--assessment-mode", dest="assessment_mode", default=None,
                        choices=["full", "focused", "verified-scan"])
    eg_set.add_argument("--destructive-mode", dest="destructive_mode", default=None,
                        choices=["human-authorize", "auto-allow"])
    eg_set.add_argument("--otp-assist", dest="otp_assist", default=None,
                        choices=["assisted", "silent"])

    # scope
    sc = sub.add_parser("scope", help="scope membership check + runtime edits")
    sc_sub = sc.add_subparsers(dest="action", required=True)
    sc_c = sc_sub.add_parser("contains", help="exit 0 if target in scope, 3 if not")
    sc_c.add_argument("target", help="ip / cidr / hostname / fqdn / url")
    sc_c.add_argument("--strict-origin", action="store_true",
                      help="require an authorised HTTP(S) scheme/host/effective-port origin")
    sc_c.add_argument("--json", action="store_true")
    sc_a = sc_sub.add_parser("add", help="append a seed to scope_in / scope_out")
    sc_a.add_argument("--seed", required=True,
                      help="kind:value, e.g. cidr:10.0.0.0/24, domain:example.com")
    sc_grp = sc_a.add_mutually_exclusive_group()
    sc_grp.add_argument("--in", dest="in_", action="store_true",
                        help="add to scope_in (default)")
    sc_grp.add_argument("--out", action="store_true", help="add to scope_out")
    sc_a.add_argument("--json", action="store_true")

    # auth
    a = sub.add_parser("auth", help="auth records (credentials, sessions, captured)")
    a_sub = a.add_subparsers(dest="action", required=True)
    a_creds = a_sub.add_parser("credentials")
    a_creds.add_argument("--actor", required=True)
    a_creds.add_argument("--kind", default="password",
                         choices=["password", "ssh-key", "api-token", "kerb-ticket"],
                         help="credential kind (default password)")
    a_creds.add_argument("--user", default=None)
    a_creds.add_argument("--password", default=None)
    a_creds.add_argument("--token", default=None,
                         help="secret material for api-token / kerb-ticket kinds")
    a_creds.add_argument("--file", default=None,
                         help="path to key/credential file (ssh-key kind)")
    a_creds.add_argument("--email", default=None)
    a_creds.add_argument("--mobile", default=None)
    a_creds.add_argument("--note", default=None)
    a_cap = a_sub.add_parser("captured",
                             help="store target-side captured credential plaintext")
    a_cap.add_argument("--cred-id", dest="cred_id", required=True,
                       help="the CRED-N entity this plaintext backs")
    a_cap.add_argument("--file", required=True, help="path to the captured secret file")
    a_cap.add_argument("--note", default=None)
    a_sess = a_sub.add_parser("session")
    a_sess.add_argument("--actor", required=True)
    a_sess.add_argument("--cookie", default=None)
    a_sess.add_argument("--bearer", default=None)
    a_sess.add_argument("--header", action="append", default=None,
                        help="repeatable: 'Key: Value'")
    for action, help_text in (
        ("reserve", "exclusively reserve an actor for an auth-impacting task"),
        ("read-acquire", "acquire a shared actor lease for an authenticated read"),
        ("password-verified", "record an independently verified current password"),
        ("handover-required", "mark a verified password for customer handover"),
        ("mark-locked", "mark an actor unavailable after a login defense"),
        ("mark-unknown", "mark an actor credential state as unverified"),
        ("release", "release an untouched actor reservation"),
    ):
        state_action = a_sub.add_parser(action, help=help_text)
        state_action.add_argument("--actor", required=True)
        state_action.add_argument("--task", required=True)
        if action in {"reserve", "read-acquire"}:
            state_action.add_argument("--action", dest="auth_action", required=True,
                                       help="authenticated-read|bounded-login|password-change|password-reset|other auth impact")
        if action == "read-acquire":
            state_action.add_argument("--draft-dir", required=True,
                                       help="this probe's assigned draft directory; binds normal finalization")
        if action == "password-verified":
            state_action.add_argument("--password-stdin", action="store_true", required=True,
                                      help="read the password from stdin; never pass it as argv")
        if action in {"handover-required", "mark-locked", "mark-unknown"}:
            state_action.add_argument("--reason", required=True)
    a_show = a_sub.add_parser("show")
    a_show.add_argument("--actor", default=None)
    a_show.add_argument("--json", action="store_true")

    # pivot — shared, worker-writable store of reusable RUNNABLE artifacts.
    # Strict bar via required fields: must be a file (--file), tied to a real
    # target (--target), with a concrete way to run it (--run). No prose.
    ar_v = sub.add_parser("pivot", help="reusable operational artifacts (implant/transport/exploit)")
    ar_sub = ar_v.add_subparsers(dest="action", required=True)
    ar_add = ar_sub.add_parser("add", help="register a runnable artifact")
    ar_add.add_argument("--kind", required=True, choices=("implant", "transport", "exploit"))
    ar_add.add_argument("--file", required=True, help="path to the runnable artifact (script / re-deploy record)")
    ar_add.add_argument("--target", required=True, help="the asset/finding id (or host) it works against — no generic entries")
    ar_add.add_argument("--run", required=True, help="the exact command another worker runs to reuse it")
    ar_add.add_argument("--name", default=None, help="stable handle (default: file stem)")
    ar_add.add_argument("--desc", default=None, help="one line: what it does")
    ar_add.add_argument("--status", default="unverified", choices=("verified", "unverified", "stale", "blocked"))
    ar_add.add_argument("--needs", default=None, help="required creds/inputs BY auth/ reference — never plaintext")
    ar_add.add_argument("--task", default=None, help="the TASK-N that produced it")
    ar_add.add_argument("--force", action="store_true", help="overwrite an existing artifact of this name")
    ar_add.add_argument("--json", action="store_true")
    ar_list = ar_sub.add_parser("list", help="discover reusable artifacts")
    ar_list.add_argument("--kind", default=None, choices=("implant", "transport", "exploit"))
    ar_list.add_argument("--json", action="store_true")
    ar_show = ar_sub.add_parser("show", help="one artifact's metadata + path")
    ar_show.add_argument("name")
    ar_show.add_argument("--json", action="store_true")
    ar_set = ar_sub.add_parser("set", help="update an artifact's status / note")
    ar_set.add_argument("name")
    ar_set.add_argument("--status", default=None, choices=("verified", "unverified", "stale", "blocked"))
    ar_set.add_argument("--note", default=None)

    # asset — cross-session per-asset memory (raw notes + recall).
    # The durable consolidated files live OUTSIDE the workspace
    # (/data/asset-memory) and are written by the server-side consolidation
    # task; this verb group appends raw notes and reads/recalls.
    at = sub.add_parser("asset", help="cross-session asset memory (note/show/list/recall)")
    at_sub = at.add_subparsers(dest="action", required=True)
    at_note = at_sub.add_parser("note", help="append one durable fact about a target "
                                             "(one fact per note; never credentials)")
    at_note.add_argument("--target", required=True,
                         help="IP / dotted domain the fact is anchored to "
                              "(never a kb entity id like SERVICE-001)")
    at_note.add_argument("--category", required=True,
                         choices=("concept", "quirk", "dead-end", "auth-fact",
                                  "vuln-structure", "transport", "defense"),
                         help="memory category (see plan/skills)")
    at_note.add_argument("--statement", required=True,
                         help="one-sentence statement (8-600 chars); NO credentials")
    at_note.add_argument("--anchor", default="_asset",
                         help="service key / path prefix, e.g. tcp/8443 or /api/* (default _asset; "
                              "port-shaped (tcp/22) and path-shaped (/api/*) anchors are the ones "
                              "`show --narrow`/`--kind` can match; kb entity ids / asset-shaped "
                              "keys are rejected — use --evidence for entity refs)")
    at_note.add_argument("--evidence", default=None,
                         help="evidence reference, e.g. NOTE-3 or a pivot name")
    at_note.add_argument("--confidence", default="medium",
                         choices=("low", "medium", "high"))
    at_note.add_argument("--tag", action="append", default=None,
                         help="short tag (repeatable, max 6)")
    at_note.add_argument("--json", action="store_true")
    at_show = at_sub.add_parser("show", help="print an asset's memory digest")
    at_show.add_argument("--target", default=None)
    at_show.add_argument("--raw", action="store_true", help="dump raw entries as JSON")
    at_show.add_argument("--since", default=None,
                         help="only entries discovered after this ISO timestamp (with --raw)")
    at_show.add_argument("--json", action="store_true")
    at_show.add_argument("--anchor", action="append", default=None,
                         help="only anchor groups matching this glob (repeatable, "
                              "case-insensitive), e.g. 'tcp/*' or '/api/*'")
    at_show.add_argument("--narrow", action="store_true",
                         help="narrow to the --target's port/path (explicit or "
                              "scheme-implied, e.g. tcp/<port> anchors, path anchors "
                              "segment-matching); bare host/domain = full digest")
    at_show.add_argument("--kind", action="append", choices=("host", "web"), default=None,
                         help="only one face (repeatable): host = port-shaped anchors "
                              "(tcp/22), web = path-shaped anchors (/api/*)")
    at_list = at_sub.add_parser("list", help="list all remembered assets")
    at_list.add_argument("--json", action="store_true")
    at_sub.add_parser("recall", help="rebuild STATE.md `## Prior knowledge` index cards")

    # list
    ls = sub.add_parser("list", help="list entities")
    ls.add_argument("type", nargs="?", default=None,
                    help="entity type (omit for cross-type)")
    ls.add_argument("--filter", action="append", default=None,
                    help="repeatable: key=value or key=~regex")
    ls.add_argument("--include-archived", action="store_true")
    ls.add_argument("--json", action="store_true")

    # show
    sh = sub.add_parser("show", help="print entity body + frontmatter + refs")
    sh.add_argument("id", nargs="+", help="one or more entity/topic ids — batched in a single index build")
    sh.add_argument("--json", action="store_true")

    # find
    fd = sub.add_parser("find", help="fuzzy lookup over IDs / titles / slugs")
    fd.add_argument("query")
    fd.add_argument("--json", action="store_true")

    # schema — entity-creation field manual (how to shape any entity)
    sc = sub.add_parser("schema", help="how to create/shape any entity (run with no arg for the index)")
    sc.add_argument("topic", nargs="?", help="entity type or vocab topic (finding, evidence, hypothesis, class, …); omit for the index")
    sc.add_argument("--json", action="store_true")

    # grep
    gp = sub.add_parser("grep", help="content search across entity bodies (ID-anchored)")
    gp.add_argument("pattern", help="regex, matched case-insensitively")
    gp.add_argument("--type", default=None, help="restrict to one entity type (FINDING, NOTE, …)")
    gp.add_argument("--include-archived", action="store_true")
    gp.add_argument("--json", action="store_true")

    # plan (batch plan-tier writes)
    pl = sub.add_parser("plan", help="plan-tier batch ops")
    pl_sub = pl.add_subparsers(dest="action")
    pl_add = pl_sub.add_parser(
        "add",
        help="append a batch of hypotheses (each with its tasks) from JSON",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        description=(
            "Append a validated batch of hypotheses + tasks. Validates the WHOLE batch\n"
            "(writes nothing on any error — one fix pass), auto-links each task to its\n"
            "hypothesis, and assigns placeholder IDs. JSON envelope:\n"
            '  {"hypotheses": [\n'
            "     {title, targets: [ENTITY-ID | \"system-wide\"], class, severity_guess,\n"
            "      rationale, tasks: [{actions, playbook?, preconds?}]} ]}\n"
            "A bare [ ... ] is accepted as the hypotheses list. Unknown keys are ignored.\n"
            "web authz/idor/bola/rbac/business-logic hypotheses additionally REQUIRE the\n"
            "object-model bullets (object_type/owner_scope/operation/boundary/control/...).\n"
            "Full per-field contract + examples: `bin/kb schema hypothesis`."
        ),
    )
    pl_add.add_argument("file", nargs="?", default=None, help="JSON file path (omit or '-' = stdin)")
    pl_add.add_argument("--json", action="store_true", help="emit machine-readable JSON (added ids)")

    # pending
    pn = sub.add_parser("pending", help="open hypotheses + pending tasks")
    pn.add_argument("--json", action="store_true")

    # stale
    sa = sub.add_parser("stale", help="files with stale last_updated")
    sa.add_argument("--older-than", default="7d", help="duration like '7d' or '2w'")
    sa.add_argument("--json", action="store_true")

    # health
    h = sub.add_parser("health", help="lint the engagement tree")
    h.add_argument("--quiet", action="store_true", help="suppress the report; exit code only")
    h.add_argument("--json", action="store_true", help="emit machine-readable JSON (rules + counts)")

    # coverage
    cov = sub.add_parser("coverage", help="hypothesis-coverage matrix + reason exit gate")
    cov.add_argument("--json", action="store_true",
                     help="emit the full payload as JSON (schema: `bin/kb schema coverage`)")
    cov.add_argument("--quiet", action="store_true",
                     help="suppress output (use with --check)")
    cov.add_argument("--check", action="store_true",
                     help="gate-only mode: exit 0 if gate open, 3 if blocked")
    cov.add_argument("--focus", action="append", metavar="SLICE",
                     help="show only this slice's detail (repeatable): a workflow / "
                          "asset-type name, or universal|scenario|conditional|semantic|"
                          "orphans|leads|entity. The GAP OVERVIEW + SUMMARY + EXIT GATE "
                          "always stay global. Human view only; ignored with --json.")

    # commit
    c = sub.add_parser("commit", help="renumber placeholders, append log entry")
    c.add_argument("-m", "--message", action="append", required=True,
                   help="first -m is title; subsequent -m become body")
    c.add_argument("--no-renumber", action="store_true",
                   help="keep existing IDs; skip placeholder→real renumbering (rare)")
    c.add_argument("--json", action="store_true", help="emit machine-readable JSON (id renames)")

    # promote
    pr = sub.add_parser("promote", help="hypothesis → finding")
    pr.add_argument("hypothesis_id")
    pr.add_argument("--severity",
                    choices=["critical", "high", "medium", "low", "info"],
                    help="GB/T 30279 severity (required for findings; CVSS does not derive it)")
    pr.add_argument("--cvss-vector", default=None,
                    help="CVSS 3.x Base vector (REQUIRED for findings); computes cvss_score")
    pr.add_argument("--json", action="store_true")

    # archive
    ar = sub.add_parser("archive", help="sweep resolved entries to plan/archive/")
    grp = ar.add_mutually_exclusive_group()
    grp.add_argument("id", nargs="?", default=None,
                     help="explicit single entity to archive")
    grp.add_argument("--auto", action="store_true",
                     help="auto-sweep (default if no id)")
    ar.add_argument("--json", action="store_true")

    # verify
    v = sub.add_parser("verify", help="lightweight integrity check")
    v.add_argument("--quiet", action="store_true")
    v.add_argument("--fix", action="store_true",
                   help="rewrite counters from observed maxima on drift")

    # export
    sub.add_parser("export", help="generate .api/*.json for UI consumption")

    # status (per-entity status edits)
    ss = sub.add_parser("status", help="per-entity status edits")
    ss_sub = ss.add_subparsers(dest="action", required=True)
    ss_set = ss_sub.add_parser(
        "set",
        help="flip an entity's status (heading-bullet entities + FINDING triage, "
             "e.g. `kb status set FINDING-3 false-positive`)")
    ss_set.add_argument("id", help="real (non-placeholder) entity ID")
    ss_set.add_argument("value", help="new status value (validated against schema enum)")
    ss_set.add_argument("--json", action="store_true")

    # bullet (per-entity bullet edits)
    bl = sub.add_parser("bullet", help="per-entity bullet edits")
    bl_sub = bl.add_subparsers(dest="action", required=True)
    bl_app = bl_sub.add_parser("append", help="append one or more wikilinks to a bullet")
    bl_app.add_argument("id", help="real (non-placeholder) entity ID")
    bl_app.add_argument("key", help="bullet key (e.g. evidence, promoted_to, related)")
    bl_app.add_argument("wikilink", nargs="+",
                        help="one or more target IDs (e.g. EVIDENCE-3 [[EVIDENCE-4]])")
    bl_app.add_argument("--json", action="store_true")

    bl_set = bl_sub.add_parser("set",
                               help="set an arbitrary scalar bullet (e.g. coverage-skip, retire-reason)")
    bl_set.add_argument("id", help="real (non-placeholder) entity ID")
    bl_set.add_argument("key", help="bullet key (e.g. coverage-skip, coverage-block, retire-reason)")
    bl_set.add_argument("value", help="bullet value, written as-is. No wikilink validation.")
    bl_set.add_argument("--json", action="store_true")

    # draft (per-worker draft folder lifecycle)
    df = sub.add_parser("draft", help="per-worker draft folder lifecycle")
    df_sub = df.add_subparsers(dest="action", required=True)

    df_sc = df_sub.add_parser("scaffold", help="emit a skeleton file into a draft folder")
    df_sc.add_argument("draft_dir", help="draft folder path (e.g. .drafts/worker-probe-1)")
    df_sc.add_argument("kind", choices=["finding", "evidence", "handoff"],
                       help="skeleton to emit: finding (needs --hypothesis) | evidence | handoff")
    df_sc.add_argument("--hypothesis", default=None,
                       help="canonical HYPOTHESIS-NNN to seed the finding from (required for kind=finding)")
    df_sc.add_argument("--task", default=None,
                       help="TASK-NNN this handoff resolves (kind=handoff; seeds the `task` field)")
    df_sc.add_argument("--related-endpoint", dest="related_endpoint", default=None,
                       help="ENTITY-ID this evidence points at (kind=evidence; seeds `related_endpoint`)")
    df_sc.add_argument("--severity",
                       choices=["critical", "high", "medium", "low", "info"],
                       help="GB/T 30279 severity (required for findings; CVSS does not derive it)")
    df_sc.add_argument("--cvss-vector", default=None,
                       help="CVSS 3.x Base vector (REQUIRED for findings); computes cvss_score")
    df_sc.add_argument("--json", action="store_true")

    df_cm = df_sub.add_parser("commit", help="validate draft + stamp committed_at")
    df_cm.add_argument("draft_dir", help="draft folder path")
    df_cm.add_argument("--json", action="store_true")

    df_in = df_sub.add_parser("integrate", help="orchestrator-side: validate + atomic apply")
    df_in.add_argument("draft_dir", help="draft folder path")
    df_in.add_argument("--json", action="store_true")

    df_fa = df_sub.add_parser("fail", help="orchestrator-side: archive draft + write NOTE")
    df_fa.add_argument("draft_dir", help="draft folder path")
    df_fa.add_argument("--reason", required=True,
                       help="short text explaining why integration failed")
    df_fa.add_argument("--json", action="store_true")

    return p


def dispatch(args: argparse.Namespace) -> int:
    verb = args.verb

    if verb == "init":
        from .verbs.init import cmd_init
        return cmd_init(args)
    if verb == "current":
        from .verbs.init import cmd_current_show, cmd_current_set
        if args.action == "show":
            return cmd_current_show(args)
        return cmd_current_set(args)
    if verb == "state":
        from .verbs.state import cmd_state
        return cmd_state(args)
    if verb == "stats":
        from .verbs.state import cmd_stats
        return cmd_stats(args)
    if verb == "target":
        from .verbs.target import cmd_target_show, cmd_target_set
        return cmd_target_show(args) if args.action == "show" else cmd_target_set(args)
    if verb == "engagement":
        from .verbs.engagement import cmd_engagement_set
        return cmd_engagement_set(args)
    if verb == "scope":
        from .verbs.scope import cmd_scope_add, cmd_scope_contains
        return cmd_scope_contains(args) if args.action == "contains" else cmd_scope_add(args)
    if verb == "auth":
        from .verbs.auth import (
            cmd_auth_captured_add, cmd_auth_credentials, cmd_auth_lifecycle, cmd_auth_read_lease,
            cmd_auth_session, cmd_auth_show,
        )
        if args.action == "credentials":
            return cmd_auth_credentials(args)
        if args.action == "session":
            return cmd_auth_session(args)
        if args.action == "captured":
            return cmd_auth_captured_add(args)
        if args.action == "read-acquire":
            return cmd_auth_read_lease(args)
        if args.action in {"reserve", "password-verified",
                           "handover-required", "mark-locked", "mark-unknown", "release"}:
            return cmd_auth_lifecycle(args)
        return cmd_auth_show(args)
    if verb == "pivot":
        from .verbs.pivot import (
            cmd_pivot_add, cmd_pivot_list, cmd_pivot_set, cmd_pivot_show,
        )
        if args.action == "add":
            return cmd_pivot_add(args)
        if args.action == "list":
            return cmd_pivot_list(args)
        if args.action == "show":
            return cmd_pivot_show(args)
        return cmd_pivot_set(args)
    if verb == "asset":
        from . import asset_memory as am
        from .verbs.asset import (
            cmd_asset_disabled, cmd_asset_list, cmd_asset_note, cmd_asset_recall, cmd_asset_show,
        )
        # Family-level kill switch: PENTEST_ASSET_MEMORY=0 makes every sub-command a no-op.
        if not am.enabled():
            return cmd_asset_disabled(args)
        if args.action == "note":
            return cmd_asset_note(args)
        if args.action == "show":
            return cmd_asset_show(args)
        if args.action == "list":
            return cmd_asset_list(args)
        return cmd_asset_recall(args)
    if verb == "list":
        from .verbs.list_ import cmd_list
        return cmd_list(args)
    if verb == "show":
        from .verbs.show import cmd_show
        return cmd_show(args)
    if verb == "find":
        from .verbs.find import cmd_find
        return cmd_find(args)
    if verb == "schema":
        from .verbs.schema import cmd_schema
        return cmd_schema(args)
    if verb == "grep":
        from .verbs.grep import cmd_grep
        return cmd_grep(args)
    if verb == "plan":
        if args.action == "add":
            from .verbs.plan import cmd_plan_add
            return cmd_plan_add(args)
        from .util import die
        die("unknown plan action (use: plan add)", code=2)
    if verb == "pending":
        from .verbs.list_ import cmd_pending
        return cmd_pending(args)
    if verb == "stale":
        from .verbs.list_ import cmd_stale
        return cmd_stale(args)
    if verb == "health":
        from .verbs.health import cmd_health
        return cmd_health(args)
    if verb == "coverage":
        from .verbs.coverage import cmd_coverage
        return cmd_coverage(args)
    if verb == "commit":
        from .verbs.commit import cmd_commit
        return cmd_commit(args)
    if verb == "promote":
        from .verbs.promote import cmd_promote
        return cmd_promote(args)
    if verb == "archive":
        from .verbs.archive import cmd_archive
        return cmd_archive(args)
    if verb == "verify":
        from .verbs.verify import cmd_verify
        return cmd_verify(args)
    if verb == "export":
        from .verbs.export_ import cmd_export
        return cmd_export(args)
    if verb == "status":
        from .verbs.edit import cmd_status_set
        return cmd_status_set(args)
    if verb == "bullet":
        from .verbs.edit import cmd_bullet_append, cmd_bullet_set
        if args.action == "append":
            return cmd_bullet_append(args)
        if args.action == "set":
            return cmd_bullet_set(args)
        die(f"unknown bullet action: {args.action!r}", code=2)
    if verb == "draft":
        from .verbs.draft import (
            cmd_draft_scaffold, cmd_draft_commit,
            cmd_draft_integrate, cmd_draft_fail,
        )
        if args.action == "scaffold":
            return cmd_draft_scaffold(args)
        if args.action == "commit":
            return cmd_draft_commit(args)
        if args.action == "integrate":
            return cmd_draft_integrate(args)
        if args.action == "fail":
            return cmd_draft_fail(args)
        die(f"unknown draft action: {args.action!r}", code=2)
    die(f"unknown verb {verb!r}", code=2)
    return 2  # unreachable


def main(argv: Optional[list] = None) -> int:
    p = build_parser()
    args = p.parse_args(argv)
    from .profiles import set_profile_override
    set_profile_override(getattr(args, "profile", None))
    return dispatch(args)
