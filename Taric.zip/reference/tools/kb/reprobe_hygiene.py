"""Anti-re-probe reminder — a just-in-time `<system-reminder>` that flags a
pending/running probe whose root cause is ALREADY established, so the
orchestrator doesn't spend a probe (~17.5 min, run befba7df) re-testing it.

Why this exists (measured, run befba7df): the probe fleet re-tested the same
handful of root causes over and over — two sinks (`comn/service?sqlid=` and
`cms/template/save.json`) accounted for ~40% of all 188 pentest workers. Two
patterns drove it: (1) an escalation decomposed into a probe *per rung* on one
sink, and (2) a proven exploit re-run *per actor*. The static "don't re-probe"
prose in deepening.md §"去重" was present the whole run and did not prevent it.
So — like pool_hygiene.py (1fc9324) — the enforcement is a reminder computed
from kb data and surfaced at the decision sites, fresh each call:
  • `bin/kb pending`      — the "what to run next" query, right before dispatch.
  • `bin/kb list finding` — read at generation, before raising new probes.

Key: (root cause, class), where root cause = an endpoint's METHOD + path with the
query string dropped (see `_root`). This collapses a generic router's per-`sqlid`
endpoint entities — which OFCMS catalogs as separate `ENDPOINT-NNN` all sharing one
`path` — into one root cause, so proving it once flags every selector/actor/endpoint
variant. The reminder then defers the value judgment to the model: KEEP only if it
lifts the impact ceiling or is a genuinely different root cause / vuln class; DROP a
variation that changes only actor / selector / endpoint / field / a lower rung.

"Established" = a verified HYPOTHESIS or a FINDING on that (root cause, class).
"In-flight" = a pending/running TASK whose hypothesis targets it. A probe is flagged
when its (root cause, class) is already proven, or when two+ in-flight probes share it.
"""
from __future__ import annotations

import re
from typing import Dict, List, Optional, Tuple

from .index import build_index

Key = Tuple[str, str]  # (endpoint_id, class)
_MAX_LISTED = 8


def _ids(val) -> List[str]:
    """Clean id(s) from a bullet/frontmatter value (str or list), wikilinks and
    surrounding punctuation stripped. Parser strips wikilinks on heading-bullet
    entities; FINDING frontmatter may still carry `[[...]]`, so strip defensively."""
    if val is None:
        return []
    raw = val if isinstance(val, list) else [val]
    out: List[str] = []
    for item in raw:
        s = str(item).strip().strip("[]").strip()
        # split comma-joined ids that slipped through as one string
        for tok in re.split(r"[,\s]+", s):
            tok = tok.strip().strip("[]").strip()
            if re.fullmatch(r"[A-Z]+-\d+", tok):
                out.append(tok)
    return out


def _cls(val) -> str:
    return str(val).strip().lower() if val not in (None, "") else ""


def _root(idx, ep_id: str) -> str:
    """Endpoint entity id -> its root-cause locator: METHOD + path with the query
    string dropped. OFCMS-style generic routers catalog each `?sqlid=…` selector as
    a SEPARATE endpoint entity that all share one `path`; keying on METHOD+path
    collapses that whole selector family to one root cause (so proving it once flags
    the rest). Falls back to the entity id when method/path are absent."""
    e = idx.by_id.get(ep_id)
    if e is None:
        return ep_id
    method = str(e.bullets.get("method", "")).upper().strip()
    path = str(e.bullets.get("path", "")).split("?")[0].strip()  # drop ?sqlid=… selector
    return f"{method} {path}".strip() if path else ep_id


def _hyp_keys(idx, hyp_id: str) -> List[Key]:
    """(root cause, class) pairs a HYPOTHESIS covers — root cause = METHOD+path."""
    h = idx.by_id.get(hyp_id)
    if h is None:
        return []
    cls = _cls(h.bullets.get("class"))
    if not cls:
        return []
    return [(_root(idx, ep), cls) for ep in _ids(h.bullets.get("targets"))]


def _coverage(idx) -> Tuple[Dict[Key, List[str]], Dict[Key, List[str]]]:
    """Returns (proven, inflight): each maps (endpoint, class) -> list of the
    entity ids that establish / occupy it."""
    archived = idx.archived_entity_ids()
    proven: Dict[Key, List[str]] = {}
    inflight: Dict[Key, List[str]] = {}

    def add(d, key, ident):
        d.setdefault(key, [])
        if ident not in d[key]:
            d[key].append(ident)

    # Proven — verified hypotheses.
    for h in idx.by_type.get("HYPOTHESIS", []):
        if h.is_placeholder or h.id in archived:
            continue
        if h.bullets.get("status") == "verified":
            for k in _hyp_keys(idx, h.id):
                add(proven, k, h.id)

    # Proven — findings (class resolved via the linked hypothesis).
    for fdg in idx.by_type.get("FINDING", []):
        if fdg.is_placeholder or fdg.id in archived:
            continue
        hyp = _ids(fdg.bullets.get("hypothesis"))
        cls = _cls(idx.by_id[hyp[0]].bullets.get("class")) if hyp and hyp[0] in idx.by_id else ""
        if not cls:
            continue
        for ep in _ids(fdg.bullets.get("related_endpoints")):
            add(proven, (_root(idx, ep), cls), fdg.id)

    # In-flight — pending/running tasks, via their hypothesis.
    for t in idx.by_type.get("TASK", []):
        if t.is_placeholder or t.id in archived:
            continue
        if t.bullets.get("status") not in ("pending", "running"):
            continue
        for hyp in _ids(t.bullets.get("hypothesis")):
            for k in _hyp_keys(idx, hyp):
                add(inflight, k, t.id)

    return proven, inflight


def collisions(eng) -> List[dict]:
    """One record per in-flight probe whose (endpoint, class) is already proven
    or shared by another in-flight probe. Empty when nothing overlaps."""
    idx = build_index(eng)
    proven, inflight = _coverage(idx)
    out: List[dict] = []
    for (ep, cls), tasks in inflight.items():
        proof = proven.get((ep, cls), [])
        dup = len(tasks) > 1
        if not proof and not dup:
            continue
        out.append({
            "endpoint": ep, "class": cls, "tasks": tasks,
            "proven_by": proof, "duplicate_inflight": dup,
        })
    out.sort(key=lambda r: (r["endpoint"], r["class"]))
    return out


def banner(eng) -> Optional[str]:
    """`<system-reminder>` flagging likely re-probes, or None when nothing overlaps."""
    cols = collisions(eng)
    if not cols:
        return None
    lines = [
        "<system-reminder>",
        "Re-probe check — a pending/proposed probe targets a ROOT CAUSE (METHOD+path, class)",
        "that is already ESTABLISHED. Re-proving it adds no value (a duplicate finding, a parallel probe):",
    ]
    for r in cols[:_MAX_LISTED]:
        who = []
        if r["proven_by"]:
            who.append("verified by " + ", ".join(r["proven_by"]))
        if r["duplicate_inflight"]:
            who.append("also in-flight: " + ", ".join(r["tasks"]))
        lines.append(f"  • {r['endpoint']} / {r['class']}  ⟵ {'; '.join(who)}")
    if len(cols) > _MAX_LISTED:
        lines.append(f"  … and {len(cols) - _MAX_LISTED} more.")
    lines += [
        "Default = DROP. If the only difference from the verified finding is the ACTOR, the SELECTOR",
        "(another sqlid / object id / record), the ENDPOINT (same root cause), the FIELD, or a LOWER rung —",
        "it is NOT new value: do not raise/dispatch. Record the scope on the existing finding instead —",
        "add the endpoint to its related_endpoints; per-actor reach composes from the sweep tags (the finding's",
        "CVSS PR: = lowest-priv actor the sweep says reaches it). A systemic defect is ONE finding, endpoints listed.",
        "KEEP it ONLY if it (a) LIFTS the impact ceiling (a higher rung not yet proven — read→write→code-exec),",
        "or (b) is a genuinely DIFFERENT root cause / vuln class the finding does not entail. Say which.",
        "</system-reminder>",
    ]
    return "\n".join(lines)


def emit(eng) -> None:
    b = banner(eng)
    if b:
        print(b)
