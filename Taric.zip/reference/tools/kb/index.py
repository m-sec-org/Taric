"""Engagement-wide index built by walking the markdown tree.

Built fresh on every invocation — no cache. Engagement scale (hundreds of
entities, not thousands) makes this fast.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional

from .ctx import Engagement
from .parser import (
    Entity,
    ParsedFile,
    find_wikilinks,
    parse_file,
    parse_id,
    walk_engagement,
)


@dataclass
class Index:
    eng: Engagement
    files: List[ParsedFile] = field(default_factory=list)
    by_id: Dict[str, Entity] = field(default_factory=dict)            # real IDs only
    placeholders: Dict[str, Entity] = field(default_factory=dict)     # placeholder IDs
    by_type: Dict[str, List[Entity]] = field(default_factory=dict)
    topics: Dict[str, ParsedFile] = field(default_factory=dict)       # slug → file (wiki/<slug>.md)

    def all_entities(self) -> List[Entity]:
        out: List[Entity] = []
        for f in self.files:
            out.extend(f.entities)
        return out

    def archived_entity_ids(self) -> set:
        """IDs whose source file is under plan/archive/."""
        ids = set()
        for f in self.files:
            if f.rel_path.startswith("plan/archive/"):
                for e in f.entities:
                    ids.add(e.id)
        return ids

    def find_file_by_rel(self, rel: str) -> Optional[ParsedFile]:
        for f in self.files:
            if f.rel_path == rel:
                return f
        return None


def build_index(eng: Engagement) -> Index:
    idx = Index(eng=eng)
    for path in walk_engagement(eng.root):
        try:
            pf = parse_file(path, eng.root)
        except Exception as e:
            from .util import err
            err(f"warn: failed to parse {path}: {e}")
            continue
        idx.files.append(pf)
        # Topic page registration (wiki/<slug>.md, single level only):
        rel = pf.rel_path
        if rel.startswith("wiki/") and rel.endswith(".md") and "/" not in rel[len("wiki/"):]:
            slug = rel[len("wiki/"):-len(".md")]
            idx.topics[slug] = pf
        # Synthesize a virtual Entity for standalone-file entities
        # (finding / evidence). Their "declaration" is the frontmatter id.
        ftype = pf.frontmatter.get("type")
        fid = pf.frontmatter.get("id")
        if ftype in ("finding", "evidence") and isinstance(fid, str):
            parsed = parse_id(fid)
            if parsed:
                t, num, is_ph = parsed
                # Frontmatter doubles as the entity's bullet metadata.
                synthesized = Entity(
                    id=fid,
                    type=t,
                    n=num,
                    is_placeholder=is_ph,
                    title=str(pf.frontmatter.get("title", "")),
                    bullets=dict(pf.frontmatter),
                    body=pf.body,
                    source_file=path,
                    heading_line=0,
                    end_line=0,
                    raw_heading="",
                    raw_block=pf.raw,
                )
                # A finding / evidence file IS exactly one entity — its body is
                # content (repro prose, raw request/response), NOT a container of
                # entity declarations. Discard any `### TYPE-N` headings parsed
                # from the body (e.g. an `### ENDPOINT-028` quoted in a repro
                # section) so they don't pollute by_id / by_type and trip
                # per-entity gates against the wrong file (the finding, not the
                # real wiki endpoint).
                pf.entities = [synthesized]
        for e in pf.entities:
            if e.is_placeholder:
                idx.placeholders.setdefault(e.id, e)
            else:
                idx.by_id[e.id] = e
            idx.by_type.setdefault(e.type, []).append(e)
    return idx


# ───────────────────────── Inbound-ref discovery ─────────────────────────

def inbound_refs(idx: Index, target_id: str) -> List[Dict[str, str]]:
    """Find every reference to target_id across all files.

    Picks up both wikilinks `[[ID]]` in text/bullets/frontmatter, and bare ID
    occurrences in frontmatter list values like `related_endpoints: [ENDPOINT-7]`.
    """
    out: List[Dict[str, str]] = []
    for f in idx.files:
        # Frontmatter scan: any value that's a list containing the ID, or a scalar equal to it.
        for k, v in f.frontmatter.items():
            if isinstance(v, list):
                for item in v:
                    if isinstance(item, str) and item == target_id:
                        out.append({"id": _entity_anchor_id(f, target_id) or "(file)", "file": f.rel_path,
                                    "via": f"frontmatter {k}"})
            elif isinstance(v, str) and v == target_id:
                out.append({"id": _entity_anchor_id(f, target_id) or "(file)", "file": f.rel_path,
                            "via": f"frontmatter {k}"})
        # Wikilinks in body — entity heading_line is 1-based within body, so
        # scan body (not raw) to keep coordinates aligned.
        for ref in find_wikilinks(f.body):
            if ref.target == target_id:
                anchor = _enclosing_entity(f, ref.line)
                via = "body"
                if anchor:
                    # Bullet block is the lines immediately under the heading,
                    # before the first blank line.
                    via = "bullets" if ref.line <= anchor.heading_line + _bullet_block_size(f, anchor) else "body"
                out.append({
                    "id": (anchor.id if anchor else "(file)"),
                    "file": f.rel_path,
                    "via": via,
                })
        # Bare-ID references inside entity bullet values (already parsed):
        for e in f.entities:
            for k, v in e.bullets.items():
                if isinstance(v, list):
                    for item in v:
                        if isinstance(item, str) and item == target_id:
                            out.append({"id": e.id, "file": f.rel_path, "via": f"bullet {k}"})
                elif isinstance(v, str) and v == target_id:
                    out.append({"id": e.id, "file": f.rel_path, "via": f"bullet {k}"})
    # Deduplicate (same ref might be found via both wikilink and bullet scans):
    seen = set()
    uniq: List[Dict[str, str]] = []
    for r in out:
        key = (r["id"], r["file"], r["via"])
        if key in seen:
            continue
        seen.add(key)
        uniq.append(r)
    return uniq


def _enclosing_entity(f: ParsedFile, line_no: int) -> Optional[Entity]:
    last: Optional[Entity] = None
    for e in f.entities:
        if e.heading_line <= line_no:
            last = e
        else:
            break
    return last


def _bullet_block_size(f: ParsedFile, e: Entity) -> int:
    """Count consecutive bullet lines immediately under e's heading (within body)."""
    lines = f.body.splitlines()
    n = 0
    i = e.heading_line  # 0-based index into lines is heading_line; heading_line is 1-based start
    # Allow optional one blank between heading and first bullet:
    if i < len(lines) and not lines[i].strip():
        i += 1
        n += 1
    while i < len(lines) and lines[i].lstrip().startswith(("-", "*", "+")) and lines[i].strip():
        i += 1
        n += 1
    return n


def _entity_anchor_id(f: ParsedFile, target_id: str) -> Optional[str]:
    # If the frontmatter belongs to a finding/evidence file, the file's frontmatter
    # `id` is the natural anchor. Otherwise no anchor (it's a topic-page level reference).
    fid = f.frontmatter.get("id")
    return fid if isinstance(fid, str) else None
