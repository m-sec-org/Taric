"""Plan-file archive nudge — tell the agent to run `bin/kb archive` when an
active plan file has grown large AND is mostly closed.

Runs at the end of `kb commit` and `kb draft integrate` (the write-paths that
grow plan/), same hook as state_hygiene. Unlike state_hygiene it moves nothing:
closing timing carries dedup / coverage signal (an archived HYPOTHESIS is hidden
from `bin/kb list` and an archived skip-NOTE stops clearing a gap), so the sweep
is left to the agent's own `bin/kb archive` call — this only decides WHEN to nag.

Trigger is count-based, per file: an active plan file must hold more than
COUNT_THRESHOLD entities AND at least ARCHIVABLE_FRACTION of them must be
terminally closed (the exact `bin/kb archive --auto` signal — refuted / abandoned
/ verified+promoted HYPOTHESIS, done TASK). Both conditions guard against nagging
when there's little to reclaim or when the file is full of genuine open work.

Best-effort; never raises, so it cannot break a commit / integrate.
"""
from __future__ import annotations

from typing import List, Optional, Tuple

from .index import build_index

# Numeric thresholds (per active plan file). Tunable.
COUNT_THRESHOLD = 100         # more than this many active entries before nagging
ARCHIVABLE_FRACTION = 0.80    # ... and at least this share must be safely archivable

# (display label, entity type) for the two files that accumulate closed entries.
_PLAN_FILES = (("plan/hypotheses.md", "HYPOTHESIS"), ("plan/tasks.md", "TASK"))


def _active_counts(idx, etype: str) -> Tuple[int, int]:
    """(active_total, archivable) for etype. active = committed (non-placeholder),
    not-yet-archived entities; archivable = of those, how many `bin/kb archive
    --auto` would move (terminally closed — safe to remove, references still
    resolve by id, still counted by coverage)."""
    from .verbs.archive import _is_auto_archivable
    archived = idx.archived_entity_ids()
    total = archivable = 0
    for e in idx.by_type.get(etype, []):
        if e.is_placeholder or e.id in archived:
            continue
        total += 1
        if _is_auto_archivable(e):
            archivable += 1
    return total, archivable


def archive_banner(eng, idx=None) -> Optional[str]:
    """`<system-reminder>` when a plan file is > COUNT_THRESHOLD entries and
    >= ARCHIVABLE_FRACTION of them closed, else None."""
    if idx is None:
        idx = build_index(eng)
    rows: List[Tuple[str, int, int]] = []
    for label, etype in _PLAN_FILES:
        total, archivable = _active_counts(idx, etype)
        if total > COUNT_THRESHOLD and archivable >= ARCHIVABLE_FRACTION * total:
            rows.append((label, total, archivable))
    if not rows:
        return None
    out = [
        "<system-reminder>",
        f"plan file(s) past the archive threshold (>{COUNT_THRESHOLD} active entries, "
        f"≥{int(ARCHIVABLE_FRACTION * 100)}% closed) — plan/ is read + edited on the "
        "planning write-path, so a closed backlog taxes every planning turn:",
    ]
    for label, total, archivable in rows:
        pct = round(100 * archivable / total)
        out.append(f"  · {label}: {total} active, {archivable} ({pct}%) closed and safe to archive")
    out += [
        "Run `bin/kb archive` to sweep the closed entries into plan/archive/ before the "
        "next dispatch. Cheap + safe: archived entities still resolve by id and still count "
        "in coverage. This is the lightweight sweep — NOT the post-report `reason curation`.",
        "</system-reminder>",
    ]
    return "\n".join(out)


def emit(eng, idx=None) -> None:
    """Print the archive banner if a plan file is large + mostly-closed.
    Best-effort — never raises, so it cannot break a commit / integrate."""
    try:
        banner = archive_banner(eng, idx)
        if banner:
            print(banner)
    except Exception:
        pass
