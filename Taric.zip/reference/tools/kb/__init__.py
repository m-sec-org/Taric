"""kb — markdown wiki CLI for pentest engagements.

Spec: docs/framework-v2/cli-design.md and wiki-design.md.
"""
