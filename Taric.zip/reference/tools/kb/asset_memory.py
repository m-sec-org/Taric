"""Asset memory — cross-session per-asset knowledge store (filesystem client).

The store is split across TWO locations (mirrors server's store.ts):

    <workspace>/data/asset-memory/raw/<slug>.jsonl
                              append-only raw notes — written HERE by
                              ``kb asset note`` under an flock so concurrent
                              workers never tear a line. Workspace-scoped: the
                              session workspace is the only place a sandboxed
                              shell may write, and this dir dies with the
                              workspace — raw is the current session's backlog,
                              consolidated away at report time.
    /data/asset-memory/<project_id>/final/<slug>.{json,md}
                              canonical consolidated docs, written ONLY by the
                              server's consolidation task into the PERSISTENT
                              store — split into ONE FOLDER PER SESSION PROJECT
                              (the project-level isolation boundary; sessions
                              without a project_id land in ``default``).
                              Survives workspaces; read-only here for ``show`` /
                              ``recall`` / ``list``, which search ONLY the
                              current session's project folder.
    /data/asset-memory/<project_id>/state.json
                              project-scoped consolidation watermarks (server-owned)

project_id is NOT recorded inside memory files — it is carried by the folder.
It resolves from <workspace>/aipts.json (or ASSET_MEMORY_PROJECT env override).
Overrides: ``ASSET_MEMORY_DIR`` = persistent store base (default
``/data/asset-memory``); ``ASSET_RAW_DIR`` = workspace raw store — used by
hermetic tests/E2E where the runtime is not installed inside a workspace;
``PENTEST_ASSET_MEMORY=0`` = kill switch for the whole subsystem (the
``kb asset`` family goes inert and ``kb export`` emits an empty harvest) —
unset OR empty means enabled, so an empty value never disables memory.

There is no HTTP surface and none is needed: sessions run inside the same
host as the store. Fail-open discipline: a missing/unwritable store must
never block pentest work — callers get warnings on stderr, not exceptions.

Slug normalization lives HERE (mirrored coarsely by the TS side only as a
shape check). Pipeline: ``target_gate._host_kind`` canonicalizes any URL /
host:port / bare host / IP to (kind, value); the slug replaces every char
outside ``[a-z0-9.-]`` with ``-`` — colons become dashes so IPv6 literals
stay injective without breaking the slug charset.
"""
from __future__ import annotations

import fcntl
import fnmatch
import ipaddress
import json
import os
import re
import sys
import uuid
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple

from .schema import ENTITY_TYPES
from .target_gate import _host_kind

DEFAULT_DIR = "/data/asset-memory"
ENTRY_SCHEMA_VERSION = "asset-memory-entry/v1"

CATEGORIES = ("concept", "quirk", "dead-end", "auth-fact", "vuln-structure", "transport", "defense")
CONFIDENCES = ("low", "medium", "high")

# Mirrors SECRET_PATTERNS in src/services/assetMemory/store.ts — keep in sync.
SECRET_RE = re.compile(
    "|".join(
        pattern
        for pattern in (
            r"\b(?:pass(?:word|wd)?|pwd)\s*[:=]\s*\S+",
            r"\b(?:api[_-]?key|access[_-]?key|secret|token|bearer|apikey)\s*[:=]\s*\S+",
            r"\b(?:authorization|cookie|x-api-key|x-auth-token|x-csrf-token)\s*:\s*\S+",
            r"\beyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.",
            r"-----BEGIN [A-Z ]*PRIVATE KEY-----",
        )
    ),
    re.IGNORECASE,
)


# ── Configuration ────────────────────────────────────────────────────────

def project_dir_name(project_id: Optional[str]) -> str:
    """Filesystem-safe folder name for a project's memory slice (mirrors
    store.ts ``projectDirName`` — keep in sync). Sessions without a project_id
    land in ``default``."""
    raw = (project_id or "").strip().lower()
    cleaned = re.sub(r"[^a-z0-9._-]+", "-", raw).strip("-")
    return cleaned or "default"


def project_id() -> Optional[str]:
    """Resolve the session project: ASSET_MEMORY_PROJECT env override first
    (tests/E2E), else ``<workspace>/aipts.json`` project_id (written by the
    session registry at provisioning). Returns None when absent."""
    env = os.environ.get("ASSET_MEMORY_PROJECT")
    if env and env.strip():
        return env.strip()
    from .ctx import repo_root  # local import avoids import cycles

    try:
        data = json.loads((repo_root() / "aipts.json").read_text(encoding="utf-8"))
        pid = data.get("project_id")
        if isinstance(pid, str) and pid.strip():
            return pid.strip()
    except Exception:  # noqa: BLE001 — missing/corrupt file is just "no project"
        pass
    return None


def final_base() -> str:
    """Persistent consolidated store, scoped to the session project:
    ``<ASSET_MEMORY_DIR>/<project_dir_name(project_id())>``. Server-owned
    (final docs + state.json); the CLI only reads it. ASSET_MEMORY_DIR
    overrides the base (default /data/asset-memory)."""
    base = (os.environ.get("ASSET_MEMORY_DIR") or DEFAULT_DIR).rstrip("/") or DEFAULT_DIR
    return os.path.join(base, project_dir_name(project_id()))


def raw_base() -> str:
    """Workspace-scoped raw notes store. Default: <engagement-root>/data/asset-memory
    (the session workspace — the only place a sandboxed shell may write, and the
    dir the server-side consolidation reads back). ASSET_RAW_DIR overrides for
    hermetic tests/E2E, e.g. when the runtime is not installed inside a workspace."""
    env = os.environ.get("ASSET_RAW_DIR")
    if env:
        return env.rstrip("/") or env
    from .ctx import repo_root  # local import avoids import cycles

    return str(repo_root() / "data" / "asset-memory")


def enabled() -> bool:
    """Kill switch: ``0/false/no/off`` disables the whole subsystem.

    An unset OR empty value means enabled — deliberately unlike
    ``target_gate.enabled()``, which reads ``""`` as disabled: an accidental
    bare ``PENTEST_ASSET_MEMORY=`` export must not silently turn memory off."""
    return (os.environ.get("PENTEST_ASSET_MEMORY") or "1").strip().lower() not in (
        "0", "false", "no", "off",
    )


def warn(msg: str) -> None:
    try:
        print(f"[kb asset-memory] {msg}", file=sys.stderr)
    except Exception:  # noqa: BLE001 — warnings must never break anything
        pass


# ── Normalization ────────────────────────────────────────────────────────

def normalize_asset(value: str) -> Optional[Tuple[str, str]]:
    """URL / host:port / bare host / IP → ``(kind, canonical)`` or None."""
    return _host_kind(value)


def slugify(kind: str, value: str) -> str:
    """Canonical value → filesystem-safe slug. Colons → dashes keeps IPv6
    injective within the [a-z0-9.-] charset the TS side validates."""
    s = re.sub(r"[^a-z0-9.-]+", "-", str(value).lower())
    return s.strip("-")[:200] or f"{kind}-empty"


def resolve_slug(value: str) -> Optional[Tuple[str, str, str]]:
    """Any target-ish string → ``(slug, kind, canonical)`` or None.

    CIDR/range notation never reaches the anchor model on purpose — memory is
    kept for individual hosts/domains, matching the central target gate's rule
    (``_host_kind`` alone would silently strip ``/24`` and anchor to the bare
    network address, which no real asset ever carries).
    """
    if _looks_like_cidr(value):
        return None
    norm = normalize_asset(value)
    if not norm:
        return None
    kind, canonical = norm
    return slugify(kind, canonical), kind, canonical


def _looks_like_cidr(value: Any) -> bool:
    """True for IPv4/v6 network notations like ``10.0.0.0/24``. URLs carry
    path slashes too, so scheme'd inputs are exempt before the network parse."""
    s = str(value or "").strip().lower()
    if "://" in s or "/" not in s:
        return False
    try:
        ipaddress.ip_network(s, strict=False)
        return True
    except ValueError:
        return False


# ── Paths ────────────────────────────────────────────────────────────────

def raw_path(slug: str) -> str:
    return os.path.join(raw_base(), "raw", f"{slug}.jsonl")


def final_json_path(slug: str) -> str:
    return os.path.join(final_base(), "final", f"{slug}.json")


# ── Secret guard ─────────────────────────────────────────────────────────

def secret_leak(text: str) -> bool:
    return bool(SECRET_RE.search(text or ""))


# ── Anchor quality guard (write path) ────────────────────────────────────
#
# Anchors are the long-lived filter keys (`show --anchor/--kind/--narrow`),
# so the write path keeps them meaningful — mirrors the server's
# allowed-anchor discipline (`kb export` materials only ever carry `_asset` /
# proto-port / path anchors, and the consolidation fork may not invent
# anchors). Rejected here:
#   * kb entity ids (`SERVICE-001` …) — workspace-local, meaningless to a
#     future session, unlistable as a face; they belong in --evidence;
#   * asset-shaped keys (`10.0.0.5`, `app.example.com`) — that names a
#     target, not a face: asset-wide facts use `_asset`;
#   * anything outside the filterable charset (letters/digits/._-/*) — incl.
#     whitespace.
# The read side stays permissive on purpose: legacy raw lines must keep
# flowing until consolidation cleans them server-side.

_ENTITY_ID_RE = re.compile(r"^([A-Za-z]+)-(\d+)$")
_ANCHOR_CHARSET_RE = re.compile(r"^[A-Za-z0-9._/*-]+$")


def anchor_problem(anchor: str) -> Optional[str]:
    """Corrective message when an anchor is unusable as a long-lived filter
    key, else None. Enforced by ``build_note``."""
    m = _ENTITY_ID_RE.match(anchor)
    if m and m.group(1).upper() in ENTITY_TYPES:
        return (
            f"'{anchor}' 是 kb 实体 id,不是 anchor——实体 id 只在本工作区有效,"
            "对新会话毫无意义;请改用 <协议>/<端口>、/api路径前缀 或 _asset,实体引用放 --evidence"
        )
    if not _ANCHOR_CHARSET_RE.match(anchor):
        return (
            f"anchor 含不允许的字符(仅限字母/数字/._-/*):'{anchor}'——"
            "形如 tcp/8443、/api/* 或 _asset"
        )
    if not anchor.startswith("/"):
        head = anchor.split("/", 1)[0]
        host = _host_kind(head)
        if host and (host[0] == "ip" or "." in head):
            return (
                f"'{anchor}' 看起来是资产本身(IP/域名),不是资产的「面」——"
                "资产级事实用 _asset,单个服务用 <协议>/<端口>,某片api路径用 /前缀"
            )
    return None


# ── Append (the only write this client performs) ─────────────────────────

def build_note(
    value: str,
    category: str,
    statement: str,
    anchor: str = "_asset",
    evidence_ref: Optional[str] = None,
    confidence: str = "medium",
    tags: Optional[List[str]] = None,
    engagement: str = "",
) -> Tuple[str, Dict[str, Any]]:
    """Validate inputs and assemble one raw entry. Returns ``(slug, entry)`` —
    the entry carries NO per-entry ``asset`` field (entries always live in a
    per-asset container: ``raw/<slug>.jsonl`` here, the final doc's top-level
    ``asset`` after consolidation — duplicating it per entry was redundant).
    Raises ValueError on bad input (CLI turns that into exit 2 with a clear
    message)."""
    resolved = resolve_slug(value)
    if not resolved:
        raise ValueError(f"'{value}' 不像可归一化的主机/域名/IP 目标")
    slug, kind, canonical = resolved
    if kind == "domain" and "." not in canonical:
        # Recallability guard: scope seeds are IPs / FQDNs / CIDRs, so a
        # dotless single label can never satisfy `kb asset recall`'s scope
        # match — such a note is write-only noise. kb entity ids (SERVICE-001
        # …) normalize to exactly this shape; they belong in --evidence.
        raise ValueError(
            f"'{value}' 是单标签名,落不进任何 scope,记了也无法被 `kb asset recall` 召回"
            "——--target 须是 IP 或含点域名;kb 实体 id(如 SERVICE-001)不是资产,请放 --evidence"
        )
    if category not in CATEGORIES:
        raise ValueError(f"category 必须是 {'/'.join(CATEGORIES)}，得到 '{category}'")
    statement = (statement or "").strip()
    if len(statement) < 8 or len(statement) > 600:
        # Bounds mirrored end-to-end — the server's write path (store.ts
        # entrySchema) and the consolidation validate both accept 8–600, so a
        # note this client admits can never wedge the fork's staging check.
        raise ValueError("statement 长度须在 8–600 字符之间（一事一条）")
    if secret_leak(statement):
        raise ValueError(
            "statement 疑似包含凭据明文（口令/token/Cookie/header 值）——"
            "资产记忆只记事实不记材料，请改写为『（已脱敏）』式表述"
        )
    if confidence not in CONFIDENCES:
        raise ValueError(f"confidence 必须是 {'/'.join(CONFIDENCES)}")
    anchor = (anchor or "_asset").strip() or "_asset"
    if len(anchor) > 120:
        raise ValueError("anchor 过长(≤120 字符)，使用如 tcp/8443、/api/* 或 _asset")
    problem = anchor_problem(anchor)
    if problem:
        raise ValueError(problem)
    now = datetime.now(timezone.utc).isoformat()
    entry = {
        "id": uuid.uuid4().hex[:12],
        "schema": ENTRY_SCHEMA_VERSION,
        "category": category,
        "anchor": anchor,
        "statement": statement,
        "evidence_ref": evidence_ref,
        "confidence": confidence,
        "discovered_at": now,
        "last_confirmed": now,
        "source": {
            "engagement": engagement,
            "session": os.environ.get("KB_SESSION_ID") or None,
            "actor": os.environ.get("KB_ACTOR") or None,
        },
        "tags": [t.strip() for t in (tags or []) if t.strip()][:6],
    }
    return slug, entry


def append_notes(notes: List[Tuple[str, Dict[str, Any]]]) -> int:
    """Append pre-built ``(slug, entry)`` pairs to their slugs' jsonl files
    under flock.

    Returns the number appended. Never raises for I/O problems (fail-open):
    unwritable store → warning + 0. Only programming errors would raise.
    """
    if not notes:
        return 0
    by_slug: Dict[str, List[Dict[str, Any]]] = {}
    for slug, e in notes:
        by_slug.setdefault(slug, []).append(e)
    n = 0
    for slug, group in by_slug.items():
        path = raw_path(slug)
        try:
            os.makedirs(os.path.dirname(path), exist_ok=True)
            fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o644)
        except OSError as exc:
            warn(f"cannot append to {path}: {exc}")
            continue
        try:
            with os.fdopen(fd, "a", encoding="utf-8") as fh:
                fcntl.flock(fh.fileno(), fcntl.LOCK_EX)
                for e in group:
                    fh.write(json.dumps(e, ensure_ascii=False) + "\n")
                fh.flush()
                fcntl.flock(fh.fileno(), fcntl.LOCK_UN)
            n += len(group)
        except OSError as exc:
            warn(f"append failed for {slug}: {exc}")
    return n


# ── Reads (lock-free; torn tail lines are skipped) ───────────────────────

def read_final(slug: str) -> Optional[Dict[str, Any]]:
    try:
        data = json.loads(_read_file(final_json_path(slug)) or "")
        if isinstance(data, dict) and data.get("schema", "").endswith("/v1"):
            return data
    except Exception:  # noqa: BLE001
        pass
    return None


def read_raw(slug: str, since: Optional[str] = None,
             engagement: Optional[str] = None) -> List[Dict[str, Any]]:
    text = _read_file(raw_path(slug))
    out: List[Dict[str, Any]] = []
    if not text:
        return out
    lines = [ln for ln in text.splitlines() if ln.strip()]
    for i, line in enumerate(lines):
        try:
            e = json.loads(line)
        except json.JSONDecodeError:
            continue  # torn tail or damaged line — prefix stays trustworthy
        if since and str(e.get("discovered_at", "")) <= since:
            continue
        if engagement and e.get("source", {}).get("engagement") != engagement:
            continue
        out.append(e)
    return out


def list_assets() -> List[Dict[str, Any]]:
    final_dir = os.path.join(final_base(), "final")
    raw_dir = os.path.join(raw_base(), "raw")
    finals: Dict[str, Dict[str, Any]] = {}
    if os.path.isdir(final_dir):
        for name in sorted(os.listdir(final_dir)):
            if not name.endswith(".json"):
                continue
            doc = read_final(name[: -len(".json")])
            if doc:
                asset: Dict[str, Any] = doc["asset"]
                finals[asset["slug"]] = {
                    "asset_kind": asset.get("kind", ""),
                    "asset_value": asset.get("value", ""),
                    "entries_amount": len(doc.get("entries", []))
                }
    raw_counts: Dict[str, int] = {}
    if os.path.isdir(raw_dir):
        for name in sorted(os.listdir(raw_dir)):
            if not name.endswith(".jsonl"):
                continue
            raw_counts[name[: -len(".jsonl")]] = sum(
                1 for ln in (_read_file(os.path.join(raw_dir, name)) or "").splitlines()
                if ln.strip()
            )
    slugs = sorted(set(finals) | set(raw_counts))
    return [
        {
            "slug": s,
            "kind": finals.get(s, {}).get("asset_kind", ""),
            "value": finals.get(s, {}).get("asset_value") or s,
            "final_entries": finals.get(s, {}).get("entries_amount", 0),
            "raw_entries": raw_counts.get(s, 0),
        }
        for s in slugs
    ]


# ── Digest rendering (transient consumption — never persisted to STATE) ──

STALE_DAYS = 90
DIGEST_MAX_ENTRIES = 40
DIGEST_MAX_CHARS = 4000
CONF_WEIGHT = {"high": 3, "medium": 2, "low": 1}


def _entry_sort_key(e: Dict[str, Any]):
    """Confidence first (desc), recency second (desc)."""
    conf = CONF_WEIGHT.get(str(e.get("confidence")), 2)
    ts = _parse_iso(e.get("last_confirmed")) or 0.0
    return (-conf, -ts)


def _parse_iso(v: Any) -> Optional[float]:
    try:
        return datetime.fromisoformat(str(v).replace("Z", "+00:00")).timestamp()
    except Exception:  # noqa: BLE001
        return None


def stale_mark(e: Dict[str, Any], now: Optional[float] = None) -> str:
    ts = _parse_iso(e.get("last_confirmed"))
    if ts is None:
        return ""
    now = now or datetime.now(timezone.utc).timestamp()
    return "[stale] " if (now - ts) > STALE_DAYS * 86400 else ""


# ── Anchor selection for `kb asset show` (filters) ───────────────────────
#
# A filter spec is a list of ``(selector, value)`` tuples; ANY selector
# matching keeps a group (union), and the default ``_asset`` anchor is always
# kept — asset-wide priors (auth posture, WAF behavior, cred reuse) apply
# across every face. Selectors:
#   ("pattern", "tcp/*")    fnmatch glob over the anchor name,
#                           case-insensitive
#   ("port", 8080)          host-shaped anchors for that port
#                           (tcp/8080, ssl/8080 — any proto)
#   ("path", "/api/v2")     path-shaped anchors, segment-prefix either way
#   ("kind", "host"|"web")  the anchor's face — see anchor_shape
#
# Shape classification is shared by --narrow and --kind on purpose (one
# mental model, one classifier): host face = `head/<digits>` (tcp/22,
# ssl/443, udp/53); web face = leading "/" (/api/*); anything else
# (wordpress-admin, _asset) is unclassified and matches neither face —
# hidden under a filter but always disclosed in the footer, never dropped
# silently.

DEFAULT_ANCHOR = "_asset"


def anchor_shape(anchor: str) -> Optional[str]:
    """Anchor face: "host" (port-shaped), "web" (path-shaped), or None."""
    a = str(anchor or "").strip()
    if not a:
        return None
    if a.startswith("/"):
        return "web"
    if "/" in a:
        head, tail = a.rsplit("/", 1)
        if head and tail.isdigit():
            return "host"
    return None


def anchor_port(anchor: str) -> Optional[int]:
    """The port a host-shaped anchor encodes, else None. Path-shaped
    anchors are port-agnostic by design."""
    a = str(anchor or "").strip()
    if anchor_shape(a) != "host":
        return None
    return int(a.rsplit("/", 1)[-1])


def _path_segments(path: str) -> List[str]:
    return [s for s in str(path or "").strip().lower().split("/") if s]


def anchor_matches_path(anchor: str, path: str) -> bool:
    """Path-shaped anchor vs a target path — segment-prefix in EITHER
    direction (`/api/*` ↔ `/api/v2/users`, `/api/v2` ↔ `/api`), so both the
    broader area and a deeper pre-recorded path surface for their
    counterpart. `/ap` never matches `/api` (segment boundary). Trailing
    ``/`` and ``*`` are stripped before the comparison."""
    a = str(anchor or "").strip().lower()
    if not a.startswith("/"):
        return False
    a = a.rstrip("/*")
    if not a:
        return True  # anchor was "/" — site-level, applies to every path
    target = _path_segments(path)
    if not target:
        return False
    segs = _path_segments(a)
    n = min(len(segs), len(target))
    return segs[:n] == target[:n]


def anchor_matches_pattern(anchor: str, pattern: str) -> bool:
    """fnmatch glob over the anchor name, case-insensitive."""
    return fnmatch.fnmatchcase(
        str(anchor or "").strip().lower(), str(pattern or "").strip().lower()
    )


def anchor_matches_filters(anchor: str, filters: List[Tuple[str, Any]]) -> bool:
    """True when ANY selector matches this anchor."""
    for selector, value in filters:
        if selector == "pattern" and anchor_matches_pattern(anchor, value):
            return True
        if selector == "port" and anchor_port(anchor) == value:
            return True
        if selector == "path" and anchor_matches_path(anchor, value):
            return True
        if selector == "kind" and anchor_shape(anchor) == value:
            return True
    return False


def anchor_kept(anchor: str, filters: List[Tuple[str, Any]]) -> bool:
    """True when an anchor group survives selection: any selector matches,
    or the group is the default ``_asset`` anchor (cross-face priors are
    never filtered away), or no filter is active at all. Consumed by both
    the digest render and the ``--raw`` dump so the two stay in lockstep."""
    if not filters or str(anchor or "").strip() == DEFAULT_ANCHOR:
        return True
    return anchor_matches_filters(anchor, filters)


def _describe_filters(filters: List[Tuple[str, Any]]) -> str:
    parts: List[str] = []
    for selector, value in filters:
        if selector in ("port", "kind"):
            parts.append(f"{selector}={value}")
        else:
            parts.append(f"{selector}='{value}'")
    return ", ".join(parts)


def render_digest(doc: Dict[str, Any], filters: Optional[List[Tuple[str, Any]]] = None) -> str:
    """Human digest of one final doc — verify-first framing, capped size.

    Refuted entries never render here: they are tombstones for the record
    (see final .md), not prior knowledge to re-verify — showing them as
    hypotheses would push sessions to re-chase disproven claims.

    ``filters`` narrows the render to the matching anchor groups plus
    ``_asset``; the 40-entry / 4000-char caps then apply INSIDE that
    selection — deeper visibility for the groups actually asked about is the
    point of narrowing. Hidden groups and a zero-match roster are always
    disclosed (footer / header hint), so a filtered view can never be
    mistaken for "nothing else known". No filters → output is byte-identical
    to the unfiltered digest.
    """
    slug = doc.get('asset', {}).get('slug', '<该资产>')
    entries, refuted = [], []
    for entry in doc.get("entries", []):
        if str(entry.get("status", "active")) != "refuted":
            entries.append(entry)
        else:
            refuted.append(entry)

    active = filters or []
    pool = [e for e in entries if anchor_kept(str(e.get("anchor", DEFAULT_ANCHOR)), active)]
    ranked = sorted(pool, key=_entry_sort_key)[:DIGEST_MAX_ENTRIES]
    groups: Dict[str, List[Dict[str, Any]]] = {}
    for e in ranked:
        groups.setdefault(str(e.get("anchor", DEFAULT_ANCHOR)), []).append(e)

    lines = [
        f"# 资产记忆 digest — {doc.get('asset', {}).get('value', '?')}",
        "> 跨会话历史先验，为待复核假设，以本次实测为准；[stale] 条目须先廉价复核再用。",
    ]
    hidden_by_filter: List[str] = []
    matched: List[str] = []
    if active:
        all_anchors = sorted(
            {str(e.get("anchor", DEFAULT_ANCHOR)) for e in entries},
            key=lambda a: (a != DEFAULT_ANCHOR, a),
        )
        matched = [a for a in all_anchors if anchor_matches_filters(a, active)]
        lines.append(f"> filter: {_describe_filters(active)}(`_asset` always included)")
        if all_anchors and not matched:
            names = [a for a in all_anchors if a != DEFAULT_ANCHOR]
            roster = ", ".join(names[:10]) + ("…" if len(names) > 10 else "")
            lines.append(f"> filter 未命中任何 anchor;该资产现有anchor: {roster}")
        hidden_by_filter = [a for a in all_anchors if not anchor_kept(a, active)]
    lines.append("")
    body_budget = DIGEST_MAX_CHARS
    kept = 0
    for anchor in sorted(groups, key=lambda a: (a != DEFAULT_ANCHOR, a)):
        lines.append(f"## {anchor}")
        for e in groups[anchor]:
            # evidence_ref is meaningless to a new session — not rendered here.
            ts = str(e.get("last_confirmed", ""))[:10]
            line = (
                f"- [{e.get('category')}/{e.get('confidence')}] "
                f"{stale_mark(e)}{e.get('statement')} ({ts})"
            )
            if len(line) + 1 > body_budget:
                break
            lines.append(line)
            body_budget -= len(line) + 1
            kept += 1
        lines.append("")
    final_path = f"{final_base()}/{slug}.md"
    if kept < len(pool):
        hidden = len(pool) - kept
        lines.append(f"…另有 {hidden} 条未展示 → See `{final_path}` if needed(may be large, read it gradually)")
    if hidden_by_filter and matched:
        shown = ", ".join(hidden_by_filter[:3]) + ("…" if len(hidden_by_filter) > 3 else "")
        lines.append(f"…filter 隐藏 {len(hidden_by_filter)} 组({shown})")
    if refuted:
        most_recent = max(refuted, key=lambda e: _parse_iso(e.get("refuted_at")) or 0.0)
        when = str(most_recent.get("refuted_at") or most_recent.get("last_confirmed", ""))[:7]
        lines.append(
            f"~{len(refuted)} 条已失效(最近: {when} <{_brief(most_recent)}>)"
            f"——完整坟场见 {final_path} 的「已失效」节"
        )
    return "\n".join(lines).rstrip() + "\n"


def _brief(e: Dict[str, Any], width: int = 40) -> str:
    s = re.sub(r"\s+", " ", str(e.get("statement", ""))).strip()
    return s[:width] + ("…" if len(s) > width else "")


# ── helpers ──────────────────────────────────────────────────────────────

def _read_file(path: str) -> Optional[str]:
    try:
        with open(path, encoding="utf-8") as fh:
            return fh.read()
    except OSError:
        return None
