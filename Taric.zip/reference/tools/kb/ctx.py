"""Engagement context: locating the engagement directory.

Resolution order:
  1. --engagement <slug> on the CLI (caller passes via override)
  2. KB_ENGAGEMENT env var
  3. data/kb/.current pointer file
"""
from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from typing import Optional


_MODULE_ANCHORED_ROOT = Path(__file__).resolve().parents[2]


def repo_root() -> Path:
    """Locate the engagement root.

    Anchored to this module's install location: `tools/kb/ctx.py` sits at
    `<engagement-root>/tools/kb/ctx.py`, so `parents[2]` is the engagement
    root. Each `/install` copies the runtime wholesale, so the module's own
    path is the authoritative anchor — immune to cwd drift, env vars, or
    nested `data/kb/` ancestors from another session.
    """
    return _MODULE_ANCHORED_ROOT


def kb_root() -> Path:
    return repo_root() / "data" / "kb"


def current_pointer() -> Path:
    return kb_root() / ".current"


def read_current() -> Optional[str]:
    p = current_pointer()
    if not p.exists():
        return None
    s = p.read_text().strip()
    return s or None


def write_current(slug: str) -> None:
    root = kb_root()
    root.mkdir(parents=True, exist_ok=True)
    current_pointer().write_text(slug + "\n")


def clear_current() -> None:
    """Remove the current-engagement pointer (no-op if unset)."""
    p = current_pointer()
    if p.exists():
        p.unlink()


@dataclass
class Engagement:
    slug: str
    root: Path  # data/kb/<slug>/

    @property
    def target_json(self) -> Path:
        return self.root / "target.json"

    @property
    def state_md(self) -> Path:
        return self.root / "STATE.md"

    @property
    def index_md(self) -> Path:
        return self.root / "index.md"

    @property
    def log_md(self) -> Path:
        return self.root / "log.md"

    @property
    def events_jsonl(self) -> Path:
        return self.root / "events.jsonl"

    @property
    def auth_dir(self) -> Path:
        return self.root / "auth"

    @property
    def wiki_dir(self) -> Path:
        return self.root / "wiki"

    @property
    def plan_dir(self) -> Path:
        return self.root / "plan"

    @property
    def plan_archive_dir(self) -> Path:
        return self.root / "plan" / "archive"

    @property
    def record_dir(self) -> Path:
        return self.root / "record"

    @property
    def findings_dir(self) -> Path:
        return self.root / "record" / "findings"

    @property
    def evidence_dir(self) -> Path:
        return self.root / "record" / "evidence"

    @property
    def raw_dir(self) -> Path:
        return self.root / "raw"

    @property
    def pivot_dir(self) -> Path:
        return self.root / "pivot"

    @property
    def report_dir(self) -> Path:
        return self.root / "report"

    @property
    def lock_file(self) -> Path:
        return self.root / ".kb-lock"


def dispatch_id() -> Optional[str]:
    """The dispatching subagent's id, from the KB_DISPATCH_ID env var, or None.

    The harness sets this in a subagent's shell environment (it is NOT passed by
    the agent). Recorded on commit/integrate events so the subagent-timeline UI
    can attribute each entity to the subagent that created/touched it. Absent
    for the main agent or non-subagent invocations.
    """
    v = os.environ.get("KB_DISPATCH_ID")
    return v.strip() if v and v.strip() else None


def resolve(slug_override: Optional[str] = None) -> Optional[Engagement]:
    """Find the active engagement. Returns None if no engagement is set."""
    if slug_override:
        slug = slug_override
    elif os.environ.get("KB_ENGAGEMENT"):
        slug = os.environ["KB_ENGAGEMENT"]
    else:
        slug = read_current()
    if not slug:
        return None
    root = kb_root() / slug
    if not root.exists():
        return None
    return Engagement(slug=slug, root=root)


def require(slug_override: Optional[str] = None) -> Engagement:
    """Like resolve() but die with code 2 if no engagement is active."""
    eng = resolve(slug_override)
    if eng is None:
        from .util import die
        die(
            "no current engagement (run `kb init <slug>` or `kb current set <slug>` "
            "or pass --engagement <slug>)",
            code=2,
        )
    return eng
