"""Coverage profile interface — the swappable web/host taxonomy.

A `Profile` holds everything `coverage.py` + `health.py` need that differs by
engagement kind (web vs host): the per-entity gated types, the rollup taxonomy
(OWASP for web, ATT&CK tactics for host), the universal-check and scenario
checklists, the coverage-skip/block category regex, the per-entity display
bullets, the JSON key names, and the reason-facing hints.

`coverage.py` is taxonomy-blind: it reads these fields and never names a web
construct directly. `web.py` reproduces today's exact behavior; `host.py`
supplies host data. Selection lives in `__init__.py` (`active_profile()`).
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Optional, Pattern, Tuple


@dataclass(frozen=True)
class Profile:
    name: str                                   # "web" | "host"

    # Per-entity gate: which wiki entity types must each carry coverage.
    gated_entity_types: Tuple[str, ...]

    # Rollup taxonomy. web: OWASP cat -> tag set. host: ATT&CK tactic -> tag set.
    rollup_to_tags: Dict[str, frozenset]
    rollup_order: Tuple[str, ...]               # display / iteration order
    rollup_label: str                           # human header, e.g. "OWASP" / "ATT&CK"
    breakdown_key: str                          # per-entity JSON field, e.g. "owasp_breakdown"
    rollup_cat_key: str                         # blocked-list cats field, e.g. "owasp" / "tactics"

    # coverage-skip / coverage-block category regex — two groups: (cat, reason).
    cov_item_re: Pattern

    # Per-entity display bullets, shown in the human row + emitted in JSON.
    display_bullets: Tuple[str, ...]

    # Static checklists (opaque dicts; builders match by slug / class).
    universal_checks: Tuple[dict, ...]
    scenarios: Tuple[dict, ...]

    # Reason-facing hints.
    hint_human: str
    hints_json: Tuple[dict, ...]

    # Gated entity types that must be covered by a SPECIFIC hypothesis `class:`.
    # Each pair is (entity_type, required_class). For such a type, a hypothesis of
    # any OTHER class targeting the entity does NOT satisfy its per-entity gate —
    # only a matching-class hypothesis (or an explicit coverage-skip /
    # coverage-block) does. e.g. host WEBAPP → `web-app-pentest`: a webapp is only
    # covered once it carries a delegation hypothesis, not a stray host-class one.
    # Empty = every gated type is satisfied by any hypothesis (web behavior).
    required_hyp_class: Tuple[Tuple[str, str], ...] = ()

    # Copy-paste worked examples per gap kind, shown in `kb coverage` human output
    # for the gap types currently present (see coverage.py _render_human). Ordered
    # (kind, example_text) pairs; kind ∈ per-entity | universal | conditional |
    # scenario | orphan | follow-up-lead. Empty = no examples shown. These carry
    # the taxonomy-specific tag / class / category vocab so coverage.py stays blind.
    gap_examples: Tuple[Tuple[str, str], ...] = ()

    # GAP OVERVIEW per-entity grouping axis. `overview_group_field` is the wiki
    # FILE frontmatter key coverage reads to bucket each entity (web: `workflow`
    # = logical area; host: `service_class` = web / smb-ad / db / …). An entity
    # with no such frontmatter falls back to its entity type. `overview_group_label`
    # just names the axis for humans. File-splitting, coverage slicing (--focus)
    # and the planning fan-out unit all follow this one label.
    overview_group_field: str = "workflow"
    overview_group_label: str = "workflow"

    # Per-endpoint sweep-membership tags (see validators/sweep_tags.py). Every
    # ENDPOINT must carry each of these at commit; coverage keeps the matching
    # sweep's universal check open until every tagged endpoint is disposed. A
    # universal check binds to its tag via the check dict's `endpoint_tag`. Empty
    # = the profile has no per-endpoint sweep tags (host).
    sweep_endpoint_tags: Tuple[str, ...] = ()

    # Optional profile-specific semantic inventory advisory. None disables it.
    semantic_inventory_note_type: Optional[str] = None
    semantic_inventory_label: str = ""
    semantic_inventory_slot_keys: Tuple[str, ...] = ()
    semantic_inventory_patterns: Tuple[str, ...] = ()

    @property
    def tag_to_rollup(self) -> Dict[str, str]:
        return {tag: cat for cat, tags in self.rollup_to_tags.items() for tag in tags}

    @property
    def required_hyp_class_map(self) -> Dict[str, str]:
        """entity_type -> required hypothesis `class:` (see required_hyp_class)."""
        return {etype: cls for etype, cls in self.required_hyp_class}
