"""Coverage-profile selection.

Resolution order (see docs/framework-host/overview.md §13.1.1):
  1. explicit override — `kb --profile web|host` (set by cli.main)
  2. `kb.profile` marker file at the workspace root (shipped by the runtime)
  3. default `web` — back-compat: existing engagements have no marker

The marker lives OUTSIDE the shared `tools/kb/` tree (which is symlinked into
both runtimes, so both profile modules are always present). The selector is the
workspace-root file, not which module exists.
"""
from __future__ import annotations

from typing import Optional

from .base import Profile
from .host import HOST
from .web import WEB

_REGISTRY = {"web": WEB, "host": HOST}
_DEFAULT = "web"
_override: Optional[str] = None


def profile_names() -> tuple:
    return tuple(sorted(_REGISTRY))


def set_profile_override(name: Optional[str]) -> None:
    """Record an explicit `--profile` choice (None clears it). Validated here so
    a bad value fails fast at CLI parse time, not deep inside a builder."""
    global _override
    if name is not None and name not in _REGISTRY:
        from ..util import die
        die(f"unknown profile {name!r} (choices: {', '.join(profile_names())})", code=2)
    _override = name


def _read_marker() -> Optional[str]:
    from .. import ctx
    try:
        val = (ctx.repo_root() / "kb.profile").read_text(encoding="utf-8").strip().lower()
    except OSError:
        return None
    return val or None


def resolve_profile_name() -> str:
    if _override:
        return _override
    marker = _read_marker()
    if marker is not None:
        if marker not in _REGISTRY:
            from ..util import die
            die(f"kb.profile names unknown profile {marker!r} "
                f"(choices: {', '.join(profile_names())})", code=2)
        return marker
    return _DEFAULT


def active_profile() -> Profile:
    return _REGISTRY[resolve_profile_name()]
