"""Host coverage profile — ATT&CK rollup + host entity gate.

Data is drawn from docs/framework-host/overview.md: §4 (5 entities), §5.3
(ATT&CK-tactic rollup + host tag vocab), §7.2 (host hypothesis classes), §9
(starter playbooks). The universal-check and scenario checklists are
**provisional** — the design doc fixed the rollup and entity model but left the
exact host checklists to implementation; tune them freely, they are pure data.

A tag maps to exactly one tactic (tag_to_rollup is flat — duplicates would let
the last writer win), so each host tag below appears under a single tactic.
"""
from __future__ import annotations

import re

from .base import Profile


# ───────────────────────── ATT&CK rollup ─────────────────────────
# Tactic slug -> host `tags:` it covers. View only (does not gate).

_ATTACK_TO_TAGS = {
    "recon": frozenset({
        "exposed-mgmt-port", "mgmt-on-public-iface", "default-snmp-community",
        "telnet-exposed", "ssh-weak-cipher",
    }),
    "initial-access": frozenset({
        "default-credentials", "weak-credentials", "anonymous-access",
        "unauthenticated-rce", "public-cve",
        "unauth-redis", "unauth-mongo", "unauth-elasticsearch",
        "unauth-jenkins", "unauth-docker-api",
        "ftp-anon", "smtp-open-relay",
    }),
    "cred-access": frozenset({"kerberoast", "asreproast", "dcsync"}),
    "lateral": frozenset({"smb-relay", "pass-the-hash"}),
    "priv-esc": frozenset({"patch-missing", "eol-os"}),
}


# ───────────────────────── Universal checks (system-wide hygiene) ─────────────────────────
# Provisional. Matched by slug tokens against `targets: system-wide` hypotheses.

_UNIVERSAL_CHECKS = (
    {"id": 1, "name": "Weak / exposed protocols (telnet, ftp-anon, smtp-relay)",
     "slug": "weak-protocols", "attack": "recon"},
    {"id": 2, "name": "Default SNMP community strings",
     "slug": "default-snmp", "attack": "recon"},
    {"id": 3, "name": "Management ports on public interface",
     "slug": "mgmt-public-iface", "attack": "recon"},
    {"id": 4, "name": "Missing patches / EOL operating systems",
     "slug": "patch-eol", "attack": "priv-esc"},
    {"id": 5, "name": "Anonymous / unauthenticated service sweep",
     "slug": "unauth-services", "attack": "initial-access"},
    {"id": 6, "name": "Weak TLS / cipher configuration",
     "slug": "weak-tls", "attack": "recon"},
    {"id": 7, "name": "Template-based poc-scan sweep across hosts",
     "slug": "poc-scan", "attack": "initial-access",
     # Lifecycle gate: the whole-scope sweep must actually run + be analyzed, so a
     # bare untested hypothesis is still a gap (see coverage.build_universal_block).
     "require_tested": True,
     "hint": ("verify a whole-scope poc-scan was created and its result "
              "collected/analyzed; clears only when this hypothesis reaches "
              "tested (untested does not count)")},
)


# ───────────────────────── Scenarios (playbook-backed attack classes) ─────────────────────────
# Mirrors web's playbook scenarios; slugs == host hypothesis `class` values (§7.2)
# and map to starter playbooks (§9). Covered by a `class: <slug>` hypothesis,
# skipped via a `scenario-skip: <slug>` NOTE.

_SCENARIOS = (
    {"id": 1, "name": "Default credentials",
     "slug": "default-credentials", "playbook": "default-credentials"},
    {"id": 2, "name": "Unauthenticated services",
     "slug": "unauthenticated-access", "playbook": "unauthenticated-services"},
    {"id": 3, "name": "SMB / AD attack (relay, PtH, kerberoast)",
     "slug": "smb-relay", "playbook": "smb-attack"},
)


# ───────────────────────── Hints ─────────────────────────

_HINT_HUMAN = """\
<system-reminder>
The coverage gate checks that every host asset (HOST / SERVICE / WEBAPP /
DOMAIN) carries at least one hypothesis, skip, or block. It does NOT prescribe
which ATT&CK tactics to cover — that is your judgment. Lenses the gate can't see:

  1. Kill-chain pivots. For each foothold, ask what it unlocks:
       • a validated CRED on host A → can it log into host B? (lateral)
       • an http(s) SERVICE → WEBAPP delegation to the web framework
       • a DOMAIN cert SAN / ASN → new in-scope assets (ask the user first)
       • an unauth service (redis/docker/k8s) → command execution → cred harvest

  2. Cred reuse sweep. Before returning `done`, walk every discovered CRED
     against every reachable SERVICE of a compatible kind — password reuse and
     pass-the-hash are the cheapest lateral moves and easy to miss per-host.

  3. Domain-specific risk classes. What you would try against this exact
     stack (specific product versions, AD posture), not a generic checklist.
</system-reminder>"""

_HINTS_JSON = (
    {
        "kind": "killchain-pivot",
        "text": (
            "The gate does not prescribe tactics — for each foothold ask what it "
            "unlocks next (lateral via cred, web delegation, new in-scope assets)."
        ),
        "examples": [
            "validated CRED → login other hosts (lateral)",
            "http SERVICE → WEBAPP delegation",
            "unauth redis/docker → execution → cred-access",
        ],
    },
    {
        "kind": "cred-reuse-sweep",
        "text": (
            "Before returning done, test every discovered CRED against every "
            "reachable compatible SERVICE (password reuse / pass-the-hash)."
        ),
    },
    {
        "kind": "domain-specific",
        "text": "Consider risk classes specific to the exact stack / AD posture.",
    },
)


# ───────────────────────── Gap-clearing worked examples ─────────────────────────
# Copy-paste templates shown by `kb coverage` for the gap types currently present.
# IDs (SERVICE-007, HYPOTHESIS-1 …) are placeholders — swap in the real ones. New
# entities use small-int placeholder IDs; `bin/kb commit` assigns real 3-digit IDs.

_GAP_EXAMPLES = (
    ("per-entity", """\
PER-ENTITY gap — the asset has no hypothesis / skip / block. Give it ONE:
  • a hypothesis (plan/hypotheses.md) + a task (plan/tasks.md) referencing it:
      ### HYPOTHESIS-1: default credentials on SERVICE-007
      - targets: [[SERVICE-007]]
      - class: default-credentials
      - severity_guess: high
      - status: untested
      ### TASK-1: try default creds on SERVICE-007
      - hypothesis: [[HYPOTHESIS-1]]
      - status: pending
    class ∈ default-credentials · unauthenticated-access · public-cve: <CVE> ·
      weak-protocol · kerberoast · asreproast · dcsync · smb-relay · pass-the-hash ·
      pivot-via-cred · web-app-pentest · system-wide
    (a WEBAPP is covered ONLY by class: web-app-pentest — host delegates, never tests it)
  • OR skip it — add a bullet inside the entity's block in wiki/*.md:
      - coverage-skip: initial-access(no auth surface — static banner only)
  • OR block it (needs user / technical):
      - coverage-block: initial-access(needs-user-input: credentials not provided)
    category ∈ recon · initial-access · cred-access · lateral · priv-esc"""),

    ("universal", """\
UNIVERSAL gap — cover the check with a system-wide hypothesis whose title/rationale
text contains the check's slug tokens (matched as TEXT, not `tags:`), or skip it:
      ### HYPOTHESIS-1: whole-scope weak-protocols sweep (telnet / ftp-anon / smtp-relay)
      - targets: system-wide
      - class: weak-protocol
      - severity_guess: medium
      - status: untested
      ### TASK-1: sweep scope for weak protocols
      - hypothesis: [[HYPOTHESIS-1]]
      - status: pending
  OR skip — a NOTE in plan/notes.md:
      ### NOTE-1: skip weak-protocols
      - status: open

      universal-skip: weak-protocols (no such services in scope)"""),

    ("conditional", """\
CONDITIONAL system-feature gap — the `system-feature:` NOTE needs a hypothesis, or retire it:
  • raise a `targets: system-wide` hypothesis whose rationale names the feature (+ a task); or
  • retire the NOTE — add bullets to it:
      - status: retired
      - retire-reason: <why out of scope>"""),

    ("scenario", """\
BUSINESS SCENARIO gap — raise a hypothesis of the scenario's class, or skip it:
      ### HYPOTHESIS-1: default-credentials sweep across scope
      - targets: system-wide
      - class: default-credentials
      - severity_guess: high
      - status: untested
      ### TASK-1: run default-credential sweep
      - hypothesis: [[HYPOTHESIS-1]]
      - status: pending
  OR skip — NOTE in plan/notes.md with `- status: open`:
      scenario-skip: default-credentials (no such services in scope)"""),

    ("orphan", """\
ORPHAN hypothesis — no task references it. EVERY hypothesis must have a task, whatever its
status: closing it (refuted / verified / blocked) does NOT clear this — a task is required.
  • give it a task (plan/tasks.md) so probe actually tests it:
      ### TASK-1: probe HYPOTHESIS-003
      - hypothesis: [[HYPOTHESIS-003]]
      - status: pending
  • if you will NOT test it, it is not a hypothesis — delete it and instead record a
    coverage-skip bullet on the entity, or a NOTE. Do not leave a task-less hypothesis."""),

    ("follow-up-lead", """\
OPEN FOLLOW-UP LEAD — probe flagged a chainable signal (a deepen-lead: NOTE) not yet worked.
Do ONE, then the NOTE clears:
  • convert it — raise the chain hypothesis + task it implies (reason deepening), then
    retire the NOTE: set its bullet `- status: stale` (or resolved);
  • OR if not worth pursuing, retire with a reason:
      - status: stale
      - retire-reason: <why not chainable>
  Also prune its line from STATE.md `## Follow-up leads`."""),
)


HOST = Profile(
    name="host",
    gated_entity_types=("HOST", "SERVICE", "WEBAPP", "DOMAIN"),
    # A WEBAPP is only "covered" once it carries a `web-app-pentest` (delegation)
    # hypothesis. Host classes (default-credentials / unauthenticated-access / …)
    # targeting a webapp do NOT count — host never tests webapps itself, it
    # delegates them to a web pentest sub-session. This is the gate that forces
    # reason to raise the delegation hypothesis instead of folding the webapp into
    # a host vuln class. See runtimes/host/.claude/rules/web-delegation.md.
    required_hyp_class=(("WEBAPP", "web-app-pentest"),),
    rollup_to_tags=_ATTACK_TO_TAGS,
    rollup_order=("recon", "initial-access", "cred-access", "lateral", "priv-esc"),
    rollup_label="ATT&CK",
    breakdown_key="attack_breakdown",
    rollup_cat_key="tactics",
    cov_item_re=re.compile(
        r"(recon|initial-access|execution|cred-access|lateral|priv-esc|"
        r"persistence|discovery|exfil)\s*\(([^)]*)\)"
    ),
    display_bullets=("ip", "fqdn", "host", "port", "name", "url"),
    universal_checks=_UNIVERSAL_CHECKS,
    scenarios=_SCENARIOS,
    hint_human=_HINT_HUMAN,
    hints_json=_HINTS_JSON,
    gap_examples=_GAP_EXAMPLES,
    # Group the attack surface by SERVICE CLASS (web / smb-ad / db / mail / remote
    # / mgmt / …), read from each wiki file's `service_class` frontmatter. SERVICE
    # and WEBAPP files carry their class; HOST / DOMAIN files use `host` / `domain`
    # (or a network-segment label when split). A file with no `service_class` falls
    # back to entity type (flat, backward-compatible for small engagements). Key is
    # underscore (the frontmatter parser rejects hyphens in keys); values may hyphen.
    overview_group_field="service_class",
    overview_group_label="service class",
)
