"""Web coverage profile — reproduces the historical coverage.py behavior.

Every constant here is a verbatim lift of what used to live at module scope in
coverage.py. The web profile is the default (see __init__.py), so the existing
test suite — which runs with no `kb.profile` marker — exercises exactly this.
"""
from __future__ import annotations

import re

from .base import Profile


# ───────────────────────── OWASP rollup ─────────────────────────

_OWASP_TO_TAGS = {
    "A01": frozenset({"authz-vertical", "authz-horizontal", "idor", "bola", "rbac"}),
    "A02": frozenset({"weak-crypto", "hardcoded-secret", "crypto-misuse"}),
    "A03": frozenset({
        "sqli", "nosqli", "xss", "command-injection", "ssti",
        "xxe", "xpath", "xpath-injection", "ldap-injection",
    }),
    "A04": frozenset({"business-logic", "workflow-bypass", "race-condition"}),
    "A05": frozenset({"headers-missing", "cookie-flags", "debug-exposure", "cors-misconfig"}),
    "A07": frozenset({
        "authn", "session", "mfa-bypass", "jwt", "password-recovery",
        "oauth", "sso", "weak-password", "username-enum", "rate-limit", "captcha-bypass", "auth-bypass",
        "login", "registration",
    }),
    "A08": frozenset({"deserialization"}),
    "A10": frozenset({"ssrf"}),
}


# ───────────────────────── Universal checks ─────────────────────────

_UNIVERSAL_CHECKS = (
    # Response header hygiene: HSTS, security headers (CSP / X-Frame-Options /
    # X-Content-Type-Options / Referrer-Policy), cookie flags (HttpOnly / Secure /
    # SameSite), and CORS (origin reflection / null / wildcard on authed endpoints).
    # One system-wide sweep over response-header config — a single hypothesis
    # covers all four sub-areas.
    {"id": 1, "name": "Response header hygiene (HSTS / security headers / cookie flags / CORS)",
     "slug": "response-headers", "owasp": "A05"},
    {"id": 2, "name": "Debug endpoints exposed", "slug": "debug-endpoints", "owasp": "A05"},
    {"id": 3, "name": "Verbose error pages", "slug": "verbose-errors", "owasp": "A05"},
    # #4 folds the old robots.txt/sitemap.xml check into the broader file/path
    # leakage sweep — both are A05 info leakage over discoverable paths.
    {"id": 4, "name": "Sensitive file / path leakage sweep (incl. robots.txt, sitemap.xml, source, backups, dotfiles)",
     "slug": "file-leakage", "owasp": "A05"},
    # Unauthenticated-access sweep (A01): replay every catalogued endpoint with
    # auth stripped and diff against the authed baseline; flag any returning
    # authed/sensitive data without a session. MUST actually run — lifecycle gate:
    # a bare untested sweep hypothesis is a gap; clears only at tested/finding
    # (or universal-skip: unauth-access).
    {"id": 5, "name": "Unauthenticated endpoint sweep (endpoints reachable without auth that leak authed data)",
     "slug": "unauth-access", "owasp": "A01",
     "require_tested": True,
     # Recall ledger: this sweep's per-endpoint membership tag. The check stays
     # open while any ENDPOINT is `unauth_sweep: required` / `blocked(...)`, and
     # closes once the per-area sweep has disposed every tagged endpoint
     # (enforced / missing→finding / na). See validators/sweep_tags.py.
     "endpoint_tag": "unauth_sweep",
     "hint": ("strip session/token and replay every catalogued endpoint "
              "unauthenticated, diffing against the authed baseline; flag any 2xx "
              "returning authenticated or otherwise sensitive data without auth. "
              "Clears only when the sweep reaches tested (a bare untested "
              "hypothesis does not count). Essentially always applies — skip only "
              "if the app has no authenticated surface: universal-skip: "
              "unauth-access (<reason>)")},
    # Vulnerable/outdated components (A06): run POC scanning against the app's
    # tech fingerprint. Lifecycle gate — a bare untested sweep hypothesis is a
    # gap; clears only at tested/finding (or universal-skip: poc-scan).
    {"id": 6, "name": "Template-based poc-scan (tech-fingerprint) sweep",
     "slug": "poc-scan", "owasp": "A06",
     "require_tested": True,
     "hint": ("if observe found a server / tech fingerprint (framework + version, "
              "e.g. nginx/PHP/CMS), run a poc-scan and collect/analyze its results; "
              "clears only when the sweep hypothesis reaches tested (untested does "
              "not count). No identifiable tech / no scannable surface → skip: "
              "universal-skip: poc-scan (<reason>)")},
    # Authorization sweep (A01): the read-comparison authz check. Replay every
    # endpoint tagged authz_sweep as a lower-priv actor (function-level,
    # actor-swap) AND — where the contract carries an object selector — as a
    # same-level peer with the selector swapped (horizontal IDOR/BOLA read),
    # diffing against the high-priv data-bearing baseline. Both are permission
    # failures decided by the same replay-and-compare, so ONE check covers both.
    # Bound to the authz_sweep endpoint tag (endpoint_tag): coverage closes it
    # from the ledger — open while any endpoint is required/blocked, closed once
    # every tagged endpoint is enforced/missing/na. (unauth-access #5 handles the
    # anon dimension; horizontal is n/a where the endpoint carries no selector.)
    {"id": 7, "name": "Authorization sweep (function-level + object-level / IDOR read)",
     "slug": "authz-sweep", "owasp": "A01",
     "require_tested": True,
     "endpoint_tag": "authz_sweep",
     "hint": ("replay every endpoint tagged authz_sweep as each lower-priv actor "
              "(function-level, actor-swap) and — where the contract has an object "
              "selector — as a same-level peer with the selector swapped (horizontal "
              "IDOR/BOLA read), diffing against the high-priv data-bearing baseline; "
              "a lower-priv actor or peer that gets data it shouldn't -> authz "
              "missing. Runs per-area inside the loop. Needs a comparison actor "
              "(orchestrator acquires: admin-creates-user / self-register x2); can't "
              "acquire -> the endpoint's authz_sweep tag goes blocked(no-actor) / "
              "blocked(no-peer), keeping this check OPEN — an owed gap, never a silent "
              "close. But if an endpoint is GENUINELY untestable (500 state / WAF / no data "
              "baseline), tag blocked(technical: <why>): recorded + CLOSES the check "
              "(mirrors coverage-block technical) so one untestable endpoint can't wedge the "
              "gate open forever. Skip only if the app has no privileged surface: "
              "universal-skip: authz-sweep (<reason>)")},
)


# ───────────────────────── Business scenarios ─────────────────────────

_SCENARIOS = (
    {"id": 1, "name": "Login authentication", "slug": "login", "playbook": "login"},
    {"id": 2, "name": "Registration / signup", "slug": "registration", "playbook": None},
    {"id": 3, "name": "Password recovery / account recovery",
     "slug": "password-recovery", "playbook": "password-recovery"},
)


# ───────────────────────── Hints ─────────────────────────

_HINT_HUMAN = """\
<system-reminder>
The coverage gate checks that every wiki entity has at least one hypothesis,
skip, or block. It does NOT prescribe which OWASP categories to cover —
that is your judgment. Use these lenses to find risks the gate can't see:

  1. OWASP categories beyond the obvious. Think about:
       • bulk-export endpoints → A01 (mass disclosure)
       • share / public-link endpoints → A05 (predictable token)
       • file upload paths → A03 (filename injection) + A05 (storage path)
       • OAuth callback handlers → A07 (state/PKCE) + A01 (open redirect)

  2. STRIDE sweep per entity. Before returning `done`, mentally walk each
     endpoint through:
       S — who could spoof this caller?
       T — which fields can a client tamper that the server trusts?
       R — is action attribution / audit forgeable?
       I — what does this leak in error paths, side channels, timing?
       D — high-cost operations, unbounded inputs?
       E — non-admin reaching admin code path?
     Hypotheses still tag with existing OWASP/tags vocab.

  3. Domain-specific risk classes. What you would test if attacking this
     product manually, not following a checklist.
</system-reminder>"""

_HINTS_JSON = (
    {
        "kind": "lateral-owasp",
        "text": (
            "The gate does not prescribe OWASP categories — consider lateral "
            "cats beyond the obvious for each entity."
        ),
        "examples": [
            "bulk-export → A01",
            "share endpoint → A05",
            "file upload → A03+A05",
            "oauth callback → A07+A01",
        ],
    },
    {
        "kind": "stride-sweep",
        "text": (
            "Before returning done, walk each entity through "
            "Spoofing/Tampering/Repudiation/InfoDisclosure/DoS/Elevation."
        ),
    },
    {
        "kind": "domain-specific",
        "text": "Consider risk classes outside OWASP that match this product.",
    },
)


# ───────────────────────── Gap-clearing worked examples ─────────────────────────
# Copy-paste templates shown by `kb coverage` for the gap types currently present.
# IDs (ENDPOINT-007, HYPOTHESIS-1 …) are placeholders — swap in the real ones. New
# entities use small-int placeholder IDs; `bin/kb commit` assigns real 3-digit IDs.

_GAP_EXAMPLES = (
    ("per-entity", """\
PER-ENTITY gap — the entity has no hypothesis / skip / block. Give it ONE:
  • a hypothesis (plan/hypotheses.md) + a task (plan/tasks.md) referencing it:
      ### HYPOTHESIS-1: horizontal IDOR on ENDPOINT-007
      - targets: [[ENDPOINT-007]]
      - class: idor
      - severity_guess: high
      - status: untested
      ### TASK-1: probe IDOR on ENDPOINT-007
      - hypothesis: [[HYPOTHESIS-1]]
      - status: pending
    class is a tag from the OWASP vocab (see the rollup above), e.g.
      idor · authz-horizontal · authz-vertical · bola · sqli · xss · ssrf ·
      business-logic · authn · session · jwt · ssti · command-injection
  • OR skip it — add a bullet inside the entity's block in wiki/*.md:
      - coverage-skip: A01(read-only, no object reference in request)
  • OR block it (needs user / technical):
      - coverage-block: A07(needs-user-input: no second test account provided)
    category ∈ A01 · A02 · A03 · A04 · A05 · A07 · A08 · A10"""),

    ("universal", """\
UNIVERSAL gap — cover the check with a system-wide hypothesis whose title/rationale
text contains the check's slug tokens (matched as TEXT, not `tags:`), or skip it:
      ### HYPOTHESIS-1: response-headers hygiene sweep (HSTS / CSP / cookie flags / CORS)
      - targets: system-wide
      - class: headers-missing
      - severity_guess: low
      - status: untested
      ### TASK-1: sweep response header hygiene
      - hypothesis: [[HYPOTHESIS-1]]
      - status: pending
  OR skip — a NOTE in plan/notes.md:
      ### NOTE-1: skip response-headers
      - status: open

      universal-skip: response-headers (static site: no cookies, no cross-origin API)"""),

    ("conditional", """\
CONDITIONAL system-feature gap — the `system-feature:` NOTE needs a hypothesis, or retire it:
  • raise a `targets: system-wide` hypothesis whose rationale names the feature (+ a task); or
  • retire the NOTE — add bullets to it:
      - status: retired
      - retire-reason: <why out of scope>"""),

    ("scenario", """\
BUSINESS SCENARIO gap — raise a hypothesis of the scenario's class, or skip it:
      ### HYPOTHESIS-1: login authentication testing
      - targets: [[WORKFLOW-002]]
      - class: login
      - severity_guess: high
      - status: untested
      ### TASK-1: test login auth flow
      - hypothesis: [[HYPOTHESIS-1]]
      - status: pending
    scenario class ∈ login · registration · password-recovery
  OR skip — NOTE in plan/notes.md with `- status: open`:
      scenario-skip: registration (no signup flow on this app)"""),

    ("orphan", """\
ORPHAN hypothesis — no task references it. EVERY hypothesis must have a task, whatever its
status: closing it (refuted / verified / blocked) does NOT clear this — a task is required.
  • give it a task (plan/tasks.md) so probe actually tests it:
      ### TASK-1: probe HYPOTHESIS-003
      - hypothesis: [[HYPOTHESIS-003]]
      - status: pending
  • if you will NOT test it, it is not a hypothesis — delete it and instead record a
    coverage-skip bullet on the entity, or a NOTE. Do not leave a task-less hypothesis."""),

    ("follow-up-lead", """\
OPEN FOLLOW-UP LEAD — probe flagged a chainable signal (a deepen-lead: NOTE) not yet worked.
Do ONE, then the NOTE clears:
  • convert it — raise the chain hypothesis + task it implies (reason deepening), then
    retire the NOTE: set its bullet `- status: stale` (or resolved);
  • OR if not worth pursuing, retire with a reason:
      - status: stale
      - retire-reason: <why not chainable>
  Also prune its line from STATE.md `## Follow-up leads`."""),
)


WEB = Profile(
    name="web",
    gated_entity_types=("ENDPOINT", "WORKFLOW", "PAGE", "BUNDLE"),
    rollup_to_tags=_OWASP_TO_TAGS,
    rollup_order=("A01", "A02", "A03", "A04", "A05", "A07", "A08", "A10"),
    rollup_label="OWASP",
    breakdown_key="owasp_breakdown",
    rollup_cat_key="owasp",
    cov_item_re=re.compile(r"(A0[1-9]|A10)\s*\(([^)]*)\)"),
    display_bullets=("method", "path"),
    sweep_endpoint_tags=("unauth_sweep", "authz_sweep"),
    universal_checks=_UNIVERSAL_CHECKS,
    scenarios=_SCENARIOS,
    hint_human=_HINT_HUMAN,
    hints_json=_HINTS_JSON,
    gap_examples=_GAP_EXAMPLES,
    semantic_inventory_note_type="capability-inventory",
    semantic_inventory_label="TIER 0 SEMANTIC INVENTORY",
    semantic_inventory_slot_keys=(
        "slots_selected",
        "slots_covered",
        "slots_refuted",
        "slots_missing",
        "slots_deferred",
        "slots_blocked",
        "slots_skipped",
    ),
    semantic_inventory_patterns=(
        "Upload / file management",
        "Template / content editor",
        "Generic CRUD / sqlid router",
        "Raw interpreter / executor",
        "Admin config / credential store",
        "Auth / session / user management",
        "Import / export / report",
        "Webhook / URL fetcher",
    ),
)
