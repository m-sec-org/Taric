"""Stigmergy-file hygiene for STATE.md / index.md — keeps the two files that
every agent reads at task start from growing unbounded.

Two mechanical layers, run at the end of `kb commit` and `kb draft integrate`
(the write-paths that grow the files). No prompt / skill involvement:

  Layer 1 — size banner. If STATE.md or index.md exceeds a soft threshold, emit a
    `<system-reminder>` the orchestrator reads, telling it to compact the file
    before the next dispatch. This is a nudge for the *narrative* content that
    only an agent can judge stale.

  Layer 2 — mechanical prune. Remove STATE.md `## Follow-up leads` lines whose
    backing `deepen-lead:` NOTE is no longer OPEN (retired / stale / resolved /
    archived — i.e. reason has drained it). This needs no agent: "drained" is the
    exact machine signal coverage's gate uses (see `coverage.build_follow_up_lead_block`).
    Only lines that reference a `[[NOTE-N]]` that is provably not-open are dropped;
    anything still open, or any line without a resolvable NOTE ref, is kept.

Both layers are best-effort and never raise: hygiene must not break a commit.
"""
from __future__ import annotations

import re
from typing import Optional, Set

from .index import build_index
from .parser import parse_frontmatter, serialize_frontmatter, split_frontmatter
from .util import today_iso

# Soft = start nagging; hard = louder tag. Per file (STATE and index bloat
# independently). Tunable — these files are a summary, not a log; a healthy one is
# a few KB, so 40KB already gives generous headroom before the nudge.
STATE_SOFT_KB = 40
STATE_HARD_KB = 80

DEEPEN_LEAD_PREFIX = "deepen-lead:"
_NOTE_REF = re.compile(r"\[\[(NOTE-\d+)\]\]")
_FOLLOWUP_HEAD = re.compile(r"^##\s+follow-up leads\s*$", re.IGNORECASE)
_NEXT_H2 = re.compile(r"^##\s+")


def open_lead_note_ids(idx) -> Set[str]:
    """IDs of `deepen-lead:` NOTEs still OPEN — the exact set coverage's gate blocks
    on (status bullet == "open", not archived). Anything else the gate treats as
    drained, so STATE need not keep queueing it."""
    archived = idx.archived_entity_ids()
    out: Set[str] = set()
    for n in idx.by_type.get("NOTE", []):
        if n.is_placeholder or n.id in archived:
            continue
        body = n.body or ""
        is_lead = (n.title or "").strip().lower().startswith("deepen-lead") or any(
            ln.strip().lower().startswith(DEEPEN_LEAD_PREFIX) for ln in body.splitlines()
        )
        if not is_lead:
            continue
        if str(n.bullets.get("status") or "open").strip().lower() == "open":
            out.add(n.id)
    return out


def prune_drained_leads(eng, idx=None) -> int:
    """Drop STATE.md `## Follow-up leads` lines whose `[[NOTE-N]]` is no longer an
    open deepen-lead. Returns the count removed. Safe: only removes a line when its
    referenced NOTE is provably not-open; lines still open, or without a NOTE ref,
    are kept."""
    path = eng.state_md
    if not path.exists():
        return 0
    text = path.read_text(encoding="utf-8")
    fm_text, body = split_frontmatter(text)
    lines = body.splitlines()

    start = None
    for i, ln in enumerate(lines):
        if _FOLLOWUP_HEAD.match(ln.strip()):
            start = i + 1
            break
    if start is None:
        return 0
    end = len(lines)
    for j in range(start, len(lines)):
        if _NEXT_H2.match(lines[j]):
            end = j
            break

    section = lines[start:end]
    # Nothing to do unless the section has NOTE-referencing bullet lines.
    if not any(_NOTE_REF.search(ln) for ln in section):
        return 0

    if idx is None:
        idx = build_index(eng)
    open_ids = open_lead_note_ids(idx)

    kept, removed = [], 0
    for ln in section:
        m = _NOTE_REF.search(ln)
        if ln.strip().startswith(("-", "*", "+")) and m and m.group(1) not in open_ids:
            removed += 1
            continue
        kept.append(ln)
    if removed == 0:
        return 0

    # If pruning left the section entirely blank, leave a clean placeholder so the
    # next `_append_under_section` recognises it as empty. Never discard non-bullet
    # content that happened to sit in the section — only collapse pure whitespace.
    if not any(k.strip() for k in kept):
        kept = ["", "_(none)_"]

    new_body = "\n".join(lines[:start] + kept + lines[end:])
    if body.endswith("\n") and not new_body.endswith("\n"):
        new_body += "\n"

    head = (f"---\n{fm_text}---\n") if fm_text else ""
    if fm_text:
        fm = parse_frontmatter(fm_text)
        if "last_updated" in fm:
            fm["last_updated"] = today_iso()
            head = serialize_frontmatter(fm)
    path.write_text(head + new_body, encoding="utf-8")
    return removed


def size_banner(eng) -> Optional[str]:
    """`<system-reminder>` if STATE.md / index.md exceed the soft threshold, else
    None. Advisory nudge for the narrative content only an agent can prune."""
    over = []
    for label, path in (("STATE.md", eng.state_md), ("index.md", eng.index_md)):
        try:
            kb = path.stat().st_size / 1024.0
        except OSError:
            continue
        if kb >= STATE_SOFT_KB:
            over.append((label, kb, kb >= STATE_HARD_KB))
    if not over:
        return None
    out = [
        "<system-reminder>",
        f"stigmergy file(s) over the compaction threshold (soft {STATE_SOFT_KB}KB / "
        f"hard {STATE_HARD_KB}KB) — read at the start of EVERY task, so bloat taxes every dispatch:",
    ]
    for label, kb, hard in over:
        out.append(f"  · {label}: {kb:.0f}KB{'  [HARD]' if hard else ''}")
    out += [
        "Before the next dispatch, compact them (safe = only remove items already resolved in kb):",
        "drop ## Next actions now done, answered ## Open questions, cleared ## Blockers, and",
        "## Background work already ingested; rebuild the ## index narrative. KEEP the",
        "## Engagement block, ## Transport recipes, ## Prior knowledge (both rebuildable via kb",
        "but each taxes every dispatch while gone), and anything still open / running.",
        "</system-reminder>",
    ]
    return "\n".join(out)


def emit(eng, idx=None) -> None:
    """Run Layer 2 (prune) then Layer 1 (size banner), printing to stdout.
    Best-effort — never raises, so it cannot break a commit / integrate."""
    try:
        n = prune_drained_leads(eng, idx)
        if n:
            print(f"state-hygiene: pruned {n} drained follow-up-lead line(s) from "
                  "STATE.md `## Follow-up leads` (backing NOTE retired / archived).")
    except Exception:
        pass
    try:
        banner = size_banner(eng)
        if banner:
            print(banner)
    except Exception:
        pass
