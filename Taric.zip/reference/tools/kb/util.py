"""Shared helpers."""
from __future__ import annotations

import datetime as _dt
import re
import sys


def today_iso() -> str:
    """ISO date for `last_updated:` and `created:` frontmatter."""
    return _dt.date.today().isoformat()


def now_iso() -> str:
    """ISO datetime for log headers and event rows (minute precision)."""
    return _dt.datetime.now().strftime("%Y-%m-%d %H:%M")


def now_isoZ() -> str:
    """ISO datetime with seconds + Z, for evidence captured_at."""
    return _dt.datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")


def slugify(s: str) -> str:
    s = s.strip().lower()
    s = re.sub(r"[^a-z0-9]+", "-", s)
    s = s.strip("-")
    return s or "untitled"


def err(msg: str) -> None:
    sys.stderr.write(msg.rstrip() + "\n")


def die(msg: str, code: int = 1):
    err(msg)
    sys.exit(code)
