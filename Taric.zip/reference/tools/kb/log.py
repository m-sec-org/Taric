"""log.md and events.jsonl writers."""
from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any

from .util import now_iso


def append_log(log_path: Path, verb: str, title: str, body: str = "") -> None:
    """Append a markdown entry to log.md.

    Header format: ## [YYYY-MM-DD HH:MM] <verb> | <title>
    Body is the agent's commit message (may be multi-paragraph).
    """
    header = f"## [{now_iso()}] {verb} | {title}\n"
    chunk = "\n" + header + ("\n" + body.rstrip() + "\n" if body.strip() else "")
    if not log_path.exists():
        # Initialise log.md with frontmatter + heading.
        eng_slug = log_path.parent.name
        bootstrap = (
            "---\n"
            "type: log\n"
            "---\n\n"
            f"# {eng_slug} — Log\n"
        )
        log_path.write_text(bootstrap + chunk)
        return
    with log_path.open("a", encoding="utf-8") as fh:
        fh.write(chunk)


def append_event(events_path: Path, **kwargs: Any) -> None:
    """Append a structured row to events.jsonl. Caller supplies all keys."""
    # Keep the human-readable timestamp and a monotonic-enough ordering key for
    # callers that need to audit operations occurring within the same minute.
    row = {"ts": now_iso(), "time_ns": time.time_ns(), **kwargs}
    with events_path.open("a", encoding="utf-8") as fh:
        fh.write(json.dumps(row, ensure_ascii=False) + "\n")
