"""transcript — a read-only navigator for Claude Code .jsonl transcripts.

These transcripts grow to tens of MB. Loading one into an agent's context is
wasteful and often impossible, yet an auditor needs to see *what a session
actually did* and resume from a cursor on each pass. This tool:

  * `info`  — shape of the file (event count, roles, tool-call breakdown).
  * `slice` — compact one-line projection of an event range, with filters and a
              trailing `# next_index:` cursor so the caller can resume.
  * `show`  — one event expanded in full (when `slice` flags something).

It is generic: it understands the transcript envelope, not pentest semantics.

Transcript format — one JSON object per line = one event (0-based index):

    {type: user|assistant|system|...,
     isSidechain: bool, timestamp, uuid, cwd, ...,
     message: {role, content: [block, ...] | str},
     toolUseResult?: {...}}

Content blocks:

    {type: thinking,     thinking}                       assistant reasoning
    {type: text,         text}                            assistant / user text
    {type: tool_use,     id, name, input}                 a tool call
    {type: tool_result,  tool_use_id, content, is_error}  its result
"""
from __future__ import annotations

import argparse
import collections
import json
import os
import re
import sys


# ───────────────────────── streaming + projection ─────────────────────────

def iter_events(path):
    """Yield (index, raw_line, parsed_obj) for each non-empty line.

    A malformed line still gets an index (so cursors stay stable) and is
    surfaced as a synthetic event rather than crashing the read.
    """
    with open(path, encoding="utf-8", errors="replace") as fh:
        idx = 0
        for line in fh:
            line = line.rstrip("\n")
            if not line.strip():
                continue
            try:
                obj = json.loads(line)
            except json.JSONDecodeError:
                obj = {"type": "malformed", "raw": line[:200]}
            yield idx, line, obj
            idx += 1


def prescan(path):
    """One cheap pass: total event count + tool_use id -> name map.

    The map lets `slice` resolve a tool_result's tool name even when the
    matching tool_use sits before the requested `--from` window.
    """
    total = 0
    id2name = {}
    for idx, _raw, obj in iter_events(path):
        total = idx + 1
        msg = obj.get("message")
        if isinstance(msg, dict):
            content = msg.get("content")
            if isinstance(content, list):
                for b in content:
                    if isinstance(b, dict) and b.get("type") == "tool_use":
                        id2name[b.get("id")] = b.get("name", "?")
    return total, id2name


def _trunc(s, n):
    s = " ".join(str(s).split())  # collapse newlines/runs of whitespace
    return s if len(s) <= n else s[: max(0, n - 1)] + "…"


def _arg_summary(name, inp, width):
    """Render a tool_use input as one compact, tool-aware line."""
    if not isinstance(inp, dict):
        return _trunc(inp, width)
    name = name or ""
    if name == "Bash":
        return _trunc(inp.get("command", ""), width)
    if name in ("Read", "Edit", "Write", "NotebookEdit"):
        return _trunc(inp.get("file_path", ""), width)
    if name in ("Grep", "Glob"):
        return _trunc(inp.get("pattern", inp.get("query", "")), width)
    if name in ("Agent", "Task"):
        who = inp.get("subagent_type") or inp.get("description") or ""
        return _trunc(f"{who}: {inp.get('prompt', '')}", width)
    # WebPentest* / MCP / unknown tools: keys=values, truncated as a whole.
    return _trunc(", ".join(f"{k}={v}" for k, v in inp.items()), width)


def _result_text(block):
    c = block.get("content")
    if isinstance(c, str):
        return c
    if isinstance(c, list):
        parts = []
        for b in c:
            if isinstance(b, dict):
                if b.get("type") == "text":
                    parts.append(b.get("text", ""))
                elif b.get("type") == "image":
                    parts.append("[image]")
            else:
                parts.append(str(b))
        return " ".join(parts)
    return "" if c is None else str(c)


def _is_error(block):
    return block.get("is_error") in (True, "True", "true")


def project(idx, obj, id2name, width, thinking, tools_only):
    """Project one event to zero or more compact display lines."""
    side = "~" if obj.get("isSidechain") else " "
    tag = f"[{idx:>5}]{side}"
    msg = obj.get("message")

    if not isinstance(msg, dict):
        typ = obj.get("type")
        if typ == "system":
            body = obj.get("content") or obj.get("message") or ""
            return [f"{tag} system: {_trunc(body, width)}"]
        if obj.get("isCompactSummary"):
            return [f"{tag} compact-summary"]
        if typ == "queue-operation":
            return [f"{tag} queue-op: {_trunc(obj.get('operation', ''), 60)}"]
        if typ == "malformed":
            return [f"{tag} malformed: {_trunc(obj.get('raw', ''), width)}"]
        return [f"{tag} {typ}"]

    role = msg.get("role") or obj.get("type") or "?"
    content = msg.get("content")
    if isinstance(content, str):
        content = [{"type": "text", "text": content}]
    if not isinstance(content, list):
        content = []

    lines = []
    for b in content:
        if not isinstance(b, dict):
            continue
        bt = b.get("type")
        if bt == "thinking":
            if thinking:
                lines.append(f"{tag} think: {_trunc(b.get('thinking', ''), width)}")
        elif bt == "text":
            if tools_only:
                continue
            txt = b.get("text", "")
            if txt.strip():
                lines.append(f"{tag} {role}: {_trunc(txt, width)}")
        elif bt == "tool_use":
            nm = b.get("name", "?")
            lines.append(f"{tag} → {nm}({_arg_summary(nm, b.get('input'), width)})")
        elif bt == "tool_result":
            nm = id2name.get(b.get("tool_use_id"), "?")
            err = "ERR " if _is_error(b) else ""
            lines.append(f"{tag}   ↳ {nm}: {err}{_trunc(_result_text(b), width)}")
    return lines


# ───────────────────────── subcommands ─────────────────────────

def cmd_info(args):
    total = 0
    types = collections.Counter()
    roles = collections.Counter()
    tools = collections.Counter()
    side = 0
    first_ts = last_ts = None
    for idx, _raw, obj in iter_events(args.file):
        total = idx + 1
        types[obj.get("type")] += 1
        if obj.get("isSidechain"):
            side += 1
        ts = obj.get("timestamp")
        if ts:
            first_ts = first_ts or ts
            last_ts = ts
        msg = obj.get("message")
        if isinstance(msg, dict):
            roles[msg.get("role")] += 1
            content = msg.get("content")
            if isinstance(content, list):
                for b in content:
                    if isinstance(b, dict) and b.get("type") == "tool_use":
                        tools[b.get("name", "?")] += 1

    print(f"file:       {args.file}")
    print(f"size:       {os.path.getsize(args.file):,} bytes")
    print(f"events:     {total}   (valid resume cursors: 0..{total})")
    print(f"types:      {dict(types)}")
    print(f"roles:      {dict(roles)}")
    print(f"sidechain:  {side}   (subagent messages)")
    print(f"timespan:   {first_ts}  ..  {last_ts}")
    print(f"tool calls: {sum(tools.values())}")
    for nm, n in tools.most_common(12):
        print(f"   {n:>5}  {nm}")
    return 0


def cmd_slice(args):
    total, id2name = prescan(args.file)
    frm = max(0, args.frm)
    to = total if args.to is None else min(args.to, total)
    pat = re.compile(args.grep) if args.grep else None

    shown = 0
    out = []
    for idx, raw, obj in iter_events(args.file):
        if idx < frm:
            continue
        if idx >= to:
            break
        if args.role and (obj.get("message") or {}).get("role") != args.role:
            continue
        if pat and not pat.search(raw):
            continue
        lines = project(idx, obj, id2name, args.width, args.thinking, args.tools)
        if lines:
            out.extend(lines)
            shown += 1

    if out:
        print("\n".join(out))
    print(f"\n# events [{frm}, {to}) of {total}; matched {shown}; next_index: {to}")
    return 0


def cmd_show(args):
    for idx, _raw, obj in iter_events(args.file):
        if idx != args.index:
            continue
        msg = obj.get("message")
        role = (msg or {}).get("role") if isinstance(msg, dict) else None
        print(f"# event {idx}  type={obj.get('type')}  role={role}  "
              f"sidechain={obj.get('isSidechain')}  ts={obj.get('timestamp')}")
        if not isinstance(msg, dict):
            print(json.dumps(obj, ensure_ascii=False, indent=2))
            return 0
        content = msg.get("content")
        if isinstance(content, str):
            print("\n" + content)
            return 0
        for b in content or []:
            if not isinstance(b, dict):
                continue
            bt = b.get("type")
            if bt == "thinking":
                print("\n--- thinking ---\n" + b.get("thinking", ""))
            elif bt == "text":
                print("\n--- text ---\n" + b.get("text", ""))
            elif bt == "tool_use":
                print(f"\n--- tool_use: {b.get('name')} (id={b.get('id')}) ---")
                print(json.dumps(b.get("input"), ensure_ascii=False, indent=2))
            elif bt == "tool_result":
                print(f"\n--- tool_result (for {b.get('tool_use_id')}, "
                      f"error={b.get('is_error')}) ---")
                print(_result_text(b))
        return 0
    print(f"no event at index {args.index} (file has fewer events)", file=sys.stderr)
    return 2


# ───────────────────────── dispatch ─────────────────────────

def build_parser():
    p = argparse.ArgumentParser(
        prog="transcript",
        description="read-only navigator for Claude Code .jsonl transcripts")
    sub = p.add_subparsers(dest="cmd", required=True)

    pi = sub.add_parser("info", help="file shape: event count, roles, tool-call breakdown")
    pi.add_argument("file")
    pi.set_defaults(func=cmd_info)

    ps = sub.add_parser("slice", help="compact one-line projection of an event range")
    ps.add_argument("file")
    ps.add_argument("--from", dest="frm", type=int, default=0,
                    help="start event index, inclusive (default 0)")
    ps.add_argument("--to", type=int, default=None,
                    help="end event index, exclusive (default: end of file)")
    ps.add_argument("--role", choices=["user", "assistant"], default=None,
                    help="only events with this message role")
    ps.add_argument("--tools", action="store_true",
                    help="only tool_use + tool_result (drop text/thinking)")
    ps.add_argument("--thinking", action="store_true",
                    help="include assistant thinking blocks (off by default)")
    ps.add_argument("--grep", default=None,
                    help="only events whose raw JSON line matches this regex")
    ps.add_argument("--width", type=int, default=200,
                    help="per-line truncation width (default 200)")
    ps.set_defaults(func=cmd_slice)

    psh = sub.add_parser("show", help="print one event in full")
    psh.add_argument("file")
    psh.add_argument("index", type=int)
    psh.set_defaults(func=cmd_show)

    return p


def main(argv=None):
    args = build_parser().parse_args(argv)
    try:
        return args.func(args)
    except FileNotFoundError:
        print(f"no such file: {args.file}", file=sys.stderr)
        return 2
    except BrokenPipeError:
        return 0
