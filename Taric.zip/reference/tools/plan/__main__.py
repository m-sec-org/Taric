import sys

from .digest import main

raise SystemExit(main(sys.argv[1:]))
