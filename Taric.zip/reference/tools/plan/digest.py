"""plan-digest — aggregate group-planner stage records into ONE compact digest.

The `plan-groups` workflow (web + host) fans out one group-planner sub-agent per
group; each writes a big group-record JSON to the batch stage dir. That record
holds the full per-member SWEEP detail (OWASP/STRIDE on web, vuln-class on host)
PLUS the actionable payload (hypotheses / tasks / coverage_disposition /
needs_observe). The reason combiner only ACTS on the actionable payload — the
sweep rows are a generation-time thinking scaffold that is never persisted (the
stage dir is `rm`'d after commit). Reading every full record into the combiner
saturates its context (the root cause of the planning slowdown + compaction
storm).

This reads every `group-*.json` in a stage dir and writes `digest.md` carrying
ONLY the actionable, plan-ready payload, so the combiner reads one small file.
It is schema-generic — it touches only the fields common to the web and host
records — so the same tool serves both runtimes.

Usage:  bin/plan-digest <stage_dir>
Writes: <stage_dir>/digest.md   (+ prints a one-line summary)
"""
from __future__ import annotations

import glob
import json
import os
import sys


def _links(ids):
    return ", ".join(f"[[{i}]]" for i in ids) if ids else ""


def _load(stage_dir):
    """Return (records, parse_errors). records = list of (filename, dict)."""
    recs, errs = [], []
    for fp in sorted(glob.glob(os.path.join(stage_dir, "group-*.json"))):
        try:
            with open(fp, encoding="utf-8") as fh:
                recs.append((os.path.basename(fp), json.load(fh)))
        except Exception as e:  # malformed stage file → flag, never crash the batch
            errs.append((os.path.basename(fp), str(e)))
    return recs, errs


def _render_group(rec):
    """Return (markdown_chunk, hyp_count, task_count, needs_observe_count, thin[(label,eid)])."""
    out = []
    label = rec.get("group_label", "(unlabeled)")
    sc = rec.get("service_class")  # host-only; absent on web
    members = [m.get("entity") for m in rec.get("members", []) if isinstance(m, dict) and m.get("entity")]

    head = f"## GROUP: {label}"
    if sc:
        head += f"  [service_class: {sc}]"
    if members:
        head += f"  members: {', '.join(members)}"
    out.append(head)

    hyps = rec.get("hypotheses") or []
    tasks = rec.get("tasks") or []

    if hyps:
        out.append("### hypotheses")
        for i, h in enumerate(hyps, 1):
            out.append(f"#### h{i}: {h.get('title', '')}")
            out.append(f"- targets: {_links(h.get('targets', []))}")
            for k in ("class", "gbt_category", "severity_guess", "rating_basis", "confidence"):
                if h.get(k) not in (None, ""):
                    out.append(f"- {k}: {h[k]}")
            if h.get("rationale"):
                out.append(f"- rationale: {h['rationale']}")
            out.append("- status: untested")

    if tasks:
        out.append("### tasks")
        for t in tasks:
            fi = t.get("for_hypothesis")
            ref = f"h{fi + 1}" if isinstance(fi, int) and 0 <= fi < len(hyps) else f"h?({fi})"
            out.append(f"#### t -> {ref}")
            if t.get("playbook"):
                out.append(f"- playbook: {t['playbook']}")
            if t.get("preconds"):
                out.append(f"- preconds: {t['preconds']}")
            out.append(f"- actions: {t.get('actions', '')}")

    disp, nobs = [], []
    for m in rec.get("members", []):
        if not isinstance(m, dict):
            continue
        eid = m.get("entity", "?")
        cd = m.get("coverage_disposition")
        if isinstance(cd, dict):
            disp.append(f"- [[{eid}]] class={cd.get('class', '?')} {cd.get('kind', 'skip')}: {cd.get('reason', '')}")
        no = m.get("needs_observe")
        if isinstance(no, dict):
            nobs.append(f"- [[{eid}]]: {no.get('reason', '')} -- {no.get('request', '')}")
    if disp:
        out.append("### coverage_disposition")
        out.extend(disp)
    if nobs:
        out.append("### needs_observe")
        out.extend(nobs)

    # thin member = got no hypothesis target, no disposition, no needs_observe
    targeted = set()
    for h in hyps:
        for t in (h.get("targets") or []):
            targeted.add(t)
    thin = []
    for m in rec.get("members", []):
        if not isinstance(m, dict):
            continue
        eid = m.get("entity")
        if not eid or eid in targeted:
            continue
        if isinstance(m.get("coverage_disposition"), dict) or isinstance(m.get("needs_observe"), dict):
            continue
        thin.append(eid)

    out.append("")
    return "\n".join(out), len(hyps), len(tasks), len(nobs), [(label, e) for e in thin]


def _plan_add_errors(stage_dir):
    """The exact problems `bin/kb plan add` would reject in this batch — run the
    SAME validator over the plan-ready `digest.json` payload, so `digest.md`
    previews the rejection (object-model gaps, missing rationale, orphan hyps) and
    the combiner fixes them in one pass instead of hitting `plan add` blind. No
    kb index here, so the target-existence check is skipped (`known_ids=None`);
    fail-open — any import/resolution error reports nothing, never blocks the
    digest. Indices in the messages are the `digest.json` `hypotheses[]` array."""
    try:
        from tools.kb.profiles import active_profile
        from tools.kb.verbs.plan import validate_batch
        hyps = build_digest_json(stage_dir).get("hypotheses", [])
        return validate_batch(hyps, None, active_profile().name)
    except Exception:
        return []


def build_digest(stage_dir):
    """Return (digest_markdown, summary_dict)."""
    recs, errs = _load(stage_dir)
    body, gh, gt, go, thin_all = [], 0, 0, 0, []
    for _, rec in recs:
        chunk, h, t, o, thin = _render_group(rec)
        body.append(chunk)
        gh += h
        gt += t
        go += o
        thin_all += thin
    pa_errors = _plan_add_errors(stage_dir)

    lines = [
        "# plan-groups digest",
        f"stage_dir: {stage_dir}",
        f"groups: {len(recs)} | hypotheses: {gh} | tasks: {gt} | "
        f"needs_observe: {go} | thin_members: {len(thin_all)} | "
        f"plan_add_gaps: {len(pa_errors)} | parse_errors: {len(errs)}",
        "",
        "<!-- Combiner: this is the ONLY file to read for the batch. It carries every",
        "     hypothesis / task / disposition / needs_observe the planners produced,",
        "     plan-ready. The per-member OWASP/STRIDE/vuln-class SWEEP detail is",
        "     intentionally omitted: it is a generation-time scaffold, never persisted",
        "     (the stage dir is rm'd after commit). Do NOT open the group-*.json.",
        "     Your job: dedup across groups AND against existing plan/ (same targets+class),",
        "     apply dispositions, write plan/, raise needs-observe NOTEs, commit. -->",
        "",
    ]
    lines.extend(body)

    if thin_all or errs or pa_errors:
        lines.append("## WARNING -- needs attention (fix before `plan add`)")
        if pa_errors:
            lines.append("### `plan add` WILL REJECT these — fix them in digest.json first")
            lines.append("(full field contract: `bin/kb schema hypothesis`; indices are the "
                         "digest.json `hypotheses[]` array):")
            for e in pa_errors:
                lines.append(f"- {e}")
        for label, eid in thin_all:
            lines.append(f"- thin: group `{label}` member {eid} got no hypothesis / skip / needs_observe (replan)")
        for fn, msg in errs:
            lines.append(f"- parse-error: {fn}: {msg}")
        lines.append("")

    return "\n".join(lines), {
        "groups": len(recs), "hyps": gh, "tasks": gt,
        "needs_observe": go, "thin": len(thin_all),
        "plan_add_gaps": len(pa_errors), "errors": len(errs),
    }


def build_digest_json(stage_dir):
    """The batch as `bin/kb plan add` input: {"hypotheses": [{..., tasks:[...]}]}.

    Combines every group record and nests each group's tasks under their parent
    hypothesis (by the `for_hypothesis` index). This is the plan-ready payload —
    the combiner prunes cross-group / cross-batch dupes and fills any gaps, then
    `bin/kb plan add <stage_dir>/digest.json`. Same schema-generic subset the
    markdown digest uses, so it serves web and host."""
    recs, _ = _load(stage_dir)
    hyps_out = []
    for _, rec in recs:
        ghyps = rec.get("hypotheses") or []
        by_h = {}
        for t in (rec.get("tasks") or []):
            fi = t.get("for_hypothesis")
            if isinstance(fi, int) and 0 <= fi < len(ghyps):
                by_h.setdefault(fi, []).append(t)
        for i, h in enumerate(ghyps):
            entry = {
                "title": h.get("title", ""),
                "targets": h.get("targets", []),
                "class": h.get("class", ""),
                "severity_guess": h.get("severity_guess", ""),
                "rationale": h.get("rationale", ""),
            }
            for k in ("gbt_category", "rating_basis", "confidence", "owasp", "tags",
                      "object_type", "object_id_source", "owner_scope", "operation",
                      "boundary", "control", "unique_variable", "verified_if", "refuted_if"):
                if h.get(k) not in (None, ""):
                    entry[k] = h[k]
            tasks = []
            for t in by_h.get(i, []):
                tk = {k: t[k] for k in ("title", "playbook", "preconds", "actions", "skill")
                      if t.get(k) not in (None, "")}
                tasks.append(tk)
            entry["tasks"] = tasks
            hyps_out.append(entry)
    return {"hypotheses": hyps_out}


def main(argv):
    if not argv:
        print("usage: bin/plan-digest <stage_dir>", file=sys.stderr)
        return 2
    stage_dir = argv[0].rstrip("/")
    if not os.path.isdir(stage_dir):
        print(f"plan-digest: not a directory: {stage_dir}", file=sys.stderr)
        return 2
    text, s = build_digest(stage_dir)
    out = os.path.join(stage_dir, "digest.md")
    with open(out, "w", encoding="utf-8") as fh:
        fh.write(text)
    jout = os.path.join(stage_dir, "digest.json")
    with open(jout, "w", encoding="utf-8") as fh:
        json.dump(build_digest_json(stage_dir), fh, ensure_ascii=False, indent=2)
    print(f"digest: {s['groups']} groups | {s['hyps']} hyps | {s['tasks']} tasks | "
          f"{s['needs_observe']} needs_observe | {s['thin']} thin | "
          f"{s['plan_add_gaps']} plan-add-gaps | {s['errors']} errors "
          f"-> {out} (+ {jout} for `bin/kb plan add`)")
    return 0
